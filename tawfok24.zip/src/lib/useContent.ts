import { useState, useEffect } from 'react';
import { BLOG_POSTS, FAQS, getPostById } from './data';

// ============================================================
//  خطافات المحتوى (FAQs / Blog) — محلية بالكامل من src/lib/data.ts
//  لا قاعدة بيانات خارجية، لا fetch. كل البيانات داخل المشروع.
// ============================================================

export interface FaqRow { id: number; question: string; answer: string; sort_order: number; }
export interface BlogRow {
  id: string; title: string; excerpt: string; content: string;
  category: string; author: string; date: string; read_time: string; image: string;
}

// تحويل البيانات المحلية إلى الشكل الذي تتوقّعه الصفحات
function mapFaqs(): FaqRow[] {
  return FAQS.map((f, i) => ({ id: i + 1, question: f.q, answer: f.a, sort_order: i }));
}

function mapBlog(p: typeof BLOG_POSTS[number]): BlogRow {
  return {
    id: p.id, title: p.title, excerpt: p.excerpt, content: p.content,
    category: p.category, author: p.author, date: p.date, read_time: p.readTime, image: p.image,
  };
}

export function useFaqs() {
  const [faqs, setFaqs] = useState<FaqRow[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setFaqs(mapFaqs());
    setLoading(false);
  }, []);
  return { faqs, loading, error: null as string | null };
}

export function useBlogPosts() {
  const [posts, setPosts] = useState<BlogRow[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setPosts(BLOG_POSTS.map(mapBlog));
    setLoading(false);
  }, []);
  return { posts, loading, error: null as string | null };
}

export function useBlogPost(id?: string) {
  const [post, setPost] = useState<BlogRow | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!id) { setLoading(false); return; }
    const found = getPostById(id);
    setPost(found ? mapBlog(found) : null);
    setLoading(false);
  }, [id]);
  return { post, loading, error: null as string | null };
}
