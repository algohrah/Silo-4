import { useState, useEffect, useCallback } from 'react';
import {
  CURRENT_USER_ID, DEFAULT_USER_ID, getCurrentUserId, setCurrentUserId,
  getMembers, getRequests, getRequest, createRequest,
  runRequestAction, getEvents, getInquiry, buyInquiry, sendInquiry, simulateReply, initializeInquiry,
  isRequestUnseen, markRequestSeen,
  getJourneyNotifications, markNotificationRead, markAllNotificationsRead, deleteNotification,
  markRequestNotificationsRead, getUnreadNotificationsCount, getActionableRequestsCount,
  hasUserPaidDepositAnywhere,
  type LocalRequest, type LocalEvent, type InquiryStateLocal, type LocalNotification,
} from './localStore';

// ============================================================
//  خطاف رحلة طلب الاهتمام — يعمل محلياً بالكامل (localStorage)
//  الهوية النشطة ديناميكية: تتبع الحساب الذي تم الدخول إليه
//  من لوحة التحكم (active_member_id). كل شيء يُحفظ محلياً.
// ============================================================

export {
  CURRENT_USER_ID, DEFAULT_USER_ID, getCurrentUserId, setCurrentUserId, isRequestUnseen, markRequestSeen,
  getJourneyNotifications, markNotificationRead, markAllNotificationsRead, deleteNotification,
  markRequestNotificationsRead, getUnreadNotificationsCount, getActionableRequestsCount,
  hasUserPaidDepositAnywhere,
};

// أنواع متوافقة مع الواجهة
export type ApiRequest = LocalRequest;
export type RequestEvent = LocalEvent;
export type InquiryState = InquiryStateLocal;
export type JourneyNotification = LocalNotification;

export interface ApiMember {
  id: string;
  nickname: string;
  gender: 'male' | 'female';
  age: number;
  country: string;
  city: string;
  verified: boolean;
  premium: boolean;
}

export function useInterestRequests(userId: string = getCurrentUserId()) {
  const [requests, setRequests] = useState<ApiRequest[]>([]);
  const [members, setMembers] = useState<ApiMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<number | null>(null);

  const fetchAll = useCallback(async () => {
    try {
      setError(null);
      const [reqData, memData] = await Promise.all([
        getRequests(userId),
        getMembers(),
      ]);
      setRequests(reqData);
      setMembers(memData as ApiMember[]);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء التحميل');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const getMember = useCallback(
    (id: string) => members.find((m) => m.id === id),
    [members],
  );

  const runAction = useCallback(
    async (requestId: number, action: string, payload: Record<string, any> = {}) => {
      setActionLoading(requestId);
      try {
        const res = await runRequestAction(requestId, action, userId, payload);
        if (!res.ok) return { ok: false, error: res.error };
        await fetchAll();
        return { ok: true, data: res.data };
      } finally {
        setActionLoading(null);
      }
    },
    [userId, fetchAll],
  );

  const sendRequest = useCallback(
    async (receiverId: string, message: string) => {
      const res = await createRequest(userId, receiverId, message);
      if (res.ok) await fetchAll();
      return res;
    },
    [userId, fetchAll],
  );

  return {
    requests, members, loading, error, actionLoading,
    getMember, runAction, sendRequest, refresh: fetchAll, userId,
  };
}

// ===== دوال مساعدة مستقلة (تستخدمها صفحة الرحلة الكاملة) =====
export async function fetchRequest(requestId: number): Promise<ApiRequest | null> {
  return getRequest(requestId);
}

export async function fetchRequestEvents(requestId: number): Promise<RequestEvent[]> {
  return getEvents(requestId);
}

export async function fetchMembers(): Promise<ApiMember[]> {
  return (await getMembers()) as ApiMember[];
}

export async function fetchInquiry(requestId: number): Promise<InquiryState> {
  return getInquiry(requestId);
}

export async function initializeInquiryPackage(requestId: number, userId: string): Promise<{ ok: boolean; state?: InquiryState; error?: string }> {
  return initializeInquiry(requestId, userId);
}

export async function buyInquiryPackage(requestId: number, ownerId: string) {
  return buyInquiry(requestId, ownerId);
}

export async function sendInquiryMessage(requestId: number, senderId: string, text: string) {
  return sendInquiry(requestId, senderId, text);
}

export async function runActionStandalone(requestId: number, action: string, actorId: string, payload: Record<string, any> = {}) {
  return runRequestAction(requestId, action, actorId, payload);
}

// محاكاة ردّ الطرف الآخر داخل غرفة الاستفسار (للتجربة)
export async function simulateInquiryReply(requestId: number, replierId: string, text: string) {
  return simulateReply(requestId, replierId, text);
}

// إنشاء طلب اهتمام جديد (تستخدمه صفحة الملف الشخصي)
export async function createInterestRequest(senderId: string, receiverId: string, message: string) {
  return createRequest(senderId, receiverId, message);
}
