import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Search, Heart, Headphones, User } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { SUPPORT_TICKETS } from '../../lib/data';
import { getActionableRequestsCount, getCurrentUserId } from '../../lib/useInterestRequests';

const items = [
  { to: '/', label: 'الرئيسية', icon: Home, end: true },
  { to: '/search', label: 'البحث', icon: Search, end: false },
  { to: '/requests', label: 'طلباتي', icon: Heart, end: false },
  { to: '/admin-chat', label: 'الإدارة', icon: Headphones, end: false },
  { to: '/profile', label: 'حسابي', icon: User, end: false },
];

export default function MobileNav() {
  const { user } = useApp();
  const [pendingRequests, setPendingRequests] = useState(0);

  useEffect(() => {
    let mounted = true;
    const loadCount = async () => {
      if (!user.isLoggedIn) { if (mounted) setPendingRequests(0); return; }
      const count = await getActionableRequestsCount(user.memberId || getCurrentUserId());
      if (mounted) setPendingRequests(count);
    };
    loadCount();
    const onFocus = () => loadCount();
    window.addEventListener('focus', onFocus);
    const timer = window.setInterval(loadCount, 2500);
    return () => { mounted = false; window.removeEventListener('focus', onFocus); window.clearInterval(timer); };
  }, [user.isLoggedIn, user.memberId]);

  if (!user.isLoggedIn) return null;

  const openTickets = SUPPORT_TICKETS.filter(t => t.status === 'open' || t.status === 'in_progress').length;

  const badges: Record<string, number> = {
    '/requests': pendingRequests,
    '/admin-chat': openTickets,
  };

  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 glass border-t border-gold-500/20 pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-center justify-around h-16">
        {items.map((item) => {
          const badge = badges[item.to] || 0;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `relative flex flex-col items-center justify-center gap-1 px-3 py-1.5 rounded-xl transition-all no-tap-highlight ${
                  isActive ? 'text-gold-600' : 'text-navy-500'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className="relative">
                    <item.icon
                      className={`w-5 h-5 ${isActive ? 'fill-gold-300/30' : ''}`}
                      strokeWidth={isActive ? 2.5 : 2}
                    />
                    {badge > 0 && (
                      <span className="absolute -top-1.5 -left-2 bg-rose-deep text-white text-[9px] font-bold min-w-[16px] h-4 px-1 rounded-full flex items-center justify-center ring-2 ring-cream-50">
                        {badge > 9 ? '9+' : badge}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] font-cairo font-semibold">{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}
