import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppProvider } from './lib/AppContext';
import Layout from './components/layout/Layout';
import ProtectedRoute from './components/layout/ProtectedRoute';
import AdminLayout from './components/admin/AdminLayout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Search from './pages/Search';
import MemberProfile from './pages/MemberProfile';
import AdminChat from './pages/AdminChat';
import InterestRequests from './pages/InterestRequests';
import JourneyPage from './pages/JourneyPage';
import Notifications from './pages/Notifications';
import Profile from './pages/Profile';
import EditProfile from './pages/EditProfile';
import CompleteProfile from './pages/CompleteProfile';
import Plans from './pages/Plans';
import Checkout from './pages/Checkout';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import About from './pages/About';
import Contact from './pages/Contact';
import Support from './pages/Support';
import FAQ from './pages/FAQ';
import LegalPage from './pages/Legal';
import NotFound from './pages/NotFound';

// ===== لوحة الإدارة =====
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminMembers from './pages/admin/AdminMembers';
import AdminVerifications from './pages/admin/AdminVerifications';
import AdminModerators from './pages/admin/AdminModerators';
import AdminRequests from './pages/admin/AdminRequests';
import AdminMessages from './pages/admin/AdminMessages';
import AdminReports from './pages/admin/AdminReports';
import AdminAuditLog from './pages/admin/AdminAuditLog';
import AdminPlans from './pages/admin/AdminPlans';
import AdminTransactions from './pages/admin/AdminTransactions';
import AdminCoupons from './pages/admin/AdminCoupons';
import AdminExemptions from './pages/admin/AdminExemptions';
import AdminContent from './pages/admin/AdminContent';
import AdminNotifications from './pages/admin/AdminNotifications';
import AdminAnalytics from './pages/admin/AdminAnalytics';
import AdminFields from './pages/admin/AdminFields';
import AdminPlatformSettings from './pages/admin/AdminPlatformSettings';
import AdminPaymentSettings from './pages/admin/AdminPaymentSettings';
import AdminFeatureSettings from './pages/admin/AdminFeatureSettings';
import AdminSecuritySettings from './pages/admin/AdminSecuritySettings';
import AdminImportMembers from './pages/admin/AdminImportMembers';

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Routes>
          {/* ===== لوحة الإدارة ===== */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />

            {/* إدارة المستخدمين */}
            <Route path="members" element={<AdminMembers />} />
            <Route path="import-members" element={<AdminImportMembers />} />
            <Route path="verifications" element={<AdminVerifications />} />
            <Route path="moderators" element={<AdminModerators />} />

            {/* إدارة الرحلات */}
            <Route path="requests" element={<AdminRequests />} />

            {/* الدعم والسلامة */}
            <Route path="messages" element={<AdminMessages />} />
            <Route path="reports" element={<AdminReports />} />
            <Route path="audit-log" element={<AdminAuditLog />} />

            {/* الإيرادات والاشتراكات */}
            <Route path="plans" element={<AdminPlans />} />
            <Route path="transactions" element={<AdminTransactions />} />
            <Route path="coupons" element={<AdminCoupons />} />
            <Route path="exemptions" element={<AdminExemptions />} />

            {/* المحتوى والتسويق */}
            <Route path="content" element={<AdminContent />} />
            <Route path="notifications" element={<AdminNotifications />} />

            {/* التحليلات */}
            <Route path="analytics" element={<AdminAnalytics />} />

            {/* الإعدادات */}
            <Route path="fields" element={<AdminFields />} />
            <Route path="settings/platform" element={<AdminPlatformSettings />} />
            <Route path="settings/payments" element={<AdminPaymentSettings />} />
            <Route path="settings/features" element={<AdminFeatureSettings />} />
            <Route path="settings/security" element={<AdminSecuritySettings />} />

            {/* توافق رجعي للروابط القديمة */}
            <Route path="blog" element={<AdminContent />} />
            <Route path="faq" element={<AdminContent />} />
            <Route path="site" element={<AdminPlatformSettings />} />
            <Route path="settings" element={<AdminPlatformSettings />} />
            <Route path="moderation" element={<AdminRequests />} />
          </Route>

          {/* ===== الموقع العام ===== */}
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/search" element={<Search />} />
            <Route path="/member/:id" element={<MemberProfile />} />
            <Route path="/plans" element={<Plans />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:id" element={<BlogPost />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/support" element={<Support />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/privacy" element={<LegalPage type="privacy" />} />
            <Route path="/terms" element={<LegalPage type="terms" />} />

            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/profile/edit" element={<ProtectedRoute><EditProfile /></ProtectedRoute>} />
            <Route path="/profile/complete" element={<ProtectedRoute><CompleteProfile /></ProtectedRoute>} />
            <Route path="/profile/*" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/checkout/:planId" element={<ProtectedRoute><Checkout /></ProtectedRoute>} />
            <Route path="/admin-chat" element={<ProtectedRoute><AdminChat /></ProtectedRoute>} />
            <Route path="/requests" element={<ProtectedRoute><InterestRequests /></ProtectedRoute>} />
            <Route path="/journey/:requestId" element={<ProtectedRoute><JourneyPage /></ProtectedRoute>} />
            <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />

            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AppProvider>
  );
}
