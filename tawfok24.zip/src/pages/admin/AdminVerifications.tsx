import { useState, useMemo } from 'react';
import { BadgeCheck, Search, CheckCircle2, XCircle, Clock, FileCheck, Eye } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { useAdminMembers } from '../../lib/useAdminData';
import Modal from '../../components/ui/Modal';
import FilterDropdown from '../../components/admin/FilterDropdown';

export default function AdminVerifications() {
  const { adminMembers, showToast } = useApp();
  const { members, toggleVerified } = useAdminMembers();
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'verified' | 'rejected'>('all');
  const [selected, setSelected] = useState<any | null>(null);

  const combined = useMemo(() => {
    return adminMembers.map((adminM) => {
      const live = members.find((m) => m.id === adminM.id);
      return { ...adminM, verified: live?.verified ?? adminM.verified };
    });
  }, [adminMembers, members]);

  const filtered = useMemo(() => {
    return combined.filter((m) => {
      const matchSearch =
        !search || m.nickname.includes(search) || m.realName.includes(search) || m.email.includes(search);
      const status = m.verified ? 'verified' : Math.random() > 0.7 ? 'pending' : 'rejected';
      const matchStatus = filterStatus === 'all' || status === filterStatus;
      return matchSearch && matchStatus;
    });
  }, [combined, search, filterStatus]);

  const stats = {
    total: combined.length,
    verified: combined.filter((m) => m.verified).length,
    pending: combined.filter((m) => !m.verified).length,
  };

  const handleVerify = async (id: string, verified: boolean) => {
    await toggleVerified(id, verified);
    showToast(verified ? 'تم التوثيق بنجاح' : 'تم إلغاء التوثيق', 'success');
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          <BadgeCheck className="w-5 h-5 text-amber-500" /> طلبات التوثيق
        </h2>
        <p className="text-sm text-slate-500 font-tajawal">مراجعة طلبات توثيق الأعضاء والمستندات</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {[
          { label: 'إجمالي الطلبات', value: stats.total, icon: FileCheck, color: 'text-slate-700', bg: 'bg-slate-50' },
          { label: 'موثقون', value: stats.verified, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'بانتظار المراجعة', value: stats.pending, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className={`${s.bg} rounded-2xl p-3`}>
              <Icon className={`w-5 h-5 ${s.color} mb-1`} />
              <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالاسم أو البريد..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterDropdown
            label="الحالة:"
            value={filterStatus}
            onChange={(v) => setFilterStatus(v as typeof filterStatus)}
            options={[
              { value: 'all', label: 'كل الحالات' },
              { value: 'pending', label: 'بانتظار المراجعة' },
              { value: 'verified', label: 'موثقون' },
              { value: 'rejected', label: 'مرفوضون' },
            ]}
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {['العضو', 'البريد', 'الحالة', 'إجراء'].map((h) => (
                <th key={h} className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filtered.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                        m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                      }`}
                    >
                      {m.nickname.charAt(0)}
                    </div>
                    <div>
                      <p className="font-cairo font-bold text-slate-900 text-sm">{m.nickname}</p>
                      <p className="text-[11px] text-slate-400 font-tajawal">{m.realName}</p>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-xs text-slate-600 font-tajawal">{m.email}</td>
                <td className="px-5 py-3">
                  {m.verified ? (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-cairo font-bold bg-emerald-100 text-emerald-700">
                      <CheckCircle2 className="w-3 h-3" /> موثق
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-cairo font-bold bg-amber-100 text-amber-700">
                      <Clock className="w-3 h-3" /> معلق
                    </span>
                  )}
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setSelected(m)}
                      className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600"
                      title="عرض المستندات"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {!m.verified ? (
                      <button
                        onClick={() => handleVerify(m.id, true)}
                        className="w-8 h-8 rounded-lg bg-emerald-100 hover:bg-emerald-200 flex items-center justify-center text-emerald-600"
                        title="توثيق"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                    ) : (
                      <button
                        onClick={() => handleVerify(m.id, false)}
                        className="w-8 h-8 rounded-lg bg-rose-100 hover:bg-rose-200 flex items-center justify-center text-rose-600"
                        title="إلغاء التوثيق"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <p className="text-center py-10 text-slate-400 font-cairo text-sm">لا توجد طلبات مطابقة</p>
        )}
      </div>

      {/* Document preview modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title="مراجعة مستندات التوثيق">
        {selected && (
          <div className="space-y-4 text-right" dir="rtl">
            <div className="flex items-center gap-3">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold ${
                  selected.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                }`}
              >
                {selected.nickname.charAt(0)}
              </div>
              <div>
                <h3 className="font-cairo font-bold text-slate-900">{selected.nickname}</h3>
                <p className="text-xs text-slate-500 font-tajawal">{selected.realName}</p>
              </div>
            </div>
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
              <p className="text-sm text-slate-600 font-tajawal">
                في الإصدار الحقيقي ستتم مراجعة المستندات المرفقة (هوية، عقد ميلاد، إثبات الحالة الاجتماعية) من قبل المشرف.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  handleVerify(selected.id, true);
                  setSelected(null);
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-100 text-emerald-700 font-cairo font-bold text-sm"
              >
                <CheckCircle2 className="w-4 h-4" /> قبول
              </button>
              <button
                onClick={() => {
                  handleVerify(selected.id, false);
                  setSelected(null);
                }}
                className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-rose-100 text-rose-700 font-cairo font-bold text-sm"
              >
                <XCircle className="w-4 h-4" /> رفض
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
