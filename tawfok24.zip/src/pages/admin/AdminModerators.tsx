import { useState } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Plus, Edit2, Trash2, Mail, CheckCircle2, XCircle, Key, UserCheck } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { Button } from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import type { AdminUser, AdminPermissions } from '../../lib/types';

export default function AdminModerators() {
  const { adminUsers, addAdminUser, updateAdminUser, deleteAdminUser, simulateAdminLogin, currentAdminPermissions } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminUser | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'super_admin' | 'moderator'>('moderator');
  const [permissions, setPermissions] = useState<AdminPermissions>({
    manage_members: false,
    manage_requests: true,
    manage_support: false,
    manage_content: false,
    view_sensitive_data: false
  });

  const handleOpenModal = (admin?: AdminUser) => {
    if (admin) {
      setEditingAdmin(admin);
      setName(admin.name);
      setEmail(admin.email);
      setPassword(''); // Don't show existing password
      setRole(admin.role);
      setPermissions(admin.permissions);
    } else {
      setEditingAdmin(null);
      setName('');
      setEmail('');
      setPassword('');
      setRole('moderator');
      setPermissions({
        manage_members: false,
        manage_requests: true,
        manage_support: false,
        manage_content: false,
        view_sensitive_data: false
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!name || !email) return;

    if (editingAdmin) {
      updateAdminUser(editingAdmin.id, {
        name,
        email,
        role,
        permissions: role === 'super_admin' 
          ? { manage_members: true, manage_requests: true, manage_support: true, manage_content: true, view_sensitive_data: true } 
          : permissions
      });
    } else {
      addAdminUser({
        name,
        email,
        role,
        permissions: role === 'super_admin' 
          ? { manage_members: true, manage_requests: true, manage_support: true, manage_content: true, view_sensitive_data: true } 
          : permissions,
        status: 'active'
      });
    }
    setIsModalOpen(false);
  };

  const togglePermission = (key: keyof AdminPermissions) => {
    setPermissions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  if (!currentAdminPermissions.manage_members) {
    return (
      <div className="text-center py-16">
        <ShieldCheck className="w-16 h-16 text-rose-500 mx-auto mb-4" />
        <h2 className="text-2xl font-cairo font-bold text-navy-900">عذراً، لا تملك صلاحية الوصول</h2>
        <p className="text-navy-600 mt-2 font-tajawal">هذه الصفحة مخصصة للمدير العام فقط.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-cairo font-bold text-navy-900">المشرفين والصلاحيات</h1>
          <p className="text-sm text-navy-600 font-tajawal mt-1">إضافة مشرفين، تحديد أدوارهم، والتحكم بما يمكنهم رؤيته.</p>
        </div>
        <Button onClick={() => handleOpenModal()} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> إضافة مشرف
        </Button>
      </div>

      {/* Admins Table */}
      <div className="bg-white rounded-2xl shadow-soft border border-cream-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-cream-50 border-b border-cream-200">
              <tr>
                <th className="px-6 py-4 text-sm font-cairo font-bold text-navy-900">المشرف</th>
                <th className="px-6 py-4 text-sm font-cairo font-bold text-navy-900">الدور</th>
                <th className="px-6 py-4 text-sm font-cairo font-bold text-navy-900">الصلاحيات</th>
                <th className="px-6 py-4 text-sm font-cairo font-bold text-navy-900">الحالة</th>
                <th className="px-6 py-4 text-sm font-cairo font-bold text-navy-900 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-cream-200">
              {adminUsers.map((admin) => (
                <tr key={admin.id} className="hover:bg-cream-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-navy-gradient flex items-center justify-center text-white font-bold shadow-sm">
                        {admin.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-cairo font-bold text-navy-900 text-sm">{admin.name}</p>
                        <p className="font-tajawal text-xs text-navy-500">{admin.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold ${
                      admin.role === 'super_admin' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {admin.role === 'super_admin' ? <ShieldCheck className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                      {admin.role === 'super_admin' ? 'مدير عام' : 'مشرف'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1.5 max-w-[200px]">
                      {admin.role === 'super_admin' ? (
                        <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">كافة الصلاحيات</span>
                      ) : (
                        <>
                          {admin.permissions.manage_requests && <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded">طلبات الاهتمام</span>}
                          {admin.permissions.manage_support && <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded">الدعم الفني</span>}
                          {admin.permissions.view_sensitive_data ? (
                            <span className="text-[10px] bg-rose-50 text-rose-600 px-2 py-0.5 rounded">بيانات حساسة</span>
                          ) : (
                            <span className="text-[10px] bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded">حماية الخصوصية</span>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 text-xs font-bold ${
                      admin.status === 'active' ? 'text-emerald-600' : 'text-rose-600'
                    }`}>
                      {admin.status === 'active' ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                      {admin.status === 'active' ? 'نشط' : 'موقوف'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-2">
                      <button 
                        onClick={() => simulateAdminLogin(admin.role === 'super_admin' ? null : admin.id)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors tooltip-trigger relative"
                        title="تجربة الدخول بهذا الحساب"
                      >
                        <Key className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleOpenModal(admin)}
                        className="p-2 text-navy-600 hover:bg-cream-100 rounded-lg transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      {admin.id !== 'admin-1' && (
                        <button 
                          onClick={() => deleteAdminUser(admin.id)}
                          className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingAdmin ? "تعديل بيانات المشرف" : "إضافة مشرف جديد"}>
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-cairo font-bold text-navy-800 mb-1.5">الاسم</label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm" placeholder="اسم المشرف..." />
            </div>
            <div>
              <label className="block text-sm font-cairo font-bold text-navy-800 mb-1.5">البريد الإلكتروني</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-left" dir="ltr" placeholder="admin@domain.com" />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-cairo font-bold text-navy-800 mb-1.5">كلمة المرور {editingAdmin && '(اتركها فارغة لعدم التغيير)'}</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm" placeholder="••••••••" />
          </div>

          <div>
            <label className="block text-sm font-cairo font-bold text-navy-800 mb-2">الدور</label>
            <div className="flex gap-3">
              <label className={`flex-1 flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${role === 'super_admin' ? 'border-amber-500 bg-amber-50/50 ring-1 ring-amber-500/20' : 'border-cream-200 hover:bg-cream-50'}`}>
                <input type="radio" checked={role === 'super_admin'} onChange={() => setRole('super_admin')} className="hidden" />
                <ShieldCheck className={`w-5 h-5 ${role === 'super_admin' ? 'text-amber-600' : 'text-slate-400'}`} />
                <div>
                  <div className="font-cairo font-bold text-sm text-navy-900">مدير عام</div>
                  <div className="font-tajawal text-[10px] text-navy-500">كافة الصلاحيات</div>
                </div>
              </label>
              <label className={`flex-1 flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${role === 'moderator' ? 'border-blue-500 bg-blue-50/50 ring-1 ring-blue-500/20' : 'border-cream-200 hover:bg-cream-50'}`}>
                <input type="radio" checked={role === 'moderator'} onChange={() => setRole('moderator')} className="hidden" />
                <UserCheck className={`w-5 h-5 ${role === 'moderator' ? 'text-blue-600' : 'text-slate-400'}`} />
                <div>
                  <div className="font-cairo font-bold text-sm text-navy-900">مشرف مخصص</div>
                  <div className="font-tajawal text-[10px] text-navy-500">صلاحيات محددة</div>
                </div>
              </label>
            </div>
          </div>

          {role === 'moderator' && (
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <h4 className="font-cairo font-bold text-sm text-navy-900 border-b border-slate-200 pb-2">تحديد الصلاحيات المخصصة</h4>
              
              <label className="flex items-center justify-between cursor-pointer group">
                <div>
                  <div className="font-cairo font-bold text-sm text-navy-900 group-hover:text-gold-600 transition-colors">مراجعة طلبات الاهتمام</div>
                  <div className="font-tajawal text-[11px] text-navy-500">يمكنه رؤية طلبات الاهتمام والتنسيق بين الأعضاء</div>
                </div>
                <div className={`w-10 h-5.5 rounded-full transition-colors relative ${permissions.manage_requests ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                  <div className={`absolute top-0.5 bottom-0.5 w-4.5 rounded-full bg-white transition-transform ${permissions.manage_requests ? 'left-0.5 translate-x-0' : 'right-0.5 translate-x-0'}`} />
                  <input type="checkbox" className="hidden" checked={permissions.manage_requests} onChange={() => togglePermission('manage_requests')} />
                </div>
              </label>

              <label className="flex items-center justify-between cursor-pointer group">
                <div>
                  <div className="font-cairo font-bold text-sm text-navy-900 group-hover:text-gold-600 transition-colors">الدعم الفني والرسائل</div>
                  <div className="font-tajawal text-[11px] text-navy-500">يمكنه الرد على تذاكر الدعم الفني للأعضاء</div>
                </div>
                <div className={`w-10 h-5.5 rounded-full transition-colors relative ${permissions.manage_support ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                  <div className={`absolute top-0.5 bottom-0.5 w-4.5 rounded-full bg-white transition-transform ${permissions.manage_support ? 'left-0.5 translate-x-0' : 'right-0.5 translate-x-0'}`} />
                  <input type="checkbox" className="hidden" checked={permissions.manage_support} onChange={() => togglePermission('manage_support')} />
                </div>
              </label>

              <div className="h-px bg-slate-200 my-2" />

              <label className="flex items-center justify-between cursor-pointer group">
                <div>
                  <div className="font-cairo font-bold text-sm text-rose-600 group-hover:text-rose-700 transition-colors flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5" /> عرض البيانات الحساسة
                  </div>
                  <div className="font-tajawal text-[11px] text-navy-500">إذا تم تعطيلها، سيتم إخفاء (رقم الهاتف، البريد) عن هذا المشرف</div>
                </div>
                <div className={`w-10 h-5.5 rounded-full transition-colors relative ${permissions.view_sensitive_data ? 'bg-rose-500' : 'bg-slate-300'}`}>
                  <div className={`absolute top-0.5 bottom-0.5 w-4.5 rounded-full bg-white transition-transform ${permissions.view_sensitive_data ? 'left-0.5 translate-x-0' : 'right-0.5 translate-x-0'}`} />
                  <input type="checkbox" className="hidden" checked={permissions.view_sensitive_data} onChange={() => togglePermission('view_sensitive_data')} />
                </div>
              </label>
            </div>
          )}

          <div className="pt-4 flex gap-3">
            <Button fullWidth onClick={handleSave}>
              حفظ المشرف
            </Button>
            <Button fullWidth variant="outline" onClick={() => setIsModalOpen(false)}>
              إلغاء
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
