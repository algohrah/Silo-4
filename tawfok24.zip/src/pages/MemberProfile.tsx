import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MapPin, Briefcase, GraduationCap, Ruler, Heart, Bookmark,
  ShieldCheck, Calendar, Users, Globe, Send, ArrowRight,
  Home, Scale, Cigarette, Weight, Palette, Sparkles, AlertTriangle,
  ChevronDown, FileText, User, Copy, MessageCircle, Share2, Clock,
  Crown, Check,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import { getMemberById } from '../lib/data';
import { useApp } from '../lib/AppContext';
import { getAvatar, getGenderColors } from '../lib/types';
import { getCompatBadgeColor, getCompatLabel } from '../lib/compatibility';
import { getCurrentUserId, createInterestRequest } from '../lib/useInterestRequests';

type InfoTab = 'about' | 'details' | 'partner';

// قوالب رسائل طلب الاهتمام
const MESSAGE_TEMPLATES = [
  'السلام عليكم ورحمة الله، لفت انتباهي توافق ملفنا وأتمنى التوفيق لنا.',
  'مرحبًا، أرى توافقًا في القيم والأهداف وأرغب بالتعارف الجاد بإذن الله.',
  'السلام عليكم، ملفك أعجبني وأبحث عن شريك بصفات مشابهة، أتمنى التواصل.',
  'تحية طيبة، لاحظت توافقًا في المواصفات وأرغب في التقدم عبر الإدارة.',
];

export default function MemberProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const {
    likedMembers, toggleLike, user, showToast, checkLimit, incrementUsage,
    sendInterestRequest, calculateCompatDetailed, interestPurchaseSettings,
    buyExtraInterests, submitReport, members,
  } = useApp();
  // يقرأ من قائمة الأعضاء الحيّة في السياق (تعكس تعديلات الإدارة فوراً)
  // ثم يسقط إلى getMemberById المحفوظ في localStorage.
  const member = id ? (members.find((m) => m.id === id) || getMemberById(id)) : undefined;
  const [contactOpen, setContactOpen] = useState(false);
  const [contactMsg, setContactMsg] = useState('');
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [activeTab, setActiveTab] = useState<InfoTab>('about');

  if (!member) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <h2 className="font-cairo font-bold text-2xl text-navy-900">العضو غير موجود</h2>
        <Button onClick={() => navigate('/search')} className="mt-4">العودة للبحث</Button>
      </div>
    );
  }

  const liked = likedMembers.has(member.id);
  // هل العضو المعروض هو الحساب الحالي؟ (لمنع طلب الاهتمام للنفس)
  const isSelf = member.id === (user?.memberId || getCurrentUserId());
  const avatar = getAvatar(member.gender);
  const c = getGenderColors(member.gender);
  const isMale = member.gender === 'male';

  // حساب نسبة التوافق
  const compat = calculateCompatDetailed(member);
  const compatScore = compat.score;
  const badge = getCompatBadgeColor(compatScore, compat.isGenderMatch);
  const compatLabel = getCompatLabel(compatScore, compat.isGenderMatch);
  const whyMatches = compat.reasons;

  // الحصول على عدد الطلبات المتبقية
  const limitCheck = checkLimit('message');
  const remainingRequests = limitCheck.allowed ? limitCheck.max - limitCheck.current : 0;

  // معلومات سريعة كشارات (chips)
  const quickChips = [
    { icon: Calendar, label: `${member.age} سنة` },
    { icon: MapPin, label: member.city },
    { icon: GraduationCap, label: member.education },
    { icon: Scale, label: member.sect },
    { icon: Briefcase, label: member.workType },
  ];

  // تجميع المعلومات في أقسام منطقية
  const infoSections = [
    {
      title: 'المعلومات الأساسية',
      icon: User,
      items: [
        { icon: Calendar, label: 'العمر', value: member.age + ' سنة' },
        { icon: Heart, label: 'الحالة الاجتماعية', value: member.maritalLabel },
        { icon: MapPin, label: 'المدينة', value: member.city },
        { icon: MapPin, label: 'المنطقة', value: member.district },
        { icon: Globe, label: 'الدولة', value: member.country },
        { icon: Globe, label: 'الجنسية', value: member.nationality },
        { icon: Scale, label: 'المذهب', value: member.sect },
      ],
    },
    {
      title: 'الصفات الشخصية',
      icon: Ruler,
      items: [
        { icon: Ruler, label: 'الطول', value: member.height + ' سم' },
        { icon: Weight, label: 'الوزن', value: member.weight + ' كجم' },
        { icon: Palette, label: 'لون البشرة', value: member.skinColor },
        { icon: Heart, label: 'الحالة الصحية', value: member.health },
        { icon: Cigarette, label: 'التدخين', value: member.smoking },
        ...(member.hasChildren ? [{ icon: Users, label: 'الأبناء', value: member.childrenCount + ' أبناء' }] : []),
      ],
    },
    {
      title: 'التعليم والعمل',
      icon: GraduationCap,
      items: [
        { icon: GraduationCap, label: 'المؤهل', value: member.education },
        { icon: Briefcase, label: 'نوع العمل', value: member.workType },
        { icon: Home, label: 'نوع السكن', value: member.housing },
      ],
    },
  ];

  const tabsList: { id: InfoTab; label: string; icon: typeof User }[] = [
    { id: 'about', label: 'نبذة عني', icon: FileText },
    { id: 'details', label: 'التفاصيل', icon: Users },
    { id: 'partner', label: 'أبحث عن', icon: Sparkles },
  ];

  // نسخ الرابط
  const handleCopyLink = () => {
    const link = window.location.href;
    navigator.clipboard.writeText(link).then(() => {
      showToast('تم نسخ رابط الملف ✓', 'success');
    }).catch(() => {
      showToast('رابط الملف: ' + link, 'info');
    });
  };

  // مشاركة واتساب
  const handleShareWhatsApp = () => {
    const text = `مرحبًا، وجدت هذا الملف على منصة توافق وقد يكون مناسبًا: ${window.location.href}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="bg-cream-50 min-h-screen pb-8">
      {/* ===== Hero header — بدون صورة كبيرة ===== */}
      <div className="relative">
        <div className={'relative h-32 sm:h-40 overflow-hidden ' + c.bg}>
          <div className="absolute inset-0 pattern-arabesque opacity-20" />
          <div className="absolute -top-10 -right-10 w-60 h-60 bg-gold-500/20 rounded-full blur-3xl" />
          <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-rose-deep/10 rounded-full blur-3xl" />
          <button onClick={() => navigate(-1)} className="absolute top-4 right-4 w-10 h-10 rounded-full glass flex items-center justify-center text-navy-900 no-tap-highlight">
            <ArrowRight className="w-5 h-5" />
          </button>
          {/* زر الإبلاغ — أيقونة صغيرة في الأعلى */}
          <button
            onClick={() => {
              if (!user.isLoggedIn) navigate('/login');
              else setReportOpen(true);
            }}
            className="absolute top-4 left-4 w-9 h-9 rounded-full glass flex items-center justify-center text-red-500 hover:bg-red-50 transition-colors no-tap-highlight"
            aria-label="إبلاغ"
          >
            <AlertTriangle className="w-4 h-4" />
          </button>
        </div>

        <div className="max-w-5xl mx-auto px-4 sm:px-6 -mt-14 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl shadow-luxe border border-cream-200/60 p-5 sm:p-7"
          >
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              {/* Avatar */}
              <div className="relative flex-shrink-0">
                <div className={'w-20 h-20 sm:w-24 sm:h-24 rounded-3xl ' + c.bg + ' flex items-center justify-center ring-4 ring-white shadow-lg overflow-hidden'}>
                  <img src={avatar} alt="" className="w-full h-full object-contain p-2" />
                </div>
                {member.online && <span className="absolute bottom-1 left-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white" />}
              </div>

              {/* Name + badges — صف واحد مرتّب */}
              <div className="flex-1 text-center sm:text-right">
                <h1 className="font-cairo font-extrabold text-xl sm:text-2xl text-navy-900 mb-1.5">{member.nickname}</h1>
                {/* صف الشارات المرتّب */}
                <div className="flex items-center gap-1.5 justify-center sm:justify-start flex-wrap mb-1.5">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md ${c.badgeBg} text-white text-[11px] font-cairo font-bold`}>
                    {isMale ? 'رجل' : 'امرأة'}
                  </span>
                  {member.verified && (
                    <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-md text-[11px] font-cairo font-bold" title="موثّق">
                      <ShieldCheck className="w-3.5 h-3.5" /> موثّق
                    </span>
                  )}
                  {member.premium && (
                    <span className="inline-flex items-center gap-1 bg-gold-50 text-gold-600 px-2 py-0.5 rounded-md text-[11px] font-cairo font-bold" title="عضوية ذهبية">
                      <Crown className="w-3.5 h-3.5" /> ذهبية
                    </span>
                  )}
                  {member.hasSeriousnessBadge && (
                    <span className="inline-flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-extrabold text-[11px] px-2 py-0.5 rounded-md font-cairo" title="وسام الجدية المعتمد">
                      🏅 جاد
                    </span>
                  )}
                </div>
                <p className="text-navy-600 font-tajawal text-sm">{member.age} سنة · {member.city} · {member.workType}</p>
                <p className="text-xs text-navy-400 font-tajawal mt-0.5">{member.lastActive}</p>
              </div>

              {/* Compatibility — يظهر على جميع الشاشات */}
              <div className="w-full sm:w-auto bg-white rounded-2xl shadow-sm p-3 border border-cream-200 sm:min-w-[200px]">
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-xs font-cairo font-bold text-navy-500">نسبة التوافق</span>
                  {compat.isGenderMatch ? (
                    <span className={`font-cairo font-extrabold text-2xl ${badge.text}`}>{compatScore}%</span>
                  ) : (
                    <span className="font-cairo font-bold text-sm text-navy-400">غير متطابق</span>
                  )}
                </div>
                {compat.isGenderMatch && (
                  <>
                    <div className="h-2 bg-cream-100 rounded-full overflow-hidden">
                      <div className="h-full transition-all" style={{ width: `${compatScore}%`, backgroundColor: badge.stroke }} />
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <span className={`text-[10px] font-cairo font-bold ${badge.text}`}>{compatLabel}</span>
                      {compat.isEstimated && <span className="text-[10px] text-navy-400 font-tajawal">تقديري</span>}
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* ===== معلومات سريعة كشارات (chips) ===== */}
            <div className="flex flex-wrap gap-2 mt-4">
              {quickChips.map((chip, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-cream-100 text-navy-700 text-xs font-cairo font-semibold border border-cream-200"
                >
                  <chip.icon className={`w-3.5 h-3.5 ${c.text}`} />
                  {chip.label}
                </span>
              ))}
            </div>

            {/* ===== Action buttons — زر الاهتمام موسّع + حفظ أيقونة + مشاركة ===== */}
            {isSelf ? (
              <div className="mt-5 bg-blue-50 border border-blue-200 rounded-2xl p-4 text-center">
                <User className="w-6 h-6 text-blue-500 mx-auto mb-1.5" />
                <p className="font-cairo font-bold text-navy-700 text-sm">هذا حسابك الحالي</p>
                <p className="text-xs font-cairo text-navy-500 mt-0.5">لا يمكنك إرسال طلب اهتمام لنفسك</p>
              </div>
            ) : (
            <div className="flex items-center gap-2 mt-5">
              {/* زر طلب الاهتمام — موسّع */}
              <button
                onClick={() => (user.isLoggedIn ? setContactOpen(true) : navigate('/login'))}
                className="flex-[3] flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl bg-gold-gradient text-navy-900 font-cairo font-bold shadow-soft hover:shadow-gold transition-all no-tap-highlight"
              >
                <Send className="w-5 h-5 -scale-x-100" /> أرسل طلب اهتمام
              </button>
              {/* زر الحفظ — أيقونة */}
              <button
                onClick={() => toggleLike(member.id)}
                aria-label="حفظ"
                className={'flex items-center justify-center w-12 h-12 rounded-2xl font-cairo font-bold transition-all duration-300 no-tap-highlight flex-shrink-0 ' + (liked ? 'bg-gold-500 text-white shadow-soft' : 'bg-cream-100 text-navy-700 hover:bg-cream-200')}
              >
                <Bookmark className={'w-5 h-5 ' + (liked ? 'fill-white' : '')} />
              </button>
              {/* زر واتساب */}
              <button
                onClick={handleShareWhatsApp}
                aria-label="مشاركة واتساب"
                className="flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-all no-tap-highlight flex-shrink-0"
              >
                <MessageCircle className="w-5 h-5" />
              </button>
              {/* زر نسخ الرابط */}
              <button
                onClick={handleCopyLink}
                aria-label="نسخ الرابط"
                className="flex items-center justify-center w-12 h-12 rounded-2xl bg-cream-100 text-navy-600 hover:bg-cream-200 transition-all no-tap-highlight flex-shrink-0"
              >
                <Copy className="w-5 h-5" />
              </button>
            </div>
            )}

            {/* Mediation note */}
            <div className="mt-4 flex items-start gap-2 bg-gold-300/10 rounded-2xl p-3 border border-gold-500/20">
              <ShieldCheck className="w-5 h-5 text-gold-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-navy-600 font-tajawal leading-relaxed">
                التواصل يتم حصريًا عبر فريق الإدارة لضمان الخصوصية والجدية. عند إرسال طلب اهتمام، ستتولى الإدارة التواصل مع الطرف الآخر وتبليغك بالرد.
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      {/* ===== Main content ===== */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 mt-5 grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2">
          {/* Tabs */}
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1 mb-4">
            {tabsList.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-cairo font-semibold text-sm whitespace-nowrap transition-all no-tap-highlight ${
                  activeTab === tab.id
                    ? 'bg-navy-900 text-white shadow-soft'
                    : 'bg-white text-navy-600 border border-cream-200 hover:bg-cream-100'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {/* ===== Tab: About ===== */}
              {activeTab === 'about' && (
                <div className="space-y-4">
                  <section className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5 sm:p-6">
                    <h2 className="font-cairo font-bold text-lg text-navy-900 mb-3 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-gold-600" /> نبذة عني
                    </h2>
                    <p className="text-navy-700 font-tajawal leading-relaxed">{member.bio}</p>
                  </section>

                  {/* أسباب التوافق */}
                  {compat.isGenderMatch && whyMatches.length > 0 && (
                    <section className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5 sm:p-6">
                      <h2 className="font-cairo font-bold text-lg text-navy-900 mb-3 flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-emerald-600" /> لماذا يناسبك؟
                      </h2>
                      <div className="flex flex-wrap gap-2">
                        {whyMatches.map((reason, i) => (
                          <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-cairo font-semibold border border-emerald-200">
                            <ShieldCheck className="w-3.5 h-3.5" /> {reason}
                          </span>
                        ))}
                      </div>
                    </section>
                  )}
                </div>
              )}

              {/* ===== Tab: Details — مصنّفة لأقسام ===== */}
              {activeTab === 'details' && (
                <div className="space-y-4">
                  {infoSections.map((section) => (
                    <section key={section.title} className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5 sm:p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-xl bg-gold-300/15 flex items-center justify-center">
                          <section.icon className="w-5 h-5 text-gold-600" />
                        </div>
                        <h2 className="font-cairo font-bold text-lg text-navy-900">{section.title}</h2>
                      </div>
                      <div className="grid sm:grid-cols-2 gap-3">
                        {section.items.map((item, i) => (
                          <div key={i} className="flex items-center gap-3 bg-cream-50 rounded-xl px-3 py-2.5 border border-cream-200/60">
                            <div className={'w-9 h-9 rounded-lg ' + c.bg + ' flex items-center justify-center flex-shrink-0'}>
                              <item.icon className={'w-4 h-4 ' + c.text} />
                            </div>
                            <div className="min-w-0">
                              <p className="text-[11px] text-navy-400 font-tajawal">{item.label}</p>
                              <p className="font-cairo font-semibold text-navy-900 text-sm truncate">{item.value}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </section>
                  ))}
                </div>
              )}

              {/* ===== Tab: Partner ===== */}
              {activeTab === 'partner' && (
                <section className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5 sm:p-6">
                  <h2 className="font-cairo font-bold text-lg text-navy-900 mb-3 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-rose-deep" /> مواصفات الشريك المطلوب
                  </h2>
                  <p className="text-navy-700 font-tajawal leading-relaxed">{member.aboutPartner}</p>
                </section>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* ===== Sidebar ===== */}
        <div className="space-y-4">
          {/* بطاقة حالة العضو */}
          <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5">
            <h3 className="font-cairo font-bold text-navy-900 text-sm mb-4 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-gold-600" /> حالة العضو
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-navy-500 font-tajawal flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" /> التوثيق
                </span>
                <span className={`text-xs font-cairo font-bold ${member.verified ? 'text-emerald-600' : 'text-navy-400'}`}>
                  {member.verified ? 'موثّق ✓' : 'غير موثّق'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-navy-500 font-tajawal flex items-center gap-1.5">
                  <Crown className="w-4 h-4 text-gold-500" /> العضوية
                </span>
                <span className={`text-xs font-cairo font-bold ${member.premium ? 'text-gold-600' : 'text-navy-400'}`}>
                  {member.premium ? 'ذهبية' : 'مجانية'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-navy-500 font-tajawal flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-navy-400" /> النشاط
                </span>
                <span className={`text-xs font-cairo font-bold ${member.online ? 'text-emerald-600' : 'text-navy-400'}`}>
                  {member.online ? 'متصل الآن' : member.lastActive}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-navy-500 font-tajawal flex items-center gap-1.5">
                  <User className="w-4 h-4 text-navy-400" /> الجنس
                </span>
                <span className="text-xs font-cairo font-bold text-navy-700">
                  {isMale ? 'رجل' : 'امرأة'}
                </span>
              </div>
            </div>
          </div>

          {/* تفاصيل التوافق التفصيلية */}
          {compat.isGenderMatch && compat.details.length > 0 && (
            <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5">
              <h3 className="font-cairo font-bold text-navy-900 text-sm mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-gold-600" /> تفاصيل التوافق
              </h3>
              <div className="space-y-3">
                {compat.details.map((d, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-cairo font-semibold text-navy-700">{d.label}</span>
                      <span className={`text-xs font-cairo font-bold ${d.pct >= 80 ? 'text-emerald-600' : d.pct >= 50 ? 'text-gold-600' : 'text-rose-deep'}`}>
                        {d.pct}%
                      </span>
                    </div>
                    <div className="h-1.5 bg-cream-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${d.pct}%`,
                          backgroundColor: d.pct >= 80 ? '#059669' : d.pct >= 50 ? '#c9a961' : '#c97b7f',
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* خصوصية التواصل */}
          <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5 space-y-3">
            <h3 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-gold-600" /> خصوصية التواصل
            </h3>
            <p className="text-xs text-navy-600 font-tajawal leading-relaxed">
              لا تظهر معلومات التواصل مباشرة للأعضاء. عبر <strong>«طلب اهتمام»</strong> تتولى الإدارة التواصل مع الطرف الآخر بسرية تامة.
            </p>
            <div className="bg-gold-300/10 rounded-xl p-3 border border-gold-500/20">
              <p className="text-xs text-navy-600 font-tajawal leading-relaxed">
                لا تشارك معلوماتك المالية أو الشخصية الحساسة. ابقَ داخل المنصة لضمان حمايتك.
              </p>
            </div>
          </div>

          {/* أزرار المشاركة الأنيقة */}
          <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-4">
            <h3 className="font-cairo font-bold text-navy-900 text-sm mb-3 flex items-center gap-2">
              <Share2 className="w-4 h-4 text-gold-600" /> مشاركة الملف
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleShareWhatsApp}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-50 text-emerald-600 font-cairo font-semibold text-xs hover:bg-emerald-100 transition-colors no-tap-highlight"
              >
                <MessageCircle className="w-4 h-4" /> واتساب
              </button>
              <button
                onClick={handleCopyLink}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-cream-100 text-navy-600 font-cairo font-semibold text-xs hover:bg-cream-200 transition-colors no-tap-highlight"
              >
                <Copy className="w-4 h-4" /> نسخ الرابط
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ===== Contact request modal — محسّن ===== */}
      <Modal open={contactOpen} onClose={() => setContactOpen(false)} title="إرسال طلب اهتمام">
        <div className="space-y-4">
          <div className="flex items-center gap-2 p-3 bg-gold-300/10 rounded-2xl border border-gold-500/20">
            <ShieldCheck className="w-5 h-5 text-gold-600 flex-shrink-0" />
            <p className="text-xs text-navy-600 font-tajawal">طلبك سيصل لفريق الإدارة الذي سيتواصل مع الطرف الآخر بسرية تامة</p>
          </div>

          {/* معاينة سريعة لمعلومات العضو */}
          <div className="flex items-center gap-3 p-3 bg-cream-100 rounded-2xl">
            <div className={'w-12 h-12 rounded-xl ' + c.bg + ' flex items-center justify-center bg-white'}>
              <img src={avatar} alt="" className="w-full h-full object-contain p-1" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-cairo font-bold text-navy-900">{member.nickname}</p>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <span className="text-[11px] text-navy-500 font-tajawal flex items-center gap-1">
                  <Calendar className="w-3 h-3" /> {member.age} سنة
                </span>
                <span className="text-[11px] text-navy-500 font-tajawal flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {member.city}
                </span>
                <span className="text-[11px] text-navy-500 font-tajawal flex items-center gap-1">
                  <GraduationCap className="w-3 h-3" /> {member.education}
                </span>
              </div>
            </div>
          </div>

          {/* قوالب رسائل جاهزة */}
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">قوالب جاهزة (اضغط للاستخدام)</label>
            <div className="space-y-2">
              {MESSAGE_TEMPLATES.map((tpl, i) => (
                <button
                  key={i}
                  onClick={() => setContactMsg(tpl)}
                  className={`w-full text-right p-3 rounded-xl border-2 text-xs font-tajawal leading-relaxed transition-all no-tap-highlight ${
                    contactMsg === tpl
                      ? 'border-gold-500 bg-gold-300/10 text-navy-900'
                      : 'border-cream-200 bg-cream-50 text-navy-600 hover:border-gold-300'
                  }`}
                >
                  {tpl}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">رسالتك (اختياري)</label>
            <textarea
              value={contactMsg}
              onChange={(e) => setContactMsg(e.target.value)}
              rows={4}
              placeholder="اكتب رسالة لطيفة ومحترمة..."
              className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 resize-none"
            />
          </div>

          {/* عدد الطلبات المتبقية */}
          {limitCheck.allowed && (
            <div className="flex items-center justify-between p-3 bg-cream-100 rounded-xl">
              <span className="text-xs text-navy-600 font-tajawal flex items-center gap-1.5">
                <Send className="w-4 h-4 text-gold-600" /> الطلبات المتبقية في باقتك
              </span>
              <span className="text-xs font-cairo font-bold text-navy-900">
                {remainingRequests} من {limitCheck.max}
              </span>
            </div>
          )}

          {(() => {
            if (!limitCheck.allowed) {
              return (
                <div className="bg-amber-50/50 rounded-2xl p-4 border border-amber-200 space-y-4 text-center mt-2">
                  <p className="text-xs font-tajawal text-slate-700 font-medium">
                    لقد استنفدت حد باقتك لطلبات الاهتمام المسموحة ({limitCheck.max}/{limitCheck.max}). لا تقلق! يمكنك مواصلة التعارف فوراً.
                  </p>
                  <div className="bg-white rounded-xl p-3 shadow-sm border border-amber-100">
                    <span className="block text-xs font-cairo text-slate-400">شراء اهتمامات إضافية للمواصلة:</span>
                    <span className="block font-cairo font-extrabold text-navy-900 text-base sm:text-lg mt-1">
                      {interestPurchaseSettings.type === 'count'
                        ? `شحن +${interestPurchaseSettings.count} اهتمام إضافي`
                        : `تفعيل اهتمامات بلا حدود لـ ${interestPurchaseSettings.durationDays} أيام`}
                    </span>
                    <span className="block font-cairo font-extrabold text-gold-600 text-sm mt-1">
                      بسعر {interestPurchaseSettings.price} ر.س فقط
                    </span>
                  </div>
                  <button
                    onClick={() => buyExtraInterests()}
                    className="w-full py-3 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold hover:opacity-95 shadow-gold transition-all block text-center no-tap-highlight"
                  >
                    شراء وتفعيل العرض الآن
                  </button>
                </div>
              );
            }
            return (
              <Button
                fullWidth
                size="lg"
                onClick={async () => {
                  incrementUsage('message');
                  setContactOpen(false);
                  const msg = contactMsg;
                  setContactMsg('');
                  const res = await createInterestRequest(getCurrentUserId(), member.id, msg);
                  if (res.ok) {
                    showToast('تم إرسال طلب الاهتمام! تابع رحلتك في صفحة الطلبات 💌', 'success');
                    // الانتقال لصفحة الطلبات لمتابعة الرحلة
                    setTimeout(() => navigate('/requests'), 1200);
                  } else {
                    showToast(res.error || 'تعذّر إرسال الطلب', 'error');
                  }
                }}
              >
                <Send className="w-5 h-5 -scale-x-100" /> إرسال الطلب
              </Button>
            );
          })()}
        </div>
      </Modal>

      {/* ===== Report modal ===== */}
      <Modal open={reportOpen} onClose={() => setReportOpen(false)} title="إرسال بلاغ عن العضو">
        <div className="space-y-4 font-tajawal text-right">
          <div className="flex items-center gap-2.5 p-3 bg-red-50 rounded-2xl border border-red-100">
            <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
            <p className="text-xs text-red-800 font-medium font-cairo">
              نأخذ البلاغات على محمل الجد لضمان أمان الأعضاء وجديتهم. سيتم فحص بلاغك مباشرة.
            </p>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl">
            <span className="block text-xs text-slate-500 font-cairo">العضو المشكو في حقه:</span>
            <span className="block font-cairo font-bold text-slate-900 mt-0.5">{member.nickname}</span>
          </div>
          <div>
            <label className="block text-xs font-cairo font-bold text-slate-700 mb-2">تفاصيل البلاغ:</label>
            <textarea
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              rows={4}
              placeholder="اكتب المحتوى بالتفصيل، مثال: الحساب غير جاد، أو استخدام ألفاظ غير لائقة..."
              className="w-full p-3 rounded-xl bg-white border border-slate-200 focus:border-red-400 focus:outline-none font-sans text-sm resize-none text-right"
            />
          </div>
          <Button
            fullWidth
            onClick={() => {
              if (!reportReason.trim()) {
                showToast('الرجاء كتابة محتوى البلاغ', 'error');
                return;
              }
              submitReport(member.id, member.nickname, reportReason);
              setReportOpen(false);
              setReportReason('');
              showToast('تم إرسال البلاغ للإدارة ✓', 'success');
            }}
            className="bg-red-600 hover:bg-red-700 text-white font-cairo font-bold py-3 rounded-xl"
          >
            إرسال البلاغ
          </Button>
        </div>
      </Modal>
    </div>
  );
}
