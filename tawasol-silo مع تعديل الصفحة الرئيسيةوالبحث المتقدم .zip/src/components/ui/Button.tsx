import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';

type Variant = 'gold' | 'navy' | 'outline' | 'ghost' | 'rose';
type Size = 'sm' | 'md' | 'lg';

interface BaseProps {
  children: ReactNode;
  variant?: Variant;
  size?: Size;
  className?: string;
  fullWidth?: boolean;
  type?: 'button' | 'submit' | 'reset';
  onClick?: () => void;
  disabled?: boolean;
}

const variants: Record<Variant, string> = {
  gold: 'bg-gold-gradient text-navy-900 hover:shadow-gold hover:-translate-y-0.5 shadow-soft',
  navy: 'bg-navy-900 text-white hover:bg-navy-800 hover:-translate-y-0.5 shadow-soft',
  outline: 'border-2 border-gold-500 text-navy-900 hover:bg-gold-50 hover:bg-cream-100',
  ghost: 'text-navy-700 hover:bg-cream-100',
  rose: 'bg-rose-deep text-white hover:brightness-110 hover:-translate-y-0.5 shadow-soft',
};

const sizes: Record<Size, string> = {
  sm: 'px-4 py-2 text-sm rounded-xl',
  md: 'px-6 py-3 text-sm rounded-2xl',
  lg: 'px-8 py-4 text-base rounded-2xl',
};

export function Button({
  children, variant = 'gold', size = 'md', className = '', fullWidth, type = 'button', onClick, disabled,
}: BaseProps) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 font-cairo font-bold no-tap-highlight transition-all duration-300 ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${disabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''} ${className}`}
    >
      {children}
    </button>
  );
}

export function ButtonLink({
  children, to, variant = 'gold', size = 'md', className = '', fullWidth, onClick,
}: BaseProps & { to: string; onClick?: () => void }) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 font-cairo font-bold no-tap-highlight transition-all duration-300 ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
    >
      {children}
    </Link>
  );
}
