import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  MapPin, ShieldCheck, Crown, Heart, Share2, Eye,
  Briefcase, Calendar, Users,
} from 'lucide-react';
import type { Member } from '../lib/members';
import { getAvatar, getGenderColors } from '../lib/types';
import { useApp } from '../lib/AppContext';

export default function MemberCard({ member }: { member: Member }) {
  const { likedMembers, toggleLike } = useApp();
  const liked = likedMembers.has(member.id);
  const avatar = getAvatar(member.gender);
  const c = getGenderColors(member.gender);
  const isMale = member.gender === 'male';

  // معلومات سريعة منظمة في شبكة
  const infoItems = [
    { icon: Calendar, label: 'العمر', value: `${member.age} سنة` },
    { icon: Users, label: 'الحالة', value: member.maritalLabel },
    { icon: Briefcase, label: 'الوظيفة', value: member.workType },
  ];

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 300, damping: 22 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-soft hover:shadow-luxe transition-shadow duration-500 border border-cream-200/70 flex flex-col h-full"
    >
      <Link to={`/member/${member.id}`} className="block flex flex-col flex-1 no-tap-highlight">
        {/* ===== الرأس: الصورة الافتراضية + الاسم + الشارات ===== */}
        <div className={`relative ${c.bg} p-4`}>
          <div className="flex items-center gap-3">
            {/* الصورة الافتراضية */}
            <div className="relative flex-shrink-0">
              <div className={`w-16 h-16 rounded-2xl bg-white flex items-center justify-center overflow-hidden ring-2 ${c.ring} ring-opacity-30 shadow-sm`}>
                <img src={avatar} alt="" className="w-full h-full object-contain p-1.5" />
              </div>
              {member.online && (
                <span className="absolute -bottom-0.5 -left-0.5 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white" />
              )}
            </div>

            {/* الاسم + الشارات */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="font-cairo font-bold text-navy-900 text-base leading-tight truncate">
                  {member.nickname}
                </h3>
                {member.verified && (
                  <ShieldCheck className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                )}
                {member.premium && (
                  <Crown className="w-4 h-4 text-gold-500 flex-shrink-0" />
                )}
              </div>
              <div className="flex items-center gap-1.5 mt-1">
                <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full ${c.badgeBg}`}>
                  <GenderIcon isMale={isMale} white />
                </span>
                <span className={`text-xs font-cairo font-bold ${c.textStrong}`}>
                  {isMale ? 'رجل' : 'امرأة'}
                </span>
                <span className="text-navy-300">·</span>
                <span className="text-xs text-navy-500 font-tajawal truncate">{member.lastActive}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ===== جسم البطاقة ===== */}
        <div className="p-4 flex flex-col flex-1">
          {/* الموقع: المدينة + الدولة */}
          <div className="flex items-center gap-2 bg-cream-50 rounded-lg px-3 py-2.5 border border-cream-200/60 mb-3">
            <MapPin className={`w-4 h-4 ${c.text} flex-shrink-0`} />
            <span className="font-tajawal text-sm text-navy-700">
              {member.city}، {member.country}
            </span>
          </div>

          {/* شبكة المعلومات: العمر + الحالة الاجتماعية + الوظيفة */}
          <div className="grid grid-cols-3 gap-2 mb-3">
            {infoItems.map((item, idx) => (
              <div key={idx} className="bg-cream-50 rounded-lg p-2 text-center border border-cream-200/60">
                <item.icon className={`w-3.5 h-3.5 ${c.text} mx-auto mb-1`} />
                <div className="text-[11px] font-cairo font-bold text-navy-900 leading-tight">{item.value}</div>
                <div className="text-[9px] text-navy-400 font-tajawal">{item.label}</div>
              </div>
            ))}
          </div>

          {/* قسم "أبحث عن" — مواصفات الشريك */}
          <div className={`rounded-xl ${c.bg} p-3 mb-3`}>
            <div className="flex items-center gap-1.5 mb-1">
              <span className={`text-[11px] font-cairo font-bold ${c.textStrong}`}>أبحث عن</span>
            </div>
            <p className="text-[12px] text-navy-600 font-tajawal leading-snug line-clamp-2">
              {member.aboutPartner}
            </p>
          </div>

          {/* الأزرار — أسفل البطاقة */}
          <div className="mt-auto flex items-center gap-2 pt-1">
            {/* زر العرض — يتلوّن حسب الجنس (أزرق للرجال، أحمر للإناث) */}
            <span className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl ${c.bgStrong} text-white font-cairo font-bold text-[13px] transition-all`}>
              <Eye className="w-4 h-4" />
              عرض
            </span>

            {/* زر المفضلة — قلب فقط بدون نص */}
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggleLike(member.id);
              }}
              aria-label="إضافة للمفضلة"
              className={`flex items-center justify-center w-10 h-10 rounded-xl transition-all duration-300 no-tap-highlight flex-shrink-0 ${
                liked ? 'bg-rose-deep text-white shadow-soft' : 'bg-cream-100 text-navy-500 hover:bg-cream-200'
              }`}
            >
              <Heart className={`w-4.5 h-4.5 ${liked ? 'fill-white' : ''}`} />
            </button>

            {/* زر مشاركة الملف */}
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
              }}
              aria-label="مشاركة الملف"
              className="flex items-center justify-center w-10 h-10 rounded-xl bg-cream-100 text-navy-500 hover:bg-cream-200 transition-all duration-300 no-tap-highlight flex-shrink-0"
            >
              <Share2 className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

/* أيقونة جنس مخصصة */
function GenderIcon({ isMale, white }: { isMale: boolean; white?: boolean }) {
  const color = white ? 'white' : 'currentColor';
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
      {isMale ? (
        <path d="M14 6h6v6M20 6l-7 7M10 6H4v6M4 6l7 7M14 18h6M10 18H4" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      ) : (
        <circle cx="12" cy="12" r="6" stroke={color} strokeWidth="2.2" />
      )}
    </svg>
  );
}
