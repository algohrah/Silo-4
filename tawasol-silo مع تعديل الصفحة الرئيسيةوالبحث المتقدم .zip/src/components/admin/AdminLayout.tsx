import { useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Users, Heart, Bell, FileText, HelpCircle,
  Settings, LogOut, Menu, X, ShieldCheck, ChevronLeft, Globe, CreditCard,
} from 'lucide-react';

const navSections = [
  {
    title: 'الرئيسية',
    items: [
      { to: '/admin', label: 'لوحة المعلومات', icon: LayoutDashboard, end: true },
    ],
  },
  {
    title: 'الإدارة',
    items: [
      { to: '/admin/members', label: 'إدارة الأعضاء', icon: Users, end: false },
      { to: '/admin/requests', label: 'طلبات الاهتمام', icon: Heart, end: false },
      { to: '/admin/notifications', label: 'إرسال إشعارات', icon: Bell, end: false },
    ],
  },
  {
    title: 'المحتوى',
    items: [
      { to: '/admin/blog', label: 'المدونة', icon: FileText, end: false },
      { to: '/admin/faq', label: 'الأسئلة الشائعة', icon: HelpCircle, end: false },
      { to: '/admin/plans', label: 'الباقات والأسعار', icon: CreditCard, end: false },
    ],
  },
  {
    title: 'الإعدادات',
    items: [
      { to: '/admin/fields', label: 'حقول التسجيل', icon: FileText, end: false },
      { to: '/admin/site', label: 'إعدادات الموقع', icon: Globe, end: false },
      { to: '/admin/settings', label: 'الإعدادات العامة', icon: Settings, end: false },
    ],
  },
];

export default function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const currentTitle = (() => {
    for (const section of navSections) {
      for (const item of section.items) {
        if (item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)) {
          return item.label;
        }
      }
    }
    return 'لوحة التحكم';
  })();

  return (
    <div className="min-h-screen bg-slate-100" dir="rtl">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex fixed top-0 right-0 bottom-0 w-64 bg-slate-900 flex-col z-50">
        <AdminSidebarContent />
      </aside>

      {/* Sidebar - Mobile */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-[60]">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute top-0 right-0 bottom-0 w-72 bg-slate-900 flex flex-col animate-float-up">
            <AdminSidebarContent onNavigate={() => setSidebarOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="lg:mr-64">
        {/* Top bar */}
        <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
          <div className="flex items-center justify-between px-4 sm:px-6 h-16">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-slate-100">
                <Menu className="w-5 h-5 text-slate-700" />
              </button>
              <h1 className="font-cairo font-bold text-lg text-slate-900">{currentTitle}</h1>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/" className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-600 hover:bg-slate-100 transition-colors">
                <Globe className="w-4 h-4" /> عرض الموقع
              </Link>
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white font-bold text-sm">إ</div>
            </div>
          </div>
        </header>

        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function AdminSidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <>
      <div className="flex items-center justify-between p-5 border-b border-slate-700/50">
        <Link to="/admin" onClick={onNavigate} className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="font-cairo font-bold text-white">لوحة الإدارة</div>
            <div className="text-[10px] text-amber-400">توافق</div>
          </div>
        </Link>
      </div>

      <nav className="flex-1 overflow-y-auto p-3 space-y-5">
        {navSections.map((section) => (
          <div key={section.title}>
            <h3 className="px-3 mb-2 text-[11px] font-bold text-slate-500 uppercase tracking-wider">{section.title}</h3>
            <div className="space-y-1">
              {section.items.map((item) => (
                <NavLink key={item.to} to={item.to} end={item.end} onClick={onNavigate} label={item.label} icon={item.icon} />
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-3 border-t border-slate-700/50">
        <Link to="/" onClick={onNavigate} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-colors">
          <LogOut className="w-5 h-5" />
          <span className="font-cairo font-semibold text-sm">العودة للموقع</span>
        </Link>
      </div>
    </>
  );
}

function NavLink({ to, label, icon: Icon, end, onClick }: { to: string; label: string; icon: typeof Users; end: boolean; onClick?: () => void }) {
  const location = useLocation();
  const active = end ? location.pathname === to : location.pathname.startsWith(to);
  return (
    <Link
      to={to}
      onClick={onClick}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all no-tap-highlight ${
        active
          ? 'bg-gradient-to-l from-amber-500/20 to-transparent text-amber-400 border-r-2 border-amber-400'
          : 'text-slate-400 hover:bg-slate-800 hover:text-white'
      }`}
    >
      <Icon className="w-5 h-5 flex-shrink-0" />
      {label}
    </Link>
  );
}
