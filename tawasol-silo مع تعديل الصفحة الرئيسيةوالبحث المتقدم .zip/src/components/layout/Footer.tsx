import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, ShieldCheck, Lock, Heart, MessageCircle, Twitter, Instagram, Facebook } from 'lucide-react';
import Logo from '../ui/Logo';
import { useApp } from '../../lib/AppContext';

const footerLinks = {
  'المنصة': [
    { to: '/about', label: 'من نحن' },
    { to: '/blog', label: 'المدونة' },
    { to: '/plans', label: 'الباقات' },
    { to: '/search', label: 'البحث المتقدم' },
  ],
  'الدعم': [
    { to: '/faq', label: 'الأسئلة الشائعة' },
    { to: '/support', label: 'الدعم الفني' },
    { to: '/contact', label: 'اتصل بنا' },
  ],
  'قانوني': [
    { to: '/privacy', label: 'سياسة الخصوصية' },
    { to: '/terms', label: 'الشروط والأحكام' },
  ],
};

export default function Footer() {
  const { socialSettings } = useApp();

  return (
    <footer className="bg-navy-gradient text-white mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          <div className="lg:col-span-2 space-y-5">
            <Logo variant="light" size="md" />
            <p className="text-cream-200/70 font-tajawal leading-relaxed max-w-sm text-sm">
              منصة الزواج العربية الأولى للزواج العصري الموثوق. نربط القلوب بثقة وخصوصية تامة، لنحقق آلاف قصص النجاح.
            </p>
            
            {/* Social channels display based on admin control */}
            <div className="flex items-center gap-3 pt-1">
              {socialSettings.showWhatsapp && socialSettings.whatsappNumber && (
                <a 
                  href={`https://wa.me/${socialSettings.whatsappNumber}`} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 rounded-xl bg-emerald-500 hover:bg-emerald-600 flex items-center justify-center text-white transition-all hover:scale-105"
                  title="الدعم الفني عبر واتساب"
                >
                  <MessageCircle className="w-5 h-5 fill-current" />
                </a>
              )}
              {socialSettings.showTwitter && socialSettings.twitter && (
                <a 
                  href={socialSettings.twitter} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-white transition-all hover:scale-105"
                  title="حساب تويتر"
                >
                  <Twitter className="w-5 h-5 fill-current" />
                </a>
              )}
              {socialSettings.showInstagram && socialSettings.instagram && (
                <a 
                  href={socialSettings.instagram} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-500 hover:opacity-90 flex items-center justify-center text-white transition-all hover:scale-105"
                  title="حساب إنستغرام"
                >
                  <Instagram className="w-5 h-5" />
                </a>
              )}
              {socialSettings.showFacebook && socialSettings.facebook && (
                <a 
                  href={socialSettings.facebook} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 rounded-xl bg-blue-600 hover:bg-blue-700 flex items-center justify-center text-white transition-all hover:scale-105"
                  title="حساب فيسبوك"
                >
                  <Facebook className="w-5 h-5 fill-current" />
                </a>
              )}
            </div>

            <div className="flex items-center gap-4 flex-wrap pt-1">
              <span className="flex items-center gap-1.5 text-xs text-emerald-300 bg-emerald-500/10 px-3 py-1.5 rounded-full">
                <ShieldCheck className="w-4 h-4" /> موثوق وآمن
              </span>
              <span className="flex items-center gap-1.5 text-xs text-gold-300 bg-gold-500/10 px-3 py-1.5 rounded-full">
                <Lock className="w-4 h-4" /> خصوصية تامة
              </span>
            </div>
          </div>

          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-cairo font-bold text-gold-300 mb-4">{title}</h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.to}>
                    <Link to={link.to} className="text-cream-200/70 hover:text-gold-300 font-tajawal text-sm transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-cream-200/60 text-sm font-tajawal">© 2025 توافق. جميع الحقوق محفوظة.</p>
          <div className="flex items-center gap-2 text-cream-200/60 text-sm font-tajawal">
            صُنع بـ <Heart className="w-4 h-4 text-rose-deep fill-rose-deep" /> في المملكة العربية السعودية
          </div>
        </div>
      </div>
    </footer>
  );
}
