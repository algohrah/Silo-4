import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, ArrowLeft } from 'lucide-react';
import { BLOG_POSTS } from '../lib/data';

const categories = ['الكل', 'نصائح', 'علاقات', 'عائلة'];

export default function Blog() {
  const [cat, setCat] = useState('الكل');
  const posts = cat === 'الكل' ? BLOG_POSTS : BLOG_POSTS.filter((p) => p.category === cat);
  const featured = BLOG_POSTS[0];

  return (
    <div className="bg-cream-50 min-h-screen">
      <div className="bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 py-14 text-center">
          <h1 className="font-cairo font-extrabold text-3xl sm:text-4xl text-white">المدونة ونصائح الزواج</h1>
          <p className="mt-3 text-cream-200/80 font-tajawal max-w-xl mx-auto">مقالات ونصائح من خبراء العلاقات لزواج سعيد وناجح.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        {/* Featured */}
        <Link to={`/blog/${featured.id}`} className="group block bg-white rounded-3xl overflow-hidden shadow-luxe border border-cream-200/60 mb-10">
          <div className="grid md:grid-cols-2">
            <div className="aspect-[16/10] md:aspect-auto overflow-hidden">
              <img src={featured.image} alt={featured.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            </div>
            <div className="p-6 sm:p-10 flex flex-col justify-center">
              <span className="text-xs font-cairo font-bold text-gold-600 mb-2">مقال مميز · {featured.category}</span>
              <h2 className="font-cairo font-extrabold text-2xl sm:text-3xl text-navy-900 leading-tight mb-3 group-hover:text-gold-700 transition-colors">{featured.title}</h2>
              <p className="text-navy-600 font-tajawal leading-relaxed mb-4">{featured.excerpt}</p>
              <div className="flex items-center gap-3 text-sm text-navy-400 font-tajawal">
                <span>{featured.author}</span> · <span>{featured.date}</span> · <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{featured.readTime}</span>
              </div>
              <span className="mt-5 inline-flex items-center gap-2 text-gold-700 font-cairo font-bold">اقرأ المزيد <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /></span>
            </div>
          </div>
        </Link>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`px-5 py-2.5 rounded-full font-cairo font-semibold text-sm transition-all ${cat === c ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-white text-navy-600 border border-cream-200 hover:bg-cream-100'}`}
            >{c}</button>
          ))}
        </div>

        {/* Posts grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.map((post) => (
            <Link key={post.id} to={`/blog/${post.id}`} className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-luxe transition-all duration-400 border border-cream-200/60">
              <div className="aspect-[16/10] overflow-hidden">
                <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="p-5">
                <div className="flex items-center gap-2 text-xs text-gold-600 font-cairo font-bold mb-2">
                  <span className="px-2.5 py-1 rounded-full bg-gold-300/15">{post.category}</span>
                  <span className="flex items-center gap-1 text-navy-400"><Clock className="w-3 h-3" />{post.readTime}</span>
                </div>
                <h3 className="font-cairo font-bold text-navy-900 text-lg leading-snug mb-2 group-hover:text-gold-700 transition-colors line-clamp-2">{post.title}</h3>
                <p className="text-sm text-navy-600 font-tajawal line-clamp-2">{post.excerpt}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
