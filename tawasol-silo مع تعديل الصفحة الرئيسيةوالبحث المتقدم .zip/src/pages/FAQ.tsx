import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { FAQS } from '../lib/data';
import { Link } from 'react-router-dom';

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="bg-cream-50 min-h-screen">
      <div className="bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 py-14 text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gold-300/15 mb-4">
            <HelpCircle className="w-7 h-7 text-gold-300" />
          </div>
          <h1 className="font-cairo font-extrabold text-3xl sm:text-4xl text-white">الأسئلة الشائعة</h1>
          <p className="mt-3 text-cream-200/80 font-tajawal max-w-xl mx-auto">إجابات على أكثر الأسئلة التي تردنا حول المنصة والخصوصية والأمان.</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <div className="space-y-3">
          {FAQS.map((item, i) => (
            <div key={i} className="bg-white rounded-2xl shadow-soft border border-cream-200/60 overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between gap-4 p-5 text-right no-tap-highlight"
              >
                <span className="font-cairo font-bold text-navy-900 flex-1">{item.q}</span>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${open === i ? 'bg-gold-gradient text-navy-900 rotate-180' : 'bg-cream-100 text-navy-500'}`}>
                  <ChevronDown className="w-5 h-5" />
                </div>
              </button>
              <AnimatePresence>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="px-5 pb-5 text-navy-600 font-tajawal leading-relaxed">{item.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>

        {/* Still need help */}
        <div className="mt-10 bg-navy-gradient rounded-3xl p-8 text-center relative overflow-hidden">
          <div className="absolute inset-0 pattern-arabesque opacity-30" />
          <div className="relative">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gold-300/15 mb-4">
              <MessageCircle className="w-7 h-7 text-gold-300" />
            </div>
            <h2 className="font-cairo font-extrabold text-2xl text-white">لم تجد إجابتك؟</h2>
            <p className="text-cream-200/80 font-tajawal mt-2 mb-5">فريق الدعم متاح لمساعدتك على مدار الساعة</p>
            <Link to="/contact" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-gold-gradient text-navy-900 font-cairo font-bold shadow-gold">تواصل مع الدعم</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
