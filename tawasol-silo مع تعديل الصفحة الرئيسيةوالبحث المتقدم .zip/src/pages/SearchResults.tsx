import { useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { SlidersHorizontal, Users, X, SearchX } from 'lucide-react';
import MemberCard from '../components/MemberCard';
import { MEMBERS } from '../lib/data';

export default function SearchResults() {
  const [params] = useSearchParams();

  const results = useMemo(() => {
    const gender = params.get('gender');
    const minAge = Number(params.get('minAge') || 18);
    const maxAge = Number(params.get('maxAge') || 70);
    const country = params.get('country');
    const city = params.get('city');
    const nationality = params.get('nationality');
    const education = params.get('education');
    const job = params.get('job');
    const maritalStatus = params.get('maritalStatus');
    const sect = params.get('sect');
    const hasChildren = params.get('hasChildren');
    const childrenCount = params.get('childrenCount');

    const filtered = MEMBERS.filter((m) => {
      if (gender && m.gender !== gender) return false;
      if (m.age < minAge || m.age > maxAge) return false;
      if (country && m.country !== country) return false;
      if (city && m.city !== city) return false;
      if (nationality && m.nationality !== nationality) return false;
      if (education && m.education !== education) return false;
      if (job && m.workType !== job) return false;
      if (maritalStatus && m.maritalStatus !== maritalStatus) return false;
      if (sect && m.sect !== sect) return false;
      if (hasChildren === 'true' && !m.hasChildren) return false;
      if (hasChildren === 'false' && m.hasChildren) return false;
      if (childrenCount && m.childrenCount !== childrenCount) return false;
      return true;
    });

    // فرز النتائج: أصحاب الباقات المدفوعة أولاً ثم المجانية حسب الأحدث (ID تنازلي)
    return [...filtered].sort((a, b) => {
      if (a.premium && !b.premium) return -1;
      if (!a.premium && b.premium) return 1;
      
      const idA = parseInt(a.id.replace(/\D/g, '')) || 0;
      const idB = parseInt(b.id.replace(/\D/g, '')) || 0;
      return idB - idA;
    });
  }, [params]);

  // بناء قائمة الفلاتر النشطة للعرض
  const activeFilters: { label: string; value: string }[] = [];
  const genderParam = params.get('gender');
  if (genderParam) activeFilters.push({ label: 'النوع', value: genderParam === 'male' ? 'رجال' : 'نساء' });
  if (params.get('country')) activeFilters.push({ label: 'الدولة', value: params.get('country')! });
  if (params.get('city')) activeFilters.push({ label: 'المدينة', value: params.get('city')! });
  if (params.get('nationality')) activeFilters.push({ label: 'الجنسية', value: params.get('nationality')! });
  if (params.get('education')) activeFilters.push({ label: 'التعليم', value: params.get('education')! });
  if (params.get('job')) activeFilters.push({ label: 'الوظيفة', value: params.get('job')! });
  if (params.get('sect')) activeFilters.push({ label: 'المذهب', value: params.get('sect')! });
  if (params.get('maritalStatus')) {
    const labels: Record<string, string> = { single: 'أعزب/عزباء', divorced: 'مطلق/مطلقة', widower: 'أرمل', widow: 'أرملة', married: 'متزوج/متزوجة' };
    activeFilters.push({ label: 'الحالة', value: labels[params.get('maritalStatus')!] || params.get('maritalStatus')! });
  }
  if (params.get('hasChildren') === 'true') activeFilters.push({ label: '', value: 'لديه أبناء' });
  if (params.get('hasChildren') === 'false') activeFilters.push({ label: '', value: 'بدون أبناء' });
  if (params.get('childrenCount')) activeFilters.push({ label: 'عدد الأبناء', value: params.get('childrenCount')! });

  return (
    <div className="bg-cream-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="font-cairo font-extrabold text-2xl sm:text-3xl text-navy-900">نتائج البحث</h1>
            <p className="text-navy-600 font-tajawal mt-1 flex items-center gap-2">
              <Users className="w-4 h-4 text-gold-600" />
              تم العثور على <span className="font-bold text-gold-700">{results.length}</span> عضو
            </p>
          </div>
          <Link to="/search" className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-white border-2 border-cream-200 hover:border-gold-300 text-navy-700 font-cairo font-semibold text-sm transition-colors">
            <SlidersHorizontal className="w-4 h-4" /> تعديل الفلاتر
          </Link>
        </div>

        {activeFilters.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {activeFilters.map((f, i) => (
              <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gold-300/15 text-gold-700 font-cairo font-semibold text-sm">
                {f.label && <span className="text-navy-400">{f.label}:</span>}
                {f.value}
              </span>
            ))}
          </div>
        )}

        {results.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {results.map((m) => <MemberCard key={m.id} member={m} />)}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-cream-100 mb-4">
              <SearchX className="w-10 h-10 text-navy-300" />
            </div>
            <h3 className="font-cairo font-bold text-xl text-navy-900">لا توجد نتائج مطابقة</h3>
            <p className="text-navy-500 font-tajawal mt-2">جرّب توسيع نطاق البحث أو تعديل الفلاتر</p>
            <Link to="/search" className="inline-block mt-6 px-6 py-3 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold shadow-soft">تعديل البحث</Link>
          </div>
        )}
      </div>
    </div>
  );
}
