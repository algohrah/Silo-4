import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Headphones, Plus, Send, Clock, CheckCircle2, AlertCircle,
  MessageSquare, X, ChevronLeft, Headphones as Support,
} from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { SUPPORT_TICKETS } from '../lib/data';
import type { SupportTicket } from '../lib/types';
import { Button } from '../components/ui/Button';
import Modal from '../components/ui/Modal';

const statusConfig = {
  open: { label: 'مفتوحة', color: 'text-sky-600 bg-sky-50', icon: Clock },
  in_progress: { label: 'قيد المعالجة', color: 'text-gold-600 bg-gold-300/15', icon: AlertCircle },
  resolved: { label: 'تم الحل', color: 'text-emerald-600 bg-emerald-50', icon: CheckCircle2 },
  closed: { label: 'مغلقة', color: 'text-navy-400 bg-cream-100', icon: CheckCircle2 },
};

const categories = ['استفسار عام', 'طلب ترقية', 'مشكلة تقنية', 'شكوى', 'اقتراح'] as const;

export default function AdminChat() {
  const navigate = useNavigate();
  const { showToast } = useApp();
  const [tickets, setTickets] = useState<SupportTicket[]>(SUPPORT_TICKETS);
  const [activeTicket, setActiveTicket] = useState<SupportTicket | null>(null);
  const [draft, setDraft] = useState('');
  const [newTicketOpen, setNewTicketOpen] = useState(false);
  const [newSubject, setNewSubject] = useState('');
  const [newCategory, setNewCategory] = useState<typeof categories[number]>('استفسار عام');
  const [newMessage, setNewMessage] = useState('');

  const sendMessage = () => {
    if (!draft.trim() || !activeTicket) return;
    const updated: SupportTicket = {
      ...activeTicket,
      messages: [...activeTicket.messages, {
        id: String(Date.now()),
        sender: 'user',
        text: draft,
        time: 'الآن',
      }],
      updatedAt: 'الآن',
    };
    setActiveTicket(updated);
    setTickets(prev => prev.map(t => t.id === updated.id ? updated : t));
    setDraft('');

    // رد تلقائي من الإدارة بعد ثانيتين
    setTimeout(() => {
      const adminReply: SupportTicket = {
        ...updated,
        messages: [...updated.messages, {
          id: String(Date.now() + 1),
          sender: 'admin',
          text: 'شكرًا لتواصلك معنا. تم استلام رسالتك وسيرد عليك فريقنا في أقرب وقت ممكن. 🌹',
          time: 'الآن',
        }],
      };
      setActiveTicket(adminReply);
      setTickets(prev => prev.map(t => t.id === adminReply.id ? adminReply : t));
    }, 2000);
  };

  const createTicket = () => {
    if (!newSubject.trim() || !newMessage.trim()) return;
    const ticket: SupportTicket = {
      id: 't' + Date.now(),
      subject: newSubject,
      category: newCategory,
      status: 'open',
      priority: 'normal',
      updatedAt: 'الآن',
      messages: [{ id: '1', sender: 'user', text: newMessage, time: 'الآن' }],
    };
    setTickets(prev => [ticket, ...prev]);
    setNewTicketOpen(false);
    setNewSubject('');
    setNewMessage('');
    showToast('تم إنشاء تذكرة الدعم بنجاح! 🎫', 'success');
    setActiveTicket(ticket);
  };

  // عرض المحادثة المفتوحة على الجوال
  if (activeTicket) {
    const sc = statusConfig[activeTicket.status];
    return (
      <div className="bg-cream-50 min-h-[calc(100vh-5rem)] lg:min-h-screen">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6">
          <button
            onClick={() => setActiveTicket(null)}
            className="flex items-center gap-2 text-navy-600 hover:text-gold-700 font-cairo font-semibold text-sm mb-4 transition-colors"
          >
            <ChevronLeft className="w-4 h-4 rotate-180" /> رجوع للتذاكر
          </button>

          <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 overflow-hidden flex flex-col h-[70vh]">
            {/* Header */}
            <div className="flex items-center gap-3 p-4 border-b border-cream-200">
              <div className="w-11 h-11 rounded-xl bg-navy-gradient flex items-center justify-center flex-shrink-0">
                <Headphones className="w-6 h-6 text-gold-300" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-cairo font-bold text-navy-900 truncate">{activeTicket.subject}</h3>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${sc.color} flex items-center gap-1`}>
                    <sc.icon className="w-3 h-3" /> {sc.label}
                  </span>
                  <span className="text-xs text-navy-400 font-tajawal">{activeTicket.category}</span>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-cream-50/50">
              {activeTicket.messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.sender === 'user' ? 'justify-start' : 'justify-end'}`}
                >
                  <div className="flex gap-2 max-w-[80%]">
                    {msg.sender === 'admin' && (
                      <div className="w-8 h-8 rounded-full bg-navy-gradient flex items-center justify-center flex-shrink-0 mt-1">
                        <Headphones className="w-4 h-4 text-gold-300" />
                      </div>
                    )}
                    <div>
                      <div className={`px-4 py-2.5 rounded-2xl ${
                        msg.sender === 'user'
                          ? 'bg-navy-900 text-white rounded-bl-md'
                          : 'bg-white text-navy-900 rounded-br-md shadow-soft border border-cream-200'
                      }`}>
                        <p className="font-tajawal text-sm leading-relaxed">{msg.text}</p>
                      </div>
                      <span className={`text-[10px] mt-1 block ${msg.sender === 'user' ? 'text-navy-400' : 'text-navy-400'} px-1`}>
                        {msg.sender === 'admin' ? 'فريق الإدارة' : 'أنت'} · {msg.time}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-cream-200 flex items-center gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="اكتب رسالتك للإدارة..."
                className="flex-1 px-4 py-3 rounded-xl bg-cream-50 border border-cream-200 focus:border-gold-400 focus:outline-none font-tajawal"
              />
              <button
                onClick={sendMessage}
                className="w-12 h-12 rounded-xl bg-gold-gradient flex items-center justify-center text-navy-900 flex-shrink-0 shadow-soft"
              >
                <Send className="w-5 h-5 -scale-x-100" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-navy-gradient flex items-center justify-center">
              <Headphones className="w-6 h-6 text-gold-300" />
            </div>
            <div>
              <h1 className="font-cairo font-extrabold text-2xl text-navy-900">تواصل مع الإدارة</h1>
              <p className="text-navy-600 font-tajawal text-sm">نحن هنا لمساعدتك في أي وقت</p>
            </div>
          </div>
          <button
            onClick={() => setNewTicketOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold text-sm shadow-soft hover:shadow-gold transition-all"
          >
            <Plus className="w-4 h-4" /> تذكرة جديدة
          </button>
        </div>

        {/* Info banner */}
        <div className="bg-navy-gradient rounded-2xl p-4 mb-5 relative overflow-hidden">
          <div className="absolute inset-0 pattern-arabesque opacity-30" />
          <div className="relative flex items-center gap-3">
            <MessageSquare className="w-6 h-6 text-gold-300 flex-shrink-0" />
            <p className="text-cream-200/90 font-tajawal text-sm leading-relaxed">
              التواصل في توافق <span className="text-gold-300 font-bold">حصري بينك وبين الإدارة</span>. لا توجد رسائل مباشرة بين الأعضاء لضمان الخصوصية والجدية.
            </p>
          </div>
        </div>

        {/* Tickets list */}
        <div className="space-y-3">
          {tickets.map((ticket) => {
            const sc = statusConfig[ticket.status];
            const lastMsg = ticket.messages[ticket.messages.length - 1];
            return (
              <button
                key={ticket.id}
                onClick={() => setActiveTicket(ticket)}
                className="w-full flex items-start gap-3 p-4 bg-white rounded-2xl shadow-soft border border-cream-200/60 text-right hover:shadow-luxe hover:border-gold-300 transition-all"
              >
                <div className="w-11 h-11 rounded-xl bg-cream-100 flex items-center justify-center flex-shrink-0">
                  <Support className="w-5 h-5 text-navy-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h3 className="font-cairo font-bold text-navy-900 truncate">{ticket.subject}</h3>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${sc.color} flex items-center gap-1 flex-shrink-0`}>
                      <sc.icon className="w-3 h-3" /> {sc.label}
                    </span>
                  </div>
                  <p className="text-sm text-navy-500 font-tajawal truncate">{lastMsg.text}</p>
                  <p className="text-xs text-navy-400 font-tajawal mt-1">{ticket.category} · {ticket.updatedAt}</p>
                </div>
                <ChevronLeft className="w-5 h-5 text-navy-300 flex-shrink-0 mt-1" />
              </button>
            );
          })}
        </div>
      </div>

      {/* New ticket modal */}
      <Modal open={newTicketOpen} onClose={() => setNewTicketOpen(false)} title="تذكرة دعم جديدة">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">الموضوع</label>
            <input
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              placeholder="موضوع الاستفسار"
              className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900"
            />
          </div>
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">التصنيف</label>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setNewCategory(cat)}
                  className={`px-3 py-2 rounded-xl text-sm font-cairo font-semibold transition-all ${
                    newCategory === cat ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-cream-100 text-navy-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">رسالتك</label>
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              rows={4}
              placeholder="اشرح استفسارك بالتفصيل..."
              className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 resize-none"
            />
          </div>
          <Button fullWidth size="lg" onClick={createTicket}>
            <Send className="w-5 h-5 -scale-x-100" /> إرسال التذكرة
          </Button>
        </div>
      </Modal>
    </div>
  );
}
