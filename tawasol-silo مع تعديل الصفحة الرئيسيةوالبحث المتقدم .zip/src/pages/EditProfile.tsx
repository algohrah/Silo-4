import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Save, User, MapPin, Calendar, Briefcase, GraduationCap,
  Heart, FileText, Check, ShieldCheck, Lock, Eye, Ruler, Weight,
} from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { Button } from '../components/ui/Button';
import {
  ARAB_COUNTRIES, ARAB_CITIES, EDUCATION_LEVELS, WORK_TYPES,
  HOUSING_TYPES, SKIN_COLORS, HEALTH_OPTIONS, SMOKING_OPTIONS,
  SECTS, MARITAL_MALE, MARITAL_FEMALE, getMaritalOptions,
} from '../lib/types';

export default function EditProfile() {
  const navigate = useNavigate();
  const { user, showToast } = useApp();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // بيانات النموذج (تُعبّأ من بيانات المستخدم)
  const [form, setForm] = useState({
    nickname: user.profile.name || '',
    gender: 'female' as 'male' | 'female',
    age: user.profile.age || 26,
    country: 'السعودية',
    city: user.profile.city || 'الرياض',
    district: 'حي العليا',
    nationality: 'السعودية',
    sect: 'سني',
    maritalStatus: 'single',
    hasChildren: false,
    childrenCount: 'لا يوجد',
    height: 165,
    weight: 58,
    skinColor: 'أبيض',
    health: 'ممتازة',
    smoking: 'لا أدخن',
    education: 'بكالوريوس',
    workType: 'حكومي',
    jobTitle: '',
    housing: 'أسكن مع العائلة',
    bio: 'أبحث عن شريك حياة يخاف الله ويقدّر معنى الزواج الحقيقي.',
    aboutPartner: 'أبحث عن رجل متدين، مستقر، يحب العائلة ويقدّر الاستقرار.',
  });

  const update = (key: keyof typeof form, value: string | number | boolean) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  };

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSaved(true);
      showToast('تم حفظ التغييرات بنجاح ✓', 'success');
      setTimeout(() => navigate('/profile'), 1200);
    }, 1500);
  };

  const sections = [
    {
      title: 'المعلومات الأساسية',
      icon: User,
      fields: (
        <>
          <Field label="الاسم المستعار" icon={User}>
            <input value={form.nickname} onChange={(e) => update('nickname', e.target.value)} className={inputCls} />
          </Field>
          <Field label="العمر" icon={Calendar}>
            <div className="flex items-center gap-3">
              <input type="range" min="18" max="70" value={form.age} onChange={(e) => update('age', Number(e.target.value))} className="flex-1 accent-gold-500" />
              <span className="font-cairo font-bold text-gold-700 w-16 text-center">{form.age} سنة</span>
            </div>
          </Field>
          <Field label="الجنس">
            <div className="grid grid-cols-2 gap-2">
              {([['male', 'ذكر'], ['female', 'أنثى']] as const).map(([val, label]) => (
                <button key={val} type="button" onClick={() => update('gender', val)} className={`py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all ${form.gender === val ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-cream-100 text-navy-600'}`}>
                  {label}
                </button>
              ))}
            </div>
          </Field>
        </>
      ),
    },
    {
      title: 'الموقع والجنسية',
      icon: MapPin,
      fields: (
        <>
          <Field label="الدولة" icon={MapPin}>
            <Select value={form.country} onChange={(v) => update('country', v)} options={ARAB_COUNTRIES} />
          </Field>
          <Field label="المدينة">
            <Select value={form.city} onChange={(v) => update('city', v)} options={ARAB_CITIES} />
          </Field>
          <Field label="الحي / المنطقة">
            <input value={form.district} onChange={(e) => update('district', e.target.value)} className={inputCls} />
          </Field>
          <Field label="الجنسية">
            <Select value={form.nationality} onChange={(v) => update('nationality', v)} options={ARAB_COUNTRIES} />
          </Field>
          <Field label="المذهب">
            <Select value={form.sect} onChange={(v) => update('sect', v)} options={SECTS} />
          </Field>
        </>
      ),
    },
    {
      title: 'الحالة الاجتماعية',
      icon: Heart,
      fields: (
        <>
          <Field label="الحالة الاجتماعية">
            <Select value={form.maritalStatus} onChange={(v) => update('maritalStatus', v)} options={getMaritalOptions(form.gender).map(o => ({ value: o.value, label: o.label }))} />
          </Field>
          <Field label="هل لديك أبناء؟">
            <div className="grid grid-cols-2 gap-2">
              {([['no', 'لا'], ['yes', 'نعم']] as const).map(([val, label]) => (
                <button key={val} type="button" onClick={() => update('hasChildren', val === 'yes')} className={`py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all ${(form.hasChildren ? 'yes' : 'no') === val ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-cream-100 text-navy-600'}`}>
                  {label}
                </button>
              ))}
            </div>
          </Field>
          {form.hasChildren && (
            <Field label="عدد الأبناء">
              <Select value={form.childrenCount} onChange={(v) => update('childrenCount', v)} options={['1', '2', '3', '4', 'أكثر من 4'].map(o => ({ value: o, label: o }))} />
            </Field>
          )}
        </>
      ),
    },
    {
      title: 'الصفات الشخصية',
      icon: Ruler,
      fields: (
        <>
          <Field label="الطول (سم)" icon={Ruler}>
            <div className="flex items-center gap-3">
              <input type="range" min="140" max="210" value={form.height} onChange={(e) => update('height', Number(e.target.value))} className="flex-1 accent-gold-500" />
              <span className="font-cairo font-bold text-gold-700 w-16 text-center">{form.height} سم</span>
            </div>
          </Field>
          <Field label="الوزن (كجم)" icon={Weight}>
            <div className="flex items-center gap-3">
              <input type="range" min="40" max="150" value={form.weight} onChange={(e) => update('weight', Number(e.target.value))} className="flex-1 accent-gold-500" />
              <span className="font-cairo font-bold text-gold-700 w-16 text-center">{form.weight} كجم</span>
            </div>
          </Field>
          <Field label="لون البشرة">
            <Select value={form.skinColor} onChange={(v) => update('skinColor', v)} options={SKIN_COLORS.map(o => ({ value: o, label: o }))} />
          </Field>
          <Field label="الحالة الصحية">
            <Select value={form.health} onChange={(v) => update('health', v)} options={HEALTH_OPTIONS.map(o => ({ value: o, label: o }))} />
          </Field>
          <Field label="التدخين">
            <Select value={form.smoking} onChange={(v) => update('smoking', v)} options={SMOKING_OPTIONS.map(o => ({ value: o, label: o }))} />
          </Field>
        </>
      ),
    },
    {
      title: 'التعليم والعمل',
      icon: GraduationCap,
      fields: (
        <>
          <Field label="المؤهل العلمي" icon={GraduationCap}>
            <Select value={form.education} onChange={(v) => update('education', v)} options={EDUCATION_LEVELS.map(o => ({ value: o, label: o }))} />
          </Field>
          <Field label="نوع جهة العمل" icon={Briefcase}>
            <Select value={form.workType} onChange={(v) => { update('workType', v); update('jobTitle', ''); }} options={WORK_TYPES.map(o => ({ value: o, label: o }))} />
          </Field>
          {form.workType && form.workType !== 'بدون عمل' && (
            <Field label="المسمى الوظيفي" icon={Briefcase}>
              <input
                value={form.jobTitle}
                onChange={(e) => update('jobTitle', e.target.value)}
                placeholder={form.workType === 'طالب' ? 'طالب جامعي...' : 'معلم، طبيب، مهندس...'}
                className={inputCls}
              />
            </Field>
          )}
          <Field label="نوع السكن" icon={MapPin}>
            <Select value={form.housing} onChange={(v) => update('housing', v)} options={HOUSING_TYPES.map(o => ({ value: o, label: o }))} />
          </Field>
        </>
      ),
    },
    {
      title: 'نبذة عني',
      icon: FileText,
      fields: (
        <Field label="اكتب نبذة قصيرة عنك" icon={FileText}>
          <textarea value={form.bio} onChange={(e) => update('bio', e.target.value)} rows={4} className={inputCls + ' resize-none'} placeholder="اكتب نبذة عن شخصيتك وأهدافك..." />
          <p className="text-xs text-navy-400 font-tajawal mt-1">{form.bio.length} / 500 حرف</p>
        </Field>
      ),
    },
    {
      title: 'مواصفات الشريك',
      icon: Heart,
      fields: (
        <Field label="مواصفات الشريك المطلوب" icon={Heart}>
          <textarea value={form.aboutPartner} onChange={(e) => update('aboutPartner', e.target.value)} rows={4} className={inputCls + ' resize-none'} placeholder="اكتب مواصفات الشريك الذي تبحث عنه..." />
        </Field>
      ),
    },
  ];

  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8">
      {/* Header */}
      <div className="bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link to="/profile" className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors">
                <ArrowRight className="w-5 h-5" />
              </Link>
              <div>
                <h1 className="font-cairo font-extrabold text-2xl text-white">تعديل الملف الشخصي</h1>
                <p className="text-cream-200/70 font-tajawal text-sm">حدّث معلوماتك الشخصية</p>
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 text-cream-200/80 text-xs font-tajawal">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> بياناتك محمية
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-4">
        {/* ملاحظة الخصوصية */}
        <div className="bg-gold-300/10 border border-gold-500/20 rounded-2xl p-4 flex items-start gap-3">
          <Lock className="w-5 h-5 text-gold-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-cairo font-semibold text-navy-900 text-sm">خصوصية معلوماتك</p>
            <p className="text-xs text-navy-600 font-tajawal mt-0.5">لا يتم عرض معلوماتك الحساسة (مثل الحي، رقم الهاتف) للأعضاء الآخرين. تظهر فقط معلوماتك الأساسية.</p>
          </div>
        </div>

        {/* الأقسام */}
        {sections.map((section) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5 sm:p-6"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-gold-300/15 flex items-center justify-center">
                <section.icon className="w-5 h-5 text-gold-600" />
              </div>
              <h2 className="font-cairo font-bold text-lg text-navy-900">{section.title}</h2>
            </div>
            <div className="space-y-4">{section.fields}</div>
          </motion.div>
        ))}

        {/* أزرار الحفظ */}
        <div className="flex gap-3 sticky bottom-20 lg:bottom-4 z-20">
          <Button onClick={handleSave} size="lg" fullWidth className="shadow-gold" >
            {saving ? (
              <span className="flex items-center gap-2">
                <span className="w-5 h-5 border-2 border-navy-900/30 border-t-navy-900 rounded-full animate-spin" />
                جارِ الحفظ...
              </span>
            ) : saved ? (
              <span className="flex items-center gap-2"><Check className="w-5 h-5" /> تم الحفظ</span>
            ) : (
              <span className="flex items-center gap-2"><Save className="w-5 h-5" /> حفظ التغييرات</span>
            )}
          </Button>
          <Link to="/profile" className="flex items-center justify-center px-6 py-4 rounded-2xl bg-white border-2 border-cream-200 text-navy-600 font-cairo font-bold hover:bg-cream-100 transition-colors">
            إلغاء
          </Link>
        </div>
      </div>
    </div>
  );
}

/* ===== مكونات مساعدة ===== */
const inputCls = 'w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors';

function Field({ label, icon: Icon, children }: { label: string; icon?: typeof User; children: React.ReactNode }) {
  return (
    <div>
      <label className="flex items-center gap-2 text-sm font-cairo font-semibold text-navy-800 mb-2">
        {Icon && <Icon className="w-4 h-4 text-gold-600" />}
        {label}
      </label>
      {children}
    </div>
  );
}

function Select({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[] | string[] }) {
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className={inputCls + ' appearance-none cursor-pointer'}>
      {opts.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  );
}
