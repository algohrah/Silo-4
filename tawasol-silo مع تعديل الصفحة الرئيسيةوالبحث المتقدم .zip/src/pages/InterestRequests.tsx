import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Heart, Clock, CheckCheck, X, Send, Inbox, Sparkles,
} from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { INTEREST_REQUESTS, getMemberById } from '../lib/data';
import { getAvatar, getGenderColors } from '../lib/types';

export default function InterestRequests() {
  const { showToast } = useApp();
  const [filter, setFilter] = useState<'received' | 'sent'>('received');
  const [requests, setRequests] = useState(INTEREST_REQUESTS);

  const filtered = requests.filter(r => r.type === filter);
  const receivedPending = requests.filter(r => r.type === 'received' && r.status === 'pending').length;

  const handleAction = (id: string, action: 'accepted' | 'declined') => {
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: action } : r));
    showToast(
      action === 'accepted' ? 'تم قبول الطلب! تواصل مع الإدارة للمتابعة 🌹' : 'تم رفض الطلب',
      action === 'accepted' ? 'success' : 'info'
    );
  };

  const statusConfig = {
    pending: { label: 'قيد الانتظار', color: 'text-gold-600 bg-gold-300/15', icon: Clock },
    accepted: { label: 'مقبول', color: 'text-emerald-600 bg-emerald-50', icon: CheckCheck },
    declined: { label: 'مرفوض', color: 'text-rose-deep bg-rose-50', icon: X },
  };

  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-rose-deep/10 flex items-center justify-center">
            <Heart className="w-6 h-6 text-rose-deep fill-rose-deep" />
          </div>
          <div>
            <h1 className="font-cairo font-extrabold text-2xl text-navy-900">طلبات الاهتمام</h1>
            <p className="text-navy-600 font-tajawal text-sm">تُعالَج جميع الطلبات عبر الإدارة بسرية تامة</p>
          </div>
        </div>

        {/* Info banner */}
        <div className="bg-gold-300/10 rounded-2xl p-4 mb-5 border border-gold-500/20 flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-gold-600 flex-shrink-0 mt-0.5" />
          <p className="text-navy-600 font-tajawal text-sm leading-relaxed">
            عند إرسال طلب اهتمام، يتولى فريقنا التواصل مع الطرف الآخر نيابةً عنك. يتم إبلاغك بالرد عبر الإشعارات.
          </p>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2 mb-5">
          <button
            onClick={() => setFilter('received')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-cairo font-semibold text-sm transition-all ${
              filter === 'received' ? 'bg-navy-900 text-white shadow-soft' : 'bg-white text-navy-600 border border-cream-200'
            }`}
          >
            <Inbox className="w-4 h-4" /> الطلبات الواردة
            {receivedPending > 0 && (
              <span className="bg-rose-deep text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">{receivedPending}</span>
            )}
          </button>
          <button
            onClick={() => setFilter('sent')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-cairo font-semibold text-sm transition-all ${
              filter === 'sent' ? 'bg-navy-900 text-white shadow-soft' : 'bg-white text-navy-600 border border-cream-200'
            }`}
          >
            <Send className="w-4 h-4" /> طلباتي المُرسلة
          </button>
        </div>

        {/* Requests list */}
        <div className="space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-cream-200/60">
              <Inbox className="w-12 h-12 text-navy-200 mx-auto mb-3" />
              <p className="text-navy-500 font-tajawal">لا توجد طلبات {filter === 'received' ? 'واردة' : 'مُرسلة'} حاليًا</p>
            </div>
          ) : (
            filtered.map((req, i) => {
              const member = getMemberById(req.memberId);
              if (!member) return null;
              const avatar = getAvatar(member.gender);
              const c = getGenderColors(member.gender);
              const sc = statusConfig[req.status];
              return (
                <motion.div
                  key={req.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-white rounded-2xl p-4 shadow-soft border border-cream-200/60"
                >
                  <div className="flex items-start gap-3">
                    <Link to={`/member/${member.id}`} className="flex-shrink-0">
                      <div className={`w-14 h-14 rounded-2xl overflow-hidden ${c.bg} flex items-center justify-center bg-white`}>
                        <img src={avatar} alt="" className="w-full h-full object-contain p-1.5" />
                      </div>
                    </Link>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <Link to={`/member/${member.id}`} className="font-cairo font-bold text-navy-900 hover:text-gold-700 transition-colors truncate">
                          {member.nickname}
                        </Link>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${sc.color} flex items-center gap-1 flex-shrink-0`}>
                          <sc.icon className="w-3 h-3" /> {sc.label}
                        </span>
                      </div>
                      <p className="text-xs text-navy-400 font-tajawal mb-2">
                        {member.age} سنة · {member.city} · {member.workType}
                      </p>
                      <p className="text-sm text-navy-600 font-tajawal leading-relaxed mb-2">{req.message}</p>
                      <p className="text-xs text-navy-400 font-tajawal mb-3">{req.time}</p>

                      {/* Actions */}
                      {req.type === 'received' && req.status === 'pending' && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleAction(req.id, 'accepted')}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-cairo font-bold hover:bg-emerald-700 transition-colors"
                          >
                            <CheckCheck className="w-4 h-4" /> قبول
                          </button>
                          <button
                            onClick={() => handleAction(req.id, 'declined')}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cream-100 text-navy-600 text-sm font-cairo font-bold hover:bg-cream-200 transition-colors"
                          >
                            <X className="w-4 h-4" /> رفض
                          </button>
                        </div>
                      )}
                      {req.type === 'received' && req.status === 'accepted' && (
                        <Link
                          to="/support"
                          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-navy-900 text-white text-sm font-cairo font-bold hover:bg-navy-800 transition-colors"
                        >
                          <Sparkles className="w-4 h-4" /> تواصل مع الإدارة
                        </Link>
                      )}
                      {req.type === 'sent' && req.status === 'accepted' && (
                        <Link
                          to="/support"
                          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-50 text-emerald-700 text-sm font-cairo font-bold border border-emerald-200 hover:bg-emerald-100 transition-colors"
                        >
                          <Sparkles className="w-4 h-4" /> تابع مع الإدارة
                        </Link>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
