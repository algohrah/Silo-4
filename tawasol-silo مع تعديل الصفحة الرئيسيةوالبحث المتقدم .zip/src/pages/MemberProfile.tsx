import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  MapPin, Briefcase, GraduationCap, Ruler, Heart,
  ShieldCheck, Calendar, Users, Globe, BookOpen, Send, ArrowRight,
  Home, Scale, Cigarette, Weight, Palette, Sparkles,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { VerifiedBadge, PremiumBadge, MatchScore } from '../components/ui/Badge';
import Modal from '../components/ui/Modal';
import { getMemberById } from '../lib/data';
import { useApp } from '../lib/AppContext';
import { getAvatar, getGenderColors } from '../lib/types';

export default function MemberProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { likedMembers, toggleLike, user, showToast, checkLimit, incrementUsage, buyMicrotransaction } = useApp();
  const member = id ? getMemberById(id) : undefined;
  const [contactOpen, setContactOpen] = useState(false);
  const [contactMsg, setContactMsg] = useState('');
  const [contactRevealed, setContactRevealed] = useState(false);

  const handleRevealContact = () => {
    if (!user.isLoggedIn) {
      navigate('/login');
      return;
    }
    const check = checkLimit('contact');
    if (check.allowed) {
      incrementUsage('contact');
      setContactRevealed(true);
      showToast('تم الكشف عن رقم الجوال بنجاح! تم اقتطاع استخدام واحد من حد باقتك المتاح.', 'success');
    } else {
      showToast(check.error || 'لقد نفذ رصيد كشف التواصل المتاح لباقة حسابك الحالية.', 'error');
    }
  };

  if (!member) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <h2 className="font-cairo font-bold text-2xl text-navy-900">العضو غير موجود</h2>
        <Button onClick={() => navigate('/search')} className="mt-4">العودة للبحث</Button>
      </div>
    );
  }

  const liked = likedMembers.has(member.id);
  const avatar = getAvatar(member.gender);
  const c = getGenderColors(member.gender);
  const isMale = member.gender === 'male';

  const info = [
    { icon: Calendar, label: 'العمر', value: member.age + ' سنة' },
    { icon: Heart, label: 'الحالة الاجتماعية', value: member.maritalLabel },
    { icon: MapPin, label: 'المدينة', value: member.city },
    { icon: MapPin, label: 'المنطقة', value: member.district },
    { icon: Globe, label: 'الدولة', value: member.country },
    { icon: Globe, label: 'الجنسية', value: member.nationality },
    { icon: Scale, label: 'المذهب', value: member.sect },
    { icon: Ruler, label: 'الطول', value: member.height + ' سم' },
    { icon: Weight, label: 'الوزن', value: member.weight + ' كجم' },
    { icon: Palette, label: 'لون البشرة', value: member.skinColor },
    { icon: Heart, label: 'الحالة الصحية', value: member.health },
    { icon: Cigarette, label: 'التدخين', value: member.smoking },
    { icon: GraduationCap, label: 'المؤهل', value: member.education },
    { icon: Briefcase, label: 'نوع العمل', value: member.workType },
    { icon: Home, label: 'نوع السكن', value: member.housing },
  ];

  if (member.hasChildren) {
    info.push({ icon: Users, label: 'الأبناء', value: member.childrenCount + ' أبناء' });
  }

  return (
    <div className="bg-cream-50 min-h-screen pb-8">
      {/* Hero header */}
      <div className="relative">
        <div className={'relative h-48 sm:h-60 overflow-hidden ' + c.bg}>
          <div className="absolute inset-0 pattern-arabesque opacity-20" />
          <div className="absolute inset-0 flex items-center justify-center">
            <img src={avatar} alt="" className="w-32 h-32 sm:w-40 sm:h-40 object-contain opacity-90" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950/60 via-transparent to-transparent" />
          <button onClick={() => navigate(-1)} className="absolute top-4 right-4 w-10 h-10 rounded-full glass flex items-center justify-center text-navy-900">
            <ArrowRight className="w-5 h-5" />
          </button>
          <span className={'absolute top-4 left-4 inline-flex items-center gap-1.5 ' + c.badgeBg + ' text-white text-sm font-cairo font-bold px-4 py-2 rounded-full shadow-lg'}>
            {isMale ? 'رجل' : 'امرأة'}
          </span>
        </div>

        <div className="max-w-5xl mx-auto px-4 sm:px-6 -mt-16 relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-3xl shadow-luxe border border-cream-200/60 p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="relative">
                <div className={'w-24 h-24 sm:w-28 sm:h-28 rounded-3xl ' + c.bg + ' flex items-center justify-center ring-4 ring-white shadow-lg overflow-hidden'}>
                  <img src={avatar} alt="" className="w-full h-full object-contain p-2" />
                </div>
                {member.online && <span className="absolute bottom-1 left-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white" />}
              </div>
              <div className="flex-1 text-center sm:text-right">
                <div className="flex items-center gap-2 justify-center sm:justify-start flex-wrap mb-1">
                  <h1 className="font-cairo font-extrabold text-2xl sm:text-3xl text-navy-900">{member.nickname}</h1>
                  {member.verified && <VerifiedBadge size="md" />}
                  {member.premium && <PremiumBadge size="md" />}
                </div>
                <p className="text-navy-600 font-tajawal">{member.age} سنة · {member.city} · {member.workType}</p>
                <p className="text-sm text-navy-400 font-tajawal mt-1">{member.lastActive}</p>
              </div>
              {member.matchScore && (
                <div className="hidden sm:block"><MatchScore score={member.matchScore} /></div>
              )}
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3 mt-6">
              <button
                onClick={() => (user.isLoggedIn ? setContactOpen(true) : navigate('/login'))}
                className="flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-gold-gradient text-navy-900 font-cairo font-bold shadow-soft hover:shadow-gold transition-all sm:flex-1 no-tap-highlight"
              >
                <Send className="w-5 h-5 -scale-x-100" /> طلب اهتمام
              </button>
              <button
                onClick={() => toggleLike(member.id)}
                className={'flex items-center justify-center gap-2 py-4 px-6 rounded-2xl font-cairo font-bold transition-all duration-300 no-tap-highlight ' + (liked ? 'bg-rose-deep text-white shadow-soft' : 'bg-cream-100 text-navy-700 hover:bg-cream-200')}
              >
                <Heart className={'w-5 h-5 ' + (liked ? 'fill-white' : '')} />
                {liked ? 'في قائمتي' : 'حفظ'}
              </button>
            </div>

            {/* Mediation note */}
            <div className="mt-4 flex items-start gap-2 bg-gold-300/10 rounded-2xl p-3 border border-gold-500/20">
              <ShieldCheck className="w-5 h-5 text-gold-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-navy-600 font-tajawal leading-relaxed">
                التواصل يتم حصريًا عبر فريق الإدارة لضمان الخصوصية والجدية. عند إرسال طلب اهتمام، ستتولى الإدارة التواصل مع الطرف الآخر وتبليغك بالرد.
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 mt-6 grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* About */}
          <section className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-6">
            <h2 className="font-cairo font-bold text-xl text-navy-900 mb-3 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-gold-600" /> نبذة عني
            </h2>
            <p className="text-navy-700 font-tajawal leading-relaxed">{member.bio}</p>
          </section>

          {/* Partner expectations */}
          <section className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-6">
            <h2 className="font-cairo font-bold text-xl text-navy-900 mb-3 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-rose-deep" /> أبحث عن
            </h2>
            <p className="text-navy-700 font-tajawal leading-relaxed">{member.aboutPartner}</p>
          </section>

          {/* Detailed info grid */}
          <section className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-6">
            <h2 className="font-cairo font-bold text-xl text-navy-900 mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-gold-600" /> التفاصيل الكاملة
            </h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {info.map((item, i) => (
                <div key={i} className="flex items-center gap-3 bg-cream-50 rounded-xl px-3 py-2.5 border border-cream-200/60">
                  <div className={'w-9 h-9 rounded-lg ' + c.bg + ' flex items-center justify-center flex-shrink-0'}>
                    <item.icon className={'w-4 h-4 ' + c.text} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] text-navy-400 font-tajawal">{item.label}</p>
                    <p className="font-cairo font-semibold text-navy-900 text-sm truncate">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Direct Contact Notice Card for Members, Contact Reveal only for Admin */}
          <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-6 space-y-4">
            <h3 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-gold-600" />
              خصوصية بيانات التواصل والربط
            </h3>
            
            {user.isLoggedIn && (user.profile.email?.includes('admin') || user.profile.email === 'admin@tawasul.sa') ? (
              <div className="bg-emerald-50/50 rounded-2xl p-4 border border-emerald-200 text-right space-y-3">
                <p className="text-xs font-bold text-emerald-800">صلاحية المدير: بيانات التواصل المباشرة لهذا الملف:</p>
                <div className="space-y-1.5 text-xs font-mono text-slate-800 text-left">
                  <p className="flex justify-between"><span>رقم الجوال:</span> <strong className="text-sm font-sans">9665809{member.id.charCodeAt(0)}91</strong></p>
                  <p className="flex justify-between"><span>الواتس اَب المباشر:</span> <strong className="text-sm font-sans">9665809{member.id.charCodeAt(0)}91</strong></p>
                </div>
                <hr className="border-emerald-100" />
                <a 
                  href={`https://wa.me/9665809${member.id.charCodeAt(0)}91`} 
                  target="_blank" 
                  referrerPolicy="no-referrer"
                  className="text-center py-2 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-bold font-cairo text-xs block w-full transition-colors"
                >
                  تواصل عبر الواتساب مباشرة
                </a>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-navy-600 font-tajawal leading-relaxed">
                  تلتزم منصة توافق بالحفاظ على سرية وخصوصية بيانات التواصل بين الأعضاء. لا تظهر معلومات التواصل والاتصال بشكل مباشر للأعضاء أو المشتركين حماية للخصوصية.
                </p>
                <div className="bg-cream-50/60 rounded-xl p-3 border border-cream-200/60 text-xs text-navy-700 leading-relaxed font-tajawal">
                  من خلال النقر على <strong>«أرسل طلب اهتمام»</strong>، تتولى إدارة المنصة مراجعة طلبك والتواصل مع الطرف الآخر لربط الأطراف بشكل موثوق وبسرية تامة.
                </div>
              </div>
            )}
          </div>

          {/* Safety note */}
          <div className="bg-gold-300/10 rounded-3xl p-5 border border-gold-500/20">
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-6 h-6 text-gold-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-cairo font-bold text-navy-900 text-sm">تنبيه أمان</h3>
                <p className="text-xs text-navy-600 font-tajawal mt-1 leading-relaxed">لا تشارك معلوماتك المالية أو الشخصية الحساسة. ابقَ داخل المنصة لضمان حمايتك.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contact request modal */}
      <Modal open={contactOpen} onClose={() => setContactOpen(false)} title="إرسال طلب اهتمام">
        <div className="space-y-4">
          <div className="flex items-center gap-2 p-3 bg-gold-300/10 rounded-2xl border border-gold-500/20">
            <ShieldCheck className="w-5 h-5 text-gold-600 flex-shrink-0" />
            <p className="text-xs text-navy-600 font-tajawal">طلبك سيصل لفريق الإدارة الذي سيتواصل مع الطرف الآخر بسرية تامة</p>
          </div>
          <div className="flex items-center gap-3 p-3 bg-cream-100 rounded-2xl">
            <div className={'w-12 h-12 rounded-xl ' + c.bg + ' flex items-center justify-center bg-white'}>
              <img src={avatar} alt="" className="w-full h-full object-contain p-1" />
            </div>
            <div>
              <p className="font-cairo font-bold text-navy-900">{member.nickname}</p>
              <p className="text-xs text-navy-500 font-tajawal">{member.age} سنة · {member.city}</p>
            </div>
          </div>
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">رسالتك (اختياري)</label>
            <textarea
              value={contactMsg}
              onChange={(e) => setContactMsg(e.target.value)}
              rows={4}
              placeholder="اكتب رسالة لطيفة ومحترمة..."
              className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 resize-none"
            />
          </div>
          <Button
            fullWidth
            size="lg"
            onClick={() => {
              const check = checkLimit('message');
              if (!check.allowed) {
                showToast(check.error || 'لقد استنفدت حد طلبات الاهتمام المسموح، يرجى ترقية باقتك!', 'error');
                return;
              }
              incrementUsage('message');
              setContactOpen(false);
              setContactMsg('');
              showToast('تم إرسال طلب الاهتمام! ستتواصل معك الإدارة والوسيطة قريبًا 💌', 'success');
            }}
          >
            <Send className="w-5 h-5 -scale-x-100" /> إرسال الطلب
          </Button>
        </div>
      </Modal>
    </div>
  );
}
