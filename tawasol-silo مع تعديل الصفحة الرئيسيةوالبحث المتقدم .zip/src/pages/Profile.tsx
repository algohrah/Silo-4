import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User, Crown, Inbox, Settings, Bell, Heart, Headphones, Eye,
  Edit3, LogOut, ChevronLeft, Lock, Camera, ShieldCheck, Check,
  Clock, Send, CheckCheck, X, Sparkles, CreditCard, Gift,
} from 'lucide-react';
import { useApp } from '../lib/AppContext';
import { VerifiedBadge, PremiumBadge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { INTEREST_REQUESTS, getMemberById } from '../lib/data';
import { getAvatar } from '../lib/types';
import type { Plan } from '../lib/types';

type Tab = 'overview' | 'subscription' | 'requests' | 'settings' | 'notifications';

const tabsList: { id: Tab; label: string; icon: typeof User }[] = [
  { id: 'overview', label: 'الملف الشخصي', icon: User },
  { id: 'subscription', label: 'الاشتراك', icon: Crown },
  { id: 'requests', label: 'الطلبات', icon: Inbox },
  { id: 'notifications', label: 'الإشعارات', icon: Bell },
  { id: 'settings', label: 'الإعدادات', icon: Settings },
];

export default function Profile() {
  const { user, logout, plans } = useApp();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const name = user.profile.name || user.name || 'ضيف';

  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8">
      {/* Cover */}
      <div className="relative h-36 sm:h-48 bg-navy-gradient overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="absolute -top-10 -right-10 w-60 h-60 bg-gold-500/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-rose-deep/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 -mt-20 relative">
        {/* Profile header card */}
        <div className="bg-white rounded-3xl shadow-luxe border border-cream-200/60 p-5 sm:p-7">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
            <div className="relative">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gold-gradient flex items-center justify-center text-navy-900 font-cairo font-extrabold text-4xl ring-4 ring-white shadow-lg">
                {name.charAt(0)}
              </div>
              <Link to="/profile/edit" className="absolute -bottom-1 -left-1 w-9 h-9 rounded-full bg-navy-900 text-white flex items-center justify-center ring-2 ring-white hover:bg-navy-800 transition-colors">
                <Camera className="w-4 h-4" />
              </Link>
            </div>
            <div className="flex-1 text-center sm:text-right">
              <div className="flex items-center gap-2 justify-center sm:justify-start flex-wrap">
                <h1 className="font-cairo font-extrabold text-2xl text-navy-900">{name}</h1>
                {user.profile.verified && <VerifiedBadge size="md" />}
                <PremiumBadge size="md" />
              </div>
              <p className="text-navy-500 font-tajawal mt-1">
                {user.profile.plan === 'gold' ? 'عضو ذهبي' : user.profile.plan === 'elite' ? 'عضو نخبة' : 'عضو مجاني'} · {user.profile.city} · {user.profile.age} سنة
              </p>
              <p className="text-xs text-emerald-600 font-tajawal mt-1">ملفك مكتمل بنسبة {user.profile.profileCompletion}%</p>
              <div className="mt-2 h-1.5 bg-cream-200 rounded-full overflow-hidden max-w-xs mx-auto sm:mx-0">
                <div className="h-full bg-gold-gradient rounded-full transition-all duration-500" style={{ width: `${user.profile.profileCompletion}%` }} />
              </div>
              <div className="mt-4 flex gap-2 justify-center sm:justify-start">
                <Link to="/profile/edit" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-navy-900 text-white font-cairo font-bold text-sm hover:bg-navy-800 transition-colors">
                  <Edit3 className="w-4 h-4" /> تعديل الملف
                </Link>
                <Link to="/plans" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cream-100 text-navy-700 font-cairo font-bold text-sm hover:bg-cream-200 transition-colors">
                  <Crown className="w-4 h-4 text-gold-600" /> الباقة
                </Link>
              </div>
            </div>
          </div>

          {/* Quick stats */}
          <div className="grid grid-cols-4 gap-2 sm:gap-3 mt-6">
            {[
              { icon: Heart, label: 'إعجابات', value: 24, color: 'text-rose-deep bg-rose-deep/10' },
              { icon: Headphones, label: 'تذاكر', value: 2, color: 'text-gold-600 bg-gold-300/15' },
              { icon: Eye, label: 'زيارات', value: 86, color: 'text-navy-600 bg-navy-900/10' },
              { icon: Inbox, label: 'طلبات', value: INTEREST_REQUESTS.filter(r => r.type === 'received' && r.status === 'pending').length, color: 'text-sky-600 bg-sky-100' },
            ].map((s) => (
              <div key={s.label} className="bg-cream-50 rounded-2xl p-3 text-center border border-cream-200">
                <div className={`w-9 h-9 rounded-xl mx-auto flex items-center justify-center mb-1.5 ${s.color}`}>
                  <s.icon className="w-4.5 h-4.5" strokeWidth={2.2} />
                </div>
                <div className="font-cairo font-extrabold text-lg text-navy-900">{s.value}</div>
                <div className="text-[11px] text-navy-500 font-tajawal">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-5 flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {tabsList.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-cairo font-semibold text-sm whitespace-nowrap transition-all no-tap-highlight ${
                activeTab === tab.id
                  ? 'bg-navy-900 text-white shadow-soft'
                  : 'bg-white text-navy-600 border border-cream-200 hover:bg-cream-100'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
              {tab.id === 'requests' && INTEREST_REQUESTS.filter(r => r.type === 'received' && r.status === 'pending').length > 0 && (
                <span className="bg-rose-deep text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {INTEREST_REQUESTS.filter(r => r.type === 'received' && r.status === 'pending').length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="mt-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'overview' && <OverviewTab name={name} />}
              {activeTab === 'subscription' && <SubscriptionTab currentPlan={user.profile.plan} plans={plans} />}
              {activeTab === 'requests' && <RequestsTab />}
              {activeTab === 'notifications' && <NotificationsTab />}
              {activeTab === 'settings' && <SettingsTab onLogout={logout} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

/* ===== Overview Tab ===== */
function OverviewTab({ name }: { name: string }) {
  const { showToast } = useApp();
  const menu = [
    { icon: Edit3, label: 'تعديل الملف الشخصي', desc: 'حدّث معلوماتك الشخصية', color: 'bg-gold-300/15 text-gold-600', to: '/profile/edit' },
    { icon: ShieldCheck, label: 'التحقق من الحساب', desc: 'احصل على شارة التوثيق', color: 'bg-sky-100 text-sky-600', action: () => showToast('سيتم توجيهك لعملية التحقق قريبًا', 'info') },
    { icon: Lock, label: 'إعدادات الخصوصية', desc: 'تحكّم بمن يرى ملفك', color: 'bg-navy-900/10 text-navy-600', to: '/privacy' },
    { icon: Gift, label: 'ادعُ صديقًا', desc: 'احصل على مكافآت', color: 'bg-rose-deep/10 text-rose-deep', action: () => showToast('رابط الدعوة: tawasul.sa/r/' + name, 'success') },
  ];

  return (
    <div className="space-y-3">
      {/* زر تعديل بارز */}
      <Link
        to="/profile/edit"
        className="flex items-center justify-between gap-3 bg-gold-gradient rounded-2xl p-4 shadow-gold hover:-translate-y-0.5 transition-all group no-tap-highlight"
      >
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-navy-900/10 flex items-center justify-center">
            <Edit3 className="w-5 h-5 text-navy-900" />
          </div>
          <div>
            <h3 className="font-cairo font-bold text-navy-900">تعديل الملف الشخصي</h3>
            <p className="text-xs text-navy-800/70 font-tajawal">حدّث معلوماتك ونبذتك</p>
          </div>
        </div>
        <ChevronLeft className="w-5 h-5 text-navy-900 group-hover:-translate-x-1 transition-transform" />
      </Link>

      {menu.slice(1).map((item) => (
        <OverviewMenuItem key={item.label} item={item} />
      ))}

      {/* Activity preview */}
      <div className="bg-white rounded-2xl p-5 shadow-soft border border-cream-200/60">
        <h3 className="font-cairo font-bold text-navy-900 mb-3">آخر النشاطات</h3>
        <div className="space-y-3">
          {[
            { icon: Heart, text: 'تم استلام طلب اهتمام جديد', time: 'قبل 5 دقائق', color: 'text-rose-deep' },
            { icon: Eye, text: 'تمت مشاهدة ملفك 3 مرات اليوم', time: 'قبل ساعة', color: 'text-navy-600' },
            { icon: Headphones, text: 'رد جديد من فريق الإدارة على تذكرتك', time: 'قبل ساعتين', color: 'text-gold-600' },
          ].map((a, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl bg-cream-100 flex items-center justify-center flex-shrink-0 ${a.color}`}>
                <a.icon className="w-4.5 h-4.5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-navy-700 font-tajawal">{a.text}</p>
                <p className="text-xs text-navy-400 font-tajawal">{a.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

interface OverviewMenuItem {
  icon: typeof Edit3;
  label: string;
  desc: string;
  color: string;
  to?: string;
  action?: () => void;
}

function OverviewMenuItem({ item }: { item: OverviewMenuItem }) {
  const content = (
    <div className="flex items-center gap-4">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${item.color}`}>
        <item.icon className="w-5 h-5" />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-cairo font-bold text-navy-900">{item.label}</h3>
        <p className="text-xs text-navy-500 font-tajawal">{item.desc}</p>
      </div>
      <ChevronLeft className="w-5 h-5 text-navy-300 group-hover:text-gold-600 transition-colors" />
    </div>
  );

  if (item.to) {
    return (
      <Link to={item.to} className="block bg-white rounded-2xl p-4 shadow-soft border border-cream-200/60 hover:shadow-luxe hover:border-gold-300 transition-all group">
        {content}
      </Link>
    );
  }
  return (
    <button onClick={item.action} className="w-full text-right bg-white rounded-2xl p-4 shadow-soft border border-cream-200/60 hover:shadow-luxe hover:border-gold-300 transition-all group no-tap-highlight">
      {content}
    </button>
  );
}

/* ===== Subscription Tab ===== */
function SubscriptionTab({ currentPlan, plans }: { currentPlan: string; plans: Plan[] }) {
  const plan = plans.find(p => p.id === (currentPlan === 'gold' ? 'premium' : currentPlan === 'elite' ? 'elite' : 'free')) || plans[1];
  const renewalDate = '15 فبراير 2025';

  return (
    <div className="space-y-4">
      {/* Current plan card */}
      <div className="bg-navy-gradient rounded-3xl p-6 relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-gold-500/20 rounded-full blur-3xl" />
        <div className="relative">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Crown className="w-6 h-6 text-gold-300" />
              <span className="font-cairo font-bold text-white text-lg">باقتك الحالية</span>
            </div>
            <span className="px-3 py-1 rounded-full bg-gold-gradient text-navy-900 text-xs font-cairo font-bold">
              {plan.name}
            </span>
          </div>
          <div className="space-y-2 text-sm font-tajawal text-cream-200/80">
            <div className="flex items-center justify-between">
              <span>تاريخ التجديد</span>
              <span className="text-white font-semibold">{renewalDate}</span>
            </div>
            <div className="flex items-center justify-between">
              <span>السعر</span>
              <span className="text-white font-semibold">{plan.price} ر.س / شهريًا</span>
            </div>
          </div>
          <div className="mt-5 flex gap-2">
            <Link to="/checkout/gold" className="flex-1 text-center py-2.5 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold text-sm">
              تجديد الاشتراك
            </Link>
            <Link to="/plans" className="flex-1 text-center py-2.5 rounded-xl bg-white/10 border border-white/20 text-white font-cairo font-bold text-sm hover:bg-white/15 transition-colors">
              ترقية الباقة
            </Link>
          </div>
        </div>
      </div>

      {/* Payment history */}
      <div className="bg-white rounded-2xl p-5 shadow-soft border border-cream-200/60">
        <h3 className="font-cairo font-bold text-navy-900 mb-4 flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-gold-600" /> سجل المدفوعات
        </h3>
        <div className="space-y-3">
          {[
            { desc: 'باقة ذهبية - شهري', amount: 99, date: '15 يناير 2025', status: 'مدفوع' },
            { desc: 'باقة ذهبية - شهري', amount: 99, date: '15 ديسمبر 2024', status: 'مدفوع' },
            { desc: 'باقة ذهبية - شهري', amount: 99, date: '15 نوفمبر 2024', status: 'مدفوع' },
          ].map((p, i) => (
            <div key={i} className="flex items-center justify-between gap-3 py-2 border-b border-cream-100 last:border-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 flex items-center justify-center flex-shrink-0">
                  <Check className="w-4.5 h-4.5 text-emerald-600" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-cairo font-semibold text-navy-800 truncate">{p.desc}</p>
                  <p className="text-xs text-navy-400 font-tajawal">{p.date}</p>
                </div>
              </div>
              <div className="text-left flex-shrink-0">
                <p className="font-cairo font-bold text-navy-900 text-sm">{p.amount} ر.س</p>
                <p className="text-[10px] text-emerald-600 font-tajawal">{p.status}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ===== Requests Tab ===== */
function RequestsTab() {
  const [filter, setFilter] = useState<'received' | 'sent'>('received');
  const [requests, setRequests] = useState(INTEREST_REQUESTS);

  const filtered = requests.filter(r => r.type === filter);
  const receivedPending = requests.filter(r => r.type === 'received' && r.status === 'pending').length;

  const handleAction = (id: string, action: 'accepted' | 'declined') => {
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: action } : r));
  };

  return (
    <div className="space-y-4">
      {/* Mediation note */}
      <div className="bg-gold-300/10 rounded-2xl p-3 border border-gold-500/20 flex items-start gap-2">
        <ShieldCheck className="w-4 h-4 text-gold-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-navy-600 font-tajawal">جميع الطلبات تُعالج عبر فريق الإدارة بسرية تامة</p>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2">
        <button
          onClick={() => setFilter('received')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-cairo font-semibold text-sm transition-all ${
            filter === 'received' ? 'bg-navy-900 text-white shadow-soft' : 'bg-white text-navy-600 border border-cream-200'
          }`}
        >
          <Inbox className="w-4 h-4" /> الواردة
          {receivedPending > 0 && <span className="bg-rose-deep text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">{receivedPending}</span>}
        </button>
        <button
          onClick={() => setFilter('sent')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-cairo font-semibold text-sm transition-all ${
            filter === 'sent' ? 'bg-navy-900 text-white shadow-soft' : 'bg-white text-navy-600 border border-cream-200'
          }`}
        >
          <Send className="w-4 h-4" /> المُرسلة
        </button>
      </div>

      {/* Requests list */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-cream-200/60">
            <Inbox className="w-12 h-12 text-navy-200 mx-auto mb-2" />
            <p className="text-navy-500 font-tajawal">لا توجد طلبات {filter === 'received' ? 'واردة' : 'مُرسلة'}</p>
          </div>
        ) : (
          filtered.map((req) => {
            const member = getMemberById(req.memberId);
            if (!member) return null;
            const statusConfig = {
              pending: { label: 'قيد المعالجة', color: 'text-gold-600 bg-gold-300/15', icon: Clock },
              accepted: { label: 'مقبول', color: 'text-emerald-600 bg-emerald-50', icon: CheckCheck },
              declined: { label: 'غير متوافق', color: 'text-rose-deep bg-rose-50', icon: X },
            };
            const sc = statusConfig[req.status];
            return (
              <div key={req.id} className="bg-white rounded-2xl p-4 shadow-soft border border-cream-200/60">
                <div className="flex items-start gap-3">
                  <Link to={`/member/${member.id}`} className="flex-shrink-0">
                    <img src={getAvatar(member.gender)} alt="" className="w-14 h-14 rounded-2xl object-contain bg-cream-100 p-1.5" />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <Link to={`/member/${member.id}`} className="font-cairo font-bold text-navy-900 hover:text-gold-700 transition-colors">
                        {member.nickname}
                      </Link>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${sc.color} flex items-center gap-1`}>
                        <sc.icon className="w-3 h-3" /> {sc.label}
                      </span>
                    </div>
                    <p className="text-sm text-navy-600 font-tajawal leading-relaxed mb-2">{req.message}</p>
                    <p className="text-xs text-navy-400 font-tajawal mb-3">{req.time}</p>

                    {req.type === 'received' && req.status === 'pending' && (
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleAction(req.id, 'accepted')}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-cairo font-bold hover:bg-emerald-700 transition-colors"
                        >
                          <Check className="w-4 h-4" /> قبول
                        </button>
                        <button
                          onClick={() => handleAction(req.id, 'declined')}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cream-100 text-navy-600 text-sm font-cairo font-bold hover:bg-cream-200 transition-colors"
                        >
                          <X className="w-4 h-4" /> رفض
                        </button>
                      </div>
                    )}
                    {req.type === 'received' && req.status === 'accepted' && (
                      <Link to="/admin-chat" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-navy-900 text-white text-sm font-cairo font-bold hover:bg-navy-800 transition-colors">
                        <Headphones className="w-4 h-4" /> تواصل مع الإدارة
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

/* ===== Notifications Tab ===== */
function NotificationsTab() {
  const { showToast } = useApp();
  const [notifs, setNotifs] = useState([
    { id: 'n1', type: 'like', text: 'تم استلام طلب اهتمام جديد', time: 'قبل 5 دقائق', memberId: 'm2', read: false },
    { id: 'n2', type: 'admin', text: 'رسالة جديدة من فريق الإدارة', time: 'قبل 20 دقيقة', memberId: 'm3', read: false },
    { id: 'n3', type: 'visit', text: 'تمت مشاهدة ملفك 3 مرات اليوم', time: 'قبل ساعة', memberId: 'm4', read: false },
    { id: 'n4', type: 'verification', text: 'تم توثيق حسابك بنجاح ✓', time: 'قبل 3 ساعات', read: true },
  ]);

  const icons = {
    like: { icon: Heart, color: 'text-rose-deep bg-rose-deep/10' },
    admin: { icon: Headphones, color: 'text-gold-600 bg-gold-300/15' },
    visit: { icon: Eye, color: 'text-navy-600 bg-navy-900/10' },
    verification: { icon: ShieldCheck, color: 'text-emerald-600 bg-emerald-50' },
  };

  const removeNotif = (id: string) => {
    setNotifs((prev) => prev.filter((n) => n.id !== id));
    showToast('تم حذف الإشعار', 'info');
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-navy-600 font-tajawal">{notifs.filter(n => !n.read).length} إشعار غير مقروء</p>
        <Link to="/notifications" className="flex items-center gap-1 text-sm text-gold-700 font-cairo font-bold hover:gap-2 transition-all">
          عرض الكل <ChevronLeft className="w-4 h-4" />
        </Link>
      </div>

      <div className="space-y-2">
        {notifs.map((n) => {
          const cfg = icons[n.type as keyof typeof icons] || icons.admin;
          const Icon = cfg.icon;
          const member = n.memberId ? getMemberById(n.memberId) : null;
          return (
            <div
              key={n.id}
              className={`group relative bg-white rounded-2xl shadow-soft border overflow-hidden ${
                !n.read ? 'border-gold-300/40 ring-1 ring-gold-300/20' : 'border-cream-200/60'
              }`}
            >
              <div className="flex items-center gap-3 p-3">
                <div className="relative flex-shrink-0">
                  {member ? (
                    <img src={getAvatar(member.gender)} alt="" className="w-11 h-11 rounded-full object-contain bg-cream-100 p-1" />
                  ) : (
                    <div className="w-11 h-11 rounded-full bg-cream-100" />
                  )}
                  <div className={`absolute -bottom-1 -left-1 w-6 h-6 rounded-full flex items-center justify-center ring-2 ring-white ${cfg.color}`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                </div>
                <Link to={member ? `/member/${member.id}` : '/notifications'} className="flex-1 min-w-0">
                  <p className={`font-tajawal text-sm leading-snug ${!n.read ? 'text-navy-900 font-semibold' : 'text-navy-700'}`}>{n.text}</p>
                  <p className="text-xs text-navy-400 font-tajawal mt-0.5">{n.time}</p>
                </Link>
                {!n.read && <span className="w-2.5 h-2.5 rounded-full bg-gold-500 flex-shrink-0" />}
                <button
                  onClick={() => removeNotif(n.id)}
                  className="w-8 h-8 rounded-full bg-cream-100 hover:bg-rose-50 flex items-center justify-center text-navy-400 hover:text-rose-deep transition-colors flex-shrink-0"
                  aria-label="حذف"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              {!n.read && <div className="absolute top-0 right-0 bottom-0 w-1 bg-gold-gradient" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ===== Settings Tab ===== */
function SettingsTab({ onLogout }: { onLogout: () => void }) {
  const { showToast } = useApp();
  const [notifSettings, setNotifSettings] = useState({
    likes: true, messages: true, visits: false, marketing: false,
  });

  const Toggle = ({ checked, onChange }: { checked: boolean; onChange: () => void }) => (
    <button
      onClick={onChange}
      className={`w-12 h-7 rounded-full transition-colors relative flex-shrink-0 ${checked ? 'bg-gold-gradient' : 'bg-cream-200'}`}
    >
      <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${checked ? 'right-1' : 'right-6'}`} />
    </button>
  );

  const handleToggle = (key: keyof typeof notifSettings) => {
    setNotifSettings(prev => ({ ...prev, [key]: !prev[key] }));
    showToast('تم تحديث إعدادات الإشعارات', 'success');
  };

  return (
    <div className="space-y-4">
      {/* Account info */}
      <div className="bg-white rounded-2xl p-5 shadow-soft border border-cream-200/60">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-cairo font-bold text-navy-900">معلومات الحساب</h3>
          <Link to="/profile/edit" className="text-xs text-gold-700 font-cairo font-bold hover:underline">تعديل</Link>
        </div>
        <div className="space-y-3">
          {[
            { label: 'البريد الإلكتروني', value: 'demo@tawasul.sa', icon: Settings },
            { label: 'رقم الجوال', value: '+966 50 123 4567', icon: Settings },
            { label: 'المدينة', value: 'الرياض', icon: Settings },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between py-2 border-b border-cream-100 last:border-0">
              <span className="text-sm text-navy-500 font-tajawal">{item.label}</span>
              <span className="text-sm font-cairo font-semibold text-navy-900">{item.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Quick links */}
      <div className="bg-white rounded-2xl p-5 shadow-soft border border-cream-200/60">
        <h3 className="font-cairo font-bold text-navy-900 mb-4">روابط سريعة</h3>
        <div className="space-y-1">
          {[
            { icon: Lock, label: 'سياسة الخصوصية', to: '/privacy', color: 'text-navy-600' },
            { icon: ShieldCheck, label: 'الشروط والأحكام', to: '/terms', color: 'text-sky-600' },
            { icon: Headphones, label: 'الدعم الفني', to: '/support', color: 'text-gold-600' },
            { icon: Sparkles, label: 'ادعُ صديقًا', action: () => showToast('رابط الدعوة تم نسخه ✓', 'success'), color: 'text-rose-deep' },
          ].map((item) => {
            const inner = (
              <>
                <item.icon className={`w-4.5 h-4.5 ${item.color}`} />
                <span className="flex-1 font-cairo font-semibold text-sm text-navy-800">{item.label}</span>
                <ChevronLeft className="w-4 h-4 text-navy-300" />
              </>
            );
            return item.to ? (
              <Link key={item.label} to={item.to} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-cream-100 transition-colors">{inner}</Link>
            ) : (
              <button key={item.label} onClick={item.action} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-cream-100 transition-colors text-right no-tap-highlight">{inner}</button>
            );
          })}
        </div>
      </div>

      {/* Notification settings */}
      <div className="bg-white rounded-2xl p-5 shadow-soft border border-cream-200/60">
        <h3 className="font-cairo font-bold text-navy-900 mb-4">إعدادات الإشعارات</h3>
        <div className="space-y-1">
          {[
            { key: 'likes' as const, label: 'الإعجابات', desc: 'عندما يعجب شخص بملفك' },
            { key: 'messages' as const, label: 'رسائل الإدارة', desc: 'عند استقبال رسالة جديدة' },
            { key: 'visits' as const, label: 'الزيارات', desc: 'عند زيارة ملفك' },
            { key: 'marketing' as const, label: 'العروض والخصومات', desc: 'أخبار الباقات والميزات' },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between gap-3 py-2.5">
              <div className="flex-1 min-w-0">
                <p className="font-cairo font-semibold text-navy-800 text-sm">{item.label}</p>
                <p className="text-xs text-navy-400 font-tajawal">{item.desc}</p>
              </div>
              <Toggle checked={notifSettings[item.key]} onChange={() => handleToggle(item.key)} />
            </div>
          ))}
        </div>
      </div>

      {/* Danger zone */}
      <button
        onClick={onLogout}
        className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl bg-white border-2 border-rose-deep/20 text-rose-deep font-cairo font-bold hover:bg-rose-deep/5 transition-colors active:scale-[0.98]"
      >
        <LogOut className="w-5 h-5" /> تسجيل الخروج
      </button>
    </div>
  );
}
