import { useState } from 'react';
import { Edit3, Crown, Check, MessageSquare, Heart, ShieldAlert, Key } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import Modal from '../../components/ui/Modal';
import type { Plan } from '../../lib/types';

export default function AdminPlans() {
  const { plans, updatePlan } = useApp();
  const [editing, setEditing] = useState<Plan | null>(null);

  const getLimitText = (num: number | undefined) => {
    if (num === undefined) return 'غير محدد';
    if (num >= 999) return 'بلا حدود';
    return `${num} رسالة`;
  };

  const getRequestText = (num: number | undefined) => {
    if (num === undefined) return 'غير محدد';
    if (num >= 99) return 'بلا حدود';
    return `${num} طلب/يومياً`;
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900">الباقات والأسعار والحدود التشغيلية</h2>
        <p className="text-sm text-slate-500 font-tajawal">تحكم في باقات الاشتراك، أسعارها، وميزاتها، بالإضافة إلى حدود وخيارات التوافق والتواصل الخاصة بكل باقة.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div key={plan.id} className={`bg-white rounded-2xl p-6 shadow-sm border-2 relative flex flex-col justify-between ${plan.popular ? 'border-amber-400' : 'border-slate-200'}`}>
            <div>
              {plan.popular && (
                <span className="inline-block px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-cairo font-bold mb-3">الأكثر شعبية</span>
              )}
              <div className="flex items-center gap-2 mb-2">
                <Crown className="w-5 h-5 text-amber-500" />
                <h3 className="font-cairo font-bold text-lg text-slate-900">{plan.name}</h3>
              </div>
              <div className="mb-4">
                <span className="font-cairo font-extrabold text-3xl text-slate-900">{plan.price}</span>
                <span className="text-slate-500 font-tajawal text-sm"> ر.س / {plan.period}</span>
              </div>
              <p className="text-sm text-slate-500 font-tajawal mb-4">{plan.description}</p>

              {/* operational limits bento */}
              <div className="bg-slate-50 rounded-xl p-3.5 mb-5 space-y-2.5 border border-slate-100">
                <div className="flex items-center justify-between text-xs font-tajawal">
                  <span className="text-slate-400 flex items-center gap-1">
                    <MessageSquare className="w-3.5 h-3.5 text-slate-400" /> حد الرسائل:
                  </span>
                  <span className="font-bold text-slate-700">{getLimitText(plan.messagesLimit)}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-tajawal">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-slate-400" /> حد طلبات الاهتمام:
                  </span>
                  <span className="font-bold text-slate-700">{getRequestText(plan.requestsLimit)}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-tajawal">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Key className="w-3.5 h-3.5 text-slate-400" /> حد استخدام البحث المتقدم:
                  </span>
                  <span className="font-bold text-slate-700">
                    {plan.searchLimit !== undefined && plan.searchLimit >= 999 ? 'بلا حدود' : `${plan.searchLimit || 0} مرات/يوم`}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs font-tajawal">
                  <span className="text-slate-400 flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-slate-400" /> صلاحية الباقة:
                  </span>
                  <span className="font-bold text-slate-700">{plan.durationDays || 30} يوماً</span>
                </div>
                <div className="flex items-center justify-between text-xs font-tajawal">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Key className="w-3.5 h-3.5 text-slate-400" /> فلاتر بحث متقدمة:
                  </span>
                  <span className={`font-bold ${plan.advancedFilters ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {plan.advancedFilters ? 'متاحة ✓' : 'حساب عالي فقط'}
                  </span>
                </div>
              </div>

              <div className="space-y-2 mb-5 border-t border-slate-100 pt-4">
                <p className="text-xs font-cairo font-bold text-slate-400 mb-2">قائمة الميزات المعروضة للعميل:</p>
                {plan.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-emerald-50 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-emerald-600" />
                    </div>
                    <span className="text-xs text-slate-600 font-tajawal">{f}</span>
                  </div>
                ))}
              </div>
            </div>

            <button onClick={() => setEditing(plan)} className="w-full mt-2 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors">
              <Edit3 className="w-4 h-4" /> تعديل ميزات وحدود الباقة
            </button>
          </div>
        ))}
      </div>

      <Modal open={!!editing} onClose={() => setEditing(null)} title="تعديل الباقة والحدود" size="lg">
        {editing && (
          <PlanForm plan={editing} onSave={(updated) => {
            updatePlan(updated);
            setEditing(null);
          }} />
        )}
      </Modal>
    </div>
  );
}

interface PlanFormProps {
  plan: Plan;
  onSave: (p: Plan) => void;
}

function PlanForm({ plan, onSave }: PlanFormProps) {
  const [form, setForm] = useState<Plan>({ ...plan });
  const [newFeature, setNewFeature] = useState('');

  const inputClass = "w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm";
  const labelClass = "block text-xs font-cairo font-bold text-slate-700 mb-1.5";

  return (
    <div className="space-y-4 text-right" dir="rtl">
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>اسم الباقة</label>
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>السعر (ر.س)</label>
          <input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>الفترة</label>
          <input value={form.period} onChange={(e) => setForm({ ...form, period: e.target.value })} className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>الوصف القصير</label>
          <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={inputClass} />
        </div>
      </div>

      {/* Limits inputs */}
      <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-100 space-y-3">
        <h4 className="text-sm font-cairo font-bold text-amber-900 flex items-center gap-1.5">
          <ShieldAlert className="w-4 h-4 text-amber-600" /> الحدود والنظام التشغيلي للباقة (يمكنك تعديلها بضغطة زر)
        </h4>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
          <div>
            <label className={labelClass}>حد الرسائل الشهرية</label>
            <input 
              type="number" 
              value={form.messagesLimit !== undefined ? form.messagesLimit : 5} 
              onChange={(e) => setForm({ ...form, messagesLimit: Number(e.target.value) })} 
              className={inputClass} 
              placeholder="مثال: 100" 
            />
            <p className="text-[10px] text-slate-400 font-tajawal mt-1">أدخل 999 لباقة بلا حدود</p>
          </div>
          <div>
            <label className={labelClass}>طلب اهتمام يومياً</label>
            <input 
              type="number" 
              value={form.requestsLimit !== undefined ? form.requestsLimit : 1} 
              onChange={(e) => setForm({ ...form, requestsLimit: Number(e.target.value) })} 
              className={inputClass}
              placeholder="مثال: 10" 
            />
            <p className="text-[10px] text-slate-400 font-tajawal mt-1">أدخل 99 لباقة بلا حدود</p>
          </div>
          <div>
            <label className={labelClass}>حد بحث متقدم بالفلاتر يومياً</label>
            <input 
              type="number" 
              value={form.searchLimit !== undefined ? form.searchLimit : 2} 
              onChange={(e) => setForm({ ...form, searchLimit: Number(e.target.value) })} 
              className={inputClass}
              placeholder="مثال: 15" 
            />
            <p className="text-[10px] text-slate-400 font-tajawal mt-1">أدخل 999 لباقة بلا حدود</p>
          </div>
          <div>
            <label className={labelClass}>صلاحية الباقة (ايام)</label>
            <input 
              type="number" 
              value={form.durationDays !== undefined ? form.durationDays : 30} 
              onChange={(e) => setForm({ ...form, durationDays: Number(e.target.value) })} 
              className={inputClass}
              placeholder="مثال: 30" 
            />
            <p className="text-[10px] text-slate-400 font-tajawal mt-1">مثال: 30 لـ شهر</p>
          </div>
          <div className="flex flex-col justify-end">
            <span className={labelClass}>فلاتر البحث والمطابقة المتقدمة</span>
            <button 
              type="button"
              onClick={() => setForm({ ...form, advancedFilters: !form.advancedFilters })}
              className={`w-full py-2.5 rounded-xl border-2 transition-all font-cairo text-xs font-bold text-center flex items-center justify-center gap-1.5 ${
                form.advancedFilters 
                  ? 'bg-emerald-50 border-emerald-500 text-emerald-800' 
                  : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-amber-300'
              }`}
            >
              {form.advancedFilters ? 'تفعيل الفلاتر المتقدمة ✓' : 'تعطيل الفلاتر المتقدمة ✕'}
            </button>
          </div>
        </div>
      </div>

      <div>
        <label className={labelClass}>ميزات العرض التسويقية (تظهر بصفحة الدفع)</label>
        <div className="space-y-2 mb-2">
          {form.features.map((f, i) => (
            <div key={i} className="flex items-center gap-2">
              <input value={f} onChange={(e) => {
                const features = [...form.features];
                features[i] = e.target.value;
                setForm({ ...form, features });
              }} className={inputClass} />
              <button type="button" onClick={() => setForm({ ...form, features: form.features.filter((_, idx) => idx !== i) })} className="text-rose-500 hover:text-rose-700 p-1">✕</button>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input value={newFeature} onChange={(e) => setNewFeature(e.target.value)} placeholder="أضف ميزة جديدة للعرض..." className={inputClass} />
          <button type="button" onClick={() => { if (newFeature.trim()) { setForm({ ...form, features: [...form.features, newFeature] }); setNewFeature(''); } }} className="px-4 rounded-xl bg-slate-900 text-white font-bold">+</button>
        </div>
      </div>

      <button onClick={() => onSave(form)} className="w-full py-3 mt-4 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors">
        حفظ وتحديث هذه الباقة رسمياً
      </button>
    </div>
  );
}
