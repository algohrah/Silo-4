import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Search, MoreVertical, Eye, Edit3, Ban, CheckCircle2, Trash2,
  Mail, Phone, Lock, MapPin, ShieldCheck, Crown, Download,
} from 'lucide-react';
import { ADMIN_MEMBERS, type AdminMember } from '../../lib/admin-data';
import Modal from '../../components/ui/Modal';

export default function AdminMembers() {
  const [members, setMembers] = useState(ADMIN_MEMBERS);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended' | 'pending'>('all');
  const [filterPlan, setFilterPlan] = useState<'all' | 'free' | 'gold' | 'elite'>('all');
  const [selectedMember, setSelectedMember] = useState<AdminMember | null>(null);
  const [editMember, setEditMember] = useState<AdminMember | null>(null);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);

  const filtered = members.filter((m) => {
    const matchSearch = !search ||
      m.nickname.includes(search) ||
      m.realName.includes(search) ||
      m.email.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || m.status === filterStatus;
    const matchPlan = filterPlan === 'all' || m.plan === filterPlan;
    return matchSearch && matchStatus && matchPlan;
  });

  const handleStatusChange = (id: string, status: AdminMember['status']) => {
    setMembers(prev => prev.map(m => m.id === id ? { ...m, status } : m));
    setMenuOpen(null);
  };

  const handleDelete = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
    setMenuOpen(null);
  };

  const statusConfig = {
    active: { label: 'نشط', color: 'bg-emerald-100 text-emerald-700' },
    suspended: { label: 'موقوف', color: 'bg-rose-100 text-rose-700' },
    pending: { label: 'قيد المراجعة', color: 'bg-amber-100 text-amber-700' },
  };

  const planConfig = {
    free: { label: 'مجاني', color: 'bg-slate-100 text-slate-600' },
    gold: { label: 'ذهبي', color: 'bg-amber-100 text-amber-700' },
    elite: { label: 'نخبة', color: 'bg-purple-100 text-purple-700' },
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">إدارة الأعضاء</h2>
          <p className="text-sm text-slate-500 font-tajawal">{members.length} عضو مسجّل</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors">
          <Download className="w-4 h-4" /> تصدير القائمة
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالاسم المستعار أو الحقيقي أو البريد..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {(['all', 'active', 'pending', 'suspended'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-semibold transition-colors ${
                filterStatus === s ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {s === 'all' ? 'الكل' : statusConfig[s].label}
            </button>
          ))}
          <div className="w-px bg-slate-200 mx-1" />
          {(['all', 'free', 'gold', 'elite'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setFilterPlan(p)}
              className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-semibold transition-colors ${
                filterPlan === p ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {p === 'all' ? 'كل الباقات' : planConfig[p].label}
            </button>
          ))}
        </div>
      </div>

      {/* Members table - Desktop */}
      <div className="hidden lg:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">العضو</th>
              <th className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">البريد</th>
              <th className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">الباقة</th>
              <th className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">الحالة</th>
              <th className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">انضم في</th>
              <th className="text-center px-5 py-3 text-xs font-cairo font-bold text-slate-500">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filtered.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
                      {m.nickname.charAt(0)}
                    </div>
                    <div>
                      <div className="font-cairo font-semibold text-slate-900 text-sm flex items-center gap-1">
                        {m.nickname}
                        {m.verified && <ShieldCheck className="w-3.5 h-3.5 text-sky-500" />}
                      </div>
                      <div className="text-xs text-slate-400 font-tajawal">{m.realName}</div>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-sm text-slate-600 font-tajawal">{m.email}</td>
                <td className="px-5 py-3">
                  <span className={`px-2 py-1 rounded-md text-xs font-cairo font-bold ${planConfig[m.plan].color}`}>{planConfig[m.plan].label}</span>
                </td>
                <td className="px-5 py-3">
                  <span className={`px-2 py-1 rounded-md text-xs font-cairo font-bold ${statusConfig[m.status].color}`}>{statusConfig[m.status].label}</span>
                </td>
                <td className="px-5 py-3 text-sm text-slate-500 font-tajawal">{m.joinedAt}</td>
                <td className="px-5 py-3">
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => setSelectedMember(m)} className="p-2 rounded-lg hover:bg-blue-50 text-slate-500 hover:text-blue-600 transition-colors" title="عرض">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button onClick={() => setEditMember(m)} className="p-2 rounded-lg hover:bg-amber-50 text-slate-500 hover:text-amber-600 transition-colors" title="تعديل">
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <div className="relative">
                      <button onClick={() => setMenuOpen(menuOpen === m.id ? null : m.id)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 transition-colors">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                      {menuOpen === m.id && (
                        <div className="absolute left-0 top-full mt-1 w-44 bg-white rounded-xl shadow-lg border border-slate-200 py-1 z-10">
                          {m.status !== 'suspended' ? (
                            <button onClick={() => handleStatusChange(m.id, 'suspended')} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50 font-cairo font-semibold">
                              <Ban className="w-4 h-4" /> إيقاف العضو
                            </button>
                          ) : (
                            <button onClick={() => handleStatusChange(m.id, 'active')} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-emerald-600 hover:bg-emerald-50 font-cairo font-semibold">
                              <CheckCircle2 className="w-4 h-4" /> تفعيل العضو
                            </button>
                          )}
                          <button onClick={() => handleDelete(m.id)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50 font-cairo font-semibold">
                            <Trash2 className="w-4 h-4" /> حذف نهائي
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Members cards - Mobile */}
      <div className="lg:hidden space-y-3">
        {filtered.map((m) => (
          <div key={m.id} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200">
            <div className="flex items-start gap-3">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${m.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
                {m.nickname.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-cairo font-bold text-slate-900">{m.nickname}</span>
                  {m.verified && <ShieldCheck className="w-4 h-4 text-sky-500" />}
                </div>
                <p className="text-xs text-slate-400 font-tajawal">{m.realName}</p>
                <p className="text-xs text-slate-500 font-tajawal truncate">{m.email}</p>
                <div className="flex gap-1.5 mt-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-cairo font-bold ${planConfig[m.plan].color}`}>{planConfig[m.plan].label}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-cairo font-bold ${statusConfig[m.status].color}`}>{statusConfig[m.status].label}</span>
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-3">
              <button onClick={() => setSelectedMember(m)} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-blue-50 text-blue-600 text-sm font-cairo font-bold">
                <Eye className="w-4 h-4" /> عرض
              </button>
              <button onClick={() => setEditMember(m)} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-amber-50 text-amber-600 text-sm font-cairo font-bold">
                <Edit3 className="w-4 h-4" /> تعديل
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* View Member Modal */}
      <Modal open={!!selectedMember} onClose={() => setSelectedMember(null)} title="تفاصيل العضو" size="lg">
        {selectedMember && <MemberDetails member={selectedMember} />}
      </Modal>

      {/* Edit Member Modal */}
      <Modal open={!!editMember} onClose={() => setEditMember(null)} title="تعديل بيانات العضو" size="lg">
        {editMember && (
          <EditMemberForm
            member={editMember}
            onSave={(updated) => {
              setMembers(prev => prev.map(m => m.id === updated.id ? updated : m));
              setEditMember(null);
            }}
          />
        )}
      </Modal>
    </div>
  );
}

/* ===== Member Details View ===== */
function MemberDetails({ member }: { member: AdminMember }) {
  const [showPassword, setShowPassword] = useState(false);

  interface FieldDef {
    label: string;
    value: string;
    icon: typeof Mail | null;
    action?: () => void;
    actionLabel?: string;
  }

  const sections: { title: string; icon: typeof Lock; color: string; fields: FieldDef[] }[] = [
    {
      title: 'معلومات الحساب الحساسة', icon: Lock, color: 'text-rose-600 bg-rose-50',
      fields: [
        { label: 'الاسم الحقيقي', value: member.realName, icon: null },
        { label: 'البريد الإلكتروني', value: member.email, icon: Mail },
        { label: 'رقم الجوال', value: member.phone, icon: Phone },
        { label: 'كلمة المرور', value: showPassword ? member.password : '••••••••', icon: Lock, action: () => setShowPassword(!showPassword), actionLabel: showPassword ? 'إخفاء' : 'إظهار' },
      ],
    },
    {
      title: 'المعلومات الأساسية', icon: MapPin, color: 'text-blue-600 bg-blue-50',
      fields: [
        { label: 'الاسم المستعار', value: member.nickname, icon: null },
        { label: 'الجنس', value: member.gender === 'male' ? 'ذكر' : 'أنثى', icon: null },
        { label: 'العمر', value: `${member.age} سنة`, icon: null },
        { label: 'الدولة', value: member.country, icon: null },
        { label: 'المدينة', value: member.city, icon: null },
        { label: 'المنطقة', value: member.district || 'غير محدد', icon: null },
      ],
    },
    {
      title: 'الصفات الشخصية', icon: ShieldCheck, color: 'text-emerald-600 bg-emerald-50',
      fields: [
        { label: 'الطول', value: `${member.height} سم`, icon: null },
        { label: 'الوزن', value: `${member.weight} كجم`, icon: null },
        { label: 'لون البشرة', value: member.skinColor, icon: null },
        { label: 'الحالة الصحية', value: member.health, icon: null },
        { label: 'التدخين', value: member.smoking, icon: null },
      ],
    },
    {
      title: 'التعليم والعمل', icon: Crown, color: 'text-amber-600 bg-amber-50',
      fields: [
        { label: 'المؤهل', value: member.education, icon: null },
        { label: 'جهة العمل', value: member.workType, icon: null },
        { label: 'نوع السكن', value: member.housing, icon: null },
      ],
    },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl">
        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-2xl ${member.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
          {member.nickname.charAt(0)}
        </div>
        <div className="flex-1">
          <h3 className="font-cairo font-bold text-lg text-slate-900 flex items-center gap-1.5">
            {member.nickname}
            {member.verified && <ShieldCheck className="w-5 h-5 text-sky-500" />}
          </h3>
          <p className="text-sm text-slate-500 font-tajawal">{member.realName}</p>
        </div>
      </div>

      {sections.map((section) => {
        const SectionIcon = section.icon;
        return (
          <div key={section.title}>
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${section.color}`}>
                <SectionIcon className="w-4 h-4" />
              </div>
              <h4 className="font-cairo font-bold text-slate-900 text-sm">{section.title}</h4>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              {section.fields.map((field) => {
                const FieldIcon = field.icon;
                return (
                  <div key={field.label} className="flex items-center justify-between gap-2 px-3 py-2.5 bg-slate-50 rounded-xl">
                    <span className="text-xs text-slate-500 font-tajawal">{field.label}</span>
                    <div className="flex items-center gap-2">
                      {FieldIcon && <FieldIcon className="w-3.5 h-3.5 text-slate-400" />}
                      <span className="text-sm font-cairo font-semibold text-slate-900">{field.value}</span>
                      {field.action && (
                        <button onClick={field.action} className="text-[10px] text-amber-600 font-cairo font-bold hover:underline">{field.actionLabel}</button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}

      <div className="space-y-3">
        <div className="bg-slate-50 rounded-xl p-4">
          <h4 className="font-cairo font-bold text-slate-900 text-sm mb-1">نبذة عني</h4>
          <p className="text-sm text-slate-600 font-tajawal leading-relaxed">{member.bio}</p>
        </div>
        <div className="bg-slate-50 rounded-xl p-4">
          <h4 className="font-cairo font-bold text-slate-900 text-sm mb-1">وصف الشريك المطلوب</h4>
          <p className="text-sm text-slate-600 font-tajawal leading-relaxed">{member.aboutPartner}</p>
        </div>
      </div>
    </div>
  );
}

/* ===== Edit Member Form ===== */
function EditMemberForm({ member, onSave }: { member: AdminMember; onSave: (m: AdminMember) => void }) {
  const [form, setForm] = useState(member);

  const update = (key: keyof AdminMember, value: string | number | boolean) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

  const inputClass = "w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm";
  const labelClass = "block text-xs font-cairo font-bold text-slate-700 mb-1.5";

  return (
    <div className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>الاسم الحقيقي</label>
          <input value={form.realName} onChange={(e) => update('realName', e.target.value)} className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>الاسم المستعار</label>
          <input value={form.nickname} onChange={(e) => update('nickname', e.target.value)} className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>البريد الإلكتروني</label>
          <input value={form.email} onChange={(e) => update('email', e.target.value)} className={inputClass} dir="ltr" />
        </div>
        <div>
          <label className={labelClass}>رقم الجوال</label>
          <input value={form.phone} onChange={(e) => update('phone', e.target.value)} className={inputClass} dir="ltr" />
        </div>
        <div>
          <label className={labelClass}>كلمة المرور</label>
          <input value={form.password} onChange={(e) => update('password', e.target.value)} className={inputClass} dir="ltr" />
        </div>
        <div>
          <label className={labelClass}>العمر</label>
          <input type="number" value={form.age} onChange={(e) => update('age', Number(e.target.value))} className={inputClass} />
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>حالة الحساب</label>
          <select value={form.status} onChange={(e) => update('status', e.target.value as AdminMember['status'])} className={inputClass}>
            <option value="active">نشط</option>
            <option value="pending">قيد المراجعة</option>
            <option value="suspended">موقوف</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>الباقة</label>
          <select value={form.plan} onChange={(e) => update('plan', e.target.value as AdminMember['plan'])} className={inputClass}>
            <option value="free">مجاني</option>
            <option value="gold">ذهبي</option>
            <option value="elite">نخبة</option>
          </select>
        </div>
      </div>

      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
        <span className="text-sm font-cairo font-semibold text-slate-700">حالة التوثيق</span>
        <button
          onClick={() => update('verified', !form.verified)}
          className={`w-12 h-7 rounded-full transition-colors relative ${form.verified ? 'bg-emerald-500' : 'bg-slate-300'}`}
        >
          <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${form.verified ? 'right-1' : 'right-6'}`} />
        </button>
      </div>

      <button
        onClick={() => onSave(form)}
        className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors"
      >
        حفظ التغييرات
      </button>
    </div>
  );
}
