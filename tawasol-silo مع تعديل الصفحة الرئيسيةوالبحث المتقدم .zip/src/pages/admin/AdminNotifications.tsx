import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Users, Crown, ShieldCheck, Check, Bell } from 'lucide-react';
import { ADMIN_NOTIFICATIONS } from '../../lib/admin-data';

export default function AdminNotifications() {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [audience, setAudience] = useState<'all' | 'verified' | 'premium' | 'specific'>('all');
  const [sent, setSent] = useState(ADMIN_NOTIFICATIONS);

  const audienceConfig = {
    all: { label: 'جميع الأعضاء', icon: Users, count: 154320, color: 'bg-slate-100 text-slate-700' },
    verified: { label: 'الأعضاء الموثقون', icon: ShieldCheck, count: 98450, color: 'bg-sky-100 text-sky-700' },
    premium: { label: 'الأعضاء المميزون', icon: Crown, count: 12450, color: 'bg-amber-100 text-amber-700' },
    specific: { label: 'أعضاء محددون', icon: Users, count: 0, color: 'bg-purple-100 text-purple-700' },
  };

  const handleSend = () => {
    if (!title.trim() || !message.trim()) return;
    setSent(prev => [{
      id: 'an' + Date.now(), title, message, audience,
      sentAt: 'الآن', recipients: audienceConfig[audience].count,
    }, ...prev]);
    setTitle('');
    setMessage('');
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900">إرسال إشعارات</h2>
        <p className="text-sm text-slate-500 font-tajawal">أرسل إشعارات فورية للأعضاء</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        {/* Compose */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-4">
          <h3 className="font-cairo font-bold text-slate-900 flex items-center gap-2">
            <Send className="w-5 h-5 text-amber-500" /> إنشاء إشعار جديد
          </h3>

          <div>
            <label className="block text-xs font-cairo font-bold text-slate-700 mb-2">الجمهور المستهدف</label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.keys(audienceConfig) as Array<keyof typeof audienceConfig>).map((key) => {
                const cfg = audienceConfig[key];
                const Icon = cfg.icon;
                return (
                  <button
                    key={key}
                    onClick={() => setAudience(key)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border-2 transition-all text-right ${
                      audience === key ? 'border-amber-400 bg-amber-50' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${cfg.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-cairo font-bold text-slate-900 truncate">{cfg.label}</p>
                      <p className="text-[10px] text-slate-400 font-tajawal">{cfg.count.toLocaleString('ar-EG')} عضو</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-xs font-cairo font-bold text-slate-700 mb-2">عنوان الإشعار</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: تحديث جديد في المنصة"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-cairo font-bold text-slate-700 mb-2">نص الإشعار</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              placeholder="اكتب رسالتك هنا..."
              className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm resize-none"
            />
          </div>

          <button
            onClick={handleSend}
            disabled={!title.trim() || !message.trim()}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-4 h-4 -scale-x-100" /> إرسال للجميع ({audienceConfig[audience].count.toLocaleString('ar-EG')})
          </button>
        </div>

        {/* Sent history */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100">
            <h3 className="font-cairo font-bold text-slate-900 flex items-center gap-2">
              <Bell className="w-5 h-5 text-slate-400" /> الإشعارات المُرسة
            </h3>
          </div>
          <div className="divide-y divide-slate-50 max-h-[500px] overflow-y-auto">
            {sent.map((n) => {
              const Icon = audienceConfig[n.audience].icon;
              return (
                <div key={n.id} className="p-4 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${audienceConfig[n.audience].color}`}>
                      <Icon className="w-4.5 h-4.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="font-cairo font-bold text-slate-900 text-sm">{n.title}</h4>
                        <span className="text-[10px] text-slate-400 font-tajawal whitespace-nowrap">{n.sentAt}</span>
                      </div>
                      <p className="text-xs text-slate-600 font-tajawal mt-0.5 leading-relaxed">{n.message}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-cairo font-bold ${audienceConfig[n.audience].color}`}>{audienceConfig[n.audience].label}</span>
                        <span className="text-[10px] text-emerald-600 font-cairo font-bold flex items-center gap-0.5"><Check className="w-3 h-3" /> {n.recipients.toLocaleString('ar-EG')} وصل</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
