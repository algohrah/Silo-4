import { useState } from 'react';
import { Heart, Clock, CheckCircle2, XCircle, MessageSquare } from 'lucide-react';
import { INTEREST_REQUESTS, getMemberById } from '../../lib/data';
import Modal from '../../components/ui/Modal';

export default function AdminRequests() {
  const [requests, setRequests] = useState(INTEREST_REQUESTS);
  const [filter, setFilter] = useState<'all' | 'pending' | 'accepted' | 'declined'>('all');
  const [selected, setSelected] = useState<typeof INTEREST_REQUESTS[0] | null>(null);

  const filtered = filter === 'all' ? requests : requests.filter(r => r.status === filter);

  const handleAction = (id: string, status: 'accepted' | 'declined') => {
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status } : r));
    setSelected(null);
  };

  const statusConfig = {
    pending: { label: 'قيد الانتظار', color: 'bg-amber-100 text-amber-700', icon: Clock },
    accepted: { label: 'مقبول', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle2 },
    declined: { label: 'مرفوض', color: 'bg-rose-100 text-rose-700', icon: XCircle },
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900">طلبات الاهتمام</h2>
        <p className="text-sm text-slate-500 font-tajawal">إدارة ومتابعة طلبات الاهتمام بين الأعضاء</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {(['pending', 'accepted', 'declined'] as const).map((s) => (
          <div key={s} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 text-center">
            <div className={`w-10 h-10 rounded-xl mx-auto flex items-center justify-center mb-2 ${statusConfig[s].color}`}>
              {(() => { const Icon = statusConfig[s].icon; return <Icon className="w-5 h-5" />; })()}
            </div>
            <div className="font-cairo font-extrabold text-xl text-slate-900">{requests.filter(r => r.status === s).length}</div>
            <div className="text-xs text-slate-500 font-tajawal">{statusConfig[s].label}</div>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {(['all', 'pending', 'accepted', 'declined'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-sm font-cairo font-semibold transition-colors ${
              filter === f ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {f === 'all' ? 'الكل' : statusConfig[f].label}
          </button>
        ))}
      </div>

      {/* Requests list */}
      <div className="space-y-3">
        {filtered.map((req) => {
          const member = getMemberById(req.memberId);
          if (!member) return null;
          const sc = statusConfig[req.status];
          const StatusIcon = sc.icon;
          return (
            <div key={req.id} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200">
              <div className="flex items-start gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0 ${member.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
                  {member.nickname.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <div>
                      <span className="font-cairo font-bold text-slate-900">{member.nickname}</span>
                      <span className="text-xs text-slate-400 font-tajawal mr-2">{req.type === 'sent' ? 'طلب صادر' : 'طلب وارد'}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-cairo font-bold flex items-center gap-1 ${sc.color}`}>
                      <StatusIcon className="w-3 h-3" /> {sc.label}
                    </span>
                  </div>
                  <div className="flex items-start gap-2 p-2.5 bg-slate-50 rounded-lg mt-1">
                    <MessageSquare className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-slate-600 font-tajawal">{req.message}</p>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-slate-400 font-tajawal">{req.time}</span>
                    {req.status === 'pending' && (
                      <div className="flex gap-2">
                        <button onClick={() => handleAction(req.id, 'accepted')} className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-cairo font-bold hover:bg-emerald-700 transition-colors">قبول</button>
                        <button onClick={() => handleAction(req.id, 'declined')} className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-xs font-cairo font-bold hover:bg-slate-200 transition-colors">رفض</button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
