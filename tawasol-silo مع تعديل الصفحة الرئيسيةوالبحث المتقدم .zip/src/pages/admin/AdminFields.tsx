import { useState } from 'react';
import { Plus, Trash2, GripVertical, ToggleLeft, ToggleRight, Lock, Unlock, Edit3, X, Check, ChevronDown, ChevronUp, Settings2 } from 'lucide-react';
import { REGISTRATION_FIELDS, type RegistrationField } from '../../lib/admin-data';
import Modal from '../../components/ui/Modal';

const groupLabels = {
  basic: 'المعلومات الأساسية',
  personal: 'الصفات الشخصية',
  partner: 'مواصفات الشريك',
  contact: 'معلومات التواصل',
};

const typeLabels = {
  text: 'نص', select: 'قائمة منسدلة', number: 'رقم', textarea: 'منطقة نص',
  radio: 'اختيار واحد', checkbox: 'مربع اختيار', conditional: 'مشروط (يظهر نص)',
};

export default function AdminFields() {
  const [fields, setFields] = useState(REGISTRATION_FIELDS);
  const [adding, setAdding] = useState(false);
  const [editingField, setEditingField] = useState<RegistrationField | null>(null);
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());

  const toggleField = (id: string, key: 'required' | 'enabled') => {
    setFields(prev => prev.map(f => f.id === id ? { ...f, [key]: !f[key] } : f));
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا الحقل؟')) {
      setFields(prev => prev.filter(f => f.id !== id));
    }
  };

  const handleAdd = (field: Omit<RegistrationField, 'id'>) => {
    setFields(prev => [...prev, { ...field, id: 'f' + Date.now() }]);
    setAdding(false);
  };

  const handleEdit = (updated: RegistrationField) => {
    setFields(prev => prev.map(f => f.id === updated.id ? updated : f));
    setEditingField(null);
  };

  const toggleGroup = (group: string) => {
    setCollapsedGroups(prev => {
      const next = new Set(prev);
      if (next.has(group)) next.delete(group);
      else next.add(group);
      return next;
    });
  };

  // نقل الحقل لأعلى/أسفل
  const moveField = (id: string, dir: 'up' | 'down') => {
    setFields(prev => {
      const idx = prev.findIndex(f => f.id === id);
      if (idx === -1) return prev;
      const newIdx = dir === 'up' ? idx - 1 : idx + 1;
      if (newIdx < 0 || newIdx >= prev.length) return prev;
      const next = [...prev];
      [next[idx], next[newIdx]] = [next[newIdx], next[idx]];
      return next;
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">حقول التسجيل</h2>
          <p className="text-sm text-slate-500 font-tajawal">تحكم كامل في الحقول والخيارات — أضف، عدّل، فعّل أو عطّل</p>
        </div>
        <button onClick={() => setAdding(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors">
          <Plus className="w-4 h-4" /> حقل جديد
        </button>
      </div>

      {/* تنبيه تعليمي */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex items-start gap-2">
        <Settings2 className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-blue-700 font-tajawal leading-relaxed">
          اضغط على زر <strong>التعديل</strong> بجانب أي حقل لتغيير اسمه أو خياراته (مثل المدن، الوظائف، التعليم).
          للحقل المشروط: اختر نوع «مشروط» ليظهر للمستخدم حقل نص إضافي عند اختياره.
        </p>
      </div>

      {(['basic', 'personal', 'partner', 'contact'] as const).map((group) => {
        const groupFields = fields.filter(f => f.group === group);
        if (groupFields.length === 0) return null;
        const isCollapsed = collapsedGroups.has(group);
        return (
          <div key={group} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <button
              onClick={() => toggleGroup(group)}
              className="w-full flex items-center justify-between px-5 py-3 bg-slate-50 border-b border-slate-100 hover:bg-slate-100 transition-colors"
            >
              <h3 className="font-cairo font-bold text-slate-900 text-sm flex items-center gap-2">
                {groupLabels[group]}
                <span className="px-2 py-0.5 rounded-full bg-slate-200 text-slate-600 text-[10px]">{groupFields.length}</span>
              </h3>
              {isCollapsed ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronUp className="w-4 h-4 text-slate-400" />}
            </button>
            {!isCollapsed && (
              <div className="divide-y divide-slate-50">
                {groupFields.map((field, idx) => (
                  <div key={field.id} className="flex items-center gap-2 px-3 py-3 hover:bg-slate-50 transition-colors">
                    <div className="flex flex-col gap-0.5">
                      <button onClick={() => moveField(field.id, 'up')} disabled={idx === 0} className="text-slate-300 hover:text-slate-600 disabled:opacity-20 disabled:cursor-not-allowed">
                        <ChevronUp className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => moveField(field.id, 'down')} disabled={idx === groupFields.length - 1} className="text-slate-300 hover:text-slate-600 disabled:opacity-20 disabled:cursor-not-allowed">
                        <ChevronDown className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`font-cairo font-semibold text-slate-900 text-sm ${field.enabled ? '' : 'line-through text-slate-400'}`}>{field.label}</span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 text-[10px] font-cairo font-bold">{typeLabels[field.type]}</span>
                        {field.required && <span className="px-1.5 py-0.5 rounded bg-rose-50 text-rose-600 text-[10px] font-cairo font-bold">إلزامي</span>}
                        {field.type === 'conditional' && <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-600 text-[10px] font-cairo font-bold">يُظهر نص</span>}
                      </div>
                      {field.options && field.options.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {field.options.map((opt, i) => (
                            <span key={i} className="px-1.5 py-0.5 rounded bg-slate-50 text-slate-500 text-[10px] font-tajawal border border-slate-100">{opt}</span>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button onClick={() => setEditingField(field)} title="تعديل الحقل وخياراته" className="p-2 rounded-lg text-amber-600 bg-amber-50 hover:bg-amber-100 transition-colors">
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button onClick={() => toggleField(field.id, 'required')} title={field.required ? 'إزالة الإلزام' : 'جعله إلزامي'} className={`p-2 rounded-lg transition-colors ${field.required ? 'text-rose-600 bg-rose-50' : 'text-slate-400 hover:bg-slate-100'}`}>
                        {field.required ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                      </button>
                      <button onClick={() => toggleField(field.id, 'enabled')} title={field.enabled ? 'تعطيل الحقل' : 'تفعيل الحقل'} className={`p-2 rounded-lg transition-colors ${field.enabled ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400 hover:bg-slate-100'}`}>
                        {field.enabled ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                      </button>
                      <button onClick={() => handleDelete(field.id)} className="p-2 rounded-lg text-rose-500 hover:bg-rose-50 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}

      {/* Modal: إضافة حقل */}
      <Modal open={adding} onClose={() => setAdding(false)} title="إضافة حقل جديد" size="lg">
        <FieldForm onSave={handleAdd} />
      </Modal>

      {/* Modal: تعديل حقل */}
      <Modal open={!!editingField} onClose={() => setEditingField(null)} title="تعديل الحقل" size="lg">
        {editingField && (
          <FieldForm
            initial={editingField}
            onSave={(updated) => handleEdit({ ...updated, id: editingField.id })}
          />
        )}
      </Modal>
    </div>
  );
}

// ====================================================================
//  نموذج الحقل — يدعم الإضافة والتعديل
// ====================================================================
function FieldForm({
  initial,
  onSave,
}: {
  initial?: RegistrationField;
  onSave: (f: Omit<RegistrationField, 'id'>) => void;
}) {
  const [label, setLabel] = useState(initial?.label || '');
  const [type, setType] = useState<RegistrationField['type']>(initial?.type || 'text');
  const [required, setRequired] = useState(initial?.required || false);
  const [enabled, setEnabled] = useState(initial?.enabled ?? true);
  const [group, setGroup] = useState<RegistrationField['group']>(initial?.group || 'basic');
  const [options, setOptions] = useState<string[]>(initial?.options || []);
  const [newOption, setNewOption] = useState('');

  const inputClass = "w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm";
  const labelClass = "block text-xs font-cairo font-bold text-slate-700 mb-1.5";

  const addOption = () => {
    const val = newOption.trim();
    if (val && !options.includes(val)) {
      setOptions([...options, val]);
      setNewOption('');
    }
  };

  const removeOption = (idx: number) => {
    setOptions(options.filter((_, i) => i !== idx));
  };

  const editOption = (idx: number, value: string) => {
    setOptions(options.map((opt, i) => i === idx ? value : opt));
  };

  const hasOptions = type === 'select' || type === 'radio' || type === 'checkbox' || type === 'conditional';

  return (
    <div className="space-y-4">
      <div>
        <label className={labelClass}>اسم الحقل</label>
        <input value={label} onChange={(e) => setLabel(e.target.value)} className={inputClass} placeholder="مثال: الحالة الاجتماعية" />
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>نوع الحقل</label>
          <select value={type} onChange={(e) => setType(e.target.value as RegistrationField['type'])} className={inputClass}>
            <option value="text">نص</option>
            <option value="select">قائمة منسدلة</option>
            <option value="radio">اختيار واحد</option>
            <option value="checkbox">مربعات اختيار</option>
            <option value="number">رقم</option>
            <option value="textarea">منطقة نص</option>
            <option value="conditional">مشروط (يُظهر حقل نص)</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>القسم</label>
          <select value={group} onChange={(e) => setGroup(e.target.value as RegistrationField['group'])} className={inputClass}>
            <option value="basic">المعلومات الأساسية</option>
            <option value="personal">الصفات الشخصية</option>
            <option value="partner">مواصفات الشريك</option>
            <option value="contact">معلومات التواصل</option>
          </select>
        </div>
      </div>

      {/* إدارة الخيارات */}
      {hasOptions && (
        <div>
          <label className={labelClass}>
            الخيارات {type === 'conditional' && '(عند اختيار أي خيار سيظهر حقل نص للمستخدم)'}
          </label>

          {/* قائمة الخيارات القابلة للتعديل */}
          <div className="space-y-2 mb-2">
            {options.map((opt, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <input
                  value={opt}
                  onChange={(e) => editOption(idx, e.target.value)}
                  className={inputClass}
                  placeholder={`الخيار ${idx + 1}`}
                />
                <button
                  type="button"
                  onClick={() => removeOption(idx)}
                  className="flex-shrink-0 w-9 h-9 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center hover:bg-rose-100 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* إضافة خيار جديد */}
          <div className="flex items-center gap-2">
            <input
              value={newOption}
              onChange={(e) => setNewOption(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addOption())}
              className={inputClass}
              placeholder="اكتب خيارًا جديدًا واضغط Enter..."
            />
            <button
              type="button"
              onClick={addOption}
              disabled={!newOption.trim()}
              className="flex-shrink-0 w-9 h-9 rounded-lg bg-slate-900 text-white flex items-center justify-center hover:bg-slate-800 transition-colors disabled:opacity-40"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {options.length === 0 && (
            <p className="text-[11px] text-slate-400 font-tajawal mt-2">لم تتم إضافة خيارات بعد. مثال: حكومي، قطاع خاص، أعمال حرة، عمل خاص</p>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
          <span className="text-sm font-cairo font-semibold text-slate-700">حقل إلزامي</span>
          <button type="button" onClick={() => setRequired(!required)} className={`w-12 h-7 rounded-full transition-colors relative ${required ? 'bg-emerald-500' : 'bg-slate-300'}`}>
            <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${required ? 'right-1' : 'right-6'}`} />
          </button>
        </div>
        <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
          <span className="text-sm font-cairo font-semibold text-slate-700">مُفعّل</span>
          <button type="button" onClick={() => setEnabled(!enabled)} className={`w-12 h-7 rounded-full transition-colors relative ${enabled ? 'bg-emerald-500' : 'bg-slate-300'}`}>
            <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${enabled ? 'right-1' : 'right-6'}`} />
          </button>
        </div>
      </div>

      <button
        onClick={() => onSave({ label, type, required, enabled, group, options: hasOptions ? options : undefined })}
        disabled={!label.trim()}
        className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <span className="flex items-center justify-center gap-2"><Check className="w-4 h-4" /> {initial ? 'حفظ التغييرات' : 'إضافة الحقل'}</span>
      </button>
    </div>
  );
}
