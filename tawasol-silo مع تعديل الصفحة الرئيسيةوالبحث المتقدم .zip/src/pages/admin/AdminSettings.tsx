import { useState } from 'react';
import { Settings, Save, Check, Bell, Shield, Globe, Database, CreditCard, HelpCircle } from 'lucide-react';
import { useApp } from '../../lib/AppContext';

interface ToggleProps {
  label: string;
  desc: string;
  icon: any;
  value: boolean;
  onChange: (val: boolean) => void;
}

const Toggle = ({ label, desc, icon: Icon, value, onChange }: ToggleProps) => {
  return (
    <div className="flex items-center gap-3 py-3">
      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-slate-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-cairo font-semibold text-slate-800 text-sm pl-2">{label}</p>
        <p className="text-xs text-slate-400 font-tajawal">{desc}</p>
      </div>
      <button onClick={() => onChange(!value)} className={`w-12 h-7 rounded-full transition-colors relative flex-shrink-0 ${value ? 'bg-emerald-500' : 'bg-slate-300'}`}>
        <div className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${value ? 'right-1' : 'right-6'}`} />
      </button>
    </div>
  );
};

export default function AdminSettings() {
  const { paypalSettings, updatePaypalSettings, paymentSettings, updatePaymentSettings } = useApp();
  const [saved, setSaved] = useState(false);
  const [settings, setSettings] = useState({
    emailNotifs: true,
    smsNotifs: false,
    twoFactor: true,
    autoBackup: true,
    debugMode: false,
    cacheTimeout: '60',
  });

  // Local state for PayPal editor
  const [paypalForm, setPaypalForm] = useState({
    clientId: paypalSettings.clientId,
    clientSecret: paypalSettings.clientSecret,
    mode: paypalSettings.mode,
    guestCheckout: paypalSettings.guestCheckout,
    active: paypalSettings.active,
  });

  // Local state for multi-gateways config
  const [paymentsForm, setPaymentsForm] = useState({
    paypalActive: paymentSettings.paypalActive,
    cryptoActive: paymentSettings.cryptoActive,
    bankActive: paymentSettings.bankActive,
    cryptoWalletAddress: paymentSettings.cryptoWalletAddress,
    bankDetails: paymentSettings.bankDetails,
    forceSingleMethod: paymentSettings.forceSingleMethod,
  });

  const handleSave = () => {
    // Save standard settings (simulated)
    setSaved(true);
    
    // Save PayPal settings to Context and Local Storage
    updatePaypalSettings(paypalForm);

    // Save consolidated payment options
    updatePaymentSettings(paymentsForm);

    setTimeout(() => setSaved(false), 2500);
  };

  const inputClass = "w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm";
  const labelClass = "block text-xs font-cairo font-bold text-slate-700 mb-1.5";

  return (
    <div className="space-y-5 text-right font-tajawal" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">الإعدادات العامة وبوابات الدفع</h2>
          <p className="text-sm text-slate-500 font-tajawal">إعدادات النظام، الأمان، وبوابة دفع PayPal العالمية</p>
        </div>
        <button onClick={handleSave} className={`flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm hover:bg-slate-800 transition-colors ${saved ? 'bg-emerald-500 hover:bg-emerald-600' : ''}`}>
          {saved ? <><Check className="w-4 h-4" /> تم حفظ الإعدادات</> : <><Save className="w-4 h-4" /> حفظ جميع التغييرات</>}
        </button>
      </div>

      {/* PAYPAL CONFIGURATION CARD */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-5">
          <h3 className="font-cairo font-bold text-slate-900 flex items-center gap-2.5">
            <CreditCard className="w-5.5 h-5.5 text-amber-500" /> إعدادات بوابة الدفع PayPal
          </h3>
          <button 
            type="button"
            onClick={() => setPaypalForm({ ...paypalForm, active: !paypalForm.active })}
            className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold ${
              paypalForm.active ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-500 border border-slate-200'
            }`}
          >
            {paypalForm.active ? 'البوابة مفعّلة ✓' : 'البوابة معطلة ✕'}
          </button>
        </div>

        <div className="bg-amber-50/40 border border-amber-100/70 rounded-2xl p-4 mb-5 flex items-start gap-3">
          <HelpCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="text-xs text-amber-950 font-tajawal leading-relaxed space-y-1">
            <p className="font-bold font-cairo text-amber-900">كيف تعمل هذه الميزة؟</p>
            <p>عندما تحفظ بيانات PayPal هنا، ستقوم بوابة الدفع في صفحة ترقية الباقات بتحميل أزرار PayPal الحقيقية باستخدام معرف العميل (Client ID) المدخل أدناه.</p>
            <p>• <strong>خاصية الدفع بالبطاقات اختيارياً (PayPal Guest Checkout):</strong> تتيح للعملاء إدخال بطاقات المدى أو الفيزا والدفع مباشرة كزوار دون إلزامهم بالدخول لحساب PayPal أو إنشاء حساب جديد. تعمل تلقائياً إذا كان حساب التاجر تجارياً ومفعلاً.</p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className={labelClass}>معرّف عميل باي بال (PayPal Client ID)</label>
            <input 
              value={paypalForm.clientId} 
              onChange={(e) => setPaypalForm({ ...paypalForm, clientId: e.target.value })} 
              className={`${inputClass} font-mono text-left tracking-wide`}
              placeholder="AX_AbCdEf12345ExampleClientID..."
              dir="ltr"
            />
          </div>
          <div>
            <label className={labelClass}>المفتاح السري (Client Secret) <span className="text-slate-400 font-normal">(اختياري)</span></label>
            <input 
              type="password"
              value={paypalForm.clientSecret} 
              onChange={(e) => setPaypalForm({ ...paypalForm, clientSecret: e.target.value })} 
              className={`${inputClass} font-mono text-left`}
              placeholder="••••••••••••••••••••"
              dir="ltr"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-50">
          <div>
            <label className={labelClass}>بيئة عمل بوابة الدفع (PayPal Environment)</label>
            <div className="grid grid-cols-2 gap-2 mt-1">
              <button
                type="button"
                onClick={() => setPaypalForm({ ...paypalForm, mode: 'sandbox' })}
                className={`py-2 rounded-xl border-2 font-cairo text-xs font-bold ${
                  paypalForm.mode === 'sandbox' 
                    ? 'bg-amber-50 border-amber-400 text-amber-800' 
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-amber-200'
                }`}
              >
                بيئة التجربة والاختبار (Sandbox)
              </button>
              <button
                type="button"
                onClick={() => setPaypalForm({ ...paypalForm, mode: 'live' })}
                className={`py-2 rounded-xl border-2 font-cairo text-xs font-bold ${
                  paypalForm.mode === 'live' 
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800' 
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-emerald-200'
                }`}
              >
                البيئة الحقيقية والإنتاجية (Live)
              </button>
            </div>
          </div>

          <div>
            <label className={labelClass}>تمكين تعبئة بطاقة الائتمان مباشرة (PayPal Guest Checkout)</label>
            <button
              type="button"
              onClick={() => setPaypalForm({ ...paypalForm, guestCheckout: !paypalForm.guestCheckout })}
              className={`w-full mt-1 py-3 rounded-xl border-2 font-cairo text-xs font-bold flex items-center justify-center gap-2 ${
                paypalForm.guestCheckout 
                  ? 'bg-emerald-50 border-emerald-500 text-emerald-800' 
                  : 'bg-rose-50 border-rose-300 text-rose-800'
              }`}
            >
              <span className={`w-2.5 h-2.5 rounded-full ${paypalForm.guestCheckout ? 'bg-emerald-500 animate-pulse' : 'bg-rose-400'}`} />
              {paypalForm.guestCheckout ? 'الدفع المباشر بالبطاقة مع خيار تخطي الحساب مفعّل ✓' : 'إلزام المستخدم بإنشاء حساب PayPal للدفع'}
            </button>
          </div>
        </div>
      </div>

      {/* MULTIPLE PAYMENT METHODS CONFIGURATION */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
        <h3 className="font-cairo font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
          <CreditCard className="w-5.5 h-5.5 text-amber-500" /> إدارة قنوات وطرق الدفع المتعددة
        </h3>

        <p className="text-xs text-slate-500 font-tajawal leading-relaxed">
          تحكم في قنوات الدفع المفعلة، وقم بتفعيل خيارات الدفع البديلة مثل العملات الرقمية والتحويل البنكي بالتواصل المباشر مع إدارة المنصة. يمكنك تعطيل أي قناة دفع فردياً، أو إجبار تشغيل قناة واحدة فقط.
        </p>

        {/* Toggles */}
        <div className="grid sm:grid-cols-3 gap-3 pt-2">
          <label className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-100 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-all">
            <input 
              type="checkbox" 
              checked={paymentsForm.paypalActive} 
              onChange={(e) => setPaymentsForm({ ...paymentsForm, paypalActive: e.target.checked })}
              className="rounded text-amber-500 focus:ring-amber-400 w-4.5 h-4.5"
            />
            <div>
              <span className="block font-cairo font-bold text-xs text-slate-700">باي بال (PayPal)</span>
              <span className="text-[10px] text-slate-400 font-tajawal">دفع مباشر بالبطاقات أو الحساب</span>
            </div>
          </label>

          <label className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-100 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-all">
            <input 
              type="checkbox" 
              checked={paymentsForm.cryptoActive} 
              onChange={(e) => setPaymentsForm({ ...paymentsForm, cryptoActive: e.target.checked })}
              className="rounded text-amber-500 focus:ring-amber-400 w-4.5 h-4.5"
            />
            <div>
              <span className="block font-cairo font-bold text-xs text-slate-700">العملات الرقمية (Crypto)</span>
              <span className="text-[10px] text-slate-400 font-tajawal">تحويل USDT مع رفع إثبات التحويل</span>
            </div>
          </label>

          <label className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-100 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-all">
            <input 
              type="checkbox" 
              checked={paymentsForm.bankActive} 
              onChange={(e) => setPaymentsForm({ ...paymentsForm, bankActive: e.target.checked })}
              className="rounded text-amber-500 focus:ring-amber-400 w-4.5 h-4.5"
            />
            <div>
              <span className="block font-cairo font-bold text-xs text-slate-700">التحويل البنكي المحلّي</span>
              <span className="text-[10px] text-slate-400 font-tajawal">حسابات بنكية سعودية / دولية</span>
            </div>
          </label>
        </div>

        {/* Force options */}
        <div className="bg-amber-50/20 p-4 rounded-xl border border-amber-100/60 mt-3">
          <label className={labelClass}>وضع التحكم في تشغيل الطرق ورؤيتها للعميل</label>
          <select 
            value={paymentsForm.forceSingleMethod}
            onChange={(e) => setPaymentsForm({ ...paymentsForm, forceSingleMethod: e.target.value as any })}
            className={inputClass}
          >
            <option value="none">عرض جميع طرق الدفع المفعّلة أعلاه معاً</option>
            <option value="paypal">إجبار تشغيل باي بال فقط وإيقاف جميع القنوات الأخرى مؤقتاً</option>
            <option value="crypto">إجبار تشغيل العملات الرقمية فقط وإيقاف القنوات الأخرى</option>
            <option value="bank">إجبار تشغيل التحويل البنكي فقط وإجراء الإتمام يدوياً</option>
          </select>
          <p className="text-[10px] text-slate-400 font-tajawal mt-1">يتحكم هذا الخيار ديناميكياً في صفحة الاشتراك لدى العملاء.</p>
        </div>

        {/* Inputs */}
        <div className="grid sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className={labelClass}>محفظة استلام العملات الرقمية (USDT / BTC ERC20 Address)</label>
            <input 
              type="text" 
              value={paymentsForm.cryptoWalletAddress}
              onChange={(e) => setPaymentsForm({ ...paymentsForm, cryptoWalletAddress: e.target.value })}
              className={`${inputClass} font-mono`}
              placeholder="0x..."
            />
            <p className="text-[10px] text-slate-400 font-tajawal mt-1">عنوان المحفظة يظهر للعميل لكي يقوم بالنسخ والتحويل.</p>
          </div>

          <div>
            <label className={labelClass}>تفاصيل الحساب البنكي (اسم البنك - الآيبان - رقم الحساب)</label>
            <textarea 
              rows={2}
              value={paymentsForm.bankDetails}
              onChange={(e) => setPaymentsForm({ ...paymentsForm, bankDetails: e.target.value })}
              className={inputClass}
              placeholder="اسم البنك... الآيبان..."
            />
            <p className="text-[10px] text-slate-400 font-tajawal mt-1">أدخل معلومات البنك واضحة للعملاء لإرسال الحوالات إليها.</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2"><Bell className="w-5 h-5 text-amber-500" /> الإشعارات</h3>
        <div className="divide-y divide-slate-50">
          <Toggle label="إشعارات البريد الإلكتروني" desc="استقبال تنبيهات الأعضاء الجدد والطلبات" icon={Bell} value={settings.emailNotifs} onChange={(val) => setSettings({ ...settings, emailNotifs: val })} />
          <Toggle label="إشعارات SMS" desc="استقبال تنبيهات فورية على الجوال" icon={Bell} value={settings.smsNotifs} onChange={(val) => setSettings({ ...settings, smsNotifs: val })} />
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2"><Shield className="w-5 h-5 text-amber-500" /> الأمان</h3>
        <div className="divide-y divide-slate-50">
          <Toggle label="المصادقة الثنائية" desc="حماية إضافية لحساب الإدارة" icon={Shield} value={settings.twoFactor} onChange={(val) => setSettings({ ...settings, twoFactor: val })} />
          <Toggle label="وضع التصحيح" desc="عرض الأخطاء التفصيلية للمطورين" icon={Settings} value={settings.debugMode} onChange={(val) => setSettings({ ...settings, debugMode: val })} />
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2"><Database className="w-5 h-5 text-amber-500" /> النظام</h3>
        <div className="divide-y divide-slate-50">
          <Toggle label="النسخ الاحتياطي التلقائي" desc="نسخ احتياطي يومي للبيانات" icon={Database} value={settings.autoBackup} onChange={(val) => setSettings({ ...settings, autoBackup: val })} />
          <div className="flex items-center gap-3 py-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
              <Globe className="w-5 h-5 text-slate-600" />
            </div>
            <div className="flex-1">
              <p className="font-cairo font-semibold text-slate-800 text-sm pl-2">مدة التخزين المؤقت (بالدقائق)</p>
              <p className="text-xs text-slate-400 font-tajawal">تحكم في أداء الموقع</p>
            </div>
            <input type="number" value={settings.cacheTimeout} onChange={(e) => setSettings({ ...settings, cacheTimeout: e.target.value })} className="w-20 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none text-center font-cairo font-bold text-slate-900 text-sm" />
          </div>
        </div>
      </div>
    </div>
  );
}
