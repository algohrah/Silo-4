import { useState, useRef } from 'react';
import { Plus, Edit3, Trash2, Clock, Image as ImageIcon, Link2, Upload, X, Eye } from 'lucide-react';
import { BLOG_POSTS } from '../../lib/data';
import type { BlogPost } from '../../lib/types';
import Modal from '../../components/ui/Modal';

export default function AdminBlog() {
  const [posts, setPosts] = useState(BLOG_POSTS);
  const [editing, setEditing] = useState<BlogPost | null>(null);
  const [creating, setCreating] = useState(false);
  const [previewing, setPreviewing] = useState<BlogPost | null>(null);

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه التدوينة؟')) {
      setPosts(prev => prev.filter(p => p.id !== id));
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">إدارة المدونة</h2>
          <p className="text-sm text-slate-500 font-tajawal">{posts.length} تدوينة منشورة</p>
        </div>
        <button onClick={() => setCreating(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors">
          <Plus className="w-4 h-4" /> تدوينة جديدة
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {posts.map((post) => (
          <div key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
            <div className="aspect-[16/10] bg-slate-100 relative overflow-hidden">
              {post.image ? (
                <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-300">
                  <ImageIcon className="w-10 h-10" />
                </div>
              )}
              <span className="absolute top-2 right-2 px-2 py-1 rounded-md bg-white/90 backdrop-blur text-xs font-cairo font-bold text-slate-700">{post.category}</span>
            </div>
            <div className="p-4">
              <h3 className="font-cairo font-bold text-slate-900 text-sm mb-1 line-clamp-1">{post.title}</h3>
              <p className="text-xs text-slate-500 font-tajawal line-clamp-2 mb-3">{post.excerpt}</p>
              <div className="flex items-center gap-3 text-[10px] text-slate-400 font-tajawal mb-3">
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{post.readTime}</span>
                <span>{post.date}</span>
                <span className="text-slate-300">·</span>
                <span>{post.author}</span>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setEditing(post)} className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-amber-50 text-amber-600 text-xs font-cairo font-bold hover:bg-amber-100 transition-colors">
                  <Edit3 className="w-3.5 h-3.5" /> تعديل
                </button>
                <button onClick={() => setPreviewing(post)} className="flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-slate-100 text-slate-600 text-xs font-cairo font-bold hover:bg-slate-200 transition-colors">
                  <Eye className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => handleDelete(post.id)} className="flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-rose-50 text-rose-600 text-xs font-cairo font-bold hover:bg-rose-100 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Create/Edit Modal */}
      <Modal open={creating || !!editing} onClose={() => { setCreating(false); setEditing(null); }} title={editing ? 'تعديل التدوينة' : 'تدوينة جديدة'} size="lg">
        <BlogForm
          post={editing}
          onSave={(post) => {
            if (editing) {
              setPosts(prev => prev.map(p => p.id === post.id ? post : p));
            } else {
              setPosts(prev => [{ ...post, id: 'b' + Date.now() }, ...prev]);
            }
            setCreating(false);
            setEditing(null);
          }}
        />
      </Modal>

      {/* Preview Modal */}
      <Modal open={!!previewing} onClose={() => setPreviewing(null)} title="معاينة التدوينة" size="lg">
        {previewing && (
          <div>
            {previewing.image && (
              <div className="aspect-[16/9] rounded-2xl overflow-hidden mb-4 bg-slate-100">
                <img src={previewing.image} alt={previewing.title} className="w-full h-full object-cover" />
              </div>
            )}
            <span className="inline-block px-2.5 py-1 rounded-full bg-amber-50 text-amber-600 text-xs font-cairo font-bold mb-2">{previewing.category}</span>
            <h3 className="font-cairo font-extrabold text-xl text-slate-900 mb-2">{previewing.title}</h3>
            <p className="text-sm text-slate-500 font-tajawal mb-4">{previewing.excerpt}</p>
            <div className="prose prose-sm max-w-none">
              {previewing.content.split('\n').map((line, i) => {
                if (line.startsWith('## ')) return <h4 key={i} className="font-cairo font-bold text-slate-900 mt-3 mb-1">{line.replace('## ', '')}</h4>;
                if (line.trim()) return <p key={i} className="text-slate-600 font-tajawal leading-relaxed mb-2">{line}</p>;
                return null;
              })}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function BlogForm({ post, onSave }: { post: BlogPost | null; onSave: (p: BlogPost) => void }) {
  const [form, setForm] = useState<BlogPost>(post || {
    id: '', title: '', excerpt: '', content: '', category: 'نصائح',
    author: 'فريق توافق', date: 'اليوم', readTime: '5 دقائق', image: '',
  });
  // نوع مصدر الصورة: رفع ملف أو رابط
  const [imageMode, setImageMode] = useState<'upload' | 'url' | 'none'>(
    post?.image && post.image.startsWith('/uploads/') ? 'upload' :
    post?.image ? 'url' : 'none'
  );
  const fileInputRef = useRef<HTMLInputElement>(null);

  const inputClass = "w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm";
  const labelClass = "block text-xs font-cairo font-bold text-slate-700 mb-1.5";

  // محاكاة رفع الصورة (تخزين محلي)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // في التطبيق الحقيقي يتم رفع الصورة للسيرفر، هنا نستخدم URL محلي
    const imageUrl = URL.createObjectURL(file);
    setForm({ ...form, image: imageUrl });
  };

  return (
    <div className="space-y-4">
      {/* صورة الغلاف */}
      <div>
        <label className={labelClass}>صورة الغلاف</label>
        {/* اختيار نوع المصدر */}
        <div className="flex gap-2 mb-2">
          {([
            { id: 'upload' as const, label: 'رفع صورة', icon: Upload },
            { id: 'url' as const, label: 'رابط صورة', icon: Link2 },
            { id: 'none' as const, label: 'بدون صورة', icon: X },
          ]).map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => { setImageMode(m.id); if (m.id === 'none') setForm({ ...form, image: '' }); }}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-cairo font-bold transition-colors ${
                imageMode === m.id ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              }`}
            >
              <m.icon className="w-3.5 h-3.5" /> {m.label}
            </button>
          ))}
        </div>

        {/* معاينة الصورة */}
        {form.image && (
          <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-slate-100 mb-2 border border-slate-200">
            <img src={form.image} alt="معاينة" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => setForm({ ...form, image: '' })}
              className="absolute top-2 left-2 w-7 h-7 rounded-full bg-white/90 backdrop-blur flex items-center justify-center text-rose-600 hover:bg-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* رفع ملف */}
        {imageMode === 'upload' && (
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-8 rounded-xl border-2 border-dashed border-slate-300 hover:border-amber-400 hover:bg-amber-50/50 transition-colors flex flex-col items-center justify-center gap-2 text-slate-400"
          >
            <Upload className="w-7 h-7" />
            <span className="text-sm font-cairo font-semibold">اضغط لرفع صورة</span>
            <span className="text-[10px] text-slate-400">PNG, JPG حتى 5MB</span>
          </button>
        )}
        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />

        {/* إدخال رابط */}
        {imageMode === 'url' && (
          <div className="relative">
            <Link2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              value={form.image.startsWith('blob:') ? '' : form.image}
              onChange={(e) => setForm({ ...form, image: e.target.value })}
              className={inputClass + ' pr-9'}
              placeholder="https://example.com/image.jpg"
              dir="ltr"
            />
          </div>
        )}
      </div>

      <div>
        <label className={labelClass}>عنوان التدوينة</label>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className={inputClass} placeholder="عنوان جذاب..." />
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>التصنيف</label>
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={inputClass}>
            <option>نصائح</option><option>علاقات</option><option>عائلة</option><option>إيمان</option><option>قصص نجاح</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>الكاتب</label>
          <input value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} className={inputClass} />
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>مدة القراءة</label>
          <input value={form.readTime} onChange={(e) => setForm({ ...form, readTime: e.target.value })} className={inputClass} placeholder="5 دقائق" />
        </div>
        <div>
          <label className={labelClass}>التاريخ</label>
          <input value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className={inputClass} placeholder="اليوم" />
        </div>
      </div>
      <div>
        <label className={labelClass}>المقتطف (الملخص)</label>
        <textarea value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} rows={2} className={inputClass + ' resize-none'} placeholder="ملخص قصير يظهر في بطاقة التدوينة..." />
      </div>
      <div>
        <label className={labelClass}>المحتوى الكامل</label>
        <textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={7} className={inputClass + ' resize-none'} placeholder="اكتب المحتوى هنا... استخدم ## للعناوين الفرعية" />
        <p className="text-[10px] text-slate-400 font-tajawal mt-1">نصيحة: استخدم «## العنوان» لإنشاء عنوان فرعي داخل المقال</p>
      </div>
      <button
        onClick={() => onSave(form)}
        disabled={!form.title.trim() || !form.excerpt.trim()}
        className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {post ? 'حفظ التغييرات' : 'نشر التدوينة'}
      </button>
    </div>
  );
}
