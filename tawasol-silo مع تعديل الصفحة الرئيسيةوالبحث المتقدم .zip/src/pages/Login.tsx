import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, Eye, EyeOff, ArrowLeft, ShieldCheck, Zap } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { getAvatar } from '../lib/types';
import { useApp } from '../lib/AppContext';

// بيانات الدخول التجريبية
const DEMO_EMAIL = 'demo@tawasul.sa';
const DEMO_PASSWORD = 'tawasul123';
const DEMO_NAME = 'سارة';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');

  // الصفحة اللي كان يبيها المستخدم قبل ما يُحوّل لتسجيل الدخول
  const from = (location.state as { from?: string })?.from || '/profile';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    // نتحقق من بيانات الدخول التجريبية أو أي بريد/كلمة مرور صحيحة
    const isDemo = email === DEMO_EMAIL && password === DEMO_PASSWORD;
    // للتجربة: نقبل أي بريد صحيح + كلمة مرور 6 أحرف فأكثر
    const isValid = isDemo || (email.includes('@') && password.length >= 6);

    if (!isValid) {
      setError('بيانات الدخول غير صحيحة. جرّب الحساب التجريبي أو استخدم بريدًا صحيحًا وكلمة مرور 6 أحرف فأكثر.');
      return;
    }

    // نأخذ الاسم من البريد أو نستخدم الاسم التجريبي
    const name = isDemo ? DEMO_NAME : email.split('@')[0];
    login(name);
    navigate(from);
  };

  // تعبئة تلقائية ببيانات الحساب التجريبي
  const fillDemo = () => {
    setEmail(DEMO_EMAIL);
    setPassword(DEMO_PASSWORD);
    setError('');
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] grid lg:grid-cols-2">
      {/* Visual side */}
      <div className="hidden lg:flex relative bg-navy-gradient items-center justify-center p-12 overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="absolute -top-20 -left-20 w-80 h-80 bg-gold-500/20 rounded-full blur-3xl" />
        <div className="relative max-w-md text-center">
          <div className="grid grid-cols-2 gap-3 mb-8">
            <img src={getAvatar('female')} alt="" className="rounded-3xl shadow-2xl w-full aspect-[3/4] object-cover ring-1 ring-gold-500/30 bg-cream-100" />
            <img src={getAvatar('male')} alt="" className="rounded-3xl shadow-2xl w-full aspect-[3/4] object-cover ring-1 ring-gold-500/30 bg-cream-100" />
          </div>
          <h2 className="font-cairo font-extrabold text-3xl text-white leading-tight">مرحبًا بعودتك إلى <span className="text-gradient-gold">توافق</span></h2>
          <p className="mt-4 text-cream-200/80 font-tajawal leading-relaxed">سجّل الدخول لمتابعة رحلتك نحو شريك الحياة المناسب.</p>
          <div className="mt-6 inline-flex items-center gap-2 text-sm text-emerald-300 bg-emerald-500/10 px-4 py-2 rounded-full">
            <ShieldCheck className="w-4 h-4" /> دخول آمن ومحمي
          </div>
        </div>
      </div>

      {/* Form side */}
      <div className="flex items-center justify-center p-6 sm:p-12 bg-cream-50">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <Link to="/" className="inline-flex items-center gap-2 text-navy-600 hover:text-gold-700 font-cairo font-semibold text-sm mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" /> العودة للرئيسية
          </Link>

          <h1 className="font-cairo font-extrabold text-3xl text-navy-900">تسجيل الدخول</h1>
          <p className="mt-2 text-navy-600 font-tajawal">أدخل بياناتك للوصول إلى حسابك</p>

          {/* بطاقة الحساب التجريبي */}
          <div className="mt-6 bg-gradient-to-l from-gold-300/15 to-cream-100 border border-gold-500/25 rounded-2xl p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-gold-gradient flex items-center justify-center flex-shrink-0">
                  <Zap className="w-5 h-5 text-navy-900" />
                </div>
                <div className="min-w-0">
                  <p className="font-cairo font-bold text-navy-900 text-sm">حساب تجريبي للتجربة</p>
                  <div className="mt-1.5 space-y-0.5 text-xs font-tajawal text-navy-600">
                    <p className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-gold-600 flex-shrink-0" />
                      <span className="truncate">{DEMO_EMAIL}</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-gold-600 flex-shrink-0" />
                      <span>{DEMO_PASSWORD}</span>
                    </p>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={fillDemo}
                className="flex-shrink-0 px-3 py-2 rounded-xl bg-navy-900 text-white text-xs font-cairo font-bold hover:bg-navy-800 transition-colors whitespace-nowrap"
              >
                تعبئة تلقائية
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-3 text-sm font-tajawal">
                {error}
              </div>
            )}
            <div>
              <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@email.com"
                  className="w-full pr-12 pl-4 py-3.5 rounded-2xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-cairo font-semibold text-navy-800">كلمة المرور</label>
                <Link to="/support" className="text-xs text-gold-700 font-cairo font-semibold hover:underline">نسيت كلمة المرور؟</Link>
              </div>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type={showPass ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-12 pl-12 py-3.5 rounded-2xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors"
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" className="w-4 h-4 rounded accent-gold-500" />
              <span className="text-sm text-navy-600 font-tajawal">تذكّرني</span>
            </label>

            <Button type="submit" fullWidth size="lg">دخول</Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-navy-600 font-tajawal">ليس لديك حساب؟</p>
            <Link to="/register" className="inline-block mt-1 font-cairo font-bold text-gold-700 hover:underline">أنشئ حسابًا جديدًا</Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
