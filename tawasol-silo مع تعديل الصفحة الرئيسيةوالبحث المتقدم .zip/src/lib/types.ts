export type Gender = 'male' | 'female';

export interface Member {
  id: string;
  name: string;
  displayName: string;
  age: number;
  gender: Gender;
  city: string;
  country: string;
  verified: boolean;
  premium: boolean;
  online: boolean;
  lastActive: string;
  workType: string;
  education: string;
  height: number;
  maritalStatus: 'never_married' | 'divorced' | 'widowed';
  hasChildren: boolean;
  religion: string;
  ethnicity: string;
  interests: string[];
  bio: string;
  aboutPartner: string;
  matchScore?: number;
}

// الصورة الافتراضية حسب الجنس (صور محلية ثابتة — بدون صور شخصية)
export function getAvatar(gender: Gender): string {
  return gender === 'male' ? '/images/avatar-male.png' : '/images/avatar-female.png';
}

// صورة افتراضية للبطاقات (نفس الصورة)
export function getAvatarCard(gender: Gender): string {
  return getAvatar(gender);
}

// ألوان حسب الجنس
export function getGenderColors(gender: Gender) {
  return gender === 'male'
    ? {
        ring: 'ring-blue-500',
        bg: 'bg-blue-50',
        bgStrong: 'bg-blue-500',
        text: 'text-blue-600',
        textStrong: 'text-blue-700',
        border: 'border-blue-200',
        gradient: 'from-blue-600 to-blue-500',
        glow: 'shadow-blue-500/20',
        badgeBg: 'bg-blue-500',
      }
    : {
        ring: 'ring-rose-500',
        bg: 'bg-rose-50',
        bgStrong: 'bg-rose-500',
        text: 'text-rose-600',
        textStrong: 'text-rose-700',
        border: 'border-rose-200',
        gradient: 'from-rose-600 to-rose-500',
        glow: 'shadow-rose-500/20',
        badgeBg: 'bg-rose-500',
      };
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  period: string;
  description: string;
  features: string[];
  popular?: boolean;
  color: 'gold' | 'navy' | 'rose';
  messagesLimit?: number;
  requestsLimit?: number;
  searchLimit?: number;
  showContactLimit?: number;
  durationDays?: number;
  advancedFilters?: boolean;
}

export interface FAQItem {
  q: string;
  a: string;
}

// ===== نظام التواصل مع الإدارة فقط =====
// لا يوجد رسائل بين الأعضاء — كل التواصل يتم عبر الإدارة
export type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed';
export type TicketPriority = 'low' | 'normal' | 'high' | 'urgent';

export interface SupportMessage {
  id: string;
  sender: 'user' | 'admin';
  text: string;
  time: string;
}

export interface SupportTicket {
  id: string;
  subject: string;
  category: 'استفسار عام' | 'طلب ترقية' | 'مشكلة تقنية' | 'شكوى' | 'اقتراح';
  status: TicketStatus;
  priority: TicketPriority;
  messages: SupportMessage[];
  updatedAt: string;
}

export interface Notification {
  id: string;
  type: 'request' | 'match' | 'system' | 'verification' | 'admin';
  text: string;
  time: string;
  read: boolean;
  memberId?: string;
}

export const SAUDI_CITIES = [
  'الرياض', 'جدة', 'مكة المكرمة', 'المدينة المنورة', 'الدمام',
  'الخبر', 'الطائف', 'بريدة', 'تبوك', 'أبها',
  'الجبيل', 'ينبع', 'خميس مشيط', 'حائل', 'نجران',
];

export const ARAB_CITIES = [
  ...SAUDI_CITIES,
  'دبي', 'أبو ظبي', 'الدوحة', 'الكويت', 'المنامة',
  'مسقط', 'القاهرة', 'عمّان', 'بيروت', 'تونس',
];

export const INTERESTS = [
  'القراءة', 'السفر', 'الطبخ', 'الرياضة', 'الفنون',
  'الموسيقى', 'التقنية', 'التصوير', 'التطوع', 'الديكور',
  'الحدائق', 'الأفلام', 'الشعر', 'ركوب الخيل', 'السباحة',
];

export const EDUCATION_LEVELS = [
  'ثانوية عامة', 'دبلوم', 'بكالوريوس', 'ماجستير', 'دكتوراه',
];

export const JOB_TITLES = [
  'حكومي', 'قطاع خاص', 'أعمال حرة',
];

export const MARITAL_STATUS = {
  never_married: 'أعزب / آنسة',
  divorced: 'مطلق / مطلقة',
  widowed: 'أرمل / أرملة',
};

export const ETHNICITIES = [
  'عربي', 'خليجي', 'شامي', 'مصري', 'مغاربي', 'أخرى',
];

export const RELIGIONS = [
  'مسلم سني', 'مسلم شيعي', 'مسيحي', 'أخرى',
];

// الدول العربية
export const ARAB_COUNTRIES = [
  'السعودية', 'الإمارات', 'الكويت', 'قطر', 'البحرين', 'عمان',
  'مصر', 'الأردن', 'لبنان', 'سوريا', 'العراق', 'اليمن',
  'المغرب', 'الجزائر', 'تونس', 'ليبيا', 'السودان', 'فلسطين',
];

// المذاهب
export const SECTS = [
  'سني', 'شيعي', 'سلفي', 'أشعري', 'أخرى',
];

// عدد الأبناء
export const CHILDREN_COUNTS = ['لا يوجد', '1', '2', '3', '4', 'أكثر من 4'];

// خيارات التدخين
export const SMOKING_OPTIONS = ['لا أدخن', 'أدخن', 'سابقًا وتركت', 'شيشة فقط'];

// خيارات لون البشرة
export const SKIN_COLORS = ['أبيض', 'أبيض قمحي', 'حنطي', 'حنطي مائل للسمار', 'أسمر', 'أبيض جدا'];

// خيارات الحالة الصحية
export const HEALTH_OPTIONS = ['ممتازة', 'جيدة', 'يوجد مرض مزمن'];

// خيارات نوع جهة العمل
export const WORK_TYPES = ['حكومي', 'قطاع خاص', 'أعمال حرة'];

// خيارات نوع السكن
export const HOUSING_TYPES = ['أملك منزل', 'أستأجر', 'أسكن مع العائلة'];

// ===== الحالة الاجتماعية حسب الجنس =====
// خيارات الرجال
export const MARITAL_MALE = [
  { value: 'single', label: 'أعزب' },
  { value: 'divorced', label: 'مطلق' },
  { value: 'widower', label: 'أرمل' },
  { value: 'married', label: 'متزوج' },
];

// خيارات النساء
export const MARITAL_FEMALE = [
  { value: 'single', label: 'عزباء' },
  { value: 'divorced', label: 'مطلقة' },
  { value: 'widow', label: 'أرملة' },
  { value: 'married', label: 'متزوجة' },
];

// دالة مساعدة لجلب خيارات الحالة الاجتماعية حسب الجنس
export function getMaritalOptions(gender: 'male' | 'female') {
  return gender === 'male' ? MARITAL_MALE : MARITAL_FEMALE;
}

export function getMaritalStatusLabel(status: string): string {
  return MARITAL_STATUS[status as keyof typeof MARITAL_STATUS] || status;
}
