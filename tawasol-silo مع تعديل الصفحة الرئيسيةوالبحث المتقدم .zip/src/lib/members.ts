import type { Gender } from './types';

// ====================================================================
//  واجهة العضو — مطابقة لحقول نموذج التسجيل
// ====================================================================
export interface Member {
  id: string;
  nickname: string;        // الاسم المستعار
  gender: Gender;          // الجنس
  age: number;             // العمر
  country: string;         // الدولة
  city: string;            // المدينة
  district: string;        // المنطقة / الحي
  nationality: string;     // الجنسية
  sect: string;            // المذهب
  maritalStatus: string;   // الحالة الاجتماعية (قيمة)
  maritalLabel: string;    // الحالة الاجتماعية (نص عربي صحيح حسب الجنس)
  hasChildren: boolean;    // لديه أبناء
  childrenCount: string;   // عدد الأبناء
  // شخصية
  height: number;          // الطول
  weight: number;          // الوزن
  skinColor: string;       // لون البشرة
  health: string;          // الحالة الصحية
  smoking: string;         // التدخين
  // تعليم وعمل
  education: string;       // المؤهل
  workType: string;        // نوع جهة العمل
  housing: string;         // نوع السكن
  bio: string;             // نبذة عني
  // مواصفات الشريك
  aboutPartner: string;    // وصف الشريك المطلوب
  // حالة الحساب
  verified: boolean;       // موثق
  premium: boolean;        // عضو ذهبي/نخبة
  online: boolean;         // متصل
  lastActive: string;      // آخر ظهور
  matchScore?: number;     // نسبة التوافق
}

// ===== 8 أعضاء تجريبيين — مطابقين لحقول التسجيل =====
export const MEMBERS: Member[] = [
  {
    id: 'm1',
    nickname: 'أبو عبدالله',
    gender: 'male', age: 32,
    country: 'السعودية', city: 'الرياض', district: 'حي العليا',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'أعزب',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 178, weight: 78, skinColor: 'أبيض قمحي',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'ماجستير', workType: 'حكومي',
    housing: 'أملك منزل',
    bio: 'مهندس طموح أحب الحياة المستقرة، أبحث عن شريكة تكملني وتشاركني رحلة الحياة بإذن الله.',
    aboutPartner: 'أبحث عن شريكة متعلمة، هادئة، تحب العائلة وتطمح لبناء بيت مستقر على القيم الإسلامية.',
    verified: true, premium: true, online: true, lastActive: 'متصل الآن', matchScore: 94,
  },
  {
    id: 'm2',
    nickname: 'باحثة عن الستر',
    gender: 'female', age: 27,
    country: 'السعودية', city: 'جدة', district: 'حي الروضة',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'عزباء',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 165, weight: 58, skinColor: 'أبيض',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'عمل حر',
    housing: 'أسكن مع العائلة',
    bio: 'معلمة أحب العلم والمعرفة، أؤمن أن الزواج شراكة عقول قبل القلوب، أبحث عن سكني ومستقر.',
    aboutPartner: 'أبحث عن رجل مثقف، ناضج، يحترم العائلة ويقدّر طموحي ويخاف الله.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور منذ ساعة', matchScore: 96,
  },
  {
    id: 'm3',
    nickname: 'القحطاني',
    gender: 'male', age: 35,
    country: 'السعودية', city: 'الدمام', district: 'حي الشاطئ',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'divorced', maritalLabel: 'مطلق',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 180, weight: 85, skinColor: 'حنطي',
    health: 'جيدة', smoking: 'سابقًا وتركت',
    education: 'بكالوريوس', workType: 'عمل حر',
    housing: 'أملك منزل',
    bio: 'رجل أعمال ناجح، خبرة الحياة علّمتني الصبر والحكمة، أبحث عن شريكة تكملني بصدق.',
    aboutPartner: 'أبحث عن امرأة ناضجة، واثقة، تفهم معنى الشراكة وتقدّر الاستقرار العائلي.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور منذ 3 ساعات', matchScore: 88,
  },
  {
    id: 'm4',
    nickname: 'أم محمد',
    gender: 'female', age: 30,
    country: 'السعودية', city: 'مكة المكرمة', district: 'حي العزيزية',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'divorced', maritalLabel: 'مطلقة',
    hasChildren: true, childrenCount: '1',
    height: 162, weight: 60, skinColor: 'حنطي مائل للسمار',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'دبلوم', workType: 'عمل حر',
    housing: 'أسكن مع العائلة',
    bio: 'أم لطفل واحد، أحب الحياة العائلية، أبحث عن رجل يعرف معنى المسؤولية ويقبل ابني كابن له.',
    aboutPartner: 'أبحث عن رجل متدين، حنون، يقبل أبنائي ويبني معي حياة مستقرة ومستقيمة.',
    verified: true, premium: false, online: true, lastActive: 'متصل الآن', matchScore: 85,
  },
  {
    id: 'm5',
    nickname: 'العتيبي',
    gender: 'male', age: 29,
    country: 'السعودية', city: 'الخبر', district: 'حي العقربية',
    nationality: 'السعودية', sect: 'سلفي',
    maritalStatus: 'single', maritalLabel: 'أعزب',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 175, weight: 72, skinColor: 'أبيض قمحي',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'حكومي',
    housing: 'أملك منزل',
    bio: 'ضابط في القطاع العسكري، أحب الانضباط والاستقرار، أبحث عن شريكة حياة تقف بجانبي.',
    aboutPartner: 'أبحث عن فتاة طموحة، دافئة، تحب الحياة العائلية البسيطة وتخاف الله.',
    verified: true, premium: false, online: true, lastActive: 'متصل الآن', matchScore: 91,
  },
  {
    id: 'm6',
    nickname: 'أم عبدالرحمن',
    gender: 'female', age: 25,
    country: 'السعودية', city: 'المدينة المنورة', district: 'حي قباء',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'عزباء',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 168, weight: 56, skinColor: 'أبيض',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'ماجستير', workType: 'حكومي',
    housing: 'أسكن مع العائلة',
    bio: 'محاضرة جامعية شغوفة بالعلم، أؤمن أن خير البيوت من اختارها أهلها على دينها وخلقها.',
    aboutPartner: 'أبحث عن رجل متعلم، ذو خلق ودين، يحترم طموحي ويعينني على الآخرة والدنيا.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور أمس', matchScore: 93,
  },
  {
    id: 'm7',
    nickname: 'أبو فيصل',
    gender: 'male', age: 40,
    country: 'السعودية', city: 'أبها', district: 'حي المنهل',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'widower', maritalLabel: 'أرمل',
    hasChildren: true, childrenCount: '2',
    height: 172, weight: 80, skinColor: 'أسمر',
    health: 'جيدة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'عمل حر',
    housing: 'أملك منزل',
    bio: 'تاجر وأب لطفلين، رزقني الله الصبر بعد فقد زوجتي، أبحث عن أم حنونة لأبنائي وشريكة حياة.',
    aboutPartner: 'أبحث عن امرأة صالحة، حنونة، تقبل أبنائي وتكون لهم أمًا، وتشاركني الحياة بإذن الله.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور منذ يومين', matchScore: 82,
  },
  {
    id: 'm8',
    nickname: 'بنت الخليج',
    gender: 'female', age: 24,
    country: 'الإمارات', city: 'دبي', district: 'حي الكرامة',
    nationality: 'الإمارات', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'عزباء',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 160, weight: 52, skinColor: 'أبيض جدا',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'باحث عن عمل',
    housing: 'أسكن مع العائلة',
    bio: 'محاسبة هادئة الطباع، أحب العائلة والاستقرار، أبحث عن شريك حياة جاد وحسن الخلق.',
    aboutPartner: 'أبحث عن رجل متدين، مستقر ماديًا، يحب العائلة ويقدّر معنى الزواج الحقيقي.',
    verified: false, premium: false, online: true, lastActive: 'متصل الآن', matchScore: 89,
  },
];

export function getMemberById(id: string): Member | undefined {
  return MEMBERS.find((m) => m.id === id);
}
