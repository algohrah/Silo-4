import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';

interface UserProfile {
  name: string;
  email: string;
  city: string;
  age: number;
  plan: 'free' | 'gold' | 'elite';
  verified: boolean;
  profileCompletion: number;
  credits: number;
  isBoosted?: boolean;
}

interface AuthUser {
  name: string;
  isLoggedIn: boolean;
  profile: UserProfile;
}

import { PLANS as DEFAULT_PLANS } from './data';
import type { Plan } from './types';

interface PaypalSettings {
  clientId: string;
  clientSecret: string;
  mode: 'sandbox' | 'live';
  guestCheckout: boolean;
  active: boolean;
}

export interface PaymentSettings {
  paypalActive: boolean;
  cryptoActive: boolean;
  bankActive: boolean;
  cryptoWalletAddress: string;
  bankDetails: string;
  forceSingleMethod: 'none' | 'paypal' | 'crypto' | 'bank';
}

export interface SocialSettings {
  whatsappNumber: string;
  showWhatsapp: boolean;
  twitter: string;
  showTwitter: boolean;
  instagram: string;
  showInstagram: boolean;
  snapchat: string;
  showSnapchat: boolean;
  facebook: string;
  showFacebook: boolean;
}

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  user: AuthUser;
  login: (name: string) => void;
  logout: () => void;
  likedMembers: Set<string>;
  toggleLike: (id: string) => void;
  toasts: Toast[];
  showToast: (message: string, type?: Toast['type']) => void;
  dismissToast: (id: number) => void;
  upgradePlan: (plan: 'gold' | 'elite') => void;
  plans: Plan[];
  updatePlan: (updated: Plan) => void;
  paypalSettings: PaypalSettings;
  updatePaypalSettings: (settings: PaypalSettings) => void;
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: PaymentSettings) => void;
  socialSettings: SocialSettings;
  updateSocialSettings: (settings: SocialSettings) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  usage: {
    messagesSent: number;
    searchesDone: number;
    contactsViewed: number;
  };
  checkLimit: (action: 'message' | 'search' | 'contact') => { allowed: boolean; current: number; max: number; error?: string };
  incrementUsage: (action: 'message' | 'search' | 'contact') => void;
  buyMicrotransaction: (type: 'messages_20' | 'contact_1', cost: number) => void;
  boostProfile: () => void;
  isBoosted: boolean;
  resetUsage: () => void;
}

const DEFAULT_PROFILE: UserProfile = {
  name: 'سارة',
  email: 'demo@tawasul.sa',
  city: 'الرياض',
  age: 26,
  plan: 'gold',
  verified: true,
  profileCompletion: 85,
  credits: 12,
  isBoosted: false,
};

const DEFAULT_PAYPAL: PaypalSettings = {
  clientId: 'AX_demo_paypal_client_id_12345',
  clientSecret: 'SK_demo_secret_key_54321',
  mode: 'sandbox',
  guestCheckout: true,
  active: true,
};

const DEFAULT_PAYMENTS_CONFIG: PaymentSettings = {
  paypalActive: true,
  cryptoActive: true,
  bankActive: true,
  cryptoWalletAddress: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F (USDT ERC20)',
  bankDetails: 'مصرف الراجحي - رقم الحساب: SA8980000012345678901234 - باسم شركة توافق المحدودة',
  forceSingleMethod: 'none'
};

const DEFAULT_SOCIALS: SocialSettings = {
  whatsappNumber: '966500000000',
  showWhatsapp: true,
  twitter: 'https://twitter.com/tawasul_sa',
  showTwitter: true,
  instagram: 'https://instagram.com/tawasul_sa',
  showInstagram: true,
  snapchat: 'https://snapchat.com/add/tawasul_sa',
  showSnapchat: true,
  facebook: 'https://facebook.com/tawasul_sa',
  showFacebook: false,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser>({
    name: '',
    isLoggedIn: false,
    profile: DEFAULT_PROFILE,
  });
  const [likedMembers, setLikedMembers] = useState<Set<string>>(new Set(['m2', 'm5']));
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Initialize plans with local storage backup or default
  const [plans, setPlans] = useState<Plan[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('saved_plans');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PLANS;
  });

  // Initialize PayPal settings from storage or default
  const [paypalSettings, setPaypalSettings] = useState<PaypalSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('paypal_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PAYPAL;
  });

  // Initialize Social and WhatsApp settings from storage or default
  const [socialSettings, setSocialSettings] = useState<SocialSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('social_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_SOCIALS;
  });

  // Initialize unified Multiple Payments config from storage or default
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('payment_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PAYMENTS_CONFIG;
  });

  const updatePaymentSettings = useCallback((settings: PaymentSettings) => {
    setPaymentSettings(settings);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('payment_settings', JSON.stringify(settings));
    }
  }, []);

  // Initialize dark mode
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('dark_mode');
      return saved === 'true';
    }
    return false;
  });

  const toggleDarkMode = useCallback(() => {
    setDarkMode(prev => {
      const next = !prev;
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('dark_mode', String(next));
        if (next) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
      return next;
    });
  }, []);

  // Sync dark class on mount and state change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [darkMode]);

  // Keep track of active operational counters in local state with persistent backup
  const [usage, setUsage] = useState<{
    messagesSent: number;
    searchesDone: number;
    contactsViewed: number;
  }>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('user_usage_counters');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          console.warn("Error parsing usage counters:", e);
        }
      }
    }
    return { messagesSent: 0, searchesDone: 0, contactsViewed: 0 };
  });

  const [isBoosted, setIsBoosted] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('profile_boosted');
      return saved === 'true';
    }
    return false;
  });

  const showToast = useCallback((message: string, type: Toast['type'] = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const login = (name: string) => {
    const finalName = name || 'سارة';
    setUser({
      name: finalName,
      isLoggedIn: true,
      profile: { ...DEFAULT_PROFILE, name: finalName },
    });
  };

  const logout = () => setUser({ name: '', isLoggedIn: false, profile: DEFAULT_PROFILE });

  const toggleLike = (id: string) => {
    setLikedMembers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        showToast('تمت الإزالة من الإعجابات', 'info');
      } else {
        next.add(id);
        showToast('تمت الإضافة إلى الإعجابات ❤', 'success');
      }
      return next;
    });
  };

  const upgradePlan = (plan: 'gold' | 'elite') => {
    setUser((prev) => ({
      ...prev,
      profile: { ...prev.profile, plan },
    }));
    showToast(`تم تفعيل باقة ${plan === 'gold' ? 'الذهبية' : 'النخبة'} بنجاح! 🎉`, 'success');
  };

  const updatePlan = (updated: Plan) => {
    setPlans((prev) => {
      const next = prev.map((p) => (p.id === updated.id ? updated : p));
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('saved_plans', JSON.stringify(next));
      }
      return next;
    });
    showToast(`تم تحديث باقة ${updated.name} بنجاح!`, 'success');
  };

  const updatePaypalSettings = (settings: PaypalSettings) => {
    setPaypalSettings(settings);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('paypal_settings', JSON.stringify(settings));
    }
    showToast('تم حفظ إعدادات PayPal بنجاح!', 'success');
  };

  const updateSocialSettings = (settings: SocialSettings) => {
    setSocialSettings(settings);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('social_settings', JSON.stringify(settings));
    }
    showToast('تم حفظ إعدادات التواصل الاجتماعي بنجاح!', 'success');
  };

  // CHECK LIMIT LOGIC
  const checkLimit = useCallback((action: 'message' | 'search' | 'contact') => {
    const currentPlanId = user.profile.plan === 'gold' ? 'premium' : user.profile.plan === 'elite' ? 'elite' : 'free';
    const activePlan = plans.find((p) => p.id === currentPlanId) || plans[0];

    let max = 0;
    let current = 0;

    if (action === 'message') {
      max = activePlan.messagesLimit !== undefined ? activePlan.messagesLimit : 5;
      current = usage.messagesSent;
    } else if (action === 'search') {
      max = activePlan.searchLimit !== undefined ? activePlan.searchLimit : 2;
      current = usage.searchesDone;
    } else if (action === 'contact') {
      max = activePlan.showContactLimit !== undefined ? activePlan.showContactLimit : 0;
      current = usage.contactsViewed;
    }

    const allowed = current < max;

    return {
      allowed,
      current,
      max,
      error: allowed
        ? undefined
        : `لقد استنفدت حد باقتك لهذا اليوم (${max}/${max})، يرجى ترقية اشتراكك للحصول على صلاحيات أكبر وبلا حدود!`,
    };
  }, [user.profile.plan, plans, usage]);

  // INCREMENT COUNTER ON ACTION SUCCESS
  const incrementUsage = useCallback((action: 'message' | 'search' | 'contact') => {
    setUsage((prev) => {
      const next = { ...prev };
      if (action === 'message') next.messagesSent += 1;
      if (action === 'search') next.searchesDone += 1;
      if (action === 'contact') next.contactsViewed += 1;

      if (typeof window !== 'undefined') {
        window.localStorage.setItem('user_usage_counters', JSON.stringify(next));
      }
      return next;
    });
  }, []);

  const resetUsage = useCallback(() => {
    const fresh = { messagesSent: 0, searchesDone: 0, contactsViewed: 0 };
    setUsage(fresh);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('user_usage_counters', JSON.stringify(fresh));
    }
    showToast('تم تصفير عدادات الاستخدام والميزات التجريبية بنجاح.', 'success');
  }, [showToast]);

  // MICROTRANSACTIONS LOGIC (buying 20 messages pack or 1 contact pack)
  const buyMicrotransaction = useCallback((type: 'messages_20' | 'contact_1', cost: number) => {
    // subtract usage offset so user gets more tokens allowed or just deduct from usage counter
    setUsage((prev) => {
      const next = { ...prev };
      if (type === 'messages_20') {
        // give breathing room of 20 more messages
        next.messagesSent = Math.max(0, next.messagesSent - 20);
      } else if (type === 'contact_1') {
        // give breathing room of 1 more contact
        next.contactsViewed = Math.max(0, next.contactsViewed - 1);
      }
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('user_usage_counters', JSON.stringify(next));
      }
      return next;
    });

    setUser((prev) => {
      const nextProfile = { ...prev.profile };
      // optionally adjust credits if they had enough
      nextProfile.credits = Math.max(0, nextProfile.credits - cost);
      return { ...prev, profile: nextProfile };
    });

    showToast(
      type === 'messages_20'
        ? `🎉 تم شراء حزمة (20 رسالة إضافية) وتفعيلها بنجاح!`
        : `🎉 تم تفعيل رؤية رقم تواصل لحساب إضافي بنجاح!`,
      'success'
    );
  }, [showToast]);

  // PROFILE BOOSTING LOGIC
  const boostProfile = useCallback(() => {
    setIsBoosted(true);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('profile_boosted', 'true');
    }
    setUser((prev) => ({
      ...prev,
      profile: { ...prev.profile, isBoosted: true },
    }));
    showToast('تم رفع وترقية ملفك متصدراً نتائج البحث بنجاح! 🚀✨', 'success');
  }, [showToast]);

  return (
    <AppContext.Provider
      value={{
        user,
        login,
        logout,
        likedMembers,
        toggleLike,
        toasts,
        showToast,
        dismissToast,
        upgradePlan,
        plans,
        updatePlan,
        paypalSettings,
        updatePaypalSettings,
        paymentSettings,
        updatePaymentSettings,
        socialSettings,
        updateSocialSettings,
        darkMode,
        toggleDarkMode,
        usage,
        checkLimit,
        incrementUsage,
        buyMicrotransaction,
        boostProfile,
        isBoosted,
        resetUsage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
