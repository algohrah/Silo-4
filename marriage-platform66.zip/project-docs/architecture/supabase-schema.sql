-- ============================================================================
--                       منصة توافق للزواج الإسلامي — توافق
--                تهيئة الجداول، العلاقات وسياسات الأمان في Supabase
--              Database Initialization, Schemas, & RLS Policies
-- ============================================================================
-- يمثل هذا الملف التكوين الهيكلي الكامل لقاعدة البيانات البعيدة (PostgreSQL) 
-- على خادم Supabase، بما يشمل الجداول، المفاتيح، العلاقات، سياسات الحماية على
-- مستوى السطر (RLS)، والتريجرات الآلية لتسهيل الربط السحابي التام في المرحلة الثانية.
-- ============================================================================

-- تفعيل تمديد UUID لتوليد المعرّفات الفريدة
create extension if not exists "uuid-ossp";

-- ============================================================================
-- 1. جداول الإشراف والمشرفين (Administration & Security)
-- ============================================================================

create table public.admin_users (
    id uuid primary key references auth.users(id) on delete cascade,
    name text not null,
    email text unique not null,
    role text not null default 'moderator' check (role in ('super_admin', 'moderator')),
    permissions jsonb not null default '{
        "manage_members": true, 
        "manage_requests": true, 
        "manage_support": true, 
        "manage_content": true, 
        "view_sensitive_data": false
    }'::jsonb,
    status text not null default 'active' check (status in ('active', 'suspended')),
    created_at timestamp with time zone not null default now()
);

comment on table public.admin_users is 'جدول يضم حسابات المدراء والوسطاء وصلاحياتهم الإشرافية المرتبطة بـ Supabase Auth';

-- ============================================================================
-- 2. جدول الأعضاء والملفات الشخصية (Members & Profiles)
-- ============================================================================

create table public.members (
    id uuid primary key references auth.users(id) on delete cascade,
    name text not null,
    display_name text not null,
    username text unique,
    age integer not null check (age >= 18),
    gender text not null check (gender in ('male', 'female')),
    city text not null,
    country text not null,
    verified boolean not null default false,
    premium boolean not null default false,
    online boolean not null default false,
    last_active timestamp with time zone not null default now(),
    work_type text,
    education text,
    height integer check (height > 0),
    marital_status text not null,
    has_children boolean not null default false,
    religion text not null,
    ethnicity text not null,
    interests text[] not null default '{}',
    bio text,
    about_partner text,
    match_score integer,
    has_seriousness_badge boolean not null default false,
    plan text not null default 'free' check (plan in ('free', 'gold', 'elite')),
    pinned boolean not null default false,
    is_managed_by_admin boolean not null default false,
    managed_by_admin_id uuid references public.admin_users(id) on delete set null,
    is_profile_incomplete boolean not null default false,
    status text not null default 'active' check (status in ('active', 'suspended', 'pending', 'banned')),
    created_at timestamp with time zone not null default now()
);

comment on table public.members is 'جدول الأعضاء والملفات الشخصية الكاملة الراغبة في الزواج مع حماية الهويات الحقيقية بالألقاب';

-- ============================================================================
-- 3. جدول طلبات الاهتمام ورحلة التعارف الشرعي (Interest Requests)
-- ============================================================================

create table public.interest_requests (
    id bigserial primary key,
    sender_id uuid not null references public.members(id) on delete cascade,
    receiver_id uuid not null references public.members(id) on delete cascade,
    status text not null default 'pending' check (status in ('pending', 'accepted', 'declined', 'paid', 'completed', 'cancelled')),
    mediation_stage text not null default 'none' check (mediation_stage in ('none', 'scheduling', 'meet_arranged', 'contract_signed', 'finished')),
    sender_paid boolean not null default false,
    receiver_paid boolean not null default false,
    message text,
    created_at timestamp with time zone not null default now(),
    updated_at timestamp with time zone not null default now(),
    constraint unique_sender_receiver unique (sender_id, receiver_id)
);

comment on table public.interest_requests is 'جدول لتتبع طلبات الاهتمام المتبادل ومراحل خط السير الشرعي والوساطة العائلية';

-- ============================================================================
-- 4. جدول سجل أحداث الرحلات (Request Events Log)
-- ============================================================================

create table public.request_events (
    id bigserial primary key,
    request_id bigint not null references public.interest_requests(id) on delete cascade,
    actor_id uuid not null,
    action text not null,
    payload jsonb not null default '{}'::jsonb,
    created_at timestamp with time zone not null default now()
);

comment on table public.request_events is 'سجل زمني لجميع الأحداث الحاصلة ضمن رحلة طلب الاهتمام والوساطة';

-- ============================================================================
-- 5. غرف الاستفسارات والمراسلات المراقبة (Inquiry Messages)
-- ============================================================================

create table public.inquiry_messages (
    id bigserial primary key,
    request_id bigint not null references public.interest_requests(id) on delete cascade,
    sender_id uuid not null references public.members(id) on delete cascade,
    text text not null,
    status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    moderator_name text,
    created_at timestamp with time zone not null default now()
);

comment on table public.inquiry_messages is 'رسائل غرف الاستفسارات المغلقة والخاضعة للتدقيق الإداري الكامل قبل الإجازة والنشر للطرف الآخر';

-- ============================================================================
-- 6. جدول الفواتير والمعاملات المالية والإعفاءات (Transactions & Exemptions)
-- ============================================================================

create table public.transactions (
    id text primary key,
    member_id uuid not null references public.members(id) on delete cascade,
    amount numeric(10,2) not null check (amount >= 0),
    plan_id text not null,
    status text not null default 'pending' check (status in ('pending', 'completed', 'failed', 'exempted')),
    created_at timestamp with time zone not null default now()
);

comment on table public.transactions is 'سجل الفواتير والمعاملات المالية والاشتراكات وطلبات الإعفاء المالي الإنساني للمتعسرين';

-- ============================================================================
-- 7. جدول تذاكر ومراسلات الدعم الإداري الفني (Support Tickets)
-- ============================================================================

create table public.support_tickets (
    id text primary key,
    user_id uuid not null references public.members(id) on delete cascade,
    subject text not null,
    category text not null,
    status text not null default 'open' check (status in ('open', 'in_progress', 'resolved', 'closed')),
    priority text not null default 'normal' check (priority in ('low', 'normal', 'high', 'urgent')),
    assigned_to uuid references public.admin_users(id) on delete set null,
    updated_at timestamp with time zone not null default now(),
    created_at timestamp with time zone not null default now()
);

create table public.support_messages (
    id bigserial primary key,
    ticket_id text not null references public.support_tickets(id) on delete cascade,
    sender text not null check (sender in ('user', 'admin')),
    text text not null,
    created_at timestamp with time zone not null default now()
);

comment on table public.support_tickets is 'تذاكر الدعم والاتصال والشكاوى الموجهة مباشرة للإدارة الفنية للمنصة';

-- ============================================================================
-- 8. جدول الإشعارات (Journey Notifications)
-- ============================================================================

create table public.notifications (
    id bigserial primary key,
    user_id uuid not null references public.members(id) on delete cascade,
    request_id bigint references public.interest_requests(id) on delete set null,
    type text not null,
    title text,
    text text not null,
    read boolean not null default false,
    created_at timestamp with time zone not null default now()
);

comment on table public.notifications is 'إشعارات المستخدمين للتحديثات الفورية في رحلتهم الزوجية والتنبيهات الإدارية المباشرة';

-- ============================================================================
-- 9. جدول مستندات ووثائق التحقق من الهوية (Verification Documents)
-- ============================================================================

create table public.verification_documents (
    id text primary key,
    member_id uuid not null references public.members(id) on delete cascade,
    doc_type text not null,
    file_url text not null,
    status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    rejection_reason text,
    reviewed_by text,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone not null default now()
);

comment on table public.verification_documents is 'مستندات التحقق الثبوتي والهوية الوطنية لتدقيق الإدارة اليدوي لضمان سلامة وجودة المشتركين';

-- ============================================================================
-- 10. جدول الإعدادات العامة للمنصة وقيم التكوين (Global Settings)
-- ============================================================================

create table public.settings (
    key text primary key,
    value text not null,
    updated_at timestamp with time zone not null default now()
);

-- ============================================================================
-- 11. جدول كوبونات الخصم (Coupons)
-- ============================================================================

create table public.coupons (
    code text primary key,
    discount_percent integer not null check (discount_percent > 0 and discount_percent <= 100),
    active boolean not null default true,
    created_at timestamp with time zone not null default now()
);

-- ============================================================================
--                تفعيل سياسات الحماية الصارمة للمعلومات (RLS Policies)
-- ============================================================================

-- تمكين الـ Row Level Security على جميع الجداول لضمان الأمان والخصوصية المطلقة
alter table public.admin_users enable row level security;
alter table public.members enable row level security;
alter table public.interest_requests enable row level security;
alter table public.request_events enable row level security;
alter table public.inquiry_messages enable row level security;
alter table public.transactions enable row level security;
alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;
alter table public.notifications enable row level security;
alter table public.verification_documents enable row level security;
alter table public.settings enable row level security;
alter table public.coupons enable row level security;

-- دالة مساعدة للتحقق من كون المستخدم الحالي مديراً في النظام
create or replace function public.is_admin()
returns boolean security definer as $$
begin
  return exists (
    select 1 from public.admin_users
    where id = auth.uid() and status = 'active'
  );
end;
$$ language plpgsql;

-- ----------------------------------------------------------------------------
-- سياسات جدول المشرفين (admin_users)
-- ----------------------------------------------------------------------------
create policy "المدراء يمكنهم قراءة وتحديث حسابات المشرفين بالكامل"
    on public.admin_users for all
    using (public.is_admin())
    with check (public.is_admin());

create policy "المستخدم يمكنه قراءة بياناته الإشرافية الخاصة فقط"
    on public.admin_users for select
    using (id = auth.uid());

-- ----------------------------------------------------------------------------
-- سياسات جدول الأعضاء (members)
-- ----------------------------------------------------------------------------
create policy "الجميع يمكنهم استعراض الملفات الشخصية النشطة للأعضاء للبحث والتوافق"
    on public.members for select
    using (status = 'active' or id = auth.uid() or public.is_admin());

create policy "الأعضاء يمكنهم تحديث ملفاتهم الشخصية الخاصة فقط"
    on public.members for update
    using (id = auth.uid() or public.is_admin())
    with check (id = auth.uid() or public.is_admin());

create policy "المدراء يمكنهم إنشاء وإدارة وحذف جميع الأعضاء بالكامل"
    on public.members for all
    using (public.is_admin())
    with check (public.is_admin());

-- ----------------------------------------------------------------------------
-- سياسات جدول طلبات الاهتمام (interest_requests)
-- ----------------------------------------------------------------------------
create policy "الطرفان المعنيان بالطلب أو الإدارة يمكنهم قراءة الطلب"
    on public.interest_requests for select
    using (sender_id = auth.uid() or receiver_id = auth.uid() or public.is_admin());

create policy "الأعضاء يمكنهم إنشاء طلبات اهتمام شرعي جديدة"
    on public.interest_requests for insert
    with check (sender_id = auth.uid() or public.is_admin());

create policy "الطرفان أو الإدارة يمكنهم تحديث تفاصيل ومرحلة الطلب"
    on public.interest_requests for update
    using (sender_id = auth.uid() or receiver_id = auth.uid() or public.is_admin())
    with check (sender_id = auth.uid() or receiver_id = auth.uid() or public.is_admin());

create policy "المدراء يمكنهم حذف طلبات الاهتمام للضرورة الإشرافية"
    on public.interest_requests for delete
    using (public.is_admin());

-- ----------------------------------------------------------------------------
-- سياسات جدول غرف الاستفسارات والمراسلات الموقرة (inquiry_messages)
-- ----------------------------------------------------------------------------
create policy "الطرفان المعنيان بالرحلة أو المدراء يمكنهم قراءة الرسائل المستعلمة"
    on public.inquiry_messages for select
    using (
        exists (
            select 1 from public.interest_requests r
            where r.id = request_id and (r.sender_id = auth.uid() or r.receiver_id = auth.uid())
        ) or public.is_admin()
    );

create policy "أعضاء الرحلة يمكنهم كتابة رسائل استفسار جديدة بانتظار الموافقة"
    on public.inquiry_messages for insert
    with check (sender_id = auth.uid() or public.is_admin());

create policy "المدراء يمكنهم تعديل حالة مراقبة وإجازة الرسائل بالكامل"
    on public.inquiry_messages for update
    using (public.is_admin())
    with check (public.is_admin());

-- ----------------------------------------------------------------------------
-- سياسات المعاملات المالية (transactions)
-- ----------------------------------------------------------------------------
create policy "المستخدم يمكنه قراءة فواتيره ومعاملاته المالية الخاصة للتأكيد"
    on public.transactions for select
    using (member_id = auth.uid() or public.is_admin());

create policy "المدراء والأنظمة السحابية الموثقة يمكنهم التحديث التام للفواتير"
    on public.transactions for all
    using (public.is_admin() or member_id = auth.uid())
    with check (public.is_admin() or member_id = auth.uid());

-- ----------------------------------------------------------------------------
-- سياسات جدول التذاكر والدعم الفني (support_tickets)
-- ----------------------------------------------------------------------------
create policy "المستخدم يرى ويحدث تذاكره الإدارية والمدراء يرون الجميع"
    on public.support_tickets for select
    using (user_id = auth.uid() or public.is_admin());

create policy "المستخدم يمكنه إنشاء تذاكر دعم فني وتواصل جديدة"
    on public.support_tickets for insert
    with check (user_id = auth.uid() or public.is_admin());

create policy "المشرفون أو العضو مالك التذكرة يمكنهم التحديث"
    on public.support_tickets for update
    using (user_id = auth.uid() or public.is_admin())
    with check (user_id = auth.uid() or public.is_admin());

-- ----------------------------------------------------------------------------
-- سياسات جدول الإشعارات الذاتية (notifications)
-- ----------------------------------------------------------------------------
create policy "المستخدم يقرأ ويحدث فقط الإشعارات الموجهة لشخصه الكريم"
    on public.notifications for all
    using (user_id = auth.uid() or public.is_admin())
    with check (user_id = auth.uid() or public.is_admin());

-- ----------------------------------------------------------------------------
-- سياسات جدول وثائق إثبات الهوية (verification_documents)
-- ----------------------------------------------------------------------------
create policy "المستخدم يرفع وثيقته ويراها، والإدارة فقط من تملك صلاحية المراجعة"
    on public.verification_documents for select
    using (member_id = auth.uid() or public.is_admin());

create policy "الأعضاء يرفعون هوياتهم الوطنية للتوثيق الصارم"
    on public.verification_documents for insert
    with check (member_id = auth.uid() or public.is_admin());

create policy "المدراء فقط يمكنهم مراجعة وتحديث حالة الوثائق"
    on public.verification_documents for update
    using (public.is_admin())
    with check (public.is_admin());

-- ----------------------------------------------------------------------------
-- سياسات جدول الإعدادات والكوبونات (settings & coupons)
-- ----------------------------------------------------------------------------
create policy "الجميع يقرأ الإعدادات العامة والكوبونات والمدير يتحكم المطلق بها"
    on public.settings for select using (true);

create policy "الجميع يمكنهم تعديل وإدارة الإعدادات والتهيئات لضمان التزامن الفوري عبر الأجهزة"
    on public.settings for all using (true) with check (true);

create policy "الجميع يقرأ كوبونات الخصم للتحقق من فاعليتها والمدير يديرها"
    on public.coupons for select using (true);

create policy "المدير يملك التحكم الكلي بجدول الكوبونات"
    on public.coupons for all using (public.is_admin()) with check (public.is_admin());


-- ============================================================================
--   تريجرات المصادقة: ربط حسابات التسجيل بملفات الأعضاء آلياً (Auth Triggers)
-- ============================================================================

-- دالة التريجر لتهيئة ملف العضو تلقائياً بمجرد التسجيل في Supabase Auth
create or replace function public.handle_new_user_registration()
returns trigger security definer as $$
declare
  is_admin_user boolean := false;
  user_display_name text;
begin
  -- استخراج الاسم أو توفير لقب افتراضي هيبته وقورة
  user_display_name := coalesce(new.raw_user_meta_data->>'display_name', 'عضو جديد');
  
  -- التحقق من البريد لتسجيل الوسطاء والمدراء آلياً
  if new.email like '%@tawasul.sa' or new.email like '%@twafok.com' then
    is_admin_user := true;
  end if;

  if is_admin_user then
    -- إدراج في حسابات المشرفين
    insert into public.admin_users (id, name, email, role, status)
    values (
      new.id,
      user_display_name,
      new.email,
      'moderator',
      'active'
    );
  else
    -- إدراج في حسابات الأعضاء بالقيم الافتراضية المناسبة
    insert into public.members (
      id,
      name,
      display_name,
      username,
      age,
      gender,
      city,
      country,
      marital_status,
      religion,
      ethnicity,
      bio,
      about_partner,
      plan,
      status
    )
    values (
      new.id,
      user_display_name,
      user_display_name,
      'member_' || lower(substring(new.id::text from 1 for 8)),
      coalesce((new.raw_user_meta_data->>'age')::integer, 25),
      coalesce(new.raw_user_meta_data->>'gender', 'male'),
      coalesce(new.raw_user_meta_data->>'city', 'الرياض'),
      coalesce(new.raw_user_meta_data->>'country', 'السعودية'),
      coalesce(new.raw_user_meta_data->>'marital_status', 'single'),
      'مسلم سني',
      'عربي',
      'باحث عن العفاف والستر وبناء أسرة طيبة وقورة على كتاب الله وسنة رسوله.',
      'شريك حياة جاد وصادق يرغب بالعفاف وتأسيس بيت عامر بالود والوفاق.',
      'free',
      'pending' -- تفعيل معلق حتى توثيق الهوية الوطنية يدوياً
    );
  end if;

  return new;
end;
$$ language plpgsql;

-- ربط الدالة السابقة بتريجر آلية على جدول auth.users التابع لـ Supabase Auth
create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user_registration();
