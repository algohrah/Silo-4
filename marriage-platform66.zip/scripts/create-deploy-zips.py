import os
import zipfile
import shutil

def create_dist_zip():
    print("Creating dist_static.zip...")
    if os.path.exists('dist_static.zip'):
        os.remove('dist_static.zip')
    
    # Zip the contents of 'dist' folder directly (so index.html is at the root of the zip)
    with zipfile.ZipFile('dist_static.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('dist'):
            for file in files:
                file_path = os.path.join(root, file)
                # Keep relative path inside the zip starting from inside 'dist'
                arcname = os.path.relpath(file_path, 'dist')
                zipf.write(file_path, arcname)
    print("Successfully created dist_static.zip!")

def create_source_zip():
    print("Creating project_source.zip...")
    if os.path.exists('project_source.zip'):
        os.remove('project_source.zip')

    ignored_dirs = {'.git', 'node_modules', 'dist', '__pycache__'}
    ignored_files = {'project_source.zip', 'dist_static.zip'}

    with zipfile.ZipFile('project_source.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Exclude ignored directories
            dirs[:] = [d for d in dirs if d not in ignored_dirs]
            
            for file in files:
                if file in ignored_files:
                    continue
                file_path = os.path.join(root, file)
                # Remove leading './'
                arcname = os.path.relpath(file_path, '.')
                zipf.write(file_path, arcname)
    print("Successfully created project_source.zip!")

if __name__ == '__main__':
    create_dist_zip()
    create_source_zip()
