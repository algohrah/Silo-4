export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  
  return res.status(200).json({ 
    countries: ['السعودية', 'الإمارات', 'الكويت', 'قطر', 'البحرين', 'عمان', 'مصر', 'الأردن'], 
    cities: {
      'السعودية': ['الرياض', 'جدة', 'مكة المكرمة', 'المدينة المنورة', 'الدمام', 'الخبر', 'الطائف', 'بريدة', 'تبوك', 'أبها', 'حائل', 'نجران', 'الأحساء', 'القطيف', 'الباحة'],
      'الإمارات': ['دبي', 'أبو ظبي', 'الشارقة', 'العين'],
      'الكويت': ['الكويت', 'حولي', 'الجهراء'],
      'قطر': ['الدوحة', 'الريان'],
      'البحرين': ['المنامة', 'المحرق'],
      'عمان': ['مسقط', 'صلالة']
    }
  });
}
