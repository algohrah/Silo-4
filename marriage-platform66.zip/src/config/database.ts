export type DatabaseProvider = 'local' | 'supabase' | 'real_database';

export const DATABASE_CONFIG = {
  PROVIDER: 'supabase' as DatabaseProvider,
};
