import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { AppProvider } from './lib/AppContext';
import Layout from './components/layout/Layout';
import AdminLayout from './components/admin/AdminLayout';

// Public/User pages
import Home from './pages/Home';
import Search from './pages/Search';
import Profile from './pages/Profile';
import EditProfile from './pages/EditProfile';
import CompleteProfile from './pages/CompleteProfile';
import MemberProfile from './pages/MemberProfile';
import Register from './pages/Register';
import Login from './pages/Login';
import AuthPage from './pages/AuthPage';
import About from './pages/About';
import Contact from './pages/Contact';
import FAQ from './pages/FAQ';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import Plans from './pages/Plans';
import Checkout from './pages/Checkout';
import JourneyPage from './pages/JourneyPage';
import Notifications from './pages/Notifications';
import InterestRequests from './pages/InterestRequests';
import Support from './pages/Support';
import AdminChat from './pages/AdminChat';
import LegalPage from './pages/Legal';
import NotFound from './pages/NotFound';

// Admin pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminMembers from './pages/admin/AdminMembers';
import AdminRequests from './pages/admin/AdminRequests';
import AdminVerifications from './pages/admin/AdminVerifications';
import AdminTransactions from './pages/admin/AdminTransactions';
import AdminMessages from './pages/admin/AdminMessages';
import AdminReports from './pages/admin/AdminReports';
import AdminModerators from './pages/admin/AdminModerators';
import AdminPlans from './pages/admin/AdminPlans';
import AdminPlatformSettings from './pages/admin/AdminPlatformSettings';
import AdminPaymentSettings from './pages/admin/AdminPaymentSettings';
import AdminSecuritySettings from './pages/admin/AdminSecuritySettings';
import AdminNotifications from './pages/admin/AdminNotifications';
import AdminCities from './pages/admin/AdminCities';
import AdminAnalytics from './pages/admin/AdminAnalytics';
import AdminImportMembers from './pages/admin/AdminImportMembers';
import AdminContent from './pages/admin/AdminContent';
import AdminExemptions from './pages/admin/AdminExemptions';
import AdminCoupons from './pages/admin/AdminCoupons';
import AdminFeatureSettings from './pages/admin/AdminFeatureSettings';
import AdminAuditLog from './pages/admin/AdminAuditLog';
import AdminImportedCoordination from './pages/admin/AdminImportedCoordination';

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <BrowserRouter>
          <Routes>
            {/* User facing layout */}
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="search" element={<Search />} />
              <Route path="profile" element={<Profile />} />
              <Route path="edit-profile" element={<EditProfile />} />
              <Route path="complete-profile" element={<CompleteProfile />} />
              <Route path="member/:id" element={<MemberProfile />} />
              <Route path="u/:username" element={<MemberProfile />} />
              <Route path="register" element={<Register />} />
              <Route path="login" element={<Login />} />
              <Route path="auth" element={<AuthPage />} />
              <Route path="about" element={<About />} />
              <Route path="contact" element={<Contact />} />
              <Route path="faq" element={<FAQ />} />
              <Route path="blog" element={<Blog />} />
              <Route path="blog/:id" element={<BlogPost />} />
              <Route path="plans" element={<Plans />} />
              <Route path="checkout/:planId" element={<Checkout />} />
              <Route path="journey" element={<JourneyPage />} />
              <Route path="journey/:id" element={<JourneyPage />} />
              <Route path="notifications" element={<Notifications />} />
              <Route path="requests" element={<InterestRequests />} />
              <Route path="support" element={<Support />} />
              <Route path="admin-chat" element={<AdminChat />} />
              <Route path="legal/privacy" element={<LegalPage type="privacy" />} />
              <Route path="legal/terms" element={<LegalPage type="terms" />} />
              <Route path="*" element={<NotFound />} />
            </Route>

            {/* Admin layout */}
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<AdminDashboard />} />
              <Route path="analytics" element={<AdminAnalytics />} />
              <Route path="members" element={<AdminMembers />} />
              <Route path="import-members" element={<AdminImportMembers />} />
              <Route path="cities" element={<AdminCities />} />
              <Route path="verifications" element={<AdminVerifications />} />
              <Route path="moderators" element={<AdminModerators />} />
              <Route path="requests" element={<AdminRequests />} />
              <Route path="imported-coordination" element={<AdminImportedCoordination />} />
              <Route path="messages" element={<AdminMessages />} />
              <Route path="reports" element={<AdminReports />} />
              <Route path="audit-log" element={<AdminAuditLog />} />
              <Route path="plans" element={<AdminPlans />} />
              <Route path="transactions" element={<AdminTransactions />} />
              <Route path="coupons" element={<AdminCoupons />} />
              <Route path="exemptions" element={<AdminExemptions />} />
              <Route path="content" element={<AdminContent />} />
              <Route path="notifications" element={<AdminNotifications />} />
              <Route path="settings/platform" element={<AdminPlatformSettings />} />
              <Route path="settings/payments" element={<AdminPaymentSettings />} />
              <Route path="settings/features" element={<AdminFeatureSettings />} />
              <Route path="settings/security" element={<AdminSecuritySettings />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </AppProvider>
    </AuthProvider>
  );
}
