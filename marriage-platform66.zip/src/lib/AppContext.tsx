import { dataService } from './data/DataService';
import React, { createContext, useContext, useState, useCallback, useEffect, useMemo, type ReactNode } from 'react';
import { MEMBERS } from './members';
import type { Member } from './members';
import { ADMIN_MEMBERS, ADMIN_NOTIFICATIONS } from './admin-data';
import type { AdminMember } from './admin-data';
import { INTEREST_REQUESTS, FEE_CONFIG, type InterestRequest, type RequestStatus, type MediationStage } from './data';

export interface ExemptRequest {
  id: string;
  requestId: string;
  userId: string;
  userNickname: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
}

interface UserProfile {
  name: string;
  email: string;
  city: string;
  age: number;
  plan: 'free' | 'gold' | 'elite';
  verified: boolean;
  profileCompletion: number;
  credits: number;
  isBoosted?: boolean;
  realName: string;
  phone: string;
  whatsapp: string;
  password: string;
}

interface AuthUser {
  name: string;
  isLoggedIn: boolean;
  memberId?: string;   // هوية العضو النشط (للتنقّل بين الحسابات)
  profile: UserProfile;
}

import { PLANS as DEFAULT_PLANS, SUPPORT_TICKETS as DEFAULT_TICKETS, DEFAULT_MESSAGE_PACKAGES } from './data';
import type { Plan, SupportTicket, InterestPurchaseSettings, MemberReport, AdminUser, AdminPermissions, MessagePackage } from './types';
import { calculateCompatibility, type CompatResult } from './compatibility';

interface PaypalSettings {
  clientId: string;
  clientSecret: string;
  mode: 'sandbox' | 'live';
  guestCheckout: boolean;
  active: boolean;
}

export interface PaymentSettings {
  paypalActive: boolean;
  cryptoActive: boolean;
  bankActive: boolean;
  cryptoWalletAddress: string;
  bankDetails: string;
  forceSingleMethod: 'none' | 'paypal' | 'crypto' | 'bank';
}

export interface SocialSettings {
  whatsappNumber: string;
  showWhatsapp: boolean;
  twitter: string;
  showTwitter: boolean;
  instagram: string;
  showInstagram: boolean;
  snapchat: string;
  showSnapchat: boolean;
  facebook: string;
  showFacebook: boolean;
}

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  user: AuthUser;
  login: (name: string, memberId?: string) => void;
  logout: () => void;
  registerNewMember: (memberData: any) => void;
  impersonateUser: (member: {
    id: string;
    nickname: string;
    gender?: string;
    age?: number;
    country?: string;
    city?: string;
    realName?: string;
    email?: string;
    phone?: string;
    plan?: string;
    password?: string;
  }) => void;
  importMembers: (newMembers: AdminMember[], replaceExisting?: boolean) => void;
  likedMembers: Set<string>;
  toggleLike: (id: string) => void;
  toasts: Toast[];
  showToast: (message: string, type?: Toast['type']) => void;
  dismissToast: (id: number) => void;
  upgradePlan: (plan: 'gold' | 'elite') => void;
  plans: Plan[];
  updatePlan: (updated: Plan) => void;
  addPlan: (newPlan: Plan) => void;
  deletePlan: (id: string) => void;
  paypalSettings: PaypalSettings;
  updatePaypalSettings: (settings: PaypalSettings) => void;
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: PaymentSettings) => void;
  socialSettings: SocialSettings;
  updateSocialSettings: (settings: SocialSettings) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  showDarkModeToggle: boolean;
  updateShowDarkModeToggle: (show: boolean) => void;
  usage: {
    messagesSent: number;
    searchesDone: number;
    contactsViewed: number;
  };
  checkLimit: (action: 'message' | 'search' | 'contact') => { allowed: boolean; current: number; max: number; error?: string };
  incrementUsage: (action: 'message' | 'search' | 'contact') => void;
  buyMicrotransaction: (type: 'messages_20' | 'contact_1', cost: number) => void;
  boostProfile: () => void;
  isBoosted: boolean;
  resetUsage: () => void;
  interestPurchaseSettings: InterestPurchaseSettings;
  updateInterestPurchaseSettings: (settings: InterestPurchaseSettings) => void;
  extraInterestsCount: number;
  setExtraInterestsCount: React.Dispatch<React.SetStateAction<number>>;
  unlimitedInterestsUntil: number;
  setUnlimitedInterestsUntil: React.Dispatch<React.SetStateAction<number>>;
  buyExtraInterests: () => void;
  messagePackages: MessagePackage[];
  updateMessagePackage: (updated: MessagePackage) => void;

  // Real-Time Stateful Collections & Admin integrations
  members: Member[];
  setMembers: React.Dispatch<React.SetStateAction<Member[]>>;
  adminMembers: AdminMember[];
  setAdminMembers: React.Dispatch<React.SetStateAction<AdminMember[]>>;
  interestRequests: InterestRequest[];
  adminUsers: AdminUser[];
  addAdminUser: (admin: Omit<AdminUser, 'id' | 'createdAt'>) => void;
  updateAdminUser: (id: string, updates: Partial<AdminUser>) => void;
  deleteAdminUser: (id: string) => void;
  currentAdminRole: AdminUser['role'];
  currentAdminPermissions: AdminPermissions;
  currentAdminName: string;
  simulateAdminLogin: (id: string | null) => void; // null means super admin (default)
  setInterestRequests: React.Dispatch<React.SetStateAction<InterestRequest[]>>;
  depositQuota: {
    hasActiveQuota: boolean;
    remainingAttempts: number;
    totalPaidAmount: number;
    paidAt?: string;
    selectedTierPrice?: number;
  };
  setDepositQuota: React.Dispatch<React.SetStateAction<{
    hasActiveQuota: boolean;
    remainingAttempts: number;
    totalPaidAmount: number;
    paidAt?: string;
    selectedTierPrice?: number;
  }>>;
  adminNotifications: any[];
  setAdminNotifications: React.Dispatch<React.SetStateAction<any[]>>;
  supportTickets: SupportTicket[];
  setSupportTickets: React.Dispatch<React.SetStateAction<SupportTicket[]>>;
  reports: MemberReport[];
  submitReport: (reportedId: string, reportedName: string, reason: string) => void;
  resolveReport: (id: string) => void;
  deleteReport: (id: string) => void;
  updateReport: (id: string, fields: Partial<MemberReport>) => void;
  addReportActionLog: (id: string, action: string, adminNote?: string, by?: string) => void;

  // Secure API boundaries for Admin operations
  adminDeleteMember: (id: string) => void;
  adminUpdateMemberStatus: (id: string, status: 'active' | 'suspended' | 'pending' | 'banned', reason?: string) => void;
  adminDeleteMemberFromReports: (id: string) => void;
  adminUpdateMember: (updated: AdminMember) => void;
  adminSendBulkBroadcast: (title: string, message: string, audience: 'all' | 'verified' | 'premium' | 'specific', specificIds?: string[]) => Promise<void>;
  adminUpdateInterestRequestStatus: (id: string, status: RequestStatus | 'accepted', declineReason?: string) => void;
  adminUpdateInterestRequestDetails: (id: string, fields: Partial<InterestRequest>) => void;
  adminCancelAndRefund: (requestId: string, type: 'full' | 'partial') => void;
  adminProcessExemptRequest: (id: string, action: 'approve' | 'reject') => void;
  adminModeratePreExchangeMessage: (requestId: string, messageId: string, action: 'approve' | 'reject') => void;
  
  // Exemption system
  exemptRequests: ExemptRequest[];
  submitExemptRequest: (requestId: string, reason: string) => void;
  payInterestRequestFee: (requestId: string, isSender: boolean, pledgeAccepted: boolean) => void;
  payPreExchangeChatFee: (requestId: string, isSender: boolean) => void;
  sendPreExchangeChatMessage: (requestId: string, text: string, isSender: boolean) => void;
  flagPreExchangeNoMoney: (requestId: string, isSender: boolean) => void;
  choosePreExchangeOption: (requestId: string, choice: 'chat' | 'direct_deposit' | null) => void;

  calculateCompat: (m1: Member, m2: Member) => number;
  calculateCompatDetailed: (target: Member) => CompatResult;
  sendInterestRequest: (memberId: string, messageText: string) => void;
  sendSupportMessage: (ticketId: string, text: string, sender: 'user' | 'admin') => void;
  createSupportTicket: (subject: string, category: 'استفسار عام' | 'طلب ترقية' | 'مشكلة تقنية' | 'شكوى' | 'اقتراح', initialMessageText: string, userId?: string) => SupportTicket;
  showCompatibility: boolean;
  compatibilityPaidOnly: boolean;
  updateCompatibilitySettings: (enabled: boolean, paidOnly: boolean) => void;
  profileData: ProfileData;
  updateProfileData: (fields: Partial<ProfileData>) => void;
  updateAccountInfo: (fields: { realName?: string; email?: string; phone?: string; whatsapp?: string; password?: string }) => void;
  allowProfileHiding: boolean;
  requireVerificationForRequests: boolean;
  enableWhoViewedMe: boolean;
  enableProfileBoosting: boolean;
  maxActiveRequests: number;
  pendingRequestsExpiryDays: number;
  updateFeatureSettings: (updates: {
    allowProfileHiding?: boolean;
    requireVerificationForRequests?: boolean;
    enableWhoViewedMe?: boolean;
    enableProfileBoosting?: boolean;
    maxActiveRequests?: number;
    pendingRequestsExpiryDays?: number;
  }) => void;
  isProfileHidden: boolean;
  toggleProfileHiding: () => void;
}

const DEFAULT_PROFILE: UserProfile = {
  name: 'سارة',
  email: 'demo@tawasul.sa',
  city: 'الرياض',
  age: 26,
  plan: 'gold',
  verified: true,
  profileCompletion: 85,
  credits: 12,
  isBoosted: false,
  realName: 'سارة أحمد القحطاني',
  phone: '+966501234567',
  whatsapp: '+966501234567',
  password: 'password123',
};

// ===== بيانات الملف الشخصي التفصيلية (كل حقول التسجيل) =====
export interface ProfileData {
  id?: string;
  gender: string;
  nickname: string;
  birthDate: string;
  age: number;
  country: string;
  city: string;
  district: string;
  sect: string;
  sectOther: string;
  nationality: string;
  maritalStatus: string;
  childrenCount: string;
  childrenLiveWith: string;
  hasChildren: string;
  wifeCount: string;
  seekingWife: string;
  height: number;
  weight: number;
  skinColor: string;
  ethnicity: string;
  health: string;
  smoking: string;
  acceptPolygamy: string;
  acceptDivorced: string;
  acceptWithChildren: string;
  education: string;
  workType: string;
  jobTitle: string;
  housing: string;
  bio: string;
  // مواصفات الشريك
  pCountry: string;
  pCity: string;
  pAgeMin: number;
  pAgeMax: number;
  pNationality: string;
  pMaritalStatus: string;
  pAcceptChildren: string;
  pSect: string;
  pSectOther: string;
  pEducation: string;
  pWorkType: string;
  pReligionLevel: string;
  pSkinColor: string;
  pHeightNoMatter: boolean;
  pHeight: number;
  pHousing: string;
  pNotes: string;
}

const DEFAULT_PROFILE_DATA: ProfileData = {
  id: 'm2',
  gender: 'female',
  nickname: 'سارة',
  birthDate: '',
  age: 26,
  country: 'السعودية',
  city: 'الرياض',
  district: '',
  sect: '',
  sectOther: '',
  nationality: 'السعودية',
  maritalStatus: 'single',
  childrenCount: '',
  childrenLiveWith: '',
  hasChildren: '',
  wifeCount: '',
  seekingWife: '',
  height: 0,
  weight: 0,
  skinColor: '',
  ethnicity: '',
  health: '',
  smoking: '',
  acceptPolygamy: '',
  acceptDivorced: '',
  acceptWithChildren: '',
  education: '',
  workType: '',
  jobTitle: '',
  housing: '',
  bio: '',
  pCountry: '',
  pCity: '',
  pAgeMin: 22,
  pAgeMax: 35,
  pNationality: '',
  pMaritalStatus: '',
  pAcceptChildren: '',
  pSect: '',
  pSectOther: '',
  pEducation: '',
  pWorkType: '',
  pReligionLevel: '',
  pSkinColor: '',
  pHeightNoMatter: false,
  pHeight: 170,
  pHousing: '',
  pNotes: '',
};

const DEFAULT_PAYPAL: PaypalSettings = {
  clientId: 'AX_demo_paypal_client_id_12345',
  clientSecret: 'SK_demo_secret_key_54321',
  mode: 'sandbox',
  guestCheckout: true,
  active: true,
};

const DEFAULT_PAYMENTS_CONFIG: PaymentSettings = {
  paypalActive: true,
  cryptoActive: true,
  bankActive: true,
  cryptoWalletAddress: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F (USDT ERC20)',
  bankDetails: 'مصرف الراجحي - رقم الحساب: SA8980000012345678901234 - باسم شركة توافق المحدودة',
  forceSingleMethod: 'none'
};

const DEFAULT_SOCIALS: SocialSettings = {
  whatsappNumber: '966500000000',
  showWhatsapp: true,
  twitter: 'https://twitter.com/tawasul_sa',
  showTwitter: true,
  instagram: 'https://instagram.com/tawasul_sa',
  showInstagram: true,
  snapchat: 'https://snapchat.com/add/tawasul_sa',
  showSnapchat: true,
  facebook: 'https://facebook.com/tawasul_sa',
  showFacebook: false,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [isInitialized, setIsInitialized] = useState(false);
  const [user, setUser] = useState<AuthUser>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('auth_user');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return {
      name: '',
      isLoggedIn: false,
      profile: DEFAULT_PROFILE,
    };
  });
  const [likedMembers, setLikedMembers] = useState<Set<string>>(new Set());
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((message: string, type: Toast['type'] = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Feature Settings States
  const [allowProfileHiding, setAllowProfileHiding] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('allow_profile_hiding');
      return saved === null ? true : saved === 'true';
    }
    return true;
  });

  const [requireVerificationForRequests, setRequireVerificationForRequests] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('require_verification_for_requests');
      return saved === 'true';
    }
    return false;
  });

  const [enableWhoViewedMe, setEnableWhoViewedMe] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('enable_who_viewed_me');
      return saved === null ? true : saved === 'true';
    }
    return true;
  });

  const [enableProfileBoosting, setEnableProfileBoosting] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('enable_profile_boosting');
      return saved === null ? true : saved === 'true';
    }
    return true;
  });

  const [maxActiveRequests, setMaxActiveRequests] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('max_active_requests');
      return saved ? parseInt(saved, 10) : 3;
    }
    return 3;
  });

  const [pendingRequestsExpiryDays, setPendingRequestsExpiryDays] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('pending_requests_expiry_days');
      return saved ? parseInt(saved, 10) : 7;
    }
    return 7;
  });

  // Persistent Collections for full administration real-time integration
  const [members, setMembers] = useState<Member[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_members_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return MEMBERS;
  });

  // فلترة الأعضاء النشطين فقط للعرض العام (إخفاء المحذوفين/المحظورين/المجمّدين/المخفيين)
  const activeMembers = useMemo(() => {
    if (typeof window === 'undefined') return members;
    try {
      const metaRaw = dataService.db.settings.get('twafok_admin_meta_v1');
      const meta = metaRaw ? JSON.parse(metaRaw) : {};
      return members.filter((m) => {
        const am = meta[m.id];
        if (am) {
          if (am.deleted) return false;
          if (am.status && am.status !== 'active') return false;
        }
        if (m.status && m.status !== 'active') return false;

        // تصفية الحسابات المخفية إذا تم تمكين ميزة إخفاء الحساب من الإدارة ولم يكن الحساب يخص المستخدم نفسه
        const isSelf = user && user.memberId && m.id === user.memberId;
        if (!isSelf && allowProfileHiding) {
          const isHidden = dataService.db.settings.get(`profile_hidden_${m.id}`) === 'true';
          if (isHidden) return false;
        }

        return true;
      });
    } catch {
      return members;
    }
  }, [members, allowProfileHiding, user]);

  const [adminMembers, setAdminMembers] = useState<AdminMember[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_admin_members_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return ADMIN_MEMBERS;
  });

  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_admin_users');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return [
      {
        id: 'admin-1',
        name: 'المدير العام',
        email: 'admin@tawafok.com',
        role: 'super_admin',
        permissions: { manage_members: true, manage_requests: true, manage_support: true, manage_content: true, view_sensitive_data: true },
        status: 'active',
        createdAt: new Date().toISOString(),
      }
    ];
  });

  const [currentAdminId, setCurrentAdminId] = useState<string | null>(null);

  useEffect(() => {
    if (!isInitialized) return;
    dataService.db.settings.set('saved_admin_users', JSON.stringify(adminUsers));
  }, [adminUsers, isInitialized]);

  const addAdminUser = (admin: Omit<AdminUser, 'id' | 'createdAt'>) => {
    setAdminUsers(prev => [...prev, { ...admin, id: 'admin-' + Math.random().toString(36).substr(2, 9), createdAt: new Date().toISOString() }]);
    showToast('تم إضافة المشرف بنجاح', 'success');
  };

  const updateAdminUser = (id: string, updates: Partial<AdminUser>) => {
    setAdminUsers(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
    showToast('تم تحديث بيانات المشرف', 'success');
  };

  const deleteAdminUser = (id: string) => {
    setAdminUsers(prev => prev.filter(a => a.id !== id));
    showToast('تم حذف المشرف', 'info');
  };

  const simulateAdminLogin = (id: string | null) => {
    setCurrentAdminId(id);
    showToast(id ? 'تم التبديل لصلاحيات المشرف المختار' : 'تم التبديل لصلاحيات المدير العام', 'info');
  };

  const currentAdmin = currentAdminId ? adminUsers.find(a => a.id === currentAdminId) : adminUsers.find(a => a.role === 'super_admin');
  const currentAdminName = currentAdmin?.name || 'الإدارة';
  const currentAdminRole = currentAdmin?.role || 'super_admin';
  const currentAdminPermissions = currentAdmin?.permissions || { manage_members: true, manage_requests: true, manage_support: true, manage_content: true, view_sensitive_data: true };

  // Helper to synchronously load and map legacy requests from the real database (twafok_local_db_v4)
  const getMappedRequestsFromDB = useCallback((): InterestRequest[] => {
    if (typeof window === 'undefined') return INTEREST_REQUESTS;
    try {
      const raw = localStorage.getItem('twafok_local_db_v4');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.requests)) {
          return parsed.requests.map((r: any) => {
            let status: RequestStatus = 'pending';
            if (r.journey_stage === 'sent') status = 'pending';
            else if (r.journey_stage === 'accepted') status = 'accepted_pending_payment';
            else if (r.journey_stage === 'seriousness') status = 'accepted_pending_payment';
            else if (r.journey_stage === 'coordination') status = 'in_mediation';
            else if (r.journey_stage === 'sharia_viewing') status = 'in_mediation';
            else if (r.journey_stage === 'engagement') status = 'in_mediation';
            else if (r.journey_stage === 'completed') status = 'completed';
            else if (r.journey_stage === 'declined') status = 'declined';
            else if (r.journey_stage === 'cancelled') status = 'cancelled';

            if (r.sender_paid && r.receiver_paid) {
              if (status === 'accepted_pending_payment') {
                status = 'paid';
              }
            }

            return {
              id: String(r.id),
              senderId: r.sender_id,
              receiverId: r.receiver_id,
              status: status,
              message: r.message || 'طلب اهتمام مرسل عبر الإدارة',
              time: new Date(r.created_at).toLocaleDateString('ar-SA'),
              createdAt: new Date(r.created_at).getTime(),
              paymentStatus: (r.sender_paid && r.receiver_paid) ? 'paid' : 'waiting_for_payment',
              senderPaid: r.sender_paid,
              receiverPaid: r.receiver_paid,
              meetingDate: r.meeting_date || undefined,
              meetingNotes: r.meeting_notes || undefined,
              declineReason: r.decline_reason || undefined,
              adminNotes: r.admin_notes || undefined,
            };
          });
        }
      }
    } catch (e) {
      console.error('Error loading requests from localStore database:', e);
    }
    
    // Fallback to legacy settings key
    const saved = dataService.db.settings.get('saved_interest_requests');
    if (saved) {
      try { return JSON.parse(saved); } catch { /* ignore error */ }
    }
    return INTEREST_REQUESTS;
  }, []);

  const [interestRequests, setInterestRequests] = useState<InterestRequest[]>(() => {
    if (typeof window !== 'undefined') {
      const raw = localStorage.getItem('twafok_local_db_v4');
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          if (parsed && Array.isArray(parsed.requests)) {
            return parsed.requests.map((r: any) => {
              let status: RequestStatus = 'pending';
              if (r.journey_stage === 'sent') status = 'pending';
              else if (r.journey_stage === 'accepted') status = 'accepted_pending_payment';
              else if (r.journey_stage === 'seriousness') status = 'accepted_pending_payment';
              else if (r.journey_stage === 'coordination') status = 'in_mediation';
              else if (r.journey_stage === 'sharia_viewing') status = 'in_mediation';
              else if (r.journey_stage === 'engagement') status = 'in_mediation';
              else if (r.journey_stage === 'completed') status = 'completed';
              else if (r.journey_stage === 'declined') status = 'declined';
              else if (r.journey_stage === 'cancelled') status = 'cancelled';

              if (r.sender_paid && r.receiver_paid) {
                if (status === 'accepted_pending_payment') {
                  status = 'paid';
                }
              }

              return {
                id: String(r.id),
                senderId: r.sender_id,
                receiverId: r.receiver_id,
                status: status,
                message: r.message || 'طلب اهتمام مرسل عبر الإدارة',
                time: new Date(r.created_at).toLocaleDateString('ar-SA'),
                createdAt: new Date(r.created_at).getTime(),
                paymentStatus: (r.sender_paid && r.receiver_paid) ? 'paid' : 'waiting_for_payment',
                senderPaid: r.sender_paid,
                receiverPaid: r.receiver_paid,
                meetingDate: r.meeting_date || undefined,
                meetingNotes: r.meeting_notes || undefined,
                declineReason: r.decline_reason || undefined,
                adminNotes: r.admin_notes || undefined,
              };
            });
          }
        } catch { /* ignore */ }
      }
      
      const saved = dataService.db.settings.get('saved_interest_requests');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return INTEREST_REQUESTS;
  });

  // Refresh helper
  const refreshInterestRequests = useCallback(() => {
    setInterestRequests(getMappedRequestsFromDB());
  }, [getMappedRequestsFromDB]);

  // Intercept dataService database actions to keep AppContext state fully synchronized reactive-style
  useEffect(() => {
    const originalRunRequestAction = dataService.db.runRequestAction;
    const originalCreateRequest = dataService.db.createRequest;
    const originalAdminDeleteRequest = dataService.db.adminDeleteRequest;
    
    dataService.db.runRequestAction = async (requestId, action, actorId, payload) => {
      const res = await originalRunRequestAction(requestId, action, actorId, payload);
      if (res.ok) {
        refreshInterestRequests();
      }
      return res;
    };

    dataService.db.createRequest = async (senderId, receiverId, message) => {
      const res = await originalCreateRequest(senderId, receiverId, message);
      if (res.ok) {
        refreshInterestRequests();
      }
      return res;
    };

    dataService.db.adminDeleteRequest = async (requestId) => {
      const res = await originalAdminDeleteRequest(requestId);
      if (res) {
        refreshInterestRequests();
      }
      return res;
    };
    
    return () => {
      dataService.db.runRequestAction = originalRunRequestAction;
      dataService.db.createRequest = originalCreateRequest;
      dataService.db.adminDeleteRequest = originalAdminDeleteRequest;
    };
  }, [refreshInterestRequests]);

  const [adminNotifications, setAdminNotifications] = useState<any[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_admin_notifications');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return ADMIN_NOTIFICATIONS;
  });

  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_support_tickets_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return DEFAULT_TICKETS.map(t => ({ ...t, userId: t.userId || 'm2' }));
  });

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('saved_support_tickets_list', JSON.stringify(supportTickets));
    }
  }, [supportTickets, isInitialized]);

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('saved_members_list', JSON.stringify(members));
    }
  }, [members, isInitialized]);

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('saved_admin_members_list', JSON.stringify(adminMembers));
    }
  }, [adminMembers, isInitialized]);

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('saved_interest_requests', JSON.stringify(interestRequests));
    }
  }, [interestRequests, isInitialized]);

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('saved_admin_notifications', JSON.stringify(adminNotifications));
    }
  }, [adminNotifications, isInitialized]);

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('auth_user', JSON.stringify(user));
    }
  }, [user, isInitialized]);

  // Initialize plans with local storage backup or default
  const [plans, setPlans] = useState<Plan[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_plans');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PLANS;
  });

  // Initialize PayPal settings from storage or default
  const [paypalSettings, setPaypalSettings] = useState<PaypalSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('paypal_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PAYPAL;
  });

  // Initialize Social and WhatsApp settings from storage or default
  const [socialSettings, setSocialSettings] = useState<SocialSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('social_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_SOCIALS;
  });

  // Initialize unified Multiple Payments config from storage or default
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('payment_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // fail safe fallback
        }
      }
    }
    return DEFAULT_PAYMENTS_CONFIG;
  });

  const updatePaymentSettings = useCallback((settings: PaymentSettings) => {
    setPaymentSettings(settings);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('payment_settings', JSON.stringify(settings));
    }
  }, []);

  // Extra interest requests settings & state
  const [interestPurchaseSettings, setInterestPurchaseSettings] = useState<InterestPurchaseSettings>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('interest_purchase_settings');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // ignore
        }
      }
    }
    return {
      price: 29,
      type: 'count', // 'count' or 'duration'
      count: 10,
      durationDays: 7,
    };
  });

  const updateInterestPurchaseSettings = useCallback((settings: InterestPurchaseSettings) => {
    setInterestPurchaseSettings(settings);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('interest_purchase_settings', JSON.stringify(settings));
    }
  }, []);

  const [messagePackages, setMessagePackages] = useState<MessagePackage[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_message_packages');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length === 3) {
            return parsed;
          }
        } catch {
          // fallback
        }
      }
    }
    return DEFAULT_MESSAGE_PACKAGES;
  });

  const updateMessagePackage = useCallback((updated: MessagePackage) => {
    setMessagePackages((prev) => {
      const next = prev.map((p) => (p.id === updated.id ? updated : p));
      if (typeof window !== 'undefined') {
        dataService.db.settings.set('saved_message_packages', JSON.stringify(next));
      }
      return next;
    });
    showToast(`تم تحديث باقة رسائل ${updated.name} بنجاح!`, 'success');
  }, [showToast]);

  const [extraInterestsCount, setExtraInterestsCount] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('user_extra_interests_count');
      if (saved) return Number(saved);
    }
    return 0;
  });

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('user_extra_interests_count', String(extraInterestsCount));
    }
  }, [extraInterestsCount, isInitialized]);

  const [depositQuota, setDepositQuota] = useState<{
    hasActiveQuota: boolean;
    remainingAttempts: number;
    totalPaidAmount: number;
    paidAt?: string;
    selectedTierPrice?: number;
  }>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('user_deposit_quota');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          return {
            hasActiveQuota: parsed.hasActiveQuota ?? false,
            remainingAttempts: parsed.remainingAttempts ?? 5,
            totalPaidAmount: parsed.totalPaidAmount ?? 0,
            paidAt: parsed.paidAt,
            selectedTierPrice: parsed.selectedTierPrice ?? 500,
          };
        } catch (e) {
          console.warn('Failed parsing deposit quota', e);
        }
      }
    }
    return {
      hasActiveQuota: false,
      remainingAttempts: 5,
      totalPaidAmount: 0,
    };
  });

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('user_deposit_quota', JSON.stringify(depositQuota));
    }
  }, [depositQuota, isInitialized]);

  const [unlimitedInterestsUntil, setUnlimitedInterestsUntil] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('user_unlimited_interests_until');
      if (saved) return Number(saved);
    }
    return 0;
  });

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('user_unlimited_interests_until', String(unlimitedInterestsUntil));
    }
  }, [unlimitedInterestsUntil, isInitialized]);

  // Initialize dark mode
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('dark_mode');
      return saved === 'true';
    }
    return false;
  });

  // تحكم الإدارة بإظهار/إخفاء زر الوضع الليلي
  const [showDarkModeToggle, setShowDarkModeToggle] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('show_dark_mode_toggle');
      return saved === null ? true : saved === 'true';
    }
    return true;
  });

  const updateShowDarkModeToggle = useCallback((show: boolean) => {
    setShowDarkModeToggle(show);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('show_dark_mode_toggle', String(show));
    }
  }, []);

  // Compatibility Feature Control (White priority - Admin toggle)
  const [showCompatibility, setShowCompatibility] = useState<boolean>(true); // Forced true for demo as per request

  // ===== بيانات الملف الشخصي التفصيلية =====
  const [profileData, setProfileData] = useState<ProfileData>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('user_profile_data');
      if (saved) {
        try { return { ...DEFAULT_PROFILE_DATA, ...JSON.parse(saved) }; } catch { /* ignore error */ }
      }
    }
    return DEFAULT_PROFILE_DATA;
  });

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('user_profile_data', JSON.stringify(profileData));
    }
  }, [profileData, isInitialized]);

  // Synchronize profileData state with currently logged in user's member details
  useEffect(() => {
    if (!isInitialized) return;
    if (user.isLoggedIn && user.memberId) {
      const matched = members.find((m) => m.id === user.memberId) || (adminMembers as any[]).find((m) => m.id === user.memberId);
      if (matched) {
        setProfileData(prev => {
          // If it's the exact same member ID, we do not overwrite active edits
          if (prev.id === user.memberId && prev.bio && prev.education) {
            return prev;
          }
          
          return {
            id: matched.id,
            gender: matched.gender || 'female',
            nickname: matched.nickname || (matched as any).name || 'سارة',
            birthDate: (matched as any).birthDate || '',
            age: matched.age || 26,
            country: matched.country || 'السعودية',
            city: matched.city || 'الرياض',
            district: (matched as any).district || '',
            sect: (matched as any).sect || '',
            sectOther: (matched as any).sectOther || '',
            nationality: (matched as any).nationality || matched.country || 'السعودية',
            maritalStatus: matched.maritalStatus || 'single',
            childrenCount: (matched as any).childrenCount || '',
            childrenLiveWith: (matched as any).childrenLiveWith || '',
            hasChildren: matched.hasChildren ? 'yes' : 'no',
            wifeCount: (matched as any).wifeCount || '',
            seekingWife: (matched as any).seekingWife || '',
            height: matched.height || 0,
            weight: matched.weight || 0,
            skinColor: (matched as any).skinColor || '',
            ethnicity: matched.ethnicity || '',
            health: (matched as any).health || '',
            smoking: (matched as any).smoking || '',
            acceptPolygamy: (matched as any).acceptPolygamy || '',
            acceptDivorced: (matched as any).acceptDivorced || '',
            acceptWithChildren: (matched as any).acceptWithChildren || '',
            education: matched.education || '',
            workType: matched.workType || '',
            jobTitle: (matched as any).jobTitle || '',
            housing: (matched as any).housing || '',
            bio: matched.bio || '',
            pCountry: (matched as any).pCountry || '',
            pCity: (matched as any).pCity || '',
            pAgeMin: (matched as any).pAgeMin || 22,
            pAgeMax: (matched as any).pAgeMax || 35,
            pNationality: (matched as any).pNationality || '',
            pMaritalStatus: (matched as any).pMaritalStatus || '',
            pAcceptChildren: (matched as any).pAcceptChildren || '',
            pSect: (matched as any).pSect || '',
            pSectOther: (matched as any).pSectOther || '',
            pEducation: (matched as any).pEducation || '',
            pWorkType: (matched as any).pWorkType || '',
            pReligionLevel: (matched as any).pReligionLevel || '',
            pSkinColor: (matched as any).pSkinColor || '',
            pHeightNoMatter: (matched as any).pHeightNoMatter ?? false,
            pHeight: (matched as any).pHeight || 170,
            pHousing: (matched as any).pHousing || '',
            pNotes: matched.aboutPartner || '',
          };
        });
      }
    }
  }, [user.memberId, user.isLoggedIn, isInitialized, members, adminMembers]);

  // Synchronize likedMembers state with currently logged in user's saved preferences
  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      if (user.isLoggedIn && user.memberId) {
        const key = 'liked_members_' + user.memberId;
        const saved = dataService.db.settings.get(key);
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed)) {
              setLikedMembers(new Set(parsed));
              return;
            }
          } catch {}
        }
        setLikedMembers(new Set());
      } else {
        setLikedMembers(new Set());
      }
    }
  }, [user.memberId, user.isLoggedIn, isInitialized]);

  const updateProfileData = useCallback((fields: Partial<ProfileData>) => {
    setProfileData(prev => {
      const next = { ...prev, ...fields };
      // إعادة حساب نسبة إكمال الملف
      const allFields = Object.keys(next) as (keyof ProfileData)[];
      const checkFields = allFields.filter(k =>
        !['pAgeMin', 'pAgeMax', 'pHeight', 'pHeightNoMatter', 'sectOther', 'pSectOther', 'childrenLiveWith', 'wifeCount', 'seekingWife'].includes(k as string)
      );
      const filled = checkFields.filter(k => {
        const v = next[k];
        if (typeof v === 'number') return v > 0;
        if (typeof v === 'boolean') return true;
        return v && String(v).trim().length > 0;
      }).length;
      const pct = Math.round((filled / checkFields.length) * 100);
      setUser(u => ({ ...u, profile: { ...u.profile, profileCompletion: pct } }));
      return next;
    });

    // تحديث بيانات العضو في قائمة الأعضاء وقائمة المشرفين
    setUser(u => {
      if (u.isLoggedIn && u.memberId) {
        setMembers(prevMembers => prevMembers.map(m => {
          if (m.id === u.memberId) {
            return {
              ...m,
              nickname: fields.nickname !== undefined ? fields.nickname : m.nickname,
              gender: fields.gender !== undefined ? fields.gender as any : m.gender,
              age: fields.age !== undefined ? Number(fields.age) : m.age,
              country: fields.country !== undefined ? fields.country : m.country,
              city: fields.city !== undefined ? fields.city : m.city,
              district: fields.district !== undefined ? fields.district : m.district,
              nationality: fields.nationality !== undefined ? fields.nationality : m.nationality,
              sect: fields.sect !== undefined ? fields.sect : m.sect,
              maritalStatus: fields.maritalStatus !== undefined ? fields.maritalStatus as any : m.maritalStatus,
              height: fields.height !== undefined ? Number(fields.height) : m.height,
              weight: fields.weight !== undefined ? Number(fields.weight) : m.weight,
              skinColor: fields.skinColor !== undefined ? fields.skinColor : m.skinColor,
              health: fields.health !== undefined ? fields.health : m.health,
              smoking: fields.smoking !== undefined ? fields.smoking : m.smoking,
              education: fields.education !== undefined ? fields.education : m.education,
              workType: fields.workType !== undefined ? fields.workType : m.workType,
              jobTitle: fields.jobTitle !== undefined ? fields.jobTitle : m.jobTitle,
              housing: fields.housing !== undefined ? fields.housing : m.housing,
              bio: fields.bio !== undefined ? fields.bio : m.bio,
              aboutPartner: fields.pNotes !== undefined ? fields.pNotes : m.aboutPartner,
            };
          }
          return m;
        }));

        setAdminMembers(prevAdmin => prevAdmin.map(am => {
          if (am.id === u.memberId) {
            return {
              ...am,
              nickname: fields.nickname !== undefined ? fields.nickname : am.nickname,
              gender: fields.gender !== undefined ? fields.gender as any : am.gender,
              age: fields.age !== undefined ? Number(fields.age) : am.age,
              country: fields.country !== undefined ? fields.country : am.country,
              city: fields.city !== undefined ? fields.city : am.city,
              district: fields.district !== undefined ? fields.district : am.district,
              nationality: fields.nationality !== undefined ? fields.nationality : am.nationality,
              sect: fields.sect !== undefined ? fields.sect : am.sect,
              maritalStatus: fields.maritalStatus !== undefined ? fields.maritalStatus as any : am.maritalStatus,
              height: fields.height !== undefined ? Number(fields.height) : am.height,
              weight: fields.weight !== undefined ? Number(fields.weight) : am.weight,
              skinColor: fields.skinColor !== undefined ? fields.skinColor : am.skinColor,
              health: fields.health !== undefined ? fields.health : am.health,
              smoking: fields.smoking !== undefined ? fields.smoking : am.smoking,
              education: fields.education !== undefined ? fields.education : am.education,
              workType: fields.workType !== undefined ? fields.workType : am.workType,
              jobTitle: fields.jobTitle !== undefined ? fields.jobTitle : am.jobTitle,
              housing: fields.housing !== undefined ? fields.housing : am.housing,
              bio: fields.bio !== undefined ? fields.bio : am.bio,
              aboutPartner: fields.pNotes !== undefined ? fields.pNotes : am.aboutPartner,
            };
          }
          return am;
        }));
      }
      return u;
    });
  }, [setMembers, setAdminMembers]);

  const updateAccountInfo = useCallback((fields: { realName?: string; email?: string; phone?: string; whatsapp?: string; password?: string }) => {
    setUser(u => {
      const next = {
        ...u,
        profile: {
          ...u.profile,
          ...(fields.realName !== undefined ? { realName: fields.realName } : {}),
          ...(fields.email !== undefined ? { email: fields.email } : {}),
          ...(fields.phone !== undefined ? { phone: fields.phone } : {}),
          ...(fields.whatsapp !== undefined ? { whatsapp: fields.whatsapp } : {}),
          ...(fields.password !== undefined ? { password: fields.password } : {}),
        },
      };
      if (typeof window !== 'undefined') {
        dataService.db.settings.set('auth_user', JSON.stringify(next));
      }
      return next;
    });

    setUser(u => {
      if (u.isLoggedIn && u.memberId) {
        setAdminMembers(prev => prev.map(am => {
          if (am.id === u.memberId) {
            return {
              ...am,
              realName: fields.realName !== undefined ? fields.realName : am.realName,
              email: fields.email !== undefined ? fields.email : am.email,
              phone: fields.phone !== undefined ? fields.phone : am.phone,
              whatsapp: fields.whatsapp !== undefined ? fields.whatsapp : am.whatsapp,
              password: fields.password !== undefined ? fields.password : am.password,
            };
          }
          return am;
        }));
      }
      return u;
    });
  }, [setAdminMembers]);

  const [compatibilityPaidOnly, setCompatibilityPaidOnly] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('compatibility_paid_only');
      return saved === 'true';
    }
    return true; // default paid only
  });

  const updateCompatibilitySettings = useCallback((enabled: boolean, paidOnly: boolean) => {
    setShowCompatibility(enabled);
    setCompatibilityPaidOnly(paidOnly);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('show_compatibility', String(enabled));
      dataService.db.settings.set('compatibility_paid_only', String(paidOnly));
    }
    // Use the showToast function from context (declared later)
    // For now we log - the toast is handled in the settings page
    console.log(`Compatibility settings updated: enabled=${enabled}, paidOnly=${paidOnly}`);
  }, []);

  const updateFeatureSettings = useCallback((updates: {
    allowProfileHiding?: boolean;
    requireVerificationForRequests?: boolean;
    enableWhoViewedMe?: boolean;
    enableProfileBoosting?: boolean;
    maxActiveRequests?: number;
    pendingRequestsExpiryDays?: number;
  }) => {
    if (updates.allowProfileHiding !== undefined) {
      setAllowProfileHiding(updates.allowProfileHiding);
      if (typeof window !== 'undefined') dataService.db.settings.set('allow_profile_hiding', String(updates.allowProfileHiding));
    }
    if (updates.requireVerificationForRequests !== undefined) {
      setRequireVerificationForRequests(updates.requireVerificationForRequests);
      if (typeof window !== 'undefined') dataService.db.settings.set('require_verification_for_requests', String(updates.requireVerificationForRequests));
    }
    if (updates.enableWhoViewedMe !== undefined) {
      setEnableWhoViewedMe(updates.enableWhoViewedMe);
      if (typeof window !== 'undefined') dataService.db.settings.set('enable_who_viewed_me', String(updates.enableWhoViewedMe));
    }
    if (updates.enableProfileBoosting !== undefined) {
      setEnableProfileBoosting(updates.enableProfileBoosting);
      if (typeof window !== 'undefined') dataService.db.settings.set('enable_profile_boosting', String(updates.enableProfileBoosting));
    }
    if (updates.maxActiveRequests !== undefined) {
      setMaxActiveRequests(updates.maxActiveRequests);
      if (typeof window !== 'undefined') dataService.db.settings.set('max_active_requests', String(updates.maxActiveRequests));
    }
    if (updates.pendingRequestsExpiryDays !== undefined) {
      setPendingRequestsExpiryDays(updates.pendingRequestsExpiryDays);
      if (typeof window !== 'undefined') dataService.db.settings.set('pending_requests_expiry_days', String(updates.pendingRequestsExpiryDays));
    }
  }, []);

  const [isProfileHidden, setIsProfileHidden] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const savedUser = dataService.db.settings.get('auth_user');
      if (savedUser) {
        try {
          const parsed = JSON.parse(savedUser);
          if (parsed && parsed.memberId) {
            return dataService.db.settings.get(`profile_hidden_${parsed.memberId}`) === 'true';
          }
        } catch { /* ignore */ }
      }
    }
    return false;
  });

  const toggleProfileHiding = useCallback(() => {
    setIsProfileHidden(prev => {
      const next = !prev;
      if (typeof window !== 'undefined') {
        const savedUser = dataService.db.settings.get('auth_user');
        if (savedUser) {
          try {
            const parsed = JSON.parse(savedUser);
            if (parsed && parsed.memberId) {
              dataService.db.settings.set(`profile_hidden_${parsed.memberId}`, String(next));
            }
          } catch { /* ignore */ }
        }
      }
      return next;
    });
  }, []);

  const toggleDarkMode = useCallback(() => {
    setDarkMode(prev => {
      const next = !prev;
      if (typeof window !== 'undefined') {
        dataService.db.settings.set('dark_mode', String(next));
        if (next) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
      return next;
    });
  }, []);

  // Sync dark class on mount and state change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (darkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [darkMode]);

  // Keep track of active operational counters in local state with persistent backup
  const [usage, setUsage] = useState<{
    messagesSent: number;
    searchesDone: number;
    contactsViewed: number;
  }>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('user_usage_counters');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          console.warn("Error parsing usage counters:", e);
        }
      }
    }
    return { messagesSent: 0, searchesDone: 0, contactsViewed: 0 };
  });

  const [isBoosted, setIsBoosted] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('profile_boosted');
      return saved === 'true';
    }
    return false;
  });

  const [reports, setReports] = useState<MemberReport[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_member_reports_list');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return [
      {
        id: 'rep1',
        reporterId: 'm2',
        reporterName: 'سارة',
        reportedId: 'm4',
        reportedName: 'سليمان الحربي',
        reason: 'الحساب يتصرف بشكل مريب أو يرسل رسائل مكررة غير جدية.',
        timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
        status: 'pending',
        category: 'spam' as const,
        severity: 'medium' as const,
        adminNotes: '',
        actionLog: [],
      },
      {
        id: 'rep2',
        reporterId: 'm6',
        reporterName: 'أم عبدالرحمن',
        reportedId: 'm1',
        reportedName: 'أبو عبدالله',
        reason: 'أرسل رسائل غير لائقة ومضايقات متكررة رغم الاعتذار.',
        timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
        status: 'pending',
        category: 'harassment' as const,
        severity: 'high' as const,
        adminNotes: 'تم التواصل المبدئي مع المُبلِغة، بانتظار مراجعة الإدارة.',
        actionLog: [
          { id: 'al1', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 5).toISOString(), by: 'النظام' },
          { id: 'al2', action: 'تم التواصل المبدئي مع المُبلِغة', timestamp: new Date(Date.now() - 3600000 * 3).toISOString(), by: 'د. منى السالم' },
        ],
      },
      {
        id: 'rep3',
        reporterId: 'm3',
        reporterName: 'القحطاني',
        reportedId: 'm8',
        reportedName: 'بنت الخليج',
        reason: 'الصور والمعلومات الشخصية غير حقيقية، يبدو حساباً وهمياً.',
        timestamp: new Date(Date.now() - 3600000 * 48).toISOString(),
        status: 'pending',
        category: 'fake' as const,
        severity: 'high' as const,
        adminNotes: 'يجب التحقق من هوية العضوة قبل اتخاذ إجراء.',
        actionLog: [
          { id: 'al3', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 48).toISOString(), by: 'النظام' },
        ],
      },
      {
        id: 'rep4',
        reporterId: 'm5',
        reporterName: 'العتيبي',
        reportedId: 'm7',
        reportedName: 'أبو فيصل',
        reason: 'محتوى النبذة الشخصية يحتوي على عبارات غير مناسبة.',
        timestamp: new Date(Date.now() - 3600000 * 72).toISOString(),
        status: 'resolved',
        category: 'inappropriate' as const,
        severity: 'low' as const,
        adminNotes: 'تم تنبيه العضو وتعديل النبذة.',
        actionLog: [
          { id: 'al4', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 72).toISOString(), by: 'النظام' },
          { id: 'al5', action: 'تم تنبيه العضو وتعديل النبذة', timestamp: new Date(Date.now() - 3600000 * 60).toISOString(), by: 'أ. خالد المنصور' },
          { id: 'al6', action: 'تم حل البلاغ', timestamp: new Date(Date.now() - 3600000 * 58).toISOString(), by: 'أ. خالد المنصور' },
        ],
      },
      {
        id: 'rep5',
        reporterId: 'm1',
        reporterName: 'أبو عبدالله',
        reportedId: 'm5',
        reportedName: 'العتيبي',
        reason: 'سلوك غير لائق أثناء التنسيق الشرعي وعدم احترام الإدارة.',
        timestamp: new Date(Date.now() - 3600000 * 12).toISOString(),
        status: 'pending',
        category: 'inappropriate' as const,
        severity: 'medium' as const,
        adminNotes: '',
        actionLog: [
          { id: 'al7', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 12).toISOString(), by: 'النظام' },
        ],
      },
      {
        id: 'rep6',
        reporterId: 'm8',
        reporterName: 'بنت الخليج',
        reportedId: 'm3',
        reportedName: 'القحطاني',
        reason: 'يرسل طلبات اهتمام متكررة بشكل مزعج رغم الرفض.',
        timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
        status: 'pending',
        category: 'spam' as const,
        severity: 'low' as const,
        adminNotes: '',
        actionLog: [
          { id: 'al8', action: 'تم استلام البلاغ', timestamp: new Date(Date.now() - 3600000 * 8).toISOString(), by: 'النظام' },
        ],
      },
    ];
  });

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('saved_member_reports_list', JSON.stringify(reports));
    }
  }, [reports, isInitialized]);

  const submitReport = useCallback((reportedId: string, reportedName: string, reason: string) => {
    const newReport: MemberReport = {
      id: 'rep_' + Date.now(),
      reporterId: user.isLoggedIn ? 'user_self' : 'guest',
      reporterName: user.isLoggedIn ? user.profile.name : 'زائر',
      reportedId,
      reportedName,
      reason,
      timestamp: new Date().toISOString(),
      status: 'pending'
    };
    setReports(prev => [newReport, ...prev]);
    showToast('تم إرسال بلاغك بنجاح للإدارة وسيتخذ الوسيط الإجراء اللازم حيال العضو المخالف 🛡️', 'success');
  }, [user, showToast]);

  const resolveReport = useCallback((id: string) => {
    setReports(prev => prev.map(rep => rep.id === id ? { ...rep, status: 'resolved' as const } : rep));
    showToast('تمت معالجة البلاغ ووضع العلامة كمكتمل بنجاح.', 'success');
  }, [showToast]);

  const deleteReport = useCallback((id: string) => {
    setReports(prev => prev.filter(rep => rep.id !== id));
    showToast('تم حذف البلاغ نهائياً.', 'info');
  }, [showToast]);

  const updateReport = useCallback((id: string, fields: Partial<MemberReport>) => {
    setReports(prev => prev.map(rep => rep.id === id ? { ...rep, ...fields } : rep));
  }, []);

  const addReportActionLog = useCallback((id: string, action: string, adminNote?: string, by?: string) => {
    setReports(prev => prev.map(rep => {
      if (rep.id !== id) return rep;
      const logEntry = {
        id: 'al_' + Date.now(),
        action,
        adminNote,
        timestamp: new Date().toISOString(),
        by: by || 'الإدارة',
      };
      return { ...rep, actionLog: [...(rep.actionLog || []), logEntry] };
    }));
  }, []);

  const buyExtraInterests = useCallback(() => {
    if (interestPurchaseSettings.type === 'count') {
      setExtraInterestsCount(prev => prev + interestPurchaseSettings.count);
      showToast(`🎉 تم شراء وشحن ${interestPurchaseSettings.count} اهتمامات إضافية بنجاح! يمكنك الآن إرسال الطلبات.`, 'success');
    } else {
      const newExpire = Date.now() + (interestPurchaseSettings.durationDays * 24 * 60 * 60 * 1000);
      setUnlimitedInterestsUntil(newExpire);
      showToast(`🎉 تم شراء وتفعيل اهتمامات بلا حدود لمدة ${interestPurchaseSettings.durationDays} أيام بنجاح!`, 'success');
    }
  }, [interestPurchaseSettings, showToast]);

  // Wallet & Exemption system
  const [exemptRequests, setExemptRequests] = useState<ExemptRequest[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = dataService.db.settings.get('saved_exempt_requests');
      if (saved) {
        try { return JSON.parse(saved); } catch { /* ignore error */ }
      }
    }
    return [
      {
        id: 'ex1',
        requestId: 'ir4',
        userId: 'm3',
        userNickname: 'أبو عبدالله',
        reason: 'أواجه صعوبة مالية مؤقتة وأتمنى تخفيض الرسوم أو إعفائي لتأكيد جديتي.',
        status: 'pending',
        createdAt: Date.now() - 3600000 * 12,
      }
    ];
  });

  // ========== SYNC AND INITIALIZE SETTINGS FROM CLOUD ==========
  useEffect(() => {
    async function initAndSync() {
      // 1. If Supabase is active, sync settings from cloud to localStorage
      const dbAny = dataService.db as any;
      if (typeof dbAny.syncSettingsFromCloud === 'function') {
        try {
          await dbAny.syncSettingsFromCloud();
          console.info('[AppProvider] Successfully synced settings from cloud.');
        } catch (err) {
          console.warn('[AppProvider] Error syncing settings from cloud:', err);
        }
      }

      // 2. Read synced values from settings/localStorage and update React states
      if (typeof window !== 'undefined') {
        const savedMembers = dataService.db.settings.get('saved_members_list');
        if (savedMembers) {
          try { setMembers(JSON.parse(savedMembers)); } catch {}
        }
        const savedAdminMembers = dataService.db.settings.get('saved_admin_members_list');
        if (savedAdminMembers) {
          try { setAdminMembers(JSON.parse(savedAdminMembers)); } catch {}
        }
        const savedRequests = dataService.db.settings.get('saved_interest_requests');
        if (savedRequests) {
          try { setInterestRequests(JSON.parse(savedRequests)); } catch {}
        }
        const savedNotifications = dataService.db.settings.get('saved_admin_notifications');
        if (savedNotifications) {
          try { setAdminNotifications(JSON.parse(savedNotifications)); } catch {}
        }
        const savedTickets = dataService.db.settings.get('saved_support_tickets_list');
        if (savedTickets) {
          try { setSupportTickets(JSON.parse(savedTickets)); } catch {}
        }
        const savedAdminUsers = dataService.db.settings.get('saved_admin_users');
        if (savedAdminUsers) {
          try { setAdminUsers(JSON.parse(savedAdminUsers)); } catch {}
        }
        const savedUser = dataService.db.settings.get('auth_user');
        if (savedUser) {
          try { setUser(JSON.parse(savedUser)); } catch {}
        }
        const savedPlans = dataService.db.settings.get('saved_plans');
        if (savedPlans) {
          try { setPlans(JSON.parse(savedPlans)); } catch {}
        }
        const savedPaypal = dataService.db.settings.get('paypal_settings');
        if (savedPaypal) {
          try { setPaypalSettings(JSON.parse(savedPaypal)); } catch {}
        }
        const savedSocials = dataService.db.settings.get('social_settings');
        if (savedSocials) {
          try { setSocialSettings(JSON.parse(savedSocials)); } catch {}
        }
        const savedPayments = dataService.db.settings.get('payment_settings');
        if (savedPayments) {
          try { setPaymentSettings(JSON.parse(savedPayments)); } catch {}
        }
        const savedExtraInterests = dataService.db.settings.get('user_extra_interests_count');
        if (savedExtraInterests) {
          try { setExtraInterestsCount(Number(savedExtraInterests)); } catch {}
        }
        const savedDepositQuota = dataService.db.settings.get('user_deposit_quota');
        if (savedDepositQuota) {
          try { setDepositQuota(JSON.parse(savedDepositQuota)); } catch {}
        }
        const savedUnlimitedInterests = dataService.db.settings.get('user_unlimited_interests_until');
        if (savedUnlimitedInterests) {
          try { setUnlimitedInterestsUntil(Number(savedUnlimitedInterests)); } catch {}
        }
        const savedProfileData = dataService.db.settings.get('user_profile_data');
        if (savedProfileData) {
          try { setProfileData(JSON.parse(savedProfileData)); } catch {}
        }
        const savedReports = dataService.db.settings.get('saved_member_reports_list');
        if (savedReports) {
          try { setReports(JSON.parse(savedReports)); } catch {}
        }
        const savedExempts = dataService.db.settings.get('saved_exempt_requests');
        if (savedExempts) {
          try { setExemptRequests(JSON.parse(savedExempts)); } catch {}
        }
      }

      // 3. Complete initialization
      setIsInitialized(true);
    }

    initAndSync();
  }, []);

  useEffect(() => {
    if (!isInitialized) return;
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('saved_exempt_requests', JSON.stringify(exemptRequests));
    }
  }, [exemptRequests, isInitialized]);

  const submitExemptRequest = useCallback((requestId: string, reason: string) => {
    const newExempt: ExemptRequest = {
      id: 'ex_' + Date.now(),
      requestId,
      userId: user.memberId || 'm2',
      userNickname: user.profile.name,
      reason,
      status: 'pending',
      createdAt: Date.now(),
    };
    setExemptRequests(prev => [newExempt, ...prev]);

    // Also update the interest request with exemption status
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const isSender = req.senderId === (user.memberId || 'm2');
        return {
          ...req,
          ...(isSender ? {
            senderExemptionStatus: 'pending',
            senderExemptionReason: reason,
          } : {
            receiverExemptionStatus: 'pending',
            receiverExemptionReason: reason,
          })
        };
      }
      return req;
    }));

    showToast('تم تقديم طلب التسهيل المالي للإدارة بنجاح. سيتم مراجعته والرد عليك خلال 24 ساعة.', 'success');
  }, [user, showToast]);

  const adminProcessExemptRequest = useCallback((id: string, action: 'approve' | 'reject') => {
    setExemptRequests(prev => prev.map(ex => {
      if (ex.id !== id) return ex;
      
      const updatedStatus = action === 'approve' ? 'approved' as const : 'rejected' as const;
      
      // Update corresponding interest request
      setInterestRequests(currRequests => currRequests.map(req => {
        if (req.id === ex.requestId) {
          const isSender = req.senderId === ex.userId;
          const updatedReq = {
            ...req,
            ...(isSender ? {
              senderExemptionStatus: updatedStatus,
              senderPaid: action === 'approve' ? true : req.senderPaid,
              senderPaidAmount: action === 'approve' ? 0 : req.senderPaidAmount,
              senderPaidAt: action === 'approve' ? new Date().toISOString() : req.senderPaidAt,
              senderExempted: action === 'approve' ? true : false,
            } : {
              receiverExemptionStatus: updatedStatus,
              receiverPaid: action === 'approve' ? true : req.receiverPaid,
              receiverPaidAmount: action === 'approve' ? 0 : req.receiverPaidAmount,
              receiverPaidAt: action === 'approve' ? new Date().toISOString() : req.receiverPaidAt,
              receiverExempted: action === 'approve' ? true : false,
            })
          };

          // Check if both paid
          if (updatedReq.senderPaid && updatedReq.receiverPaid) {
            updatedReq.status = 'paid';
            updatedReq.paymentStatus = 'paid';
            updatedReq.paidAt = new Date().toISOString();
            updatedReq.mediationStage = 'scheduling';
          }
          return updatedReq;
        }
        return req;
      }));

      return { ...ex, status: updatedStatus };
    }));

    showToast(action === 'approve' ? 'تمت الموافقة على طلب الإعفاء وتفعيل الجدية مجاناً ✓' : 'تم رفض طلب الإعفاء المالي.', 'info');
  }, [showToast]);

  const payInterestRequestFee = useCallback((requestId: string, isSender: boolean, pledgeAccepted: boolean) => {
    if (!pledgeAccepted) {
      showToast('يجب الموافقة على عهد الأمانة والجدية للمتابعة.', 'error');
      return;
    }

    const feeAmount = 500; // Fixed fee

    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const updatedReq = {
          ...req,
          ...(isSender ? {
            senderPaid: true,
            senderPaidAmount: feeAmount,
            senderPaidAt: new Date().toISOString(),
          } : {
            receiverPaid: true,
            receiverPaidAmount: feeAmount,
            receiverPaidAt: new Date().toISOString(),
          })
        };

        // Check if both paid
        if (updatedReq.senderPaid && updatedReq.receiverPaid) {
          updatedReq.status = 'paid';
          updatedReq.paymentStatus = 'paid';
          updatedReq.paidAt = new Date().toISOString();
          updatedReq.mediationStage = 'scheduling';
        }
        return updatedReq;
      }
      return req;
    }));

    showToast('تم تأكيد جديتك وسداد رسوم خدمة الوساطة بنجاح ✓', 'success');
  }, [showToast]);

  const payPreExchangeChatFee = useCallback((requestId: string, isSender: boolean) => {
    // الدفع المباشر عبر بوابة الدفع — يفتح المحادثة بعد إتمام الدفع
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          ...(isSender ? {
            senderChatUnlocked: true,
            senderNoMoney: false,
          } : {
            receiverChatUnlocked: true,
            receiverNoMoney: false,
          })
        };
      }
      return req;
    }));
  }, []);

  const sendPreExchangeChatMessage = useCallback((requestId: string, text: string, isSender: boolean) => {
    if (!text.trim()) return;

    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const newMsg = {
          id: 'chat_' + Date.now() + Math.random().toString(36).substring(2, 6),
          senderId: isSender ? req.senderId : req.receiverId,
          text: text.trim(),
          time: 'الآن',
          approved: false, // Messages are unapproved by default and require admin review
          rejected: false,
        };

        return {
          ...req,
          chatMessages: [...(req.chatMessages || []), newMsg],
          ...(isSender ? {
            senderChatUnlocked: true,
          } : {
            receiverChatUnlocked: true,
          })
        };
      }
      return req;
    }));
    showToast('تم إرسال رسالتك بنجاح. الرسالة قيد المراجعة والتدقيق من قبل الإدارة والوسيط الأخصائي لضمان الجدية والخصوصية الكاملة 🛡️', 'info');
  }, [user, showToast]);

  const flagPreExchangeNoMoney = useCallback((requestId: string, isSender: boolean) => {
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          ...(isSender ? { senderNoMoney: true } : { receiverNoMoney: true })
        };
      }
      return req;
    }));
    showToast('تم إرسال إشعار للطرف الآخر بعدم إمكانية الشحن حالياً.', 'info');
  }, [showToast]);

  const choosePreExchangeOption = useCallback((requestId: string, choice: 'chat' | 'direct_deposit' | null) => {
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          preExchangeChoice: choice,
        };
      }
      return req;
    }));
    showToast(choice === 'chat' ? 'تم اختيار الاستفسار المبكر قبل تبادل الأرقام.' : 'تم اختيار الانتقال المباشر لتبادل الأرقام وسداد رسوم الجدية.', 'info');
  }, [showToast]);

  const adminCancelAndRefund = useCallback((requestId: string, type: 'full' | 'partial') => {
    setInterestRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          status: 'cancelled' as const,
          cancelReason: type === 'full' ? 'إلغاء لعدم السداد الثنائي أو بطلب الإدارة' : 'عدم توافق بعد بدء الوساطة',
          refundPercentage: 0,
        };
      }
      return req;
    }));

    showToast(
      type === 'full'
        ? 'تم إلغاء الطلب بنجاح. جميع الرسوم والمدفوعات غير مستردة نهائياً.'
        : 'تم إنهاء الوساطة وإغلاق الطلب بنجاح. جميع الرسوم والمدفوعات غير مستردة نهائياً.',
      'success'
    );
  }, [showToast]);

  const login = (name: string, memberId: string = 'm2') => {
    const finalName = name || 'سارة';
    // نحاول مطابقة بيانات العضو من القائمة لعرض اسمه ومدينته الحقيقية
    const matched = members.find((m) => m.id === memberId);
    const matchedAdmin = adminMembers.find((am) => am.id === memberId);

    setUser({
      name: matched?.nickname || finalName,
      isLoggedIn: true,
      memberId,
      profile: {
        ...DEFAULT_PROFILE,
        name: matched?.nickname || finalName,
        city: matched?.city || DEFAULT_PROFILE.city,
        age: matched?.age || DEFAULT_PROFILE.age,
        email: matchedAdmin?.email || (memberId === 'm2' ? 'demo@tawasul.sa' : `${memberId}@tawafok.com`),
        realName: matchedAdmin?.realName || matched?.nickname || finalName,
        phone: matchedAdmin?.phone || (memberId === 'm2' ? '+966501234567' : ''),
        whatsapp: matchedAdmin?.whatsapp || (memberId === 'm2' ? '+966501234567' : ''),
        password: matchedAdmin?.password || 'password123',
        plan: (matchedAdmin?.plan || (memberId === 'm2' ? 'gold' : 'free')) as any,
        verified: matched?.verified || false,
      },
    });
    // تعيين الهوية النشطة لصفحة الطلبات والرحلة حسب الحساب المختار
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('active_member_id', memberId);
    }
  };

  const logout = () => {
    setUser({ name: '', isLoggedIn: false, profile: DEFAULT_PROFILE });
    if (typeof window !== 'undefined') {
      dataService.db.settings.remove('active_member_id');
      dataService.db.settings.remove('impersonating');
    }
  };

  const registerNewMember = useCallback((memberData: any) => {
    const memberId = 'm_' + Date.now();
    
    let maritalLabel = memberData.maritalStatus;
    if (memberData.maritalStatus === 'single') {
      maritalLabel = memberData.gender === 'male' ? 'أعزب' : 'عزباء';
    } else if (memberData.maritalStatus === 'divorced') {
      maritalLabel = memberData.gender === 'male' ? 'مطلق' : 'مطلقة';
    } else if (memberData.maritalStatus === 'widowed' || memberData.maritalStatus === 'widower' || memberData.maritalStatus === 'widow') {
      maritalLabel = memberData.gender === 'male' ? 'أرمل' : 'أرملة';
    }

    const newMember: Member = {
      id: memberId,
      nickname: memberData.nickname || 'عضو جديد',
      username: memberData.username,
      gender: memberData.gender as any,
      age: Number(memberData.age) || 25,
      country: memberData.country || 'السعودية',
      city: memberData.city || 'الرياض',
      district: memberData.district || '',
      nationality: memberData.nationality || memberData.country || 'السعودية',
      sect: memberData.sect || 'سني',
      maritalStatus: memberData.maritalStatus || 'single',
      maritalLabel: maritalLabel || 'أعزب',
      hasChildren: memberData.hasChildren === 'yes' || memberData.hasChildren === 'true' || memberData.hasChildren === true,
      childrenCount: memberData.childrenCount || 'لا يوجد',
      height: Number(memberData.height) || 170,
      weight: Number(memberData.weight) || 70,
      skinColor: memberData.skinColor || 'أبيض قمحي',
      health: memberData.health || 'ممتازة',
      smoking: memberData.smoking || 'لا أدخن',
      education: memberData.education || 'بكالوريوس',
      workType: memberData.workType || 'حكومي',
      jobTitle: memberData.jobTitle || 'موظف',
      housing: memberData.housing || 'ملك',
      bio: memberData.bio || '',
      aboutPartner: memberData.pNotes || 'لا توجد مواصفات تفصيلية مضافة',
      verified: false,
      premium: false,
      online: true,
      lastActive: 'متصل الآن',
      sourceType: 'registered',
    };

    const newAdminMember: AdminMember = {
      ...newMember,
      realName: memberData.realName || memberData.nickname || 'عضو جديد',
      email: memberData.email || `${memberId}@tawafok.com`,
      phone: memberData.phone || '',
      whatsapp: memberData.whatsapp || '',
      password: memberData.password || 'password123',
      status: 'active',
      plan: 'free',
      requestsCount: 0,
      joinedAt: new Date().toLocaleDateString('ar-SA'),
    };

    setMembers((prev) => [newMember, ...prev]);
    setAdminMembers((prev) => [newAdminMember, ...prev]);

    setUser({
      name: newMember.nickname,
      isLoggedIn: true,
      memberId: newMember.id,
      profile: {
        name: newMember.nickname,
        email: newAdminMember.email,
        city: newMember.city,
        age: newMember.age,
        plan: 'free',
        verified: false,
        profileCompletion: 90,
        credits: 5,
        realName: newAdminMember.realName,
        phone: newAdminMember.phone,
        whatsapp: memberData.whatsapp || '',
        password: newAdminMember.password,
      },
    });

    if (typeof window !== 'undefined') {
      dataService.db.settings.set('active_member_id', newMember.id);
    }
  }, [setMembers, setAdminMembers]);

  // يقبل أي عضو له الحقول الأساسية (id, nickname, gender, age, city, ...)
  // سواء من AdminMember أو AdminMemberRowLocal من localStore
  const impersonateUser = (member: {
    id: string;
    nickname: string;
    gender?: string;
    age?: number;
    country?: string;
    city?: string;
    realName?: string;
    email?: string;
    phone?: string;
    plan?: string;
    password?: string;
  }) => {
    setUser({
      name: member.nickname,
      isLoggedIn: true,
      memberId: member.id,
      profile: {
        ...DEFAULT_PROFILE,
        name: member.nickname,
        realName: member.realName || member.nickname,
        email: member.email || '',
        phone: member.phone || '',
        city: member.city || DEFAULT_PROFILE.city,
        age: member.age || DEFAULT_PROFILE.age,
        plan: (member.plan as UserProfile['plan']) || 'free',
      },
    });
    // تخزين الهوية النشطة لصفحة الطلبات والرحلة
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('active_member_id', member.id);
      dataService.db.settings.set('impersonating', 'true');
    }
    showToast(`تم تسجيل الدخول كـ ${member.nickname} — أنت تتصفّح بحسابه الآن`, 'success');
  };

  const importMembers = (newMembers: AdminMember[], replaceExisting = false) => {
    if (replaceExisting) {
      const newIds = new Set(newMembers.map(nm => nm.id));
      const newEmails = new Set(newMembers.map(nm => nm.email?.toLowerCase()).filter(Boolean));
      const newPhones = new Set(newMembers.map(nm => nm.phone).filter(Boolean));

      setAdminMembers((prev) => {
        const filtered = prev.filter(m => !newIds.has(m.id) && !newEmails.has((m as any).email?.toLowerCase()) && !newPhones.has((m as any).phone));
        return [...newMembers, ...filtered];
      });

      setMembers((prev) => {
        const filtered = prev.filter(m => !newIds.has(m.id) && !newEmails.has((m as any).email?.toLowerCase()) && !newPhones.has((m as any).phone));
        const publicMembers = newMembers.map(nm => ({
          ...nm,
          isManagedByAdmin: nm.isManagedByAdmin,
          managedByAdminId: nm.managedByAdminId
        }));
        return [...publicMembers, ...filtered];
      });
    } else {
      setAdminMembers(prev => [...newMembers, ...prev]);
      // Sync with public members list if needed
      setMembers(prev => {
        const publicMembers = newMembers.map(nm => ({
          ...nm, // Just spread the whole member object to keep all properties
          isManagedByAdmin: nm.isManagedByAdmin,
          managedByAdminId: nm.managedByAdminId
        }));
        return [...publicMembers, ...prev];
      });
    }

    // Update admin metadata in localStorage for both modes
    if (typeof window !== 'undefined') {
      try {
        const raw = dataService.db.settings.get('twafok_admin_meta_v1');
        const meta = raw ? JSON.parse(raw) : {};
        newMembers.forEach(nm => {
          meta[nm.id] = {
            status: nm.status || 'active',
            plan: nm.premium ? 'gold' : 'free',
            realName: nm.nickname,
            email: nm.email || `${nm.id}@twafok.sa`,
            phone: nm.phone || '',
            nationalId: (nm as any).nationalId || `10${Date.now().toString().slice(-8)}`,
            password: (nm as any).password || `Twafok@123456`,
            joinedAt: (nm as any).joinedAt || new Date().toISOString().split('T')[0],
            verifiedOverride: nm.verified,
            premiumOverride: nm.premium,
            adminNote: (nm as any).adminNote || '',
            flagged: !!(nm as any).flagged,
          };
        });
        dataService.db.settings.set('twafok_admin_meta_v1', JSON.stringify(meta));
      } catch (e) {
        console.error(e);
      }
    }

    showToast(`تم استيراد وتحديث ${newMembers.length} عضو بنجاح`, 'success');
  };

  const toggleLike = (id: string) => {
    setLikedMembers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        showToast('تمت الإزالة من المحفوظات', 'info');
      } else {
        next.add(id);
        showToast('تم الحفظ في المحفوظات ❤️', 'success');
      }
      // Save immediately for the active user session
      if (user.memberId && typeof window !== 'undefined') {
        dataService.db.settings.set('liked_members_' + user.memberId, JSON.stringify(Array.from(next)));
      }
      return next;
    });
  };

  const upgradePlan = (plan: 'gold' | 'elite') => {
    const userId = dataService.db.getCurrentUserId();
    if (userId) {
      dataService.db.adminUpdateMember(userId, { plan, premium: plan === 'elite' });
      // Grant free messages package
      const targetPlan = plans.find((p) => p.id === plan);
      if (targetPlan && targetPlan.messagesLimit) {
        dataService.db.buyMessagePackageCustom(userId, targetPlan.messagesLimit, 0);
      }
    }
    setUser((prev) => ({
      ...prev,
      profile: { ...prev.profile, plan },
    }));
    if (userId) {
      setMembers((prev) =>
        prev.map((m) => (m.id === userId ? { ...m, plan, premium: plan === 'elite' } : m))
      );
    }
    showToast(`تم تفعيل باقة ${plan === 'gold' ? 'الذهبية' : 'المميزة'} بنجاح! 🎉`, 'success');
  };

  const updatePlan = (updated: Plan) => {
    setPlans((prev) => {
      const next = prev.map((p) => (p.id === updated.id ? updated : p));
      if (typeof window !== 'undefined') {
        dataService.db.settings.set('saved_plans', JSON.stringify(next));
      }
      return next;
    });
    showToast(`تم تحديث باقة ${updated.name} بنجاح!`, 'success');
  };

  const addPlan = (newPlan: Plan) => {
    setPlans((prev) => {
      const next = [...prev, newPlan];
      if (typeof window !== 'undefined') {
        dataService.db.settings.set('saved_plans', JSON.stringify(next));
      }
      return next;
    });
    showToast(`تم إضافة باقة ${newPlan.name} بنجاح!`, 'success');
  };

  const deletePlan = (id: string) => {
    setPlans((prev) => {
      const next = prev.filter((p) => p.id !== id);
      if (typeof window !== 'undefined') {
        dataService.db.settings.set('saved_plans', JSON.stringify(next));
      }
      return next;
    });
    showToast('تم حذف الباقة بنجاح!', 'success');
  };

  const updatePaypalSettings = (settings: PaypalSettings) => {
    setPaypalSettings(settings);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('paypal_settings', JSON.stringify(settings));
    }
    showToast('تم حفظ إعدادات PayPal بنجاح!', 'success');
  };

  const updateSocialSettings = (settings: SocialSettings) => {
    setSocialSettings(settings);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('social_settings', JSON.stringify(settings));
    }
    showToast('تم حفظ إعدادات التواصل الاجتماعي بنجاح!', 'success');
  };

  // CHECK LIMIT LOGIC
  const checkLimit = useCallback((action: 'message' | 'search' | 'contact') => {
    const currentPlanId = user.profile.plan || 'free';
    const activePlan = plans.find((p) => p.id === currentPlanId) || plans[0];

    let max = 0;
    let current = 0;

    if (action === 'message') {
      if (unlimitedInterestsUntil > Date.now()) {
        return {
          allowed: true,
          current: usage.messagesSent,
          max: 999,
          error: undefined,
        };
      }
      const baseMax = activePlan.requestsLimit !== undefined ? activePlan.requestsLimit : (activePlan.messagesLimit !== undefined ? activePlan.messagesLimit : 3);
      max = baseMax + extraInterestsCount;
      current = usage.messagesSent;
    } else if (action === 'search') {
      max = activePlan.searchLimit !== undefined ? activePlan.searchLimit : 2;
      current = usage.searchesDone;
    } else if (action === 'contact') {
      max = activePlan.showContactLimit !== undefined ? activePlan.showContactLimit : 0;
      current = usage.contactsViewed;
    }

    const allowed = current < max;

    return {
      allowed,
      current,
      max,
      error: allowed
        ? undefined
        : `لقد استنفدت حد باقتك لطلبات الاهتمام المساعدة والربط المباشر (${max}/${max}). يمكنك ترقية باقتك أو شراء باقات طلبات اهتمام إضافية فورياً لمواصلة التواصل مع شريك حياتك المنشود.`,
    };
  }, [user.profile.plan, plans, usage, extraInterestsCount, unlimitedInterestsUntil]);

  // INCREMENT COUNTER ON ACTION SUCCESS
  const incrementUsage = useCallback((action: 'message' | 'search' | 'contact') => {
    setUsage((prev) => {
      const next = { ...prev };
      if (action === 'message') next.messagesSent += 1;
      if (action === 'search') next.searchesDone += 1;
      if (action === 'contact') next.contactsViewed += 1;

      if (typeof window !== 'undefined') {
        dataService.db.settings.set('user_usage_counters', JSON.stringify(next));
      }
      return next;
    });
  }, []);

  const resetUsage = useCallback(() => {
    const fresh = { messagesSent: 0, searchesDone: 0, contactsViewed: 0 };
    setUsage(fresh);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('user_usage_counters', JSON.stringify(fresh));
    }
    showToast('تم تصفير عدادات الاستخدام والميزات التجريبية بنجاح.', 'success');
  }, [showToast]);

  // MICROTRANSACTIONS LOGIC (buying 20 messages pack or 1 contact pack)
  const buyMicrotransaction = useCallback((type: 'messages_20' | 'contact_1', cost: number) => {
    // subtract usage offset so user gets more tokens allowed or just deduct from usage counter
    setUsage((prev) => {
      const next = { ...prev };
      if (type === 'messages_20') {
        // give breathing room of 20 more messages
        next.messagesSent = Math.max(0, next.messagesSent - 20);
      } else if (type === 'contact_1') {
        // give breathing room of 1 more contact
        next.contactsViewed = Math.max(0, next.contactsViewed - 1);
      }
      if (typeof window !== 'undefined') {
        dataService.db.settings.set('user_usage_counters', JSON.stringify(next));
      }
      return next;
    });

    setUser((prev) => {
      const nextProfile = { ...prev.profile };
      // optionally adjust credits if they had enough
      nextProfile.credits = Math.max(0, nextProfile.credits - cost);
      return { ...prev, profile: nextProfile };
    });

    showToast(
      type === 'messages_20'
        ? `🎉 تم شراء حزمة (20 رسالة إضافية) وتفعيلها بنجاح!`
        : `🎉 تم تفعيل رؤية رقم تواصل لحساب إضافي بنجاح!`,
      'success'
    );
  }, [showToast]);

  // PROFILE BOOSTING LOGIC
  const boostProfile = useCallback(() => {
    setIsBoosted(true);
    if (typeof window !== 'undefined') {
      dataService.db.settings.set('profile_boosted', 'true');
    }
    setUser((prev) => ({
      ...prev,
      profile: { ...prev.profile, isBoosted: true },
    }));
    showToast('تم رفع وترقية ملفك متصدراً نتائج البحث بنجاح! 🚀✨', 'success');
  }, [showToast]);

  // Synchronize demo user profile updates with the member 'm2' list entry in real-time
  useEffect(() => {
    if (user.isLoggedIn && user.profile.email === 'demo@tawasul.sa') {
      const p = user.profile;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setMembers((prev) =>
        prev.map((m) =>
          m.id === 'm2'
            ? {
                ...m,
                nickname: p.name,
                city: p.city,
                age: p.age,
                verified: p.verified,
                premium: p.plan !== 'free',
              }
            : m
        )
      );
      setAdminMembers((prev) =>
        prev.map((m) =>
          m.id === 'm2'
            ? {
                ...m,
                nickname: p.name,
                city: p.city,
                age: p.age,
                realName: p.name + ' القحطاني',
                verified: p.verified,
                plan: p.plan,
              }
            : m
        )
      );
    }
  }, [user]);

  // Mathematically balanced weighted compatibility index calculator
  const calculateCompat = useCallback((m1: Member, m2: Member): number => {
    const currentUserMember = members.find(m => m.id === 'm2') || m1;
    const result = calculateCompatibility(currentUserMember, m2, profileData);
    return result.score;
  }, [members, profileData]);

  // حساب تفصيلي يرجع الأسباب والألوان
  const calculateCompatDetailed = useCallback((target: Member): CompatResult => {
    const currentUserMember = members.find(m => m.id === 'm2');
    if (!currentUserMember) {
      return { score: 0, isGenderMatch: false, isEstimated: false, reasons: [], details: [] };
    }
    return calculateCompatibility(currentUserMember, target, profileData);
  }, [members, profileData]);

  // Secure API Operations for Administrative Console
  const adminDeleteMember = useCallback((id: string) => {
    setAdminMembers((prev) => prev.filter((m) => m.id !== id));
    setMembers((prev) => prev.filter((m) => m.id !== id));
    
    // Cascading Delete: remove from liked/bookmarked lists
    setLikedMembers((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });

    // Cascading Delete: remove from pending/active interest requests
    setInterestRequests((prev) => prev.filter((r) => r.senderId !== id && r.receiverId !== id));
    
    // real-time Session Invalidation
    if (id === 'm2' || (user.isLoggedIn && user.profile.email === 'demo@tawasul.sa' && id === 'm2')) {
      logout();
      showToast('تم إلغاء جلستك فوراً وحذف حسابك من قواعد البيانات بشكل متتالٍ وآمن', 'error');
    } else {
      showToast('تم حذف حساب العضو كلياً من المنصة مع إزالة كافة الارتباطات والبيانات ذات الصلة', 'success');
    }
  }, [user, logout, showToast]);

  const adminUpdateMemberStatus = useCallback((id: string, status: AdminMember['status'], reason?: string) => {
    setAdminMembers((prev) => prev.map((m) => (m.id === id ? { ...m, status, statusReason: status === 'active' ? '' : (reason ?? m.statusReason) } : m)));
    setMembers((prev) => prev.map((m) => (m.id === id ? { ...m, status } : m)));

    // Real-time Session Invalidation on restrictive statuses
    const restrictive = status === 'suspended' || status === 'banned';
    if (restrictive) {
      if (id === 'm2' || (user.isLoggedIn && user.profile.email === 'demo@tawasul.sa' && id === 'm2')) {
        logout();
        showToast('تم تقييد حسابك وطرد جلستك فوراً لأسباب انضباطية من الإدارة', 'error');
      } else {
        const label = status === 'banned' ? 'حظر' : 'إيقاف';
        showToast(`تم ${label} حساب العضو قسرياً بنجاح`, 'info');
      }
    } else {
      showToast('تم تحديث حالة العضو وتأكيدها بنجاح', 'success');
    }
  }, [user, logout, showToast]);

  // حذف نهائي لعضو من واجهة البلاغات/الرسائل
  const adminDeleteMemberFromReports = useCallback((id: string) => {
    setAdminMembers((prev) => prev.filter((m) => m.id !== id));
    setMembers((prev) => prev.filter((m) => m.id !== id));
    showToast('تم حذف حساب العضو نهائياً من المنصة', 'success');
  }, [showToast]);

  const adminUpdateMember = useCallback((updated: AdminMember) => {
    setAdminMembers((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
    setMembers((prev) =>
      prev.map((m) =>
        m.id === updated.id
          ? {
              ...m,
              nickname: updated.nickname,
              gender: updated.gender,
              age: updated.age,
              country: updated.country,
              city: updated.city,
              district: updated.district,
              nationality: updated.nationality,
              sect: updated.sect,
              maritalStatus: updated.maritalStatus,
              maritalLabel: updated.maritalLabel,
              hasChildren: updated.hasChildren,
              childrenCount: updated.childrenCount,
              height: updated.height,
              weight: updated.weight,
              skinColor: updated.skinColor,
              health: updated.health,
              smoking: updated.smoking,
              education: updated.education,
              workType: updated.workType,
              housing: updated.housing,
              bio: updated.bio,
              aboutPartner: updated.aboutPartner,
              verified: updated.verified,
              premium: updated.plan !== 'free',
              status: updated.status,
            }
          : m
      )
    );
    
    // If updating the demo user, synchronize current auth session
    if (updated.id === 'm2') {
      setUser((prev) => ({
        ...prev,
        profile: {
          ...prev.profile,
          name: updated.nickname,
          city: updated.city,
          age: updated.age,
          plan: updated.plan,
          verified: updated.verified,
        },
      }));
    }
    
    showToast('تم حفظ التعديلات وترقية حدود العضو برمجياً فورياً وفي اللحظة نفسها', 'success');
  }, [showToast]);

  const adminSendBulkBroadcast = useCallback(async (title: string, message: string, audience: 'all' | 'verified' | 'premium' | 'specific', specificIds?: string[]) => {
    // Non-blocking asynchronous chunk-by-chunk scheduling simulation representing Async Bulk Insertion
    showToast('تجري الجدولة غير المتزامنة والإدراج على دفعات لجدول مستلمي الرسائل (message_recipient)...', 'info');
    
    return new Promise<void>((resolve) => {
      let insertedCount = 0;
      
      let targetMembers = [];
      if (audience === 'all') {
        targetMembers = adminMembers;
      } else if (audience === 'verified') {
        targetMembers = adminMembers.filter((m) => m.verified);
      } else if (audience === 'premium') {
        targetMembers = adminMembers.filter((m) => m.premium || m.plan === 'gold' || m.plan === 'elite');
      } else if (audience === 'specific') {
        targetMembers = adminMembers.filter((m) => specificIds?.includes(m.id));
      }
      
      const targetCount = targetMembers.length || 1;
      const batchSize = Math.max(1, Math.floor(targetCount / 4));
      
      const timer = setInterval(async () => {
        insertedCount += batchSize;
        if (insertedCount >= targetCount) {
          insertedCount = targetCount;
          clearInterval(timer);
          
          // Actually write persistent notifications to localStore for matched members
          for (const m of targetMembers) {
            await dataService.db.adminSendNotification(m.id, message, title);
          }
          
          setAdminNotifications((prev) => [
            {
              id: 'an' + Date.now(),
              title,
              message,
              audience,
              sentAt: 'الآن',
              recipients: targetCount,
            },
            ...prev,
          ]);
          
          showToast(`تم الإدراج بنجاح! تم استهداف وتوصيل الرسالة إلى ${targetCount.toLocaleString('ar-EG')} عضو نشط`, 'success');
          resolve();
        } else {
          showToast(`جاري إدراج الدفعة... (${insertedCount.toLocaleString('ar-EG')} / ${targetCount.toLocaleString('ar-EG')})`, 'info');
        }
      }, 400);
    });
  }, [showToast, adminMembers]);

  const adminUpdateInterestRequestStatus = useCallback(async (requestId: string, status: RequestStatus | 'accepted', declineReason?: string) => {
    const targetStatus: RequestStatus = status === 'accepted' ? 'accepted_pending_payment' : status;
    
    // 1. Calculate compatibility if accepted
    if (targetStatus === 'accepted_pending_payment') {
      const req = interestRequests.find(r => r.id === requestId);
      if (req) {
        const partnerId = req.senderId === 'm2' ? req.receiverId : req.senderId;
        const requester = members.find((m) => m.id === partnerId);
        const targetMember = members.find((m) => m.id === 'm2');
        
        if (requester && targetMember) {
          const weightCompat = calculateCompat(requester, targetMember);
          showToast(`تم قياس وحساب التوافق الموزون للمعادلة الرياضية: ${weightCompat}% للطرفين`, 'success');
          
          setMembers((currMembers) =>
            currMembers.map((m) =>
              m.id === partnerId ? { ...m, matchScore: weightCompat } : m
            )
          );
          setAdminMembers((currAdmin) =>
            currAdmin.map((m) =>
              m.id === partnerId ? { ...m, matchScore: weightCompat } : m
            )
          );
        }
      }
    }

    // 2. Sync with localStore database
    const cleanId = typeof requestId === 'string' ? Number(requestId.replace(/\D/g, '')) : Number(requestId);
    let dbSuccess = false;
    if (!isNaN(cleanId) && cleanId > 0) {
      if (targetStatus === 'accepted_pending_payment' || targetStatus === 'accepted_pending_admin') {
        const res = await dataService.db.runRequestAction(cleanId, 'accept', 'admin');
        dbSuccess = res.ok;
      } else if (targetStatus === 'declined') {
        const res = await dataService.db.runRequestAction(cleanId, 'decline', 'admin', { reason: declineReason || 'عدم التوافق' });
        dbSuccess = res.ok;
      } else if (targetStatus === 'cancelled') {
        const res = await dataService.db.runRequestAction(cleanId, 'cancel', 'admin', { reason: declineReason || 'تم الإلغاء' });
        dbSuccess = res.ok;
      }
    }

    // 3. Fallback to manual state update if not in database (for legacy compat)
    if (!dbSuccess) {
      setInterestRequests((prevRequests) => {
        return prevRequests.map((req) => {
          if (req.id === requestId) {
            const deadlineTime = targetStatus === 'accepted_pending_payment' 
              ? new Date(Date.now() + 72 * 3600 * 1000).toISOString() 
              : req.paymentDeadline;

            return { 
              ...req, 
              status: targetStatus, 
              ...(declineReason !== undefined ? { declineReason } : {}),
              ...(targetStatus === 'accepted_pending_payment' ? { 
                paymentStatus: 'waiting_for_payment' as const,
                paymentDeadline: deadlineTime,
                senderPaid: false,
                receiverPaid: false,
                attemptsCount: FEE_CONFIG.freeAttemptsAfterDeposit,
              } : {}),
              ...(targetStatus === 'paid' ? { 
                paymentStatus: 'paid' as const,
                paidAt: 'الآن',
                mediationStage: 'scheduling' as MediationStage,
              } : {}),
              ...(targetStatus === 'in_mediation' ? { 
                mediationStage: 'scheduling' as MediationStage,
              } : {}),
              ...(targetStatus === 'completed' ? { 
                mediationStage: 'evaluating' as MediationStage,
              } : {}),
              ...(targetStatus === 'cancelled' ? { 
                refundPercentage: req.mediationStage === 'evaluating' || req.status === 'in_mediation' 
                  ? FEE_CONFIG.refundAfterMeeting 
                  : FEE_CONFIG.refundBeforeMeeting,
              } : {}),
            };
          }
          return req;
        });
      });
    }
    
    const statusLabels: Record<RequestStatus, string> = {
      pending: 'قيد الانتظار',
      accepted_pending_admin: 'مقبول وبانتظار موافقة الإدارة والتحقق ⏳',
      accepted_pending_payment: 'تمت الموافقة وبانتظار سداد رسوم تأكيد الجدية ثنائياً 💳',
      paid: 'تم السداد، جاهز للوساطة ✅',
      in_mediation: 'الوساطة جارية 🤝',
      completed: 'مكتمل 🎉',
      declined: 'مرفوض',
      cancelled: 'ملغى',
    };
    showToast(`تم تحديث حالة طلب الاهتمام: ${statusLabels[targetStatus]}`, 'info');
  }, [interestRequests, members, calculateCompat, showToast]);

  const adminUpdateInterestRequestDetails = useCallback((requestId: string, fields: Partial<InterestRequest>) => {
    setInterestRequests((prevRequests) => {
      return prevRequests.map((req) => {
        if (req.id === requestId) {
          return { ...req, ...fields };
        }
        return req;
      });
    });
    showToast('تم حفظ تحديثات طلب الاهتمام والموعد بنجاح بنظام التوفيق والمطابقة ✓', 'success');
  }, [showToast]);

  const adminModeratePreExchangeMessage = useCallback((requestId: string, messageId: string, action: 'approve' | 'reject') => {
    setInterestRequests((prevRequests) => {
      return prevRequests.map((req) => {
        if (req.id === requestId) {
          const updatedMessages = (req.chatMessages || []).map((msg: any) => {
            if (msg.id === messageId) {
              return {
                ...msg,
                approved: action === 'approve',
                rejected: action === 'reject',
              };
            }
            return msg;
          });
          return {
            ...req,
            chatMessages: updatedMessages,
          };
        }
        return req;
      });
    });
    showToast(action === 'approve' ? 'تمت الموافقة على الرسالة وتوصيلها للطرف الآخر ✓' : 'تم رفض وتصفية الرسالة لمخالفتها شروط المنصة ❌', 'info');
  }, [showToast]);

  const sendInterestRequest = useCallback((memberId: string, messageText: string) => {
    const activeUserId = user.memberId || 'm2';

    // 1. التحقق من شرط التوثيق في حال تفعيله من الإدارة
    if (requireVerificationForRequests) {
      const activeMember = members.find(m => m.id === activeUserId) || adminMembers.find(m => m.id === activeUserId);
      if (activeMember && !activeMember.verified) {
        showToast('عذراً، يجب توثيق حسابك بالهوية الوطنية أولاً لتتمكن من إرسال طلبات الاهتمام.', 'error');
        return;
      }
    }

    // 2. التحقق من الحد الأقصى للعلاقات المتزامنة النشطة
    const activeRequestsCount = interestRequests.filter(
      r => (r.senderId === activeUserId || r.receiverId === activeUserId) &&
        ['pending', 'accepted_pending_payment', 'paid', 'in_mediation', 'sharia_viewing', 'coordination', 'seriousness', 'engagement'].includes(r.status)
    ).length;
    if (activeRequestsCount >= maxActiveRequests) {
      showToast(`عذراً، لقد تجاوزت الحد الأقصى للعلاقات المتزامنة النشطة المسموح به حالياً (${maxActiveRequests} علاقات) لضمان جدية التواصل والتركيز.`, 'error');
      return;
    }

    // منع التكرار — التحقق من وجود طلب معلّق لنفس الشخص
    const existingPending = interestRequests.find(
      r => r.senderId === activeUserId && r.receiverId === memberId &&
        ['pending', 'accepted_pending_payment', 'paid', 'in_mediation'].includes(r.status)
    );
    if (existingPending) {
      showToast('لديك طلب نشط لدى هذا العضو بالفعل', 'error');
      return;
    }

    const newRequest: InterestRequest = {
      id: 'ir' + Date.now(),
      senderId: activeUserId,
      receiverId: memberId,
      status: 'pending',
      message: messageText.trim() || 'طلب اهتمام مرسل عبر الإدارة',
      time: 'الآن',
      createdAt: Date.now(),
    };
    setInterestRequests((prev) => [newRequest, ...prev]);
    showToast('تم إرسال طلب الاهتمام بنجاح ✓', 'success');
  }, [
    interestRequests,
    setInterestRequests,
    showToast,
    user.memberId,
    requireVerificationForRequests,
    maxActiveRequests,
    members,
    adminMembers
  ]);

  const sendSupportMessage = useCallback((ticketId: string, text: string, sender: 'user' | 'admin') => {
    setSupportTickets((prev) =>
      prev.map((t) => {
        if (t.id === ticketId) {
          return {
            ...t,
            status: sender === 'admin' ? 'in_progress' : 'open',
            updatedAt: 'الآن',
            messages: [
              ...t.messages,
              {
                id: 'msg-' + Date.now() + Math.random().toString(36).substring(2, 6),
                sender,
                text,
                time: 'الآن',
              },
            ],
          };
        }
        return t;
      })
    );
  }, []);

  const createSupportTicket = useCallback((
    subject: string,
    category: 'استفسار عام' | 'طلب ترقية' | 'مشكلة تقنية' | 'شكوى' | 'اقتراح',
    initialMessageText: string,
    userId?: string
  ) => {
    const newTicket: SupportTicket = {
      id: 't-' + Date.now(),
      userId: userId || user.memberId || 'm2',
      subject,
      category,
      status: 'open',
      priority: 'normal',
      updatedAt: 'الآن',
      messages: [
        {
          id: 'msg-' + Date.now(),
          sender: 'user',
          text: initialMessageText,
          time: 'الآن',
        },
      ],
    };
    setSupportTickets((prev) => [newTicket, ...prev]);
    return newTicket;
  }, []);

  return (
    <AppContext.Provider
      value={{
        user,
        login,
        logout,
        registerNewMember,
        impersonateUser,
        importMembers,
        likedMembers,
        toggleLike,
        toasts,
        showToast,
        dismissToast,
        upgradePlan,
        plans,
        updatePlan,
        addPlan,
        deletePlan,
        paypalSettings,
        updatePaypalSettings,
        paymentSettings,
        updatePaymentSettings,
        socialSettings,
        updateSocialSettings,
        darkMode,
        toggleDarkMode,
        showDarkModeToggle,
        updateShowDarkModeToggle,
        usage,
        checkLimit,
        incrementUsage,
        buyMicrotransaction,
        boostProfile,
        isBoosted,
        resetUsage,
        interestPurchaseSettings,
        updateInterestPurchaseSettings,
        extraInterestsCount,
        setExtraInterestsCount,
        unlimitedInterestsUntil,
        setUnlimitedInterestsUntil,
        buyExtraInterests,
        messagePackages,
        updateMessagePackage,
        members: activeMembers,
        setMembers,
        adminMembers,
        setAdminMembers,
        interestRequests,
        adminUsers,
        addAdminUser,
        updateAdminUser,
        deleteAdminUser,
        currentAdminRole,
        currentAdminPermissions,
        currentAdminName,
        simulateAdminLogin,
        setInterestRequests,
        depositQuota,
        setDepositQuota,
        adminNotifications,
        setAdminNotifications,
        supportTickets,
        setSupportTickets,
        reports,
        submitReport,
        resolveReport,
        deleteReport,
        updateReport,
        addReportActionLog,
        adminDeleteMember,
        adminUpdateMemberStatus,
        adminDeleteMemberFromReports,
        adminUpdateMember,
        adminSendBulkBroadcast,
        adminUpdateInterestRequestStatus,
        adminUpdateInterestRequestDetails,
        adminCancelAndRefund,
        adminProcessExemptRequest,
        adminModeratePreExchangeMessage,
        exemptRequests,
        submitExemptRequest,
        payInterestRequestFee,
        payPreExchangeChatFee,
        sendPreExchangeChatMessage,
        flagPreExchangeNoMoney,
        choosePreExchangeOption,
        calculateCompat,
        calculateCompatDetailed,
        sendInterestRequest,
        sendSupportMessage,
        createSupportTicket,
        showCompatibility,
        compatibilityPaidOnly,
        updateCompatibilitySettings,
        profileData,
        updateProfileData,
        updateAccountInfo,
        allowProfileHiding,
        requireVerificationForRequests,
        enableWhoViewedMe,
        enableProfileBoosting,
        maxActiveRequests,
        pendingRequestsExpiryDays,
        updateFeatureSettings,
        isProfileHidden,
        toggleProfileHiding,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
