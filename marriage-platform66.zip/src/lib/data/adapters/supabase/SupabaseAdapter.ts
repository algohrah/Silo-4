import { IRepository, ISettingsRepository } from '../../interfaces';
import { LocalStorageAdapter, LocalStorageRepository } from '../../LocalStorageAdapter';
import supabaseClient, { hasRealSupabase } from '../../../supabase';
import * as localStore from '../local/localStore';

// التحقق من وجود تهيئة حقيقية لـ Supabase
export let isReal = hasRealSupabase;

export function disableRealSupabase(err: any) {
  if (isReal) {
    console.warn('[SupabaseAdapter] Dynamic fallback to Local Storage enabled due to Supabase error:', err);
    isReal = false;
  }
}

const settingsCache = new Map<string, string>();

/**
 * مستودع بيانات سحابي لـ Supabase مع تراجع تلقائي محلي
 */
export class SupabaseRepository<T extends { id: string | number }> implements IRepository<T> {
  private tableName: string;
  private localFallback: LocalStorageRepository<T>;

  constructor(tableName: string) {
    this.tableName = tableName;
    let localKey = 'twafok_general';
    if (tableName === 'members') localKey = 'twafok_members';
    else if (tableName === 'interest_requests') localKey = 'twafok_requests';
    else if (tableName === 'transactions') localKey = 'twafok_transactions';
    else if (tableName === 'support_tickets') localKey = 'twafok_tickets';
    else if (tableName === 'admin_users') localKey = 'twafok_admin_users';

    this.localFallback = new LocalStorageRepository<T>(localKey);
  }

  async getAll(): Promise<T[]> {
    if (!isReal) return this.localFallback.getAll();
    try {
      const { data, error } = await supabaseClient.from(this.tableName).select('*');
      if (error) throw error;
      return data || [];
    } catch (err) {
      console.warn(`[SupabaseRepository] Failed to getAll on ${this.tableName}, falling back to local:`, err);
      disableRealSupabase(err);
      return this.localFallback.getAll();
    }
  }

  async getById(id: string | number): Promise<T | null> {
    if (!isReal) return this.localFallback.getById(id);
    try {
      const { data, error } = await supabaseClient.from(this.tableName).select('*').eq('id', id).maybeSingle();
      if (error) throw error;
      return data;
    } catch (err) {
      console.warn(`[SupabaseRepository] Failed to getById on ${this.tableName}, falling back to local:`, err);
      disableRealSupabase(err);
      return this.localFallback.getById(id);
    }
  }

  async create(item: T): Promise<T> {
    if (!isReal) return this.localFallback.create(item);
    try {
      const { data, error } = await supabaseClient.from(this.tableName).insert(item).select().single();
      if (error) throw error;
      return data || item;
    } catch (err) {
      console.warn(`[SupabaseRepository] Error creating item in ${this.tableName}, falling back to local:`, err);
      disableRealSupabase(err);
      return this.localFallback.create(item);
    }
  }

  async update(id: string | number, payload: Partial<T>): Promise<T> {
    if (!isReal) return this.localFallback.update(id, payload);
    try {
      const { data, error } = await supabaseClient.from(this.tableName).update(payload).eq('id', id).select().single();
      if (error) throw error;
      return data || { id, ...payload } as any;
    } catch (err) {
      console.warn(`[SupabaseRepository] Error updating item in ${this.tableName}, falling back to local:`, err);
      disableRealSupabase(err);
      return this.localFallback.update(id, payload);
    }
  }

  async delete(id: string | number): Promise<boolean> {
    if (!isReal) return this.localFallback.delete(id);
    try {
      const { error } = await supabaseClient.from(this.tableName).delete().eq('id', id);
      if (error) throw error;
      return true;
    } catch (err) {
      console.warn(`[SupabaseRepository] Error deleting item in ${this.tableName}, falling back to local:`, err);
      disableRealSupabase(err);
      return this.localFallback.delete(id);
    }
  }
}

/**
 * مستودع إعدادات Supabase المعتمد على الذاكرة مع المزامنة السحابية
 */
export class SupabaseSettingsRepository implements ISettingsRepository {
  get(key: string): string | null {
    if (key === 'active_member_id' || key === 'impersonating') {
      if (typeof window !== 'undefined') {
        return localStorage.getItem(key);
      }
      return null;
    }
    return settingsCache.get(key) ?? null;
  }

  set(key: string, value: string): void {
    if (key === 'active_member_id' || key === 'impersonating') {
      if (typeof window !== 'undefined') {
        localStorage.setItem(key, value);
      }
      return;
    }

    settingsCache.set(key, value);
    if (!isReal) return;

    Promise.resolve(
      supabaseClient
        .from('settings')
        .upsert({ key, value, updated_at: new Date().toISOString() })
    ).catch((err) => {
      console.warn('[SupabaseSettingsRepository] Failed to sync setting to cloud:', err);
      disableRealSupabase(err);
    });
  }

  remove(key: string): void {
    if (key === 'active_member_id' || key === 'impersonating') {
      if (typeof window !== 'undefined') {
        localStorage.removeItem(key);
      }
      return;
    }

    settingsCache.delete(key);
    if (!isReal) return;

    Promise.resolve(
      supabaseClient
        .from('settings')
        .delete()
        .eq('key', key)
    ).catch((err) => {
      console.warn('[SupabaseSettingsRepository] Failed to delete setting from cloud:', err);
      disableRealSupabase(err);
    });
  }
}

/**
 * محوّل قواعد بيانات Supabase المتكامل (SupabaseAdapter)
 * يتصل ويتزامن مع السحابة مباشرة وبشكل مستقل عن التخزين المحلي للمتصفح.
 */
export class SupabaseAdapter extends LocalStorageAdapter {
  constructor() {
    super();
    // إعادة تهيئة المستودعات الأساسية بنسخة سحابية مباشرة لـ Supabase
    this.members = new SupabaseRepository<any>('members');
    this.requests = new SupabaseRepository<any>('interest_requests');
    this.transactions = new SupabaseRepository<any>('transactions');
    this.tickets = new SupabaseRepository<any>('support_tickets');
    this.adminUsers = new SupabaseRepository<any>('admin_users');
    this.settings = new SupabaseSettingsRepository();

    if (typeof window !== 'undefined') {
      this.syncSettingsFromCloud().catch((err) => console.warn('[SupabaseAdapter] settings sync failed:', err));
    }
  }

  /** مزامنة الإعدادات العامة من السحاب للذاكرة المؤقتة */
  async syncSettingsFromCloud(): Promise<void> {
    if (!isReal) return;
    try {
      const { data, error } = await supabaseClient.from('settings').select('*');
      if (error) throw error;
      if (data) {
        settingsCache.clear();
        for (const item of data) {
          settingsCache.set(item.key, item.value);
        }
        console.info('[SupabaseAdapter] Successfully synchronized global settings from cloud.');
      }
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to sync settings from cloud:', err);
    }
  }

  /** الحصول على هوية المستخدم الحالي النشطة */
  getCurrentUserId = (): string => {
    // 1. إذا كنا نقوم بانتحال هوية مستخدم حالياً من قبل الإدارة، نرجع معرّف العضو المنتحل
    const isImpersonating = this.settings.get('impersonating') === 'true';
    const activeMemberId = this.settings.get('active_member_id');
    if (isImpersonating && activeMemberId) {
      return activeMemberId;
    }

    // 2. خلاف ذلك، نتحقق من وجود جلسة Supabase Auth حقيقية نشطة
    if (isReal) {
      // محاولة استعادة معرف الجلسة السحابية الفعلية
      const sessionStr = typeof window !== 'undefined' ? localStorage.getItem('sb-' + import.meta.env.VITE_SUPABASE_URL + '-auth-token') : null;
      if (sessionStr) {
        try {
          const session = JSON.parse(sessionStr);
          if (session?.user?.id) return session.user.id;
        } catch {
          /* تجاهل */
        }
      }
    }

    // 3. كخيار أخير، نلجأ للمعرف المخزن محلياً (والذي قد يكون active_member_id كعضو افتراضي أو محلي)
    if (activeMemberId) return activeMemberId;
    return localStore.getCurrentUserId();
  };

  /** التحقق من إتمام دفع الرسوم لأي رحلة في السحابة */
  hasUserPaidDepositAnywhere = (userId: string): boolean => {
    return localStore.hasUserPaidDepositAnywhere(userId);
  };

  /** جلب طلبات الاهتمام النشطة للمستخدم */
  getRequests = async (userId?: string): Promise<any[]> => {
    if (!isReal) return localStore.getRequests(userId);
    try {
      const query = supabaseClient.from('interest_requests').select('*');
      if (userId) {
        query.or(`sender_id.eq.${userId},receiver_id.eq.${userId}`);
      }
      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to get requests from cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      return localStore.getRequests(userId);
    }
  };

  /** إنشاء طلب اهتمام جديد مع مزامنة السحابة */
  createRequest = async (senderId: string, receiverId: string, message: string): Promise<any> => {
    // إنشاء نسخة محلية مؤقتة في الذاكرة لتحديث واجهة المستخدم
    const localReq = await localStore.createRequest(senderId, receiverId, message);
    if (!isReal) return localReq;
    if (!localReq.ok || !localReq.data) return localReq;

    try {
      const { data, error } = await supabaseClient
        .from('interest_requests')
        .insert({
          id: localReq.data.id,
          sender_id: senderId,
          receiver_id: receiverId,
          status: 'pending',
          mediation_stage: 'none',
          message: message,
        })
        .select()
        .single();

      if (error) throw error;
      return { ok: true, data: data || localReq.data };
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to sync request creation to cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      return localReq;
    }
  };

  // ===== الإشعارات (Journey Notifications) في السحاب =====
  getJourneyNotifications = async (userId: string): Promise<any[]> => {
    if (!isReal) return localStore.getJourneyNotifications(userId);
    try {
      const { data, error } = await supabaseClient
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to get notifications from cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      return localStore.getJourneyNotifications(userId);
    }
  };

  markNotificationRead = async (id: number): Promise<void> => {
    if (!isReal) {
      localStore.markNotificationRead(id);
      return;
    }
    try {
      const { error } = await supabaseClient
        .from('notifications')
        .update({ read: true })
        .eq('id', id);
      if (error) throw error;
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to mark notification read in cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      localStore.markNotificationRead(id);
    }
  };

  markAllNotificationsRead = async (userId: string): Promise<void> => {
    if (!isReal) {
      localStore.markAllNotificationsRead(userId);
      return;
    }
    try {
      const { error } = await supabaseClient
        .from('notifications')
        .update({ read: true })
        .eq('user_id', userId);
      if (error) throw error;
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to mark all notifications read in cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      localStore.markAllNotificationsRead(userId);
    }
  };

  getUnreadNotificationsCount = async (userId: string): Promise<number> => {
    if (!isReal) return localStore.getUnreadNotificationsCount(userId);
    try {
      const { count, error } = await supabaseClient
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('read', false);
      if (error) throw error;
      return count || 0;
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to get unread count from cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      return localStore.getUnreadNotificationsCount(userId);
    }
  };

  deleteNotification = async (id: number): Promise<void> => {
    if (!isReal) {
      localStore.deleteNotification(id);
      return;
    }
    try {
      const { error } = await supabaseClient
        .from('notifications')
        .delete()
        .eq('id', id);
      if (error) throw error;
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to delete notification from cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      localStore.deleteNotification(id);
    }
  };

  // ===== عمليات الإشراف (Admin Operations) في السحاب =====
  adminSendNotification = async (id: string, text: string, title?: string): Promise<boolean> => {
    if (!isReal) return localStore.adminSendNotification(id, text, title);
    try {
      const { error } = await supabaseClient
        .from('notifications')
        .insert({
          user_id: id,
          text: text,
          title: title || 'تنبيه إداري جديد',
          type: 'admin',
          read: false,
        });
      if (error) throw error;
      return true;
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to send admin notification to cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      return localStore.adminSendNotification(id, text, title);
    }
  };

  getActionableRequestsCount = async (userId: string): Promise<number> => {
    if (!isReal) return localStore.getActionableRequestsCount(userId);
    try {
      const requests = await this.getRequests(userId);
      return requests.filter((r) => {
        if (r.sender_id !== userId && r.receiver_id !== userId) return false;
        
        const stage = r.status;
        if (stage === 'declined' || stage === 'cancelled' || stage === 'completed') return false;
        
        const isSender = r.sender_id === userId;
        const selfPaid = isSender ? r.sender_paid : r.receiver_paid;
        
        if (stage === 'pending') return !isSender;
        if (stage === 'accepted') return true;
        if (stage === 'seriousness' || stage === 'paid') return !selfPaid;
        return false;
      }).length;
    } catch (err) {
      console.warn('[SupabaseAdapter] Failed to get actionable requests count from cloud, falling back to local storage:', err);
      disableRealSupabase(err);
      return localStore.getActionableRequestsCount(userId);
    }
  };
}
