import { IRepository, IDatabaseAdapter, ISettingsRepository } from './interfaces';
import * as localStore from './adapters/local/localStore';
import * as verificationStore from './adapters/local/verificationStore';
import * as geoStore from './adapters/local/geoStore';

// ============================================================
//  LocalStorage Adapter — التخزين المحلي عبر المتصفح
//  هذا هو الملف الوحيد المسموح له بالوصول المباشر لـ window.localStorage
// ============================================================

export class LocalStorageRepository<T extends { id: string | number }> implements IRepository<T> {
  private storageKey: string;

  constructor(storageKey: string) {
    this.storageKey = storageKey;
  }

  private getItems(): T[] {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem(this.storageKey);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  private saveItems(items: T[]): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(items));
    } catch (e) {
      console.error(`Error saving to localStorage [${this.storageKey}]:`, e);
    }
  }

  async getAll(): Promise<T[]> {
    return this.getItems();
  }

  async getById(id: string | number): Promise<T | null> {
    const items = this.getItems();
    const item = items.find((i) => i.id == id);
    return item || null;
  }

  async create(item: T): Promise<T> {
    const items = this.getItems();
    items.push(item);
    this.saveItems(items);
    return item;
  }

  async update(id: string | number, payload: Partial<T>): Promise<T> {
    const items = this.getItems();
    const index = items.findIndex((i) => i.id == id);
    if (index === -1) {
      throw new Error(`Item with id ${id} not found.`);
    }
    const updatedItem = { ...items[index], ...payload };
    items[index] = updatedItem;
    this.saveItems(items);
    return updatedItem;
  }

  async delete(id: string | number): Promise<boolean> {
    const items = this.getItems();
    const initialLength = items.length;
    const filteredItems = items.filter((i) => i.id != id);
    if (filteredItems.length === initialLength) {
      return false;
    }
    this.saveItems(filteredItems);
    return true;
  }
}

/**
 * مستودع الإعدادات عبر localStorage.
 * المنفذ الوحيد المسموح له بالقراءة/الكتابة المباشرة في localStorage.
 */
export class LocalStorageSettingsRepository implements ISettingsRepository {
  get(key: string): string | null {
    if (typeof window === 'undefined') return null;
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  set(key: string, value: string): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.error(`Error setting localStorage key [${key}]:`, e);
    }
  }

  remove(key: string): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.removeItem(key);
    } catch {
      /* تجاهل */
    }
  }
}

export class LocalStorageAdapter implements IDatabaseAdapter {
  members: IRepository<any> = new LocalStorageRepository<any>('twafok_members');
  requests: IRepository<any> = new LocalStorageRepository<any>('twafok_requests');
  transactions: IRepository<any> = new LocalStorageRepository<any>('twafok_transactions');
  tickets: IRepository<any> = new LocalStorageRepository<any>('twafok_tickets');
  adminUsers: IRepository<any> = new LocalStorageRepository<any>('twafok_admin_users');
  settings: ISettingsRepository = new LocalStorageSettingsRepository();

  // ===== الأعضاء (Members) =====
  getMembers = () => localStore.getMembers();
  getLiveMembers = (includeInactiveAndDeleted?: boolean) => localStore.getLiveMembers(includeInactiveAndDeleted);
  getLiveMemberById = (id: string) => localStore.getLiveMemberById(id);
  getCurrentUserId = () => localStore.getCurrentUserId();
  setCurrentUserId = (id: string) => localStore.setCurrentUserId(id);
  hasUserPaidDepositAnywhere = (userId: string) => localStore.hasUserPaidDepositAnywhere(userId);

  // ===== الطلبات والرحلات (Requests & Journeys) =====
  getRequests = (userId?: string) => localStore.getRequests(userId);
  getRequest = (id: number) => localStore.getRequest(id);
  createRequest = (senderId: string, receiverId: string, message: string) => localStore.createRequest(senderId, receiverId, message);
  runRequestAction = (requestId: number, action: string, actorId: string, payload?: any) => localStore.runRequestAction(requestId, action, actorId, payload);
  getEvents = (requestId: number) => localStore.getEvents(requestId);
  isRequestUnseen = (requestId: number, updatedAt?: string | null) => localStore.isRequestUnseen(requestId, updatedAt);
  markRequestSeen = (requestId: number) => localStore.markRequestSeen(requestId);
  markRequestNotificationsRead = (requestId: number, userId?: string) => localStore.markRequestNotificationsRead(requestId, userId);

  // ===== غرفة الاستفسار (Inquiry room messaging) =====
  getUserInquiryBalance = (userId: string) => localStore.getUserInquiryBalance(userId);
  consumeUserInquiryMessage = (userId: string) => localStore.consumeUserInquiryMessage(userId);
  getInquiry = (requestId: number) => localStore.getInquiry(requestId);
  initializeInquiry = (requestId: number, userId: string) => localStore.initializeInquiry(requestId, userId);
  buyInquiry = (requestId: number, ownerId: string) => localStore.buyInquiry(requestId, ownerId);
  buyMessagePackageCustom = (userId: string, credits: number, price: number) => localStore.buyMessagePackageCustom(userId, credits, price);
  sendInquiry = (requestId: number, senderId: string, text: string) => localStore.sendInquiry(requestId, senderId, text);
  simulateReply = (requestId: number, replierId: string, text: string) => localStore.simulateReply(requestId, replierId, text);
  getAllInquiryMessages = () => localStore.getAllInquiryMessages();
  moderateInquiryMessage = (messageId: number, action: 'approve' | 'reject', moderatorName: string) => localStore.moderateInquiryMessage(messageId, action, moderatorName);
  deleteInquiryMessage = (messageId: number) => localStore.deleteInquiryMessage(messageId);

  // ===== الإشعارات (Journey Notifications) =====
  getJourneyNotifications = (userId: string): Promise<any[]> => localStore.getJourneyNotifications(userId);
  markNotificationRead = (id: number): void | Promise<void> => localStore.markNotificationRead(id);
  markAllNotificationsRead = (userId: string): void | Promise<void> => localStore.markAllNotificationsRead(userId);
  getUnreadNotificationsCount = (userId: string): number | Promise<number> => localStore.getUnreadNotificationsCount(userId);
  getActionableRequestsCount = (userId: string): Promise<number> => localStore.getActionableRequestsCount(userId);
  deleteNotification = (id: number): void | Promise<void> => localStore.deleteNotification(id);

  // ===== لوحة الإدارة (Admin Panel Operations) =====
  adminGetMembers = () => localStore.adminGetMembers();
  adminUpdateMember = (id: string, fields: any) => localStore.adminUpdateMember(id, fields);
  adminBulkDeleteMembers = (ids: string[]) => localStore.adminBulkDeleteMembers(ids);
  adminBulkUpdateStatus = (ids: string[], status: any, reason?: string, by?: string) => localStore.adminBulkUpdateStatus(ids, status, reason, by);
  adminBulkSetVerified = (ids: string[], value: boolean) => localStore.adminBulkSetVerified(ids, value);
  adminBulkSetPinned = (ids: string[], value: boolean) => localStore.adminBulkSetPinned(ids, value);
  adminBulkSetPlan = (ids: string[], plan: 'free' | 'gold' | 'elite') => localStore.adminBulkSetPlan(ids, plan);
  adminBulkSetSeriousnessBadge = (ids: string[], value: boolean) => localStore.adminBulkSetSeriousnessBadge(ids, value);
  adminDeleteMember = (id: string) => localStore.adminDeleteMember(id);
  adminHardDeleteMember = (id: string) => localStore.adminHardDeleteMember(id);
  adminResetPassword = (id: string) => localStore.adminResetPassword(id);
  adminToggleVerified = (id: string, value: boolean) => localStore.adminToggleVerified(id, value);
  adminSetPremium = (id: string, value: boolean) => localStore.adminSetPremium(id, value);
  adminSetNote = (id: string, note: string) => localStore.adminSetNote(id, note);
  adminToggleFlag = (id: string, value: boolean) => localStore.adminToggleFlag(id, value);
  adminSendNotification = (id: string, text: string, title?: string) => localStore.adminSendNotification(id, text, title);
  adminDeleteRequest = (requestId: number) => localStore.adminDeleteRequest(requestId);
  adminGrantSeriousnessBadge = (id: string) => localStore.adminGrantSeriousnessBadge(id);
  adminRevokeSeriousnessBadge = (id: string) => localStore.adminRevokeSeriousnessBadge(id);
  adminGetRequests = () => localStore.adminGetRequests();
  adminGetStats = () => localStore.adminGetStats();
  adminGetRequestPayments = (requestId: number) => localStore.adminGetRequestPayments(requestId);
  adminApplyExemption = (memberId: string, type: 'deposit' | 'badge', value: number | boolean, memberName?: string) => localStore.adminApplyExemption(memberId, type, value, memberName);

  // ===== الكوبونات والمعاملات المالية (Coupons & Transactions) =====
  getCoupons = () => localStore.getCoupons();
  saveCoupon = (coupon: any) => localStore.saveCoupon(coupon);
  deleteCoupon = (code: string) => localStore.deleteCoupon(code);
  toggleCouponActive = (code: string) => localStore.toggleCouponActive(code);
  getTransactions = () => localStore.getTransactions();
  recordTransaction = (tx: any) => localStore.recordTransaction(tx);
  validateCoupon = (code: string, amount?: number) => localStore.validateCoupon(code, amount);
  useCoupon = (code: string) => localStore.useCoupon(code);
  resetLocalDB = () => localStore.resetLocalDB();

  // ===== مستندات التوثيق (Verification documents) =====
  submitVerificationDoc = (doc: any) => verificationStore.submitVerificationDoc(doc);
  getAllVerificationDocs = () => verificationStore.getAllVerificationDocs();
  getMemberVerificationDoc = (memberId: string) => verificationStore.getMemberVerificationDoc(memberId);
  getVerificationStatus = (memberId: string) => verificationStore.getVerificationStatus(memberId);
  approveVerificationDoc = (docId: string, reviewerName: string) => verificationStore.approveVerificationDoc(docId, reviewerName);
  rejectVerificationDoc = (docId: string, reviewerName: string, reason: string) => verificationStore.rejectVerificationDoc(docId, reviewerName, reason);
  deleteVerificationDoc = (docId: string) => verificationStore.deleteVerificationDoc(docId);
  deleteReviewedDocs = () => verificationStore.deleteReviewedDocs();
  downloadDocImage = (doc: any) => verificationStore.downloadDocImage(doc);
  downloadAllPendingDocs = () => verificationStore.downloadAllPendingDocs();

  // ===== المدن والدول (Geo Store - Cities & Countries) =====
  normalizeText = (s: string) => geoStore.normalizeText(s);
  getCountries = () => geoStore.getCountries();
  getCountryNames = () => geoStore.getCountryNames();
  addCountry = (name: string, code?: string, flag?: string) => geoStore.addCountry(name, code, flag);
  removeCountry = (name: string) => geoStore.removeCountry(name);
  renameCountry = (oldName: string, newName: string) => geoStore.renameCountry(oldName, newName);
  getCities = (country: string) => geoStore.getCities(country);
  addCityToCountry = (country: string, city: string) => geoStore.addCityToCountry(country, city);
  removeCityFromCountry = (country: string, city: string) => geoStore.removeCityFromCountry(country, city);
  renameCity = (country: string, oldName: string, newName: string) => geoStore.renameCity(country, oldName, newName);
  adminMergeCities = (sourceCountry: string, sourceCity: string, targetCountry: string, targetCity: string) => geoStore.adminMergeCities(sourceCountry, sourceCity, targetCountry, targetCity);
  adminMergeCountries = (sourceCountry: string, targetCountry: string) => geoStore.adminMergeCountries(sourceCountry, targetCountry);
  isCityKnown = (country: string, city: string) => geoStore.isCityKnown(country, city);
  isCountryKnown = (country: string) => geoStore.isCountryKnown(country);
  getPendingCities = () => geoStore.getPendingCities();
  getAllPendingCities = () => geoStore.getAllPendingCities();
  getPendingCitiesCount = () => geoStore.getPendingCitiesCount();
  addPendingCity = (name: string, country: string, suggestedBy: string, source?: any, suggestedById?: string) => geoStore.addPendingCity(name, country, suggestedBy, source, suggestedById);
  approvePendingCity = (id: string, reviewer: string, editedName?: string) => geoStore.approvePendingCity(id, reviewer, editedName);
  rejectPendingCity = (id: string, reviewer: string, reason?: string) => geoStore.rejectPendingCity(id, reviewer, reason);
  deletePendingCity = (id: string) => geoStore.deletePendingCity(id);
  checkAndRegisterUnknownGeo = (members: any[], source?: any) => geoStore.checkAndRegisterUnknownGeo(members, source);
  exportAllCountries = () => geoStore.exportAllCountries();
  exportCitiesForCountry = (country: string) => geoStore.exportCitiesForCountry(country);
  exportAllGeo = () => geoStore.exportAllGeo();
  importCountries = (json: string, mode?: 'merge' | 'replace') => geoStore.importCountries(json, mode);
  importCitiesForCountry = (country: string, json: string, mode?: 'merge' | 'replace') => geoStore.importCitiesForCountry(country, json, mode);
  importFullGeo = (json: string, mode?: 'merge' | 'replace') => geoStore.importFullGeo(json, mode);
  resetGeoDB = () => geoStore.resetGeoDB();
  refreshGeoDB = () => geoStore.refreshGeoDB();
}

export type DatabaseProvider = 'local' | 'supabase' | 'appwrite';

export const DATABASE_CONFIG = {
  PROVIDER: 'supabase' as DatabaseProvider,
};
