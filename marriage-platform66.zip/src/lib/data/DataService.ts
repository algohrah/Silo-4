import { IDatabaseAdapter } from './interfaces';
import { LocalStorageAdapter } from './LocalStorageAdapter';
import { SupabaseAdapter } from './adapters/supabase/SupabaseAdapter';
import { syncGeoDBFromCloud } from './adapters/local/geoStore';
import { syncVerificationDocsFromCloud } from './adapters/local/verificationStore';

// ============================================================================
//  DataService — نقطة الوصول الموحدة لجميع عمليات قواعد البيانات والتحكم بها
//  Single Source Data Architecture — Central Data Access Layer
// ============================================================================
//  طريقة الترقية لقاعدة بيانات حقيقية (Supabase, Firebase, PostgreSQL, SQL, Appwrite... إلخ):
//  1. قم بإنشاء فئة (Class) جديدة تُمثل محوّل قاعدة البيانات الجديدة (مثل RealDatabaseAdapter).
//  2. اجعل الفئة الجديدة تُطبق (implements) الواجهة `IDatabaseAdapter` بالكامل.
//  3. قم باستيراد محوّلك الجديد هنا، ثم قم بتغيير القيمة الافتراضية للـ provider أو استخدم المتغير البيئي.
// ============================================================================

export class DataService {
  private static instance: DataService;

  /** المحوّل النشط حالياً لتنفيذ جميع العمليات */
  public db: IDatabaseAdapter;
  
  /** نوع مزود البيانات النشط (تم توحيده على Supabase) */
  public provider: 'supabase';

  private constructor() {
    this.provider = 'supabase';
    // استخدام قاعدة البيانات السحابية الحقيقية لـ Supabase بالكامل:
    this.db = new SupabaseAdapter();
    if (typeof window !== 'undefined') {
      console.info('[DataService] Connected directly to Supabase Cloud Database.');
      syncGeoDBFromCloud().catch((err) => console.warn('[DataService] Failed to sync geo db:', err));
      syncVerificationDocsFromCloud().catch((err) => console.warn('[DataService] Failed to sync verification docs:', err));
    }
  }

  public static getInstance(): DataService {
    if (!DataService.instance) {
      DataService.instance = new DataService();
    }
    return DataService.instance;
  }
}

export const dataService = DataService.getInstance();

