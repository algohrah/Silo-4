// ============================================================
//  مخزن بيانات محلي — يحاكي قاعدة البيانات بالكامل (للتجربة فقط)
//  كل شيء في localStorage — لا اتصال بأي خادم أو Supabase
//  عند الانتهاء من التصميم سنستبدل هذا الملف بطبقة API حقيقية
// ============================================================

import { MEMBERS } from './members';
import type { Member } from './members';
import { INTEREST_REQUESTS } from './data';

// الحساب الافتراضي عند عدم وجود انتحال هوية
export const DEFAULT_USER_ID = 'm2';

// ===== مصدر الأعضاء الموحّد =====
// يقرأ تعديلات الإدارة المحفوظة في saved_members_list (يضبطها AppContext
// عند adminUpdateMember / الموافقة / التعديل) ثم يسقط إلى القائمة الأصلية.
// هكذا تظهر تعديلات الإدارة فوراً للطرف الآخر في صفحة الطلبات والرحلة.
export function getLiveMembers(includeInactiveAndDeleted: boolean = false): Member[] {
  let list: Member[] = [];
  if (typeof window !== 'undefined') {
    try {
      const saved = window.localStorage.getItem('saved_members_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) list = parsed as Member[];
      }
    } catch { /* تجاهل */ }
  }
  if (list.length === 0) {
    list = [...MEMBERS];
  }

  if (typeof window !== 'undefined' && !includeInactiveAndDeleted) {
    try {
      const adminMeta = readAdminMeta();
      list = list.filter((m) => {
        const meta = adminMeta[m.id];
        if (meta) {
          if (meta.deleted) return false;
          if (meta.status && meta.status !== 'active') return false;
        }
        if (m.status && m.status !== 'active') return false;
        return true;
      });
    } catch { /* تجاهل */ }
  }

  // دمج حالة سداد رسوم المنصة والتنسيق مع وسام الجدية بشكل ديناميكي
  try {
    const raw = typeof window !== 'undefined' ? window.localStorage.getItem(STORAGE_KEY) : null;
    if (raw) {
      const parsedDB = JSON.parse(raw);
      if (parsedDB && Array.isArray(parsedDB.requests)) {
        const paidUsers = new Set<string>();
        parsedDB.requests.forEach((r: any) => {
          if (r.sender_paid && r.sender_paid_at) paidUsers.add(r.sender_id);
          if (r.receiver_paid && r.receiver_paid_at) paidUsers.add(r.receiver_id);
        });
        return list.map((m) => {
          if (paidUsers.has(m.id)) {
            return { ...m, hasSeriousnessBadge: true };
          }
          return m;
        });
      }
    }
  } catch {}

  return list;
}

export function getLiveMemberById(id: string): Member | undefined {
  return getLiveMembers(true).find((m) => m.id === id);
}

// ===== الهوية النشطة (تتغيّر عند الدخول لحساب من لوحة التحكم) =====
// تُقرأ من active_member_id الذي يضبطه impersonateUser في AppContext
export function getCurrentUserId(): string {
  if (typeof window !== 'undefined') {
    try {
      const id = window.localStorage.getItem('active_member_id');
      if (id) return id;
    } catch { /* تجاهل */ }
  }
  return DEFAULT_USER_ID;
}

export function setCurrentUserId(id: string) {
  if (typeof window !== 'undefined') {
    try { window.localStorage.setItem('active_member_id', id); } catch { /* تجاهل */ }
  }
}

// للتوافق الرجعي مع الكود القديم — لكن يُفضّل استخدام getCurrentUserId()
export const CURRENT_USER_ID = DEFAULT_USER_ID;

// ===== تتبّع "غير المقروء" — متى آخر مرة شاهد المستخدم كل طلب =====
const SEEN_KEY = 'requests_last_seen';

function readSeenMap(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  try { return JSON.parse(window.localStorage.getItem(SEEN_KEY) || '{}'); } catch { return {}; }
}

// هل الطلب يحمل تحديثاً لم يره المستخدم بعد؟
export function isRequestUnseen(requestId: number, updatedAt?: string | null): boolean {
  if (!updatedAt) return false;
  const map = readSeenMap();
  const seen = map[String(requestId)];
  if (!seen) return true;                 // لم يُشاهد قط
  return new Date(updatedAt).getTime() > new Date(seen).getTime();
}

// تعليم طلب كمقروء (عند فتح رحلته)
export function markRequestSeen(requestId: number) {
  if (typeof window === 'undefined') return;
  try {
    const map = readSeenMap();
    map[String(requestId)] = new Date().toISOString();
    window.localStorage.setItem(SEEN_KEY, JSON.stringify(map));
  } catch { /* تجاهل */ }
}

export function markRequestNotificationsRead(requestId: number, userId?: string) {
  const d = load();
  (d.notifications || []).forEach((n) => {
    if (n.request_id === requestId && (!userId || n.user_id === userId)) n.read = true;
  });
  save();
}

// ===== الأنواع =====
export interface LocalRequest {
  id: number;
  sender_id: string;
  receiver_id: string;
  journey_stage: string;
  message: string;
  sender_paid: boolean;
  receiver_paid: boolean;
  sender_paid_at?: string | null;
  receiver_paid_at?: string | null;
  paid_at?: string | null;
  meeting_date?: string | null;
  meeting_notes?: string | null;
  decline_reason?: string | null;
  cancel_reason?: string | null;
  evaluation_result?: string | null;
  evaluation_note?: string | null;
  sender_viewing_result?: 'success' | 'failed' | null;
  receiver_viewing_result?: 'success' | 'failed' | null;
  sender_viewing_note?: string | null;
  receiver_viewing_note?: string | null;
  admin_notes?: string | null;
  // ===== معلومات التواصل (تُدخلها الأنثى، يراها الذكر بعد القَسَم) =====
  contact_info?: string | null;   // (قديم) — يُترك للتوافق الرجعي
  contact_by?: string | null;     // معرّف من أدخل معلومات التواصل
  guardian_phone?: string | null; // 📱 رقم ولي الأمر (أساسي للأنثى)
  guardian_name?: string | null;  // 👤 اسم ولي الأمر
  guardian_relation?: string | null; // صلة القرابة (الأب/الأخ/العم...)
  contact_time?: string | null;   // ⏰ الوقت المناسب للاتصال
  contact_note?: string | null;   // 📝 ملاحظة اختيارية
  male_pledged?: boolean;         // هل أقسم الذكر بعدم النشر قبل رؤية المعلومات
  // ===== معلومات تواصل الذكر وتعهّد الأنثى =====
  female_pledged?: boolean;       // هل أقسمت الأنثى قبل رؤية معلومات الذكر
  male_phone?: string | null;     // 📱 هاتف التواصل المباشر للذكر
  male_name?: string | null;      // 👤 اسم شخص التواصل للذكر
  male_relation?: string | null;  // صلة القرابة لشخص التواصل للذكر
  male_contact_time?: string | null; // ⏰ وقت الاتصال المناسب للذكر
  male_contact_note?: string | null; // 📝 ملاحظة من الطرف الذكر
  defer_date?: string | null;     // تاريخ تأجيل سداد العربون
  defer_by?: string | null;       // من الذي طلب تأجيل السداد
  deadline_date?: string | null;  // مهلة سداد العربون (١٥ يوم من القبول)
  created_at: string;
  updated_at: string;
}

export interface LocalEvent {
  id: number;
  request_id: number;
  actor_id: string;
  type: string;
  note: string;
  created_at: string;
}

export interface LocalInquiryMessage {
  id: number;
  request_id: number;
  sender_id: string;   // 'admin' = الوسيطة
  text: string;
  charged_to: string | null;
  created_at: string;
}

export interface LocalInquiryPackage {
  id: number;
  request_id: number;
  owner_id: string;
  credits_total: number;
  credits_used: number;
  price: number;
  active: boolean;
  created_at: string;
}

export interface LocalNotification {
  id: number;
  user_id: string;      // المستلم المعني بالإشعار
  request_id: number;   // الطلب المرتبط (للانتقال للرحلة)
  type: string;         // نوع الحدث
  text: string;
  read: boolean;
  created_at: string;
}

interface DB {
  requests: LocalRequest[];
  events: LocalEvent[];
  inquiryMessages: LocalInquiryMessage[];
  inquiryPackages: LocalInquiryPackage[];
  notifications: LocalNotification[];
  seq: number;
}

// رفعنا الإصدار إلى v3 لضمان بدء جميع الحسابات برحلات اهتمام فارغة نظيفة
// (يتجاهل أي بيانات بذرة قديمة كانت محفوظة في الإصدار السابق).
const STORAGE_KEY = 'twafok_local_db_v4';

// ===== بيانات البذرة (طلبات بمراحل مختلفة) =====
function seedDB(): DB {
  // تحويل بيانات الاهتمام التجريبية إلى تنسيق قاعدة بيانات الرحلات المحلية
  const seededRequests: LocalRequest[] = INTEREST_REQUESTS.map((ir, idx) => {
    let stage = 'sent';
    let sender_paid = false;
    let receiver_paid = false;
    let sender_paid_at: string | null = null;
    let receiver_paid_at: string | null = null;
    let meeting_date: string | null = null;
    let meeting_notes: string | null = null;
    let decline_reason: string | null = null;
    let cancel_reason: string | null = null;
    let evaluation_result: string | null = null;
    let evaluation_note: string | null = null;

    if (ir.status === 'pending') stage = 'sent';
    else if (ir.status === 'accepted_pending_payment') stage = 'accepted';
    else if (ir.status === 'paid') {
      sender_paid = ir.senderId === 'm2' ? true : false;
      receiver_paid = ir.receiverId === 'm2' ? true : false;
      if (!sender_paid && !receiver_paid) {
        sender_paid = true;
        receiver_paid = true;
      }
      sender_paid_at = new Date(Date.now() - 86400000 * 2).toISOString();
      receiver_paid_at = new Date(Date.now() - 86400000 * 2).toISOString();
      if ((ir as any).mediationStage === 'exchanging' || (ir as any).mediationStage === 'scheduling') {
        stage = 'coordination';
        meeting_date = (ir as any).meetingDate || null;
        meeting_notes = (ir as any).meetingNotes || null;
      } else if ((ir as any).mediationStage === 'evaluating') {
        stage = 'sharia_viewing';
        evaluation_result = (ir as any).evaluationResult || null;
        evaluation_note = (ir as any).evaluationNote || null;
      } else {
        stage = 'seriousness';
      }
    } else if (ir.status === 'declined') {
      stage = 'declined';
      decline_reason = ir.declineReason || 'عدم توافق';
    } else if (ir.status === 'completed') {
      stage = 'completed';
      evaluation_result = (ir as any).evaluationResult || 'success';
      evaluation_note = (ir as any).evaluationNote || null;
    } else if (ir.status === 'in_mediation') {
      stage = 'coordination';
      meeting_date = (ir as any).meetingDate || null;
      meeting_notes = (ir as any).meetingNotes || null;
    }

    return {
      id: idx + 1,
      sender_id: ir.senderId,
      receiver_id: ir.receiverId,
      journey_stage: stage,
      message: ir.message || 'طلب اهتمام مرسل عبر الإدارة',
      sender_paid,
      receiver_paid,
      sender_paid_at,
      receiver_paid_at,
      paid_at: sender_paid && receiver_paid ? new Date(Date.now() - 86400000 * 2).toISOString() : null,
      meeting_date,
      meeting_notes,
      decline_reason,
      cancel_reason,
      evaluation_result,
      evaluation_note,
      admin_notes: ir.adminNotes || null,
      created_at: new Date(ir.createdAt || Date.now()).toISOString(),
      updated_at: new Date(ir.createdAt || Date.now()).toISOString(),
    };
  });

  const events: LocalEvent[] = [];
  seededRequests.forEach((r) => {
    events.push({
      id: seededRequests.length + r.id,
      request_id: r.id,
      actor_id: r.sender_id,
      type: 'sent',
      note: 'تم إرسال طلب الاهتمام',
      created_at: r.created_at,
    });
    if (r.journey_stage !== 'sent' && r.journey_stage !== 'declined') {
      events.push({
        id: seededRequests.length * 2 + r.id,
        request_id: r.id,
        actor_id: r.receiver_id,
        type: 'accept',
        note: 'قبل الطلب وبدء الرحلة',
        created_at: new Date(new Date(r.created_at).getTime() + 3600000).toISOString(),
      });
    }
    if (r.sender_paid) {
      events.push({
        id: seededRequests.length * 3 + r.id,
        request_id: r.id,
        actor_id: r.sender_id,
        type: 'pay_deposit',
        note: 'تم سداد عربون الجدية (المرسِل)',
        created_at: r.sender_paid_at || r.updated_at,
      });
    }
    if (r.receiver_paid) {
      events.push({
        id: seededRequests.length * 4 + r.id,
        request_id: r.id,
        actor_id: r.receiver_id,
        type: 'pay_deposit',
        note: 'تم سداد عربون الجدية (المستقبِل)',
        created_at: r.receiver_paid_at || r.updated_at,
      });
    }
  });

  return {
    requests: seededRequests,
    events,
    inquiryMessages: [],
    inquiryPackages: [],
    notifications: [],
    seq: seededRequests.length * 10,
  };
}

// ===== تحميل/حفظ =====
let db: DB | null = null;

function syncGlobalPayments(d: DB) {
  if (!d || !d.requests) return;
  
  // 1. تحديد جميع الأعضاء الذين دفعوا العربون فعلياً في أي طلب
  const paidUsers = new Set<string>();
  d.requests.forEach((r) => {
    if (r.sender_paid && r.sender_paid_at) paidUsers.add(r.sender_id);
    if (r.receiver_paid && r.receiver_paid_at) paidUsers.add(r.receiver_id);
  });
  
  // 2. تطبيق حالة الدفع على جميع الطلبات النشطة الأخرى
  let changed = false;
  d.requests.forEach((r) => {
    if (paidUsers.has(r.sender_id) && !r.sender_paid) {
      r.sender_paid = true;
      r.sender_paid_at = r.sender_paid_at || new Date().toISOString();
      changed = true;
    }
    if (paidUsers.has(r.receiver_id) && !r.receiver_paid) {
      r.receiver_paid = true;
      r.receiver_paid_at = r.receiver_paid_at || new Date().toISOString();
      changed = true;
    }
    // إذا دفع الطرفان وكنا في مرحلة الجدية، ننتقل تلقائياً للتنسيق
    if (r.sender_paid && r.receiver_paid && r.journey_stage === 'seriousness') {
      r.journey_stage = 'coordination';
      r.paid_at = r.paid_at || new Date().toISOString();
      changed = true;
    }
  });
  
  if (changed) {
    if (typeof window !== 'undefined') {
      try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); } catch {}
    }
  }
}

function autoProcessDeadlines(d: DB): boolean {
  let changed = false;
  if (!d.requests) return false;
  
  const now = new Date();
  
  for (const r of d.requests) {
    if (r.journey_stage === 'accepted' || r.journey_stage === 'seriousness') {
      // إذا كان الطرفان قد سددا الرسوم مسبقاً، فلا ينطبق عليهم الإغلاق التلقائي لعدم السداد
      if (r.sender_paid && r.receiver_paid) {
        continue;
      }
      
      const targetDateStr = r.defer_date || r.deadline_date;
      if (!targetDateStr) continue;
      
      const targetDate = new Date(targetDateStr);
      const diffTime = targetDate.getTime() - now.getTime();
      const remainingDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (remainingDays <= 0) {
        // انتهت المهلة! نقوم بإغلاق الطلب وتغيير الحالة إلى 'cancelled' مع كتابة السبب 'انتهت المهلة ولم يتم السداد'
        r.journey_stage = 'cancelled';
        r.cancel_reason = 'انتهت المهلة ولم يتم السداد';
        r.updated_at = now.toISOString();
        changed = true;
        
        // إخطار الطرفين
        addNotification(d, r.sender_id, r.id, 'system', '⚠️ تم إغلاق طلب الاهتمام تلقائياً لانتهاء المهلة المحددة دون سداد رسوم التنسيق.');
        addNotification(d, r.receiver_id, r.id, 'system', '⚠️ تم إغلاق طلب الاهتمام تلقائياً لانتهاء المهلة المحددة دون سداد رسوم التنسيق.');
        
        // تسجيل حدث
        addEvent(d, r.id, 'system', 'deadline_expired', 'انتهت المهلة ولم يتم السداد وتأكيد الجدية');
      } else if (remainingDays <= 7) {
        // وقبل اغلاق الطلب ب ٧ ايام يعطيه كل يوم اشعار بالسداد قبل اغلاق الطلب
        const reminderText = `⏳ تنبيه هام: متبقي ${remainingDays} أيام فقط على انتهاء مهلة سداد رسوم التنسيق قبل إغلاق طلبك وتلقائياً لعدم السداد.`;
        
        // التحقق من وجود إشعار لنفس اليوم والطلب في صندوق الإشعارات لتجنب التكرار والسبام
        const senderAlreadyNotified = d.notifications?.some(
          n => n.request_id === r.id && n.user_id === r.sender_id && n.text.includes(`متبقي ${remainingDays} أيام`)
        );
        const receiverAlreadyNotified = d.notifications?.some(
          n => n.request_id === r.id && n.user_id === r.receiver_id && n.text.includes(`متبقي ${remainingDays} أيام`)
        );
        
        if (!r.sender_paid && !senderAlreadyNotified) {
          addNotification(d, r.sender_id, r.id, 'system', reminderText);
          changed = true;
        }
        if (!r.receiver_paid && !receiverAlreadyNotified) {
          addNotification(d, r.receiver_id, r.id, 'system', reminderText);
          changed = true;
        }
      }
    }
  }
  return changed;
}

function load(): DB {
  if (db) return db;
  if (typeof window !== 'undefined') {
    try {
      // تنظيف الإصدارات القديمة لضمان بداية نظيفة لجميع الحسابات
      window.localStorage.removeItem('twafok_local_db_v3');
      window.localStorage.removeItem('twafok_local_db_v2');
      window.localStorage.removeItem('twafok_local_db');
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        db = JSON.parse(raw);
        // ترقية: ضمان وجود مصفوفة الإشعارات للبيانات القديمة
        if (db && !db.notifications) db.notifications = [];
        if (db) {
          syncGlobalPayments(db);
          const changed = autoProcessDeadlines(db);
          if (changed) {
            save();
          }
        }
        return db!;
      }
    } catch { /* تجاهل */ }
  }
  db = seedDB();
  save();
  return db;
}

function save() {
  if (db && typeof window !== 'undefined') {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); } catch { /* تجاهل */ }
  }
}

function nextId(): number {
  const d = load();
  d.seq += 1;
  return d.seq;
}

// إعادة ضبط قاعدة البيانات المحلية (للتجربة)
export function resetLocalDB() {
  db = seedDB();
  save();
}

// التحقق مما إذا كان المستخدم قد دفع العربون في أي طلب سابق (لإثبات الجدية بشكل دائم)
export function hasUserPaidDepositAnywhere(userId: string): boolean {
  const d = load();
  return d.requests.some(
    (r) =>
      (r.sender_id === userId && r.sender_paid && r.sender_paid_at) ||
      (r.receiver_id === userId && r.receiver_paid && r.receiver_paid_at)
  );
}

// محاكاة تأخير شبكة بسيط (اختياري)
const delay = (ms = 120) => new Promise((r) => setTimeout(r, ms));

// ===== الأعضاء =====
export async function getMembers() {
  await delay(60);
  // يقرأ من تعديلات الإدارة الحيّة كي تظهر للطرف الآخر فور حفظها
  return getLiveMembers().map((m) => ({
    id: m.id, nickname: m.nickname, gender: m.gender, age: m.age,
    country: m.country, city: m.city, verified: m.verified, premium: m.premium,
  }));
}

// ===== الطلبات =====
export async function getRequests(userId?: string): Promise<LocalRequest[]> {
  await delay();
  const d = load();
  const sorted = [...d.requests].sort((a, b) => b.created_at.localeCompare(a.created_at));
  if (!userId) return sorted;
  return sorted.filter((r) => r.sender_id === userId || r.receiver_id === userId);
}

export async function getRequest(id: number): Promise<LocalRequest | null> {
  await delay(60);
  const d = load();
  return d.requests.find((r) => r.id === id) || null;
}

export async function createRequest(senderId: string, receiverId: string, message: string) {
  await delay();
  if (senderId === receiverId) {
    return { ok: false, error: 'لا يمكنك إرسال طلب اهتمام لنفسك' };
  }
  const d = load();
  // منع التكرار: أي طلب غير منتهٍ بالرفض/الإلغاء يُعتبر قائماً.
  // المراحل المنتهية التي تسمح بطلب جديد: declined (مرفوض) و cancelled (ملغى).
  const blocking = d.requests.find((r) =>
    r.sender_id === senderId && r.receiver_id === receiverId &&
    r.journey_stage !== 'declined' && r.journey_stage !== 'cancelled',
  );
  if (blocking) {
    // رسالة دقيقة حسب الحالة
    if (blocking.journey_stage === 'sent') {
      return { ok: false, error: 'لديك طلب اهتمام مُرسَل لهذا العضو بالفعل ولم يتم الرد عليه بعد.' };
    }
    if (blocking.journey_stage === 'completed') {
      return { ok: false, error: 'لديك رحلة مكتملة مع هذا العضو بالفعل.' };
    }
    return { ok: false, error: 'لديك طلب اهتمام نشط مع هذا العضو بالفعل.' };
  }

  const now = new Date().toISOString();
  const req: LocalRequest = {
    id: nextId(), sender_id: senderId, receiver_id: receiverId, journey_stage: 'sent',
    message: (message || '').trim() || 'طلب اهتمام مرسل عبر الإدارة',
    sender_paid: false, receiver_paid: false, created_at: now, updated_at: now,
  };
  d.requests.unshift(req);
  addEvent(d, req.id, senderId, 'sent', 'تم إرسال طلب الاهتمام');
  addNotification(d, receiverId, req.id, 'request', 'وصلك طلب اهتمام جديد بانتظار قرارك');
  save();
  return { ok: true, data: req };
}

function addEvent(d: DB, requestId: number, actorId: string, type: string, note: string) {
  d.events.push({
    id: nextId(), request_id: requestId, actor_id: actorId || 'system',
    type, note, created_at: new Date().toISOString(),
  });
}

// #9 توليد إشعار حقيقي يقود مباشرة لصفحة الرحلة
function addNotification(d: DB, userId: string, requestId: number, type: string, text: string) {
  if (!d.notifications) d.notifications = [];
  d.notifications.push({
    id: nextId(), user_id: userId, request_id: requestId, type, text,
    read: false, created_at: new Date().toISOString(),
  });
}

// إشعار الطرف الآخر بتغيّر المرحلة (المتلقّي = الطرف غير الفاعل)
function notifyOther(d: DB, req: LocalRequest, actorId: string, type: string, text: string) {
  const otherId = actorId === req.sender_id ? req.receiver_id : req.sender_id;
  addNotification(d, otherId, req.id, type, text);
}

// ===== تنفيذ إجراءات الرحلة =====
export async function runRequestAction(
  requestId: number, action: string, actorId: string, payload: Record<string, any> = {},
): Promise<{ ok: boolean; data?: LocalRequest; error?: string }> {
  await delay();
  const d = load();
  const req = d.requests.find((r) => r.id === requestId);
  if (!req) return { ok: false, error: 'الطلب غير موجود' };

  const now = new Date().toISOString();
  req.updated_at = now;
  let evType = action, evNote = '';

  switch (action) {
    case 'accept': {
      req.journey_stage = 'accepted';
      const deadline = new Date();
      deadline.setDate(deadline.getDate() + 15);
      req.deadline_date = deadline.toISOString();
      evNote = 'قبِل الطرف الآخر طلب الاهتمام';
      break;
    }
    case 'decline':
      req.journey_stage = 'declined';
      req.decline_reason = payload.reason || 'عدم التوافق';
      evNote = 'تم الاعتذار عن الطلب: ' + (payload.reason || '');
      break;
    case 'cancel':
      req.journey_stage = 'cancelled';
      req.cancel_reason = payload.reason || 'تم الإلغاء';
      evNote = 'تم إلغاء الطلب: ' + (payload.reason || '');
      break;
    case 'skip_to_seriousness': {
      req.journey_stage = 'seriousness';
      evNote = 'تأكيد الرغبة والمضي لتسديد العربون وتأكيد الجدية';
      break;
    }
    case 'defer_payment': {
      const deferDate = payload.deferDate;
      if (!deferDate) return { ok: false, error: 'تاريخ التأجيل مطلوب' };
      req.defer_date = deferDate;
      req.defer_by = actorId;
      const actorName = getLiveMemberById(actorId)?.nickname || 'أحد الطرفين';
      evNote = `قام ${actorName} بتأجيل سداد العربون إلى تاريخ ${new Date(deferDate).toLocaleDateString('ar-SA')}`;
      evType = 'defer_payment';
      
      // إشعار للطرف الآخر
      notifyOther(d, req, actorId, 'system', `قام ${actorName} بتأجيل موعد سداد عربون الجدية إلى ${new Date(deferDate).toLocaleDateString('ar-SA')}`);
      
      // إضافة تذكير قبل السداد بيوم
      const reminderDate = new Date(deferDate);
      reminderDate.setDate(reminderDate.getDate() - 1);
      addNotification(d, actorId, req.id, 'system', `تذكير: يتبقى يوم واحد على موعد سداد عربون الجدية المحدد وهو ${new Date(deferDate).toLocaleDateString('ar-SA')}`);
      break;
    }
    case 'pay_deposit': {
      const isSender = actorId === req.sender_id;
      if (isSender) { req.sender_paid = true; req.sender_paid_at = now; }
      else { req.receiver_paid = true; req.receiver_paid_at = now; }
      if (req.journey_stage === 'accepted') req.journey_stage = 'seriousness';
      if (req.sender_paid && req.receiver_paid) {
        req.journey_stage = 'coordination';
        req.paid_at = now;
      }
      evNote = 'تم سداد عربون الجدية (' + (isSender ? 'المرسِل' : 'المستقبِل') + ')';
      break;
    }
    case 'update_coordination':
      if (payload.meetingDate !== undefined) req.meeting_date = payload.meetingDate;
      if (payload.meetingNotes !== undefined) req.meeting_notes = payload.meetingNotes;
      if (payload.advance) req.journey_stage = 'sharia_viewing';
      evNote = 'تحديث تبادل التواصل وتنسيق الموعد';
      evType = 'coordination';
      break;
    case 'submit_contact': {
      const actor = getLiveMemberById(actorId);
      if (!actor) return { ok: false, error: 'تعذّر التحقق من الحساب' };
      
      if (actor.gender === 'female') {
        const phone = String(payload.guardianPhone || '').trim();
        if (!phone) {
          return { ok: false, error: 'رقم ولي الأمر مطلوب' };
        }
        req.guardian_phone = phone;
        req.guardian_name = String(payload.guardianName || '').trim() || null;
        req.guardian_relation = String(payload.guardianRelation || '').trim() || null;
        req.contact_time = String(payload.contactTime || '').trim() || null;
        req.contact_note = String(payload.contactNote || '').trim() || null;
        req.contact_by = actorId;
        
        // تجميع نصّي للتوافق الرجعي
        req.contact_info = [
          req.guardian_name ? `${req.guardian_name}${req.guardian_relation ? ' (' + req.guardian_relation + ')' : ''}` : null,
          `📱 ${phone}`,
          req.contact_time ? `⏰ ${req.contact_time}` : null,
          req.contact_note ? `📝 ${req.contact_note}` : null,
        ].filter(Boolean).join(' — ');
        evNote = 'شاركت الطرف الأنثى معلومات التواصل (رقم ولي الأمر) مباشرة';
        
        // إشعار للطرفين
        const notifText = '🌸 قامت الطرف الأنثى بمشاركة بيانات تواصل ولي أمرها بنجاح للبدء بالتنسيق.';
        addNotification(d, req.sender_id, req.id, 'match', notifText);
        addNotification(d, req.receiver_id, req.id, 'match', notifText);
      } else {
        const phone = String(payload.malePhone || '').trim();
        if (!phone) {
          return { ok: false, error: 'رقم الهاتف مطلوب' };
        }
        req.male_phone = phone;
        req.male_name = String(payload.maleName || '').trim() || null;
        req.male_relation = String(payload.maleRelation || '').trim() || null;
        req.male_contact_time = String(payload.maleContactTime || '').trim() || null;
        req.male_contact_note = String(payload.maleContactNote || '').trim() || null;
        evNote = 'شارك الطرف الذكر معلومات التواصل الخاصة به مباشرة';
        
        // إشعار للطرفين
        const notifText = '👔 قام الطرف الذكر بمشاركة بيانات التواصل الخاصة به بنجاح للبدء بالتنسيق.';
        addNotification(d, req.sender_id, req.id, 'match', notifText);
        addNotification(d, req.receiver_id, req.id, 'match', notifText);
      }
      
      evType = 'coordination';
      break;
    }
    case 'male_pledge': {
      const actor = getLiveMemberById(actorId);
      if (!actor) return { ok: false, error: 'تعذّر التحقق من الحساب' };
      if (actor.gender === 'female') {
        return { ok: false, error: 'هذا التعهّد خاص بالطرف الآخر.' };
      }
      req.male_pledged = true;
      evNote = 'أقسم الطرف الذكر بعدم نشر المعلومات والتواصل بنية الزواج الجاد';
      evType = 'coordination';
      break;
    }
    case 'female_pledge': {
      const actor = getLiveMemberById(actorId);
      if (!actor) return { ok: false, error: 'تعذّر التحقق من الحساب' };
      if (actor.gender === 'male') {
        return { ok: false, error: 'هذا التعهّد خاص بالطرف الآخر.' };
      }
      req.female_pledged = true;
      evNote = 'أقسمت الطرف الأنثى بعدم نشر معلومات التواصل والتواصل بنية الزواج الجاد';
      evType = 'coordination';
      break;
    }
    case 'report_contact_issue': {
      const reason = payload.reason || 'الطرف الآخر لم يتجاوب';
      const actorName = getLiveMemberById(actorId)?.nickname || 'أحد الطرفين';
      evNote = `قام ${actorName} بالإبلاغ عن مشكلة في التواصل: (${reason})`;
      evType = 'support_report';
      
      // إضافة إشعار للإدارة والطرف الآخر لتنبيههم
      addNotification(d, req.sender_id, req.id, 'admin', `تنبيه من الإدارة: قام ${actorName} برفع بلاغ عن وجود صعوبة في التواصل: ${reason}`);
      addNotification(d, req.receiver_id, req.id, 'admin', `تنبيه من الإدارة: قام ${actorName} برفع بلاغ عن وجود صعوبة في التواصل: ${reason}`);
      
      // حفظ البلاغ محلياً لتتمكن الإدارة من معالجته
      (req as any).contact_issue_reported = true;
      (req as any).contact_issue_reason = reason;
      (req as any).contact_issue_by = actorId;
      (req as any).contact_issue_at = now;
      break;
    }
    case 'advance_viewing':
      req.journey_stage = 'sharia_viewing';
      evNote = 'الانتقال لمرحلة النظرة الشرعية';
      evType = 'sharia_viewing';
      break;
    case 'record_result': {
      const isSender = actorId === req.sender_id;
      // نتيجة النظرة: توافق -> الملكة، اعتذار -> مرفوض مع السبب
      if (payload.result === 'failed') {
        req.journey_stage = 'declined';
        req.decline_reason = payload.note || payload.reason || 'تم الاعتذار بعد النظرة الشرعية';
        req.evaluation_result = 'failed';
        req.evaluation_note = payload.note || '';
        evNote = 'الاعتذار بعد النظرة الشرعية: ' + (payload.note || payload.reason || '');
        evType = 'decline';
      } else {
        if (isSender) {
          req.sender_viewing_result = 'success';
          req.sender_viewing_note = payload.note || '';
        } else {
          req.receiver_viewing_result = 'success';
          req.receiver_viewing_note = payload.note || '';
        }

        // إذا وافق الطرفان كلاهما على التوافق، ننتقل بالطلب رسمياً لمرحلة الملكة
        if (req.sender_viewing_result === 'success' && req.receiver_viewing_result === 'success') {
          req.journey_stage = 'engagement';
          req.evaluation_result = 'success';
          req.evaluation_note = payload.note || '';
          evNote = 'توافق ثنائي مبارك بعد النظرة الشرعية — الانتقال للملكة للطرفين 🎉';
        } else {
          evNote = 'تسجيل رغبة التوافق بعد النظرة الشرعية من قبل ' + (isSender ? 'المرسِل' : 'المستقبِل') + ' بانتظار الطرف الآخر';
        }
        evType = 'sharia_viewing';
      }
      break;
    }
    case 'complete_engagement':
      req.journey_stage = 'completed';
      req.evaluation_result = 'success';
      if (payload.note) req.evaluation_note = payload.note;
      evNote = 'تم إتمام الملكة وعقد القران المبارك 🎉';
      evType = 'completed';
      break;
    case 'set_stage':
      if (['sent', 'accepted', 'seriousness', 'coordination', 'sharia_viewing', 'engagement', 'completed', 'declined', 'cancelled'].includes(payload.stage)) {
        req.journey_stage = payload.stage;
        if (payload.stage === 'cancelled') req.cancel_reason = payload.note || 'إلغاء إداري';
        if (payload.stage === 'declined') req.decline_reason = payload.note || 'رفض إداري';
      }
      evNote = payload.note || ('تعديل إداري للمرحلة إلى ' + payload.stage);
      break;
    default:
      return { ok: false, error: 'إجراء غير معروف: ' + action };
  }

  addEvent(d, requestId, actorId, evType, evNote);

  // #9 توليد إشعارات حقيقية للطرف الآخر حسب الإجراء — تقود مباشرة للرحلة
  const actorName = getLiveMemberById(actorId)?.nickname || 'الطرف الآخر';
  switch (action) {
    case 'accept':
      notifyOther(d, req, actorId, 'request', `قبِل ${actorName} طلب اهتمامك — تابع رحلتك الآن`);
      break;
    case 'decline':
      notifyOther(d, req, actorId, 'system', `اعتذر ${actorName} عن إكمال الطلب`);
      break;
    case 'cancel':
      notifyOther(d, req, actorId, 'system', `تم إلغاء طلب الاهتمام من ${actorName}`);
      break;
    case 'pay_deposit':
      if (req.journey_stage === 'coordination') {
        // أكّد الطرفان الجدية — أشعِر كليهما ببدء التنسيق
        addNotification(d, req.sender_id, req.id, 'match', 'أكّد الطرفان الجدية! بدأت مرحلة تنسيق التعارف 🎉');
        addNotification(d, req.receiver_id, req.id, 'match', 'أكّد الطرفان الجدية! بدأت مرحلة تنسيق التعارف 🎉');
      } else {
        notifyOther(d, req, actorId, 'request', `سدّد ${actorName} عربون الجدية — بانتظار سدادك لبدء التنسيق`);
      }
      break;
    case 'submit_contact':
      notifyOther(d, req, actorId, 'match', 'تمت مشاركة معلومات التواصل — يمكنك المتابعة');
      break;
    case 'advance_viewing':
      addNotification(d, req.sender_id, req.id, 'match', 'انتقلت رحلتكما إلى مرحلة النظرة الشرعية');
      addNotification(d, req.receiver_id, req.id, 'match', 'انتقلت رحلتكما إلى مرحلة النظرة الشرعية');
      break;
    case 'record_result':
      if (payload.result !== 'failed') {
        notifyOther(d, req, actorId, 'match', 'توافق مبارك بعد النظرة — الانتقال لمرحلة الملكة 💍');
      } else {
        notifyOther(d, req, actorId, 'system', 'تم الاعتذار بعد النظرة الشرعية');
      }
      break;
    case 'complete_engagement':
      addNotification(d, req.sender_id, req.id, 'match', 'مبارك! تم إتمام الملكة وعقد القران 🎉');
      addNotification(d, req.receiver_id, req.id, 'match', 'مبارك! تم إتمام الملكة وعقد القران 🎉');
      break;
    case 'set_stage':
      // إجراء إداري — أشعِر الطرفين بتحديث الإدارة لمرحلة الرحلة
      if (actorId === 'admin') {
        const adminText = payload.stage === 'cancelled'
          ? 'قامت إدارة المنصة بإلغاء طلب الاهتمام'
          : 'حدّثت إدارة المنصة مرحلة رحلتكما';
        addNotification(d, req.sender_id, req.id, 'admin', adminText);
        addNotification(d, req.receiver_id, req.id, 'admin', adminText);
      }
      break;
    case 'update_coordination':
      if (actorId === 'admin') {
        addNotification(d, req.sender_id, req.id, 'match', 'حدّثت الإدارة تفاصيل موعد التعارف — اطّلع عليها');
        addNotification(d, req.receiver_id, req.id, 'match', 'حدّثت الإدارة تفاصيل موعد التعارف — اطّلع عليها');
      }
      break;
  }

  save();
  return { ok: true, data: { ...req } };
}

// ===== سجل الأحداث =====
export async function getEvents(requestId: number): Promise<LocalEvent[]> {
  await delay(60);
  const d = load();
  return d.events
    .filter((e) => e.request_id === requestId)
    .sort((a, b) => a.created_at.localeCompare(b.created_at));
}

// ===== باقة الاستفسار =====
const INQUIRY_CREDITS = 20;
const INQUIRY_PRICE = 100;

export interface InquiryStateLocal {
  package: LocalInquiryPackage | null;
  remaining: number;
  messages: LocalInquiryMessage[];
  inquiry_started_by?: string | null;
}

export function getUserInquiryBalance(userId: string): number {
  const d = load();
  const userPkgs = d.inquiryPackages.filter((p) => p.owner_id === userId && p.active);
  const total = userPkgs.reduce((sum, p) => sum + p.credits_total, 0);
  const used = userPkgs.reduce((sum, p) => sum + p.credits_used, 0);
  return Math.max(0, total - used);
}

export function consumeUserInquiryMessage(userId: string): boolean {
  const d = load();
  const pkgs = d.inquiryPackages
    .filter((p) => p.owner_id === userId && p.active && p.credits_used < p.credits_total)
    .sort((a, b) => a.id - b.id);

  if (pkgs.length > 0) {
    pkgs[0].credits_used += 1;
    save();
    return true;
  }
  return false;
}

function inquiryState(d: DB, requestId: number): InquiryStateLocal {
  const req = d.requests.find((r) => r.id === requestId);
  let inquiry_started_by = req ? (req as any).inquiry_started_by : null;

  let pkg = null;
  let remaining = 0;

  if (inquiry_started_by) {
    remaining = getUserInquiryBalance(inquiry_started_by);
    pkg = [...d.inquiryPackages]
      .filter((p) => p.owner_id === inquiry_started_by && p.active)
      .sort((a, b) => b.id - a.id)[0] || null;
  } else {
    const currentUserId = getCurrentUserId();
    remaining = getUserInquiryBalance(currentUserId);
    pkg = [...d.inquiryPackages]
      .filter((p) => p.owner_id === currentUserId && p.active)
      .sort((a, b) => b.id - a.id)[0] || null;
  }

  const messages = d.inquiryMessages
    .filter((m) => m.request_id === requestId)
    .sort((a, b) => a.created_at.localeCompare(b.created_at));

  return { package: pkg, remaining, messages, inquiry_started_by };
}

export async function getInquiry(requestId: number): Promise<InquiryStateLocal> {
  await delay(60);
  return inquiryState(load(), requestId);
}

export async function initializeInquiry(requestId: number, userId: string): Promise<{ ok: boolean; state?: InquiryStateLocal; error?: string }> {
  await delay();
  const d = load();
  const req = d.requests.find((r) => r.id === requestId);
  if (!req) return { ok: false, error: 'الطلب غير موجود' };

  if (!(req as any).inquiry_started_by) {
    const balance = getUserInquiryBalance(userId);
    if (balance > 0) {
      (req as any).inquiry_started_by = userId;
      req.updated_at = new Date().toISOString();
      
      const hasWelcome = d.inquiryMessages.some(m => m.request_id === requestId && m.sender_id === 'admin');
      if (!hasWelcome) {
        d.inquiryMessages.push({
          id: nextId(),
          request_id: requestId,
          sender_id: 'admin',
          text: 'مرحباً بكما في غرفة الاستفسار والتعارف الجاد والموثق تحت إشراف المنصة. يتم خصم رسائل المحادثة (المرسلة والمستقبلة) من باقة العضو الذي بدأ الاستفسار.',
          charged_to: null,
          created_at: new Date().toISOString(),
        });
      }
      save();
    }
  }

  return { ok: true, state: inquiryState(d, requestId) };
}

export async function buyInquiry(requestId: number, ownerId: string): Promise<{ ok: boolean; state?: InquiryStateLocal; error?: string }> {
  await delay();
  const d = load();
  const pkg: LocalInquiryPackage = {
    id: nextId(), request_id: requestId, owner_id: ownerId,
    credits_total: INQUIRY_CREDITS, credits_used: 0, price: INQUIRY_PRICE,
    active: true, created_at: new Date().toISOString(),
  };
  d.inquiryPackages.push(pkg);

  const req = d.requests.find((r) => r.id === requestId);
  if (req && !(req as any).inquiry_started_by) {
    (req as any).inquiry_started_by = ownerId;
    req.updated_at = new Date().toISOString();
  }

  addEvent(d, requestId, ownerId, 'inquiry_buy', `تم شراء باقة استفسار (${INQUIRY_CREDITS} رسالة بسعر ${INQUIRY_PRICE} ريال)`);
  
  const hasWelcome = d.inquiryMessages.some(m => m.request_id === requestId && m.sender_id === 'admin');
  if (!hasWelcome) {
    d.inquiryMessages.push({
      id: nextId(), request_id: requestId, sender_id: 'admin',
      text: 'مرحباً بكما في غرفة الاستفسار والتعارف الجاد والموثق تحت إشراف المنصة. يتم خصم رسائل المحادثة (المرسلة والمستقبلة) من باقة العضو الذي بدأ الاستفسار.',
      charged_to: null, created_at: new Date().toISOString(),
    });
  }

  if (req) {
    const otherId = ownerId === req.sender_id ? req.receiver_id : req.sender_id;
    addNotification(d, otherId, req.id, 'inquiry', 'فتح الطرف الآخر غرفة الاستفسار وفعّل باقة الرسائل — يمكنك الرد من صفحة الاستفسار');
  }
  
  save();
  return { ok: true, state: inquiryState(d, requestId) };
}

export async function sendInquiry(requestId: number, senderId: string, text: string): Promise<{ ok: boolean; state?: InquiryStateLocal; error?: string }> {
  await delay();
  const d = load();
  if (!text || text.trim().length < 1) return { ok: false, error: 'الرسالة قصيرة جداً' };

  const req = d.requests.find((r) => r.id === requestId);
  if (!req) return { ok: false, error: 'الطلب غير موجود' };

  let inquiry_started_by = (req as any).inquiry_started_by;
  if (!inquiry_started_by) {
    inquiry_started_by = senderId;
    (req as any).inquiry_started_by = senderId;
  }

  const balance = getUserInquiryBalance(inquiry_started_by);
  if (balance <= 0) {
    return { ok: false, error: 'نفد رصيد باقة الاستفسار للشخص الذي بدأ الاستفسار. يرجى شحن باقة جديدة للمتابعة.' };
  }

  const consumed = consumeUserInquiryMessage(inquiry_started_by);
  if (!consumed) {
    return { ok: false, error: 'تعذّر استهلاك الرسالة، يرجى شحن الرصيد.' };
  }

  d.inquiryMessages.push({
    id: nextId(), request_id: requestId, sender_id: senderId, text: text.trim(),
    charged_to: inquiry_started_by, created_at: new Date().toISOString(),
  });
  const otherId = senderId === req.sender_id ? req.receiver_id : req.sender_id;
  addNotification(d, otherId, requestId, 'inquiry', 'وصلتك رسالة جديدة في غرفة الاستفسار — افتح المحادثة للرد');
  save();
  return { ok: true, state: inquiryState(d, requestId) };
}

export async function simulateReply(requestId: number, replierId: string, text: string): Promise<{ ok: boolean; state?: InquiryStateLocal; error?: string }> {
  await delay(400);
  const d = load();

  const req = d.requests.find((r) => r.id === requestId);
  if (!req) return { ok: false, error: 'الطلب غير موجود' };

  const inquiry_started_by = (req as any).inquiry_started_by;
  if (!inquiry_started_by) return { ok: false, error: 'لم يتم بدء الاستفسار بعد' };

  const balance = getUserInquiryBalance(inquiry_started_by);
  if (balance <= 0) {
    return { ok: false, error: 'نفد رصيد الاستفسار' };
  }

  const consumed = consumeUserInquiryMessage(inquiry_started_by);
  if (!consumed) return { ok: false, error: 'نفد الرصيد' };

  d.inquiryMessages.push({
    id: nextId(), request_id: requestId, sender_id: replierId, text,
    charged_to: inquiry_started_by, created_at: new Date().toISOString(),
  });
  const otherId = replierId === req.sender_id ? req.receiver_id : req.sender_id;
  addNotification(d, otherId, requestId, 'inquiry', 'وصلتك رسالة جديدة في غرفة الاستفسار — افتح المحادثة للرد');
  save();
  return { ok: true, state: inquiryState(d, requestId) };
}

// ===== #9 إشعارات الرحلة =====
export async function getJourneyNotifications(userId: string): Promise<LocalNotification[]> {
  await delay(100);
  const d = load();
  if (!d.notifications) return [];
  return d.notifications
    .filter((n) => n.user_id === userId)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function markNotificationRead(id: number) {
  const d = load();
  const n = d.notifications?.find((x) => x.id === id);
  if (n) { n.read = true; save(); }
}

export function markAllNotificationsRead(userId: string) {
  const d = load();
  (d.notifications || []).forEach((n) => { if (n.user_id === userId) n.read = true; });
  save();
}

export function getUnreadNotificationsCount(userId: string): number {
  const d = load();
  return (d.notifications || []).filter((n) => n.user_id === userId && !n.read).length;
}

export async function getActionableRequestsCount(userId: string): Promise<number> {
  await delay(40);
  const d = load();
  return d.requests.filter((r) => {
    if (r.sender_id !== userId && r.receiver_id !== userId) return false;
    if (r.journey_stage === 'declined' || r.journey_stage === 'cancelled' || r.journey_stage === 'completed') return false;
    const isSender = r.sender_id === userId;
    const selfPaid = isSender ? r.sender_paid : r.receiver_paid;
    if (r.journey_stage === 'sent') return !isSender;
    if (r.journey_stage === 'accepted') return true;
    if (r.journey_stage === 'seriousness') return !selfPaid;
    if (r.journey_stage === 'sharia_viewing' || r.journey_stage === 'engagement') return true;
    return false;
  }).length;
}

export function deleteNotification(id: number) {
  const d = load();
  if (d.notifications) { d.notifications = d.notifications.filter((n) => n.id !== id); save(); }
}

// ============================================================
//  ===== لوحة الإدارة (محلية بالكامل) =====
//  تقرأ نفس قاعدة بيانات الطلبات المحلية، فيرتبط ما يفعله
//  الأعضاء (قبول/رفض/دفع) مباشرةً بما تراه الإدارة، والعكس.
// ============================================================

// حالات الحساب: نشط / قيد المراجعة / موقوف / مُجمّد مؤقتاً / محظور نهائياً
export type MemberStatus = 'active' | 'pending' | 'suspended' | 'frozen' | 'banned';

interface AdminMemberMeta {
  status: MemberStatus;
  plan: 'free' | 'gold' | 'elite';
  realName: string;
  email: string;
  phone: string;
  nationalId: string;
  password: string;             // كلمة سر الحساب (لعرضها للإدارة)
  joinedAt: string;
  verifiedOverride?: boolean;   // تجاوز إداري لحالة التوثيق
  premiumOverride?: boolean;    // تجاوز إداري للاشتراك المميّز
  adminNote?: string;           // ملاحظة إدارية خاصة
  flagged?: boolean;            // معلّم للمتابعة
  deleted?: boolean;            // محذوف نهائياً (إداري)
  statusReason?: string;        // سبب الحظر/التجميد/الإيقاف
  statusChangedAt?: string;     // وقت آخر تغيير للحالة
  statusChangedBy?: string;     // المشرف الذي غيّر الحالة
}

const ADMIN_META_KEY = 'twafok_admin_meta_v1';

function readAdminMeta(): Record<string, AdminMemberMeta> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(ADMIN_META_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* تجاهل */ }
  return {};
}

function writeAdminMeta(meta: Record<string, AdminMemberMeta>) {
  if (typeof window === 'undefined') return;
  try { window.localStorage.setItem(ADMIN_META_KEY, JSON.stringify(meta)); } catch { /* تجاهل */ }
}

function defaultMeta(m: Member): AdminMemberMeta {
  const plan: AdminMemberMeta['plan'] = m.premium ? (m.hasSeriousnessBadge ? 'elite' : 'gold') : 'free';
  const num = parseInt(m.id.replace(/\D/g, '') || '0', 10);
  const phoneTail = String(1000000 + (num * 13579) % 8999999);
  const pwSeed = String(100000 + (num * 246813) % 899999);
  return {
    status: 'active',
    plan,
    realName: m.nickname,
    email: `${m.id}@twafok.sa`,
    phone: `+9665${phoneTail}`.slice(0, 13),
    nationalId: `10${String(20000000 + (num * 7654321) % 79999999)}`,
    password: `Twafok@${pwSeed}`,
    joinedAt: '2025-01-15',
  };
}

function getMeta(m: Member): AdminMemberMeta {
  const all = readAdminMeta();
  if (!all[m.id]) {
    all[m.id] = defaultMeta(m);
    writeAdminMeta(all);
  }
  return all[m.id];
}

export interface AdminMemberRowLocal {
  id: string;
  nickname: string;
  gender: 'male' | 'female';
  age: number;
  country: string;
  city: string;
  verified: boolean;
  premium: boolean;
  realName: string;
  email: string;
  phone: string;
  nationalId: string;
  password: string;
  status: MemberStatus;
  plan: 'free' | 'gold' | 'elite';
  joinedAt: string;
  requestsCount: number;
  district: string;
  education: string;
  workType: string;
  adminNote: string;
  flagged: boolean;
  statusReason: string;
  statusChangedAt: string;
  statusChangedBy: string;
  isProfileIncomplete?: boolean;
  // ===== حقول الاستيراد =====
  sourceType?: 'registered' | 'imported';
  importBatchId?: string;
  importOfficeName?: string;
  importDate?: string;
  importNotes?: string;
}

export async function adminGetMembers(): Promise<AdminMemberRowLocal[]> {
  await delay(80);
  const d = load();
  return getLiveMembers(true).map((m) => {
    const meta = getMeta(m);
    const requestsCount = d.requests.filter(
      (r) => r.sender_id === m.id || r.receiver_id === m.id,
    ).length;
    const verified = meta.verifiedOverride !== undefined ? meta.verifiedOverride : m.verified;
    const premium = meta.premiumOverride !== undefined ? meta.premiumOverride : m.premium;
    return {
      id: m.id, nickname: m.nickname, gender: m.gender, age: m.age,
      country: m.country, city: m.city, verified, premium,
      realName: meta.realName, email: meta.email, phone: meta.phone,
      nationalId: meta.nationalId, password: meta.password || 'Twafok@000000',
      status: meta.status, plan: meta.plan,
      joinedAt: meta.joinedAt, requestsCount,
      district: m.district, education: m.education, workType: m.workType,
      adminNote: meta.adminNote || '', flagged: !!meta.flagged,
      statusReason: meta.statusReason || '',
      statusChangedAt: meta.statusChangedAt || '',
      statusChangedBy: meta.statusChangedBy || '',
      // حقول الاستيراد
      sourceType: (m as any).sourceType || 'registered',
      importBatchId: (m as any).importBatchId || undefined,
      importOfficeName: (m as any).importOfficeName || undefined,
      importDate: (m as any).importDate || undefined,
      importNotes: (m as any).importNotes || undefined,
      isProfileIncomplete: !!(m as any).isProfileIncomplete,
    };
  }).filter((row) => {
    const all = readAdminMeta();
    return !all[row.id]?.deleted;
  });
}

export async function adminUpdateMember(
  id: string,
  fields: any,
): Promise<boolean> {
  await delay(60);
  const all = readAdminMeta();
  const m = getLiveMemberById(id);
  if (!m) return false;
  if (!all[id]) all[id] = defaultMeta(m);
  if (fields.status) {
    all[id].status = fields.status as MemberStatus;
    all[id].statusChangedAt = new Date().toISOString();
    all[id].statusChangedBy = fields.statusChangedBy || 'الإدارة';
    // مسح السبب عند العودة لحالة نشط
    all[id].statusReason = fields.status === 'active' ? '' : (fields.statusReason ?? all[id].statusReason ?? '');
  }
  if (fields.statusReason !== undefined && !fields.status) all[id].statusReason = fields.statusReason;
  if (fields.plan) all[id].plan = fields.plan as AdminMemberMeta['plan'];
  if (fields.verified !== undefined) all[id].verifiedOverride = fields.verified;
  if (fields.premium !== undefined) all[id].premiumOverride = fields.premium;
  if (fields.adminNote !== undefined) all[id].adminNote = fields.adminNote;
  if (fields.flagged !== undefined) all[id].flagged = fields.flagged;
  writeAdminMeta(all);

  // تحديث كائن العضو الفعلي في saved_members_list في localStorage
  if (typeof window !== 'undefined') {
    try {
      let list: Member[] = [];
      const saved = window.localStorage.getItem('saved_members_list');
      if (saved) {
        list = JSON.parse(saved);
      }
      if (list.length === 0) {
        list = [...MEMBERS];
      }
      const idx = list.findIndex(item => item.id === id);
      if (idx !== -1) {
        const memberObj = list[idx] as any;
        list[idx] = {
          ...memberObj,
          ...fields,
        };
        // التأكيد على مزامنة البيانات المشتركة مع الميتا
        if (fields.status) memberObj.status = fields.status;
        if (fields.plan) memberObj.plan = fields.plan;
        if (fields.verified !== undefined) memberObj.verified = fields.verified;
        if (fields.premium !== undefined) memberObj.premium = fields.premium;
        list[idx] = memberObj;
        
        window.localStorage.setItem('saved_members_list', JSON.stringify(list));
      }
    } catch (e) {
      console.error("Error updating saved_members_list in localStore", e);
    }
  }

  return true;
}

// حذف نهائي حقيقي لعدة أعضاء (لا يبقي السجل)
export async function adminBulkDeleteMembers(ids: string[]): Promise<boolean> {
  await delay(80);
  const all = readAdminMeta();
  ids.forEach((id) => {
    const m = getLiveMemberById(id);
    if (!m) return;
    if (!all[id]) all[id] = defaultMeta(m);
    all[id].deleted = true;
    all[id].status = 'banned';
  });
  writeAdminMeta(all);

  if (typeof window !== 'undefined') {
    try {
      const saved = window.localStorage.getItem('saved_members_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          window.localStorage.setItem('saved_members_list', JSON.stringify(parsed.filter((member: any) => !ids.includes(member.id))));
        }
      }
      const savedAdmin = window.localStorage.getItem('saved_admin_members_list');
      if (savedAdmin) {
        const parsedAdmin = JSON.parse(savedAdmin);
        if (Array.isArray(parsedAdmin)) {
          window.localStorage.setItem('saved_admin_members_list', JSON.stringify(parsedAdmin.filter((member: any) => !ids.includes(member.id))));
        }
      }
    } catch (e) { console.error(e); }
  }
  return true;
}

// تحديث حالة عدة أعضاء دفعة واحدة (حظر/تجميد/تفعيل/توثيق)
export async function adminBulkUpdateStatus(
  ids: string[],
  status: MemberStatus,
  reason = '',
  by = 'الإدارة',
): Promise<boolean> {
  await delay(80);
  const all = readAdminMeta();
  ids.forEach((id) => {
    const m = getLiveMemberById(id);
    if (!m) return;
    if (!all[id]) all[id] = defaultMeta(m);
    all[id].status = status;
    all[id].statusChangedAt = new Date().toISOString();
    all[id].statusChangedBy = by;
    all[id].statusReason = status === 'active' ? '' : reason;
  });
  writeAdminMeta(all);
  return true;
}

// توثيق عدة أعضاء دفعة واحدة
export async function adminBulkSetVerified(ids: string[], value: boolean): Promise<boolean> {
  await delay(80);
  const all = readAdminMeta();
  ids.forEach((id) => {
    const m = getLiveMemberById(id);
    if (!m) return;
    if (!all[id]) all[id] = defaultMeta(m);
    all[id].verifiedOverride = value;
  });
  writeAdminMeta(all);
  return true;
}

export async function adminDeleteMember(id: string): Promise<boolean> {
  await delay(60);
  const all = readAdminMeta();
  const m = getLiveMemberById(id);
  if (!m) return false;
  if (!all[id]) all[id] = defaultMeta(m);
  all[id].deleted = true;
  all[id].status = 'suspended';
  writeAdminMeta(all);

  if (typeof window !== 'undefined') {
    try {
      const saved = window.localStorage.getItem('saved_members_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          window.localStorage.setItem('saved_members_list', JSON.stringify(parsed.filter((member: any) => member.id !== id)));
        }
      }
      const savedAdmin = window.localStorage.getItem('saved_admin_members_list');
      if (savedAdmin) {
        const parsedAdmin = JSON.parse(savedAdmin);
        if (Array.isArray(parsedAdmin)) {
          window.localStorage.setItem('saved_admin_members_list', JSON.stringify(parsedAdmin.filter((member: any) => member.id !== id)));
        }
      }
    } catch (e) { console.error(e); }
  }
  return true;
}

// إعادة تعيين كلمة سر العضو (إداري)
export async function adminResetPassword(id: string): Promise<string | null> {
  await delay(60);
  const all = readAdminMeta();
  const m = getLiveMemberById(id);
  if (!m) return null;
  if (!all[id]) all[id] = defaultMeta(m);
  const newPw = `Twafok@${String(100000 + Math.floor(Math.random() * 899999))}`;
  all[id].password = newPw;
  writeAdminMeta(all);
  return newPw;
}

// إجراءات سريعة على الأعضاء
export async function adminToggleVerified(id: string, value: boolean): Promise<boolean> {
  return adminUpdateMember(id, { verified: value });
}
export async function adminSetPremium(id: string, value: boolean): Promise<boolean> {
  return adminUpdateMember(id, { premium: value, plan: value ? 'gold' : 'free' });
}
export async function adminSetNote(id: string, note: string): Promise<boolean> {
  return adminUpdateMember(id, { adminNote: note });
}
export async function adminToggleFlag(id: string, value: boolean): Promise<boolean> {
  return adminUpdateMember(id, { flagged: value });
}

// إرسال إشعار إداري لعضو
export async function adminSendNotification(memberId: string, text: string, requestId = 0): Promise<boolean> {
  await delay(40);
  const d = load();
  if (!d.notifications) d.notifications = [];
  d.notifications.push({
    id: nextId(), user_id: memberId, request_id: requestId, type: 'admin',
    text: '📢 من الإدارة: ' + text, read: false, created_at: new Date().toISOString(),
  });
  save();
  return true;
}

// حذف طلب اهتمام نهائياً (إداري)
export async function adminDeleteRequest(requestId: number): Promise<boolean> {
  await delay(40);
  const d = load();
  d.requests = d.requests.filter((r) => r.id !== requestId);
  d.events = d.events.filter((e) => e.request_id !== requestId);
  save();
  return true;
}

export async function adminGetRequests(): Promise<LocalRequest[]> {
  await delay(80);
  const d = load();
  return [...d.requests].sort((a, b) => b.created_at.localeCompare(a.created_at));
}

// ===== سجل مدفوعات الرحلة (للوحة الإدارة) =====
export interface RequestPaymentItem {
  label: string;        // وصف الدفعة
  payer: string;        // معرّف الدافع
  amount: number;       // المبلغ بالريال
  at?: string | null;   // وقت الدفع (إن وُجد)
  type: 'deposit' | 'inquiry' | 'final';
}

export interface RequestPaymentsSummary {
  items: RequestPaymentItem[];
  total: number;
}

const DEPOSIT_AMOUNT = 500;
const FINAL_FEE_AMOUNT = 2000;

export async function adminGetRequestPayments(requestId: number): Promise<RequestPaymentsSummary> {
  await delay(40);
  const d = load();
  const req = d.requests.find((r) => r.id === requestId);
  const items: RequestPaymentItem[] = [];
  if (!req) return { items, total: 0 };

  // 1) عربون المنصة (رسوم تنسيق التواصل) — لكل طرف دفع
  if (req.sender_paid) {
    items.push({ label: 'عربون المنصة (المرسِل)', payer: req.sender_id, amount: DEPOSIT_AMOUNT, at: req.sender_paid_at, type: 'deposit' });
  }
  if (req.receiver_paid) {
    items.push({ label: 'عربون المنصة (المستقبِل)', payer: req.receiver_id, amount: DEPOSIT_AMOUNT, at: req.receiver_paid_at, type: 'deposit' });
  }

  // 2) باقات رسائل الاستفسار المرتبطة بهذا الطلب
  d.inquiryPackages
    .filter((p) => p.request_id === requestId)
    .forEach((p) => {
      items.push({ label: `باقة رسائل (${p.credits_total} رسالة)`, payer: p.owner_id, amount: p.price, at: p.created_at, type: 'inquiry' });
    });

  // 3) رسوم السعي النهائية عند إتمام الملكة (مرحلة completed)
  if (req.journey_stage === 'completed' || req.journey_stage === 'engagement') {
    items.push({ label: 'رسوم السعي النهائية', payer: 'الطرفان', amount: FINAL_FEE_AMOUNT, at: req.updated_at, type: 'final' });
  }

  const total = items.reduce((sum, it) => sum + it.amount, 0);
  return { items, total };
}

export interface AdminStatsLocal {
  totalMembers: number;
  males: number;
  females: number;
  verified: number;
  premium: number;
  pendingMembers: number;
  totalRequests: number;
  pendingRequests: number;
  activeJourneys: number;
  completed: number;
  revenue: number;
  depositsPaid: number;
  stageBreakdown: Record<string, number>;
  recentEvents: LocalEvent[];
}

export async function adminGetStats(): Promise<AdminStatsLocal> {
  await delay(80);
  const d = load();
  const members = getLiveMembers(true);
  const meta = readAdminMeta();

  const males = members.filter((m) => m.gender === 'male').length;
  const females = members.filter((m) => m.gender === 'female').length;
  const verified = members.filter((m) => m.verified).length;
  const premium = members.filter((m) => m.premium).length;
  const pendingMembers = members.filter((m) => meta[m.id]?.status === 'pending').length;

  const stageBreakdown: Record<string, number> = {};
  let depositsPaid = 0;
  let inquiryRevenue = 0;
  for (const r of d.requests) {
    stageBreakdown[r.journey_stage] = (stageBreakdown[r.journey_stage] || 0) + 1;
    if (r.sender_paid) depositsPaid += 1;
    if (r.receiver_paid) depositsPaid += 1;
  }
  for (const p of d.inquiryPackages) inquiryRevenue += p.price || 0;

  const pendingRequests = d.requests.filter((r) => r.journey_stage === 'sent').length;
  const activeJourneys = d.requests.filter(
    (r) => !['sent', 'declined', 'cancelled', 'completed'].includes(r.journey_stage),
  ).length;
  const completed = d.requests.filter((r) => r.journey_stage === 'completed').length;

  const revenue = depositsPaid * 500 + inquiryRevenue + completed * 2000;

  const recentEvents = [...d.events]
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .slice(0, 12);

  return {
    totalMembers: members.length, males, females, verified, premium, pendingMembers,
    totalRequests: d.requests.length, pendingRequests, activeJourneys, completed,
    revenue, depositsPaid, stageBreakdown, recentEvents,
  };
}
