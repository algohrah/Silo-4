import { useState, useMemo } from 'react';
import { ShieldCheck, Search, CheckCircle2, XCircle, Clock, FileText, UserCheck, AlertCircle } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { useAdminMembers } from '../../lib/useAdminData';
import FilterDropdown from '../../components/admin/FilterDropdown';
import Modal from '../../components/ui/Modal';

export default function AdminExemptions() {
  const { exemptRequests, adminProcessExemptRequest, showToast, interestRequests, adminMembers } = useApp();
  const { members } = useAdminMembers();
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selected, setSelected] = useState<any | null>(null);

  const enriched = useMemo(() => {
    return exemptRequests.map((ex) => {
      const member = members.find((m) => m.id === ex.userId) || adminMembers.find((m) => m.id === ex.userId);
      const request = interestRequests.find((r: any) => r.id === ex.requestId);
      return { ...ex, member, request };
    });
  }, [exemptRequests, members, interestRequests]);

  const filtered = useMemo(() => {
    return enriched.filter((ex) => {
      const matchSearch =
        !search ||
        ex.userNickname.includes(search) ||
        ex.member?.realName?.includes(search) ||
        ex.reason.includes(search);
      const matchStatus = filterStatus === 'all' || ex.status === filterStatus;
      return matchSearch && matchStatus;
    });
  }, [enriched, search, filterStatus]);

  const stats = {
    total: exemptRequests.length,
    pending: exemptRequests.filter((e) => e.status === 'pending').length,
    approved: exemptRequests.filter((e) => e.status === 'approved').length,
    rejected: exemptRequests.filter((e) => e.status === 'rejected').length,
  };

  const handleAction = (id: string, action: 'approve' | 'reject') => {
    adminProcessExemptRequest(id, action);
    setSelected(null);
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-amber-500" /> طلبات الإعفاء والتسهيلات المالية
        </h2>
        <p className="text-sm text-slate-500 font-tajawal">مراجعة طلبات الإعفاء من رسوم الجدية أو التنسيق</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'إجمالي الطلبات', value: stats.total, icon: FileText, color: 'text-slate-700', bg: 'bg-slate-50' },
          { label: 'معلقة', value: stats.pending, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'مقبولة', value: stats.approved, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'مرفوضة', value: stats.rejected, icon: XCircle, color: 'text-rose-600', bg: 'bg-rose-50' },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className={`${s.bg} rounded-2xl p-3`}>
              <Icon className={`w-5 h-5 ${s.color} mb-1`} />
              <p className={`font-cairo font-extrabold text-2xl ${s.color}`}>{s.value}</p>
              <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالعضو أو سبب الإعفاء..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterDropdown
            label="الحالة:"
            value={filterStatus}
            onChange={(v) => setFilterStatus(v as typeof filterStatus)}
            options={[
              { value: 'all', label: 'كل الحالات' },
              { value: 'pending', label: 'معلقة', count: stats.pending },
              { value: 'approved', label: 'مقبولة', count: stats.approved },
              { value: 'rejected', label: 'مرفوضة', count: stats.rejected },
            ]}
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {['العضو', 'رقم الطلب', 'السبب', 'الحالة', 'إجراء'].map((h) => (
                <th key={h} className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filtered.map((ex) => (
              <tr key={ex.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm ${ex.member?.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
                      {ex.userNickname.charAt(0)}
                    </div>
                    <div>
                      <p className="font-cairo font-bold text-slate-900 text-sm">{ex.userNickname}</p>
                      <p className="text-[11px] text-slate-400 font-tajawal">{ex.member?.realName || '—'}</p>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-3 text-xs text-slate-600 font-mono">{ex.requestId}</td>
                <td className="px-5 py-3 text-xs text-slate-600 font-tajawal max-w-xs truncate">{ex.reason}</td>
                <td className="px-5 py-3">
                  {ex.status === 'pending' && <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-cairo font-bold bg-amber-100 text-amber-700"><Clock className="w-3 h-3" /> معلق</span>}
                  {ex.status === 'approved' && <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-cairo font-bold bg-emerald-100 text-emerald-700"><CheckCircle2 className="w-3 h-3" /> مقبول</span>}
                  {ex.status === 'rejected' && <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-cairo font-bold bg-rose-100 text-rose-700"><XCircle className="w-3 h-3" /> مرفوض</span>}
                </td>
                <td className="px-5 py-3">
                  {ex.status === 'pending' ? (
                    <div className="flex items-center gap-1">
                      <button onClick={() => setSelected(ex)} className="px-3 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-cairo font-bold hover:bg-slate-200">عرض</button>
                      <button onClick={() => handleAction(ex.id, 'approve')} className="px-3 py-2 rounded-xl bg-emerald-100 text-emerald-700 text-xs font-cairo font-bold hover:bg-emerald-200">قبول</button>
                      <button onClick={() => handleAction(ex.id, 'reject')} className="px-3 py-2 rounded-xl bg-rose-100 text-rose-700 text-xs font-cairo font-bold hover:bg-rose-200">رفض</button>
                    </div>
                  ) : (
                    <button onClick={() => setSelected(ex)} className="px-3 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-cairo font-bold hover:bg-slate-200">عرض التفاصيل</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="py-12 text-center">
            <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-slate-400 font-cairo text-sm">لا توجد طلبات إعفاء مطابقة</p>
          </div>
        )}
      </div>

      <Modal open={!!selected} onClose={() => setSelected(null)} title="تفاصيل طلب الإعفاء">
        {selected && (
          <div className="space-y-4 text-right" dir="rtl">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold ${selected.member?.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'}`}>
                {selected.userNickname.charAt(0)}
              </div>
              <div>
                <h3 className="font-cairo font-bold text-slate-900">{selected.userNickname}</h3>
                <p className="text-xs text-slate-500 font-tajawal">{selected.member?.realName || '—'}</p>
              </div>
            </div>
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
              <p className="text-xs text-slate-400 font-cairo mb-1">سبب الإعفاء:</p>
              <p className="text-sm text-slate-800 font-tajawal leading-relaxed">{selected.reason}</p>
            </div>
            {selected.status === 'pending' ? (
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => handleAction(selected.id, 'approve')} className="flex items-center justify-center gap-1.5 py-3 rounded-xl bg-emerald-100 text-emerald-700 font-cairo font-bold text-sm hover:bg-emerald-200">
                  <CheckCircle2 className="w-4 h-4" /> قبول الإعفاء
                </button>
                <button onClick={() => handleAction(selected.id, 'reject')} className="flex items-center justify-center gap-1.5 py-3 rounded-xl bg-rose-100 text-rose-700 font-cairo font-bold text-sm hover:bg-rose-200">
                  <XCircle className="w-4 h-4" /> رفض الطلب
                </button>
              </div>
            ) : (
              <div className={`p-4 rounded-xl text-center ${selected.status === 'approved' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                <p className="font-cairo font-bold text-sm">تم {selected.status === 'approved' ? 'قبول' : 'رفض'} الطلب من قبل الإدارة</p>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
