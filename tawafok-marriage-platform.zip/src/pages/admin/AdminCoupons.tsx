import { useState } from 'react';
import { Tag, Plus, Trash2, Copy, Check, Percent } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import Modal from '../../components/ui/Modal';

interface Coupon {
  id: string;
  code: string;
  discount: number;
  type: 'percent' | 'fixed';
  usageLimit: number;
  usageCount: number;
  expiryDate: string;
  active: boolean;
}

export default function AdminCoupons() {
  const { showToast } = useApp();
  const [coupons, setCoupons] = useState<Coupon[]>([
    { id: 'c1', code: 'WELCOME20', discount: 20, type: 'percent', usageLimit: 100, usageCount: 34, expiryDate: '2026-12-31', active: true },
    { id: 'c2', code: 'GOLD50', discount: 50, type: 'fixed', usageLimit: 50, usageCount: 12, expiryDate: '2026-08-15', active: true },
  ]);
  const [isOpen, setIsOpen] = useState(false);
  const [form, setForm] = useState<Partial<Coupon>>({
    code: '',
    discount: 0,
    type: 'percent',
    usageLimit: 100,
    expiryDate: '',
    active: true,
  });

  const handleSave = () => {
    if (!form.code || !form.discount || !form.expiryDate) return;
    const newCoupon: Coupon = {
      id: 'c' + Date.now(),
      code: form.code,
      discount: form.discount,
      type: form.type as 'percent' | 'fixed',
      usageLimit: form.usageLimit || 100,
      usageCount: 0,
      expiryDate: form.expiryDate,
      active: form.active ?? true,
    };
    setCoupons((prev) => [newCoupon, ...prev]);
    setIsOpen(false);
    setForm({ code: '', discount: 0, type: 'percent', usageLimit: 100, expiryDate: '', active: true });
    showToast('تم إنشاء الكوبون بنجاح', 'success');
  };

  const toggleActive = (id: string) => {
    setCoupons((prev) => prev.map((c) => (c.id === id ? { ...c, active: !c.active } : c)));
  };

  const deleteCoupon = (id: string) => {
    setCoupons((prev) => prev.filter((c) => c.id !== id));
    showToast('تم حذف الكوبون', 'info');
  };

  const inputClass =
    'w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm';
  const labelClass = 'block text-xs font-cairo font-bold text-slate-700 mb-1.5';

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
            <Tag className="w-5 h-5 text-amber-500" /> الكوبونات والعروض
          </h2>
          <p className="text-sm text-slate-500 font-tajawal">إنشاء وإدارة أكواد الخصم والعروض التشجيعية</p>
        </div>
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors"
        >
          <Plus className="w-4 h-4" /> كوبون جديد
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {coupons.map((coupon) => (
          <div
            key={coupon.id}
            className={`bg-white rounded-2xl p-5 shadow-sm border-2 transition-all ${
              coupon.active ? 'border-slate-200' : 'border-slate-100 opacity-70'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600">
                  <Tag className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-cairo font-bold text-slate-900 text-sm">{coupon.code}</h3>
                  <p className="text-[10px] text-slate-400 font-tajawal">
                    {coupon.type === 'percent' ? `خصم ${coupon.discount}%` : `خصم ${coupon.discount} ر.س`}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  navigator.clipboard?.writeText(coupon.code);
                  showToast('تم نسخ الكود', 'success');
                }}
                className="p-2 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-tajawal">الاستخدام</span>
                <span className="font-cairo font-bold text-slate-700">
                  {coupon.usageCount} / {coupon.usageLimit}
                </span>
              </div>
              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${Math.min(100, (coupon.usageCount / coupon.usageLimit) * 100)}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-tajawal">انتهاء الصلاحية</span>
                <span className="font-tajawal text-slate-600">{coupon.expiryDate}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => toggleActive(coupon.id)}
                className={`flex-1 py-2 rounded-xl text-xs font-cairo font-bold ${
                  coupon.active
                    ? 'bg-emerald-100 text-emerald-700'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {coupon.active ? (
                  <span className="flex items-center justify-center gap-1"><Check className="w-3 h-3" /> مفعّل</span>
                ) : (
                  'معطّل'
                )}
              </button>
              <button
                onClick={() => deleteCoupon(coupon.id)}
                className="px-3 py-2 rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Modal open={isOpen} onClose={() => setIsOpen(false)} title="كوبون جديد">
        <div className="space-y-4">
          <div>
            <label className={labelClass}>كود الكوبون</label>
            <input
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
              className={inputClass}
              placeholder="مثال: WELCOME20"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>قيمة الخصم</label>
              <input
                type="number"
                value={form.discount}
                onChange={(e) => setForm({ ...form, discount: Number(e.target.value) })}
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>نوع الخصم</label>
              <select
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value as 'percent' | 'fixed' })}
                className={inputClass}
              >
                <option value="percent">نسبة %</option>
                <option value="fixed">قيمة ثابتة</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={labelClass}>حد الاستخدام</label>
              <input
                type="number"
                value={form.usageLimit}
                onChange={(e) => setForm({ ...form, usageLimit: Number(e.target.value) })}
                className={inputClass}
              />
            </div>
            <div>
              <label className={labelClass}>تاريخ الانتهاء</label>
              <input
                type="date"
                value={form.expiryDate}
                onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                className={inputClass}
                dir="ltr"
              />
            </div>
          </div>
          <button
            onClick={handleSave}
            disabled={!form.code || !form.discount || !form.expiryDate}
            className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Percent className="w-4 h-4" /> إنشاء الكوبون
          </button>
        </div>
      </Modal>
    </div>
  );
}
