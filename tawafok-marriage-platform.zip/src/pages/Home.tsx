import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShieldCheck, Lock, BadgeCheck, Heart, Search, Send,
  Sparkles, ArrowLeft, Star, Quote, Users, TrendingUp, Clock,
  HeartHandshake, CalendarClock, PartyPopper, ChevronLeft, ChevronRight,
  UserPlus, ShieldAlert, Eye, FileCheck,
} from 'lucide-react';
import { ButtonLink } from '../components/ui/Button';
import MemberCard from '../components/MemberCard';
import SectionHeading from '../components/layout/SectionHeading';
import SectionDivider from '../components/ui/SectionDivider';
import CountUp from '../components/ui/CountUp';
import { TESTIMONIALS, STATS } from '../lib/data';
import { useBlogPosts } from '../lib/useContent';
import { useApp } from '../lib/AppContext';

const features = [
  { icon: BadgeCheck, title: 'تحقق كامل من الحسابات', desc: 'كل عضو يخضع لتحقق من الهوية والبيانات لضمان مصداقية المنصة.' },
  { icon: Lock, title: 'خصوصية وحماية البيانات', desc: 'بياناتك الحساسة مشفّرة ومحمية، وتتحكم أنت بمن يراها.' },
  { icon: Search, title: 'بحث متقدم ذكي', desc: 'فلاتر دقيقة حسب العمر، المدينة، الاهتمامات، والمزيد.' },
  { icon: ShieldCheck, title: 'وساطة مهنية للتواصل', desc: 'تتولى الإدارة التواصل بين الطرفين بسرية تامة واحترام كامل.' },
];

const steps = [
  { icon: Users, title: 'أنشئ حسابك', desc: 'سجّل مجانًا وأكمل ملفك الشخصي بخطوات بسيطة.' },
  { icon: Search, title: 'ابحث واكتشف', desc: 'استخدم البحث المتقدم للعثور على من يشاركك القيم.' },
  { icon: Heart, title: 'أرسل طلب اهتمام', desc: 'عبّر عن اهتمامك وستتولى الإدارة التواصل نيابة عنك.' },
  { icon: Sparkles, title: 'ابدأ رحلتك', desc: 'تواصل جاد عبر الإدارة نحو خطوة الزواج.' },
];

const journeyStages = [
  { icon: Send, title: 'مُرسَل', desc: 'تُرسل طلب اهتمامك بسرية عبر الإدارة.', accent: 'text-amber-600 bg-amber-50' },
  { icon: HeartHandshake, title: 'مقبول', desc: 'يقبل الطرف الآخر ويبدأ التعارف الجاد.', accent: 'text-emerald-600 bg-emerald-50' },
  { icon: ShieldCheck, title: 'تأكيد الجدية', desc: 'رسوم المنصة وجهود الإدارة للتنسيق لتأكيد جدية الطرفين.', accent: 'text-amber-700 bg-amber-50' },
  { icon: CalendarClock, title: 'التنسيق', desc: 'الإدارة والوسيطة تنسّق موعد التعارف.', accent: 'text-blue-600 bg-blue-50' },
  { icon: Users, title: 'التعارف', desc: 'تبادل القنوات والنظرة الشرعية بإشراف.', accent: 'text-indigo-600 bg-indigo-50' },
  { icon: PartyPopper, title: 'مكتمل', desc: 'توافق مبارك نحو إتمام الزواج.', accent: 'text-emerald-700 bg-emerald-50' },
];

const securityPoints = [
  { icon: ShieldCheck, text: 'تحقق ثلاثي الخطوات من كل حساب جديد', color: 'text-emerald-400', bg: 'bg-emerald-500/15' },
  { icon: Lock, text: 'تشفير SSL 256-bit لجميع البيانات الحساسة', color: 'text-gold-300', bg: 'bg-gold-500/15' },
  { icon: BadgeCheck, text: 'مراقبة على مدار الساعة للحسابات المزيفة', color: 'text-blue-300', bg: 'bg-blue-500/15' },
];

export default function Home() {
  const { members } = useApp();
  const { posts: blogPosts } = useBlogPosts();

  // ===== تبويب قسم "كيف تعمل المنصة / رحلة الطلب" =====
  const [processTab, setProcessTab] = useState<'overview' | 'journey'>('overview');

  // ===== تبويب قسم الأعضاء =====
  const [membersTab, setMembersTab] = useState<'featured' | 'new' | 'compat'>('featured');

  // ===== Carousel قصص النجاح =====
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  const activeMembersOnly = useMemo(() => {
    return members.filter((m) => !m.status || m.status === 'active');
  }, [members]);

  const featuredMembers = activeMembersOnly.filter((m) => m.premium && !m.isProfileIncomplete).slice(0, 8);
  const newMembers = activeMembersOnly.filter((m) => !m.isProfileIncomplete).slice().reverse().slice(0, 8);
  const compatMembers = [...activeMembersOnly].filter((m) => !m.isProfileIncomplete).sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0)).slice(0, 8);

  const activeMembers = membersTab === 'featured' ? featuredMembers : membersTab === 'new' ? newMembers : compatMembers;

  const nextTestimonial = () => setTestimonialIdx((prev) => (prev + 1) % TESTIMONIALS.length);
  const prevTestimonial = () => setTestimonialIdx((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  const activeTestimonial = TESTIMONIALS[testimonialIdx];

  const featuredPost = blogPosts[0];
  const sidePosts = blogPosts.slice(1, 3);

  return (
    <div>
      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden bg-navy-gradient">
        <div className="absolute inset-0 pattern-islamic opacity-50" />
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-gold-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '4s' }} />
        <div className="absolute -bottom-32 -right-32 w-[28rem] h-[28rem] bg-rose-deep/10 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-8 lg:pt-20 lg:pb-12">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* النص */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="text-center lg:text-right flex flex-col items-center lg:items-start"
            >
              <span className="badge-shimmer inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold-500/15 border border-gold-500/30 text-gold-300 text-sm font-cairo font-semibold mb-5">
                <Sparkles className="w-4 h-4" />
                منصة الزواج العربية الأولى
              </span>

              <h1 className="font-cairo font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white leading-[1.15] text-shadow-gold">
                ابدأ رحلة العمر مع
                <span className="block text-gradient-gold mt-2">شريك الحياة المناسب</span>
              </h1>

              <p className="mt-5 text-lg text-cream-200/80 font-tajawal leading-relaxed max-w-2xl lg:max-w-lg">
                توافق يربطك بأشخاص موثوقين يشاركونك القيم والطموح، في بيئة آمنة تحترم خصوصيتك وتساعدك على بناء علاقة جادة نحو الزواج.
              </p>

              <div className="mt-7 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
                <ButtonLink to="/register" size="lg" className="shadow-gold">
                  <Heart className="w-5 h-5" />
                  ابدأ مجانًا الآن
                </ButtonLink>
                <ButtonLink to="/search" variant="outline" size="lg" className="!border-gold-400/50 !text-gold-300 hover:!bg-gold-500/10">
                  <Search className="w-5 h-5" />
                  تصفّح الأعضاء
                </ButtonLink>
              </div>

              {/* مؤشرات الثقة */}
              <div className="mt-7 flex flex-wrap items-center justify-center lg:justify-start gap-x-6 gap-y-2 text-sm text-cream-200/70 font-tajawal">
                <span className="flex items-center gap-1.5"><BadgeCheck className="w-4 h-4 text-emerald-400" /> حسابات موثّقة</span>
                <span className="flex items-center gap-1.5"><Lock className="w-4 h-4 text-gold-300" /> خصوصية تامة</span>
                <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-blue-300" /> وساطة مهنية</span>
              </div>
            </motion.div>

            {/* العنصر البصري الجانبي */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:flex justify-center items-center relative"
            >
              <div className="relative w-full max-w-md aspect-square">
                {/* دوائر زخرفية متحرّكة */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-0 rounded-full border-2 border-dashed border-gold-500/20"
                />
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-8 rounded-full border border-gold-500/15"
                />

                {/* البطاقة المركزية */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-64 h-64 rounded-[2.5rem] bg-gradient-to-br from-navy-800/80 to-navy-950/80 backdrop-blur-sm border border-gold-500/30 shadow-luxe glow-gold flex flex-col items-center justify-center p-8 text-center">
                    <div className="w-20 h-20 rounded-full bg-gold-gradient flex items-center justify-center mb-4 shadow-gold">
                      <Heart className="w-10 h-10 text-navy-900 fill-navy-900" />
                    </div>
                    <p className="font-cairo font-bold text-white text-lg">توافق مبارك</p>
                    <p className="text-cream-200/60 text-sm font-tajawal mt-1">ابدأ قصتك اليوم</p>

                    {/* قلوب متساقطة */}
                    {[...Array(5)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute text-gold-300/30"
                        initial={{ y: -20, opacity: 0 }}
                        animate={{ y: 200, opacity: [0, 1, 0] }}
                        transition={{ duration: 3, repeat: Infinity, delay: i * 0.6, ease: 'easeOut' }}
                        style={{ left: `${15 + i * 18}%`, top: '0%' }}
                      >
                        <Heart className="w-4 h-4 fill-current" />
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* بطاقات عائمة حول الدائرة */}
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                  className="absolute top-4 right-4 glass-navy rounded-2xl p-3 border border-gold-500/30 flex items-center gap-2"
                >
                  <ShieldCheck className="w-6 h-6 text-emerald-400" />
                  <span className="text-white text-xs font-cairo font-bold">موثوق 100%</span>
                </motion.div>

                <motion.div
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                  className="absolute bottom-8 left-0 glass-navy rounded-2xl p-3 border border-gold-500/30 flex items-center gap-2"
                >
                  <Users className="w-6 h-6 text-gold-300" />
                  <span className="text-white text-xs font-cairo font-bold">+150 ألف عضو</span>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* شريط الإحصائيات — مع عدّاد متحرّك */}
        <div className="relative border-t border-gold-500/15 bg-navy-950/30 backdrop-blur-sm">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
            {STATS.map((s, i) => {
              const isNumeric = /^[\d,]+$/.test(s.value.replace(/[+%\sألف]/g, '').trim());
              const numeric = isNumeric ? parseInt(s.value.replace(/[^0-9]/g, '')) : 0;
              const prefix = s.value.includes('+') ? '+' : '';
              const suffix = s.value.replace(/[0-9+\s]/g, '').trim() || '';
              return (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="text-center"
                >
                  <div className="font-cairo font-extrabold text-2xl sm:text-3xl text-gradient-gold">
                    {numeric > 0 ? <CountUp end={numeric} prefix={prefix} suffix={` ${suffix}`} /> : s.value}
                  </div>
                  <div className="text-xs sm:text-sm text-cream-200/70 font-tajawal mt-1">{s.label}</div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <SectionDivider />

      {/* ===== FEATURES ===== */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="لماذا توافق؟"
            title={<>منصة تُبنى على <span className="text-gradient-gold">الثقة والأمان</span></>}
            subtitle="نحن نلتزم بأعلى معايير الأمان والخصوصية لنمنحك تجربة مريحة وموثوقة في رحلتك نحو شريك الحياة."
          />

          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="relative bg-white rounded-3xl p-6 shadow-soft hover:shadow-luxe transition-all duration-500 border border-cream-200/60 text-center group overflow-hidden"
              >
                {/* رقم زخرفي خلفي */}
                <span className="bg-number">{i + 1}</span>

                <div className="relative w-16 h-16 rounded-full bg-gold-300/15 flex items-center justify-center mx-auto mb-4 transition-all duration-500 group-hover:scale-110 group-hover:bg-gold-gradient">
                  <f.icon className="w-8 h-8 text-gold-600 transition-colors duration-500 group-hover:text-navy-900" />
                </div>
                <h3 className="font-cairo font-bold text-navy-900 text-lg mb-2 relative">{f.title}</h3>
                <p className="text-sm text-navy-600 font-tajawal leading-relaxed relative">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== PROCESS: كيف تعمل المنصة + رحلة الطلب (تبويب موحّد) ===== */}
      <section className="py-16 lg:py-24 bg-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="كيف تعمل المنصة؟"
            title={<>مسار واضح <span className="text-gradient-gold">من الطلب حتى الزواج</span></>}
            subtitle="رحلة منظّمة وآمنة بإشراف الإدارة والوسيطة الشرعية، تنتقل فيها خطوة بخطوة بكل وضوح."
          />

          {/* تبويب التبديل */}
          <div className="mt-10 flex justify-center">
            <div className="inline-flex bg-white rounded-2xl p-1.5 shadow-soft border border-cream-200/60">
              <button
                onClick={() => setProcessTab('overview')}
                className={`px-5 sm:px-8 py-2.5 rounded-xl font-cairo font-bold text-sm transition-all duration-300 ${
                  processTab === 'overview' ? 'bg-gold-gradient text-navy-900 shadow-gold' : 'text-navy-500 hover:text-navy-700'
                }`}
              >
                نظرة عامة سريعة
              </button>
              <button
                onClick={() => setProcessTab('journey')}
                className={`px-5 sm:px-8 py-2.5 rounded-xl font-cairo font-bold text-sm transition-all duration-300 ${
                  processTab === 'journey' ? 'bg-gold-gradient text-navy-900 shadow-gold' : 'text-navy-500 hover:text-navy-700'
                }`}
              >
                رحلة الطلب التفصيلية
              </button>
            </div>
          </div>

          {/* محتوى التبويب */}
          <AnimatePresence mode="wait">
            {processTab === 'overview' ? (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
                className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-6 relative"
              >
              {steps.map((step, i) => (
                <motion.div
                  key={step.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="relative text-center"
                >
                  <div className="relative inline-block mb-5">
                    <div className="w-20 h-20 rounded-full bg-gold-gradient flex items-center justify-center shadow-gold">
                      <step.icon className="w-9 h-9 text-navy-900" />
                    </div>
                    <span className="absolute -top-1 -right-1 w-7 h-7 rounded-full bg-navy-900 text-gold-300 font-cairo font-bold text-sm flex items-center justify-center ring-4 ring-cream-50">
                      {i + 1}
                    </span>
                  </div>
                  <h3 className="font-cairo font-bold text-navy-900 text-lg mb-2">{step.title}</h3>
                  <p className="text-sm text-navy-600 font-tajawal leading-relaxed">{step.desc}</p>
                </motion.div>
              ))}
              </motion.div>
            ) : (
              <motion.div
                key="journey"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
                className="mt-12"
              >
                {/* Timeline متّصل */}
                <div className="relative">
                  {/* الخط الرابط للأفقية (شاشات كبيرة) */}
                  <div className="hidden lg:block absolute top-10 right-[8.33%] left-[8.33%] h-0.5 bg-gradient-to-l from-gold-500/30 via-gold-500/50 to-gold-500/30" />

                  <div className="grid grid-cols-2 lg:grid-cols-6 gap-6">
                    {journeyStages.map((stage, i) => (
                      <motion.div
                        key={stage.title}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.08 }}
                        className="relative flex flex-col items-center text-center"
                      >
                        {/* النقطة على الخط */}
                        <div className="relative z-10 w-20 h-20 rounded-full bg-white border-2 border-gold-500/40 flex items-center justify-center shadow-soft mb-4">
                          <div className={`w-12 h-12 rounded-xl ${stage.accent} flex items-center justify-center`}>
                            <stage.icon className="w-6 h-6" />
                          </div>
                          <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-navy-900 text-gold-300 font-cairo font-bold text-xs flex items-center justify-center">
                            {i + 1}
                          </span>
                        </div>
                        <h3 className="font-cairo font-bold text-navy-900 text-sm mb-1">{stage.title}</h3>
                        <p className="text-xs text-navy-500 font-tajawal leading-relaxed max-w-[140px]">{stage.desc}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="mt-12 text-center">
            <ButtonLink to="/search" variant="outline">
              ابدأ رحلتك الآن <ArrowLeft className="w-4 h-4" />
            </ButtonLink>
          </div>
        </div>
      </section>

      {/* ===== MEMBERS (مدمج: مميزون + جدد + أعلى توافق) ===== */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="أعضاء موثوقون"
            title={<>تعرّف على <span className="text-gradient-gold">أعضاء يبحثون عن شريك</span></>}
            subtitle="تصفّح ملفات لأعضاء موثقين يبحثون عن علاقة جادة."
          />

          {/* تبويب الأعضاء */}
          <div className="mt-8 flex justify-center">
            <div className="inline-flex bg-cream-100 rounded-2xl p-1.5 border border-cream-200/60">
              {[
                { key: 'featured', label: 'مميزون' },
                { key: 'new', label: 'جدد' },
                { key: 'compat', label: 'الأعلى توافقاً' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setMembersTab(tab.key as typeof membersTab)}
                  className={`px-5 sm:px-7 py-2.5 rounded-xl font-cairo font-bold text-sm transition-all duration-300 ${
                    membersTab === tab.key ? 'bg-white text-gold-700 shadow-soft' : 'text-navy-500 hover:text-navy-700'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* شبكة الأعضاء */}
          <AnimatePresence mode="wait">
            <motion.div
              key={membersTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="mt-10 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5"
            >
              {activeMembers.slice(0, 7).map((m) => (
                <MemberCard key={m.id} member={m} />
              ))}

              {/* بطاقة "انضم إليهم" */}
              <Link
                to="/register"
                className="group rounded-2xl border-2 border-dashed border-gold-400/50 hover:border-gold-500 bg-gold-300/5 hover:bg-gold-300/10 transition-all duration-500 flex flex-col items-center justify-center p-6 min-h-[280px] text-center"
              >
                <div className="w-16 h-16 rounded-full bg-gold-gradient flex items-center justify-center mb-4 shadow-gold group-hover:scale-110 transition-transform duration-500">
                  <UserPlus className="w-8 h-8 text-navy-900" />
                </div>
                <h3 className="font-cairo font-bold text-navy-900 text-base mb-1">انضم إليهم الآن</h3>
                <p className="text-xs text-navy-500 font-tajawal">ابدأ رحلتك نحو شريك الحياة</p>
              </Link>
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* ===== SECURITY HIGHLIGHT ===== */}
      <section className="py-16 lg:py-24 bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-islamic opacity-30" />
        <div className="absolute top-0 right-0 w-72 h-72 bg-gold-500/10 rounded-full blur-3xl" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading
                center={false}
                light
                eyebrow="الأمان أولاً"
                title={<>خصوصيتك <span className="text-gradient-gold">أمانة لدينا</span></>}
                subtitle="نستخدم أحدث تقنيات التشفير والتحقق لحماية بياناتك ومنحك تجربة آمنة تمامًا."
              />
              <div className="mt-8 grid sm:grid-cols-3 gap-4">
                {securityPoints.map((item, i) => (
                  <motion.div
                    key={item.text}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.15 }}
                    className="glass-navy rounded-2xl p-4 border border-gold-500/20 flex flex-col items-center text-center gap-3"
                  >
                    <div className={`w-12 h-12 rounded-xl ${item.bg} flex items-center justify-center flex-shrink-0`}>
                      <item.icon className={`w-6 h-6 ${item.color}`} />
                    </div>
                    <p className="text-cream-200/90 font-tajawal text-sm leading-relaxed">{item.text}</p>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* عنصر بصري: بطاقة شهادة موثوقية */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative flex justify-center"
            >
              <div className="relative w-full max-w-sm">
                {/* هالة خلفية */}
                <div className="absolute inset-0 bg-gold-500/10 rounded-[2.5rem] blur-2xl" />

                <div className="relative glass-navy rounded-[2.5rem] p-8 border border-gold-500/30 shadow-luxe text-center">
                  {/* أيقونة الدرع الكبيرة */}
                  <div className="relative inline-flex mb-6">
                    <motion.div
                      animate={{ scale: [1, 1.05, 1] }}
                      transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                      className="w-24 h-24 rounded-full bg-gold-gradient flex items-center justify-center shadow-gold"
                    >
                      <ShieldCheck className="w-12 h-12 text-navy-900" />
                    </motion.div>
                    {/* دوائر متحرّكة */}
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                      className="absolute inset-0 -m-3 rounded-full border border-dashed border-gold-500/30"
                    />
                  </div>

                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 mb-4">
                    <BadgeCheck className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-300 font-cairo font-bold text-sm">معتمد وموثوق</span>
                  </div>

                  <h3 className="font-cairo font-bold text-white text-xl mb-2">حماية بمعايير عالمية</h3>
                  <p className="text-cream-200/70 font-tajawal text-sm leading-relaxed mb-6">
                    ملتزمون بنظام حماية البيانات السعودي وأعلى معايير الأمان الرقمي لحماية معلوماتك الشخصية.
                  </p>

                  {/* شارات التحقق */}
                  <div className="flex items-center justify-center gap-4 flex-wrap">
                    {[
                      { icon: FileCheck, label: 'SSL مشفّر' },
                      { icon: Eye, label: 'مراقبة 24/7' },
                      { icon: Lock, label: 'بيانات محمية' },
                    ].map((badge) => (
                      <div key={badge.label} className="flex items-center gap-1.5 text-cream-200/60">
                        <badge.icon className="w-4 h-4 text-gold-300" />
                        <span className="text-xs font-tajawal">{badge.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ===== TESTIMONIALS (Carousel) ===== */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="قصص نجاح"
            title={<>قصص حب بدأت <span className="text-gradient-gold">من توافق</span></>}
            subtitle="آلاف القصص السعيدة بدأت هنا. كن أنت القصة القادمة."
          />

          <div className="mt-14 max-w-3xl mx-auto">
            <div className="relative bg-white rounded-3xl p-8 sm:p-12 shadow-luxe border border-cream-200/60 overflow-hidden">
              {/* علامة اقتباس كبيرة مزخرفة */}
              <Quote className="w-24 h-24 text-gold-300/20 absolute -top-4 -left-4" />

              <AnimatePresence mode="wait">
                <motion.div
                  key={testimonialIdx}
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.4 }}
                  className="relative z-10"
                >
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, idx) => (
                      <Star key={idx} className="w-5 h-5 fill-gold-500 text-gold-500" />
                    ))}
                  </div>

                  <p className="text-navy-700 font-tajawal text-lg leading-relaxed mb-8">
                    {activeTestimonial.story}
                  </p>

                  <div className="flex items-center gap-4 pt-6 border-t border-cream-200">
                    <div className="w-14 h-14 rounded-full bg-gold-gradient flex items-center justify-center text-navy-900 font-cairo font-bold text-xl">
                      {activeTestimonial.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-cairo font-bold text-navy-900 text-lg">{activeTestimonial.name}</div>
                      <div className="text-sm text-navy-500 font-tajawal">{activeTestimonial.city} · {activeTestimonial.duration}</div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* أزرار التنقّل */}
              <div className="flex items-center justify-between mt-8">
                <button
                  onClick={prevTestimonial}
                  className="w-11 h-11 rounded-full bg-cream-100 hover:bg-gold-300/20 flex items-center justify-center transition-all duration-300 group"
                  aria-label="السابق"
                >
                  <ChevronRight className="w-5 h-5 text-navy-600 group-hover:text-gold-700" />
                </button>

                {/* نقاط مؤشّرة */}
                <div className="flex items-center gap-2">
                  {TESTIMONIALS.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTestimonialIdx(idx)}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        idx === testimonialIdx ? 'w-8 bg-gold-gradient' : 'w-2 bg-cream-300 hover:bg-gold-300'
                      }`}
                      aria-label={`قصة ${idx + 1}`}
                    />
                  ))}
                </div>

                <button
                  onClick={nextTestimonial}
                  className="w-11 h-11 rounded-full bg-cream-100 hover:bg-gold-300/20 flex items-center justify-center transition-all duration-300 group"
                  aria-label="التالي"
                >
                  <ChevronLeft className="w-5 h-5 text-navy-600 group-hover:text-gold-700" />
                </button>
              </div>
            </div>

            {/* عدّاد القصص */}
            <div className="text-center mt-4 text-sm text-navy-400 font-tajawal">
              قصة {testimonialIdx + 1} من {TESTIMONIALS.length}
            </div>
          </div>
        </div>
      </section>

      {/* ===== BLOG PREVIEW (مقال مميز + مقالات جانبية) ===== */}
      <section className="py-16 lg:py-24 bg-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-12">
            <SectionHeading
              center={false}
              eyebrow="المدونة"
              title={<>نصائح لزواج <span className="text-gradient-gold">سعيد وناجح</span></>}
            />
            <Link to="/blog" className="hidden sm:flex items-center gap-2 text-gold-700 font-cairo font-bold hover:gap-3 transition-all">
              كل المقالات <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>

          {featuredPost && (
            <div className="grid lg:grid-cols-2 gap-6">
              {/* المقال المميز */}
              <Link
                to={`/blog/${featuredPost.id}`}
                className="group relative bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-luxe transition-all duration-500 border border-cream-200/60 lg:row-span-2"
              >
                <div className="aspect-[16/10] lg:aspect-[16/13] overflow-hidden relative">
                  <img src={featuredPost.image} alt={featuredPost.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-950/60 via-transparent to-transparent" />
                  <div className="absolute bottom-0 right-0 left-0 p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="px-3 py-1 rounded-full bg-gold-gradient text-navy-900 text-xs font-cairo font-bold">{featuredPost.category}</span>
                      <span className="flex items-center gap-1 text-white/80 text-xs font-tajawal"><Clock className="w-3 h-3" />{featuredPost.read_time}</span>
                    </div>
                    <h3 className="font-cairo font-bold text-white text-xl sm:text-2xl leading-snug group-hover:text-gold-300 transition-colors">
                      {featuredPost.title}
                    </h3>
                  </div>
                </div>
              </Link>

              {/* المقالات الجانبية */}
              {sidePosts.map((post) => (
                <Link
                  key={post.id}
                  to={`/blog/${post.id}`}
                  className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-luxe transition-all duration-500 border border-cream-200/60 flex flex-col sm:flex-row"
                >
                  <div className="sm:w-2/5 aspect-[16/10] sm:aspect-auto overflow-hidden">
                    <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  </div>
                  <div className="p-5 flex-1 flex flex-col justify-center">
                    <div className="flex items-center gap-2 text-xs text-gold-600 font-cairo font-bold mb-2">
                      <span className="px-2.5 py-1 rounded-full bg-gold-300/15">{post.category}</span>
                      <span className="flex items-center gap-1 text-navy-400"><Clock className="w-3 h-3" />{post.read_time}</span>
                    </div>
                    <h3 className="font-cairo font-bold text-navy-900 text-base sm:text-lg leading-snug mb-2 group-hover:text-gold-700 transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-sm text-navy-600 font-tajawal line-clamp-2">{post.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <ButtonLink to="/blog" variant="outline">
              كل المقالات <ArrowLeft className="w-4 h-4" />
            </ButtonLink>
          </div>
        </div>
      </section>

      {/* ===== CTA (خلفية ذهبية مميّزة) ===== */}
      <section className="py-16 lg:py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative wave-bg rounded-[2.5rem] overflow-hidden p-10 lg:p-16 text-center shadow-luxe">
            {/* زخارف خلفية */}
            <div className="absolute inset-0 pattern-islamic opacity-20" />
            <div className="absolute -top-20 -right-20 w-72 h-72 bg-white/15 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-navy-900/10 rounded-full blur-3xl" />

            {/* قلوب متساقطة */}
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-navy-900/10"
                initial={{ y: -30, opacity: 0 }}
                animate={{ y: 400, opacity: [0, 0.5, 0] }}
                transition={{ duration: 4, repeat: Infinity, delay: i * 0.7, ease: 'easeOut' }}
                style={{ left: `${10 + i * 15}%`, top: '0%' }}
              >
                <Heart className="w-5 h-5 fill-current" />
              </motion.div>
            ))}

            <div className="relative">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-navy-900 mb-6 shadow-luxe"
              >
                <Heart className="w-8 h-8 text-gold-300 fill-gold-300" />
              </motion.div>

              <h2 className="font-cairo font-extrabold text-3xl sm:text-4xl lg:text-5xl text-navy-900 leading-tight">
                قلبك ينتظر شريكه...
              </h2>
              <p className="mt-4 text-lg text-navy-800/80 font-tajawal max-w-xl mx-auto">
                انضم اليوم وابدأ رحلتك نحو شريك الحياة في بيئة آمنة وموثوقة.
              </p>

              <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
                <ButtonLink to="/register" variant="navy" size="lg" className="shadow-luxe">
                  <Heart className="w-5 h-5" /> أنشئ حسابك مجانًا
                </ButtonLink>
                <ButtonLink to="/plans" variant="outline" size="lg" className="!border-navy-900/30 !text-navy-900 hover:!bg-navy-900/10">
                  <TrendingUp className="w-5 h-5" /> اكتشف الباقات
                </ButtonLink>
              </div>

              {/* عنصر ثقة إضافي */}
              <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-navy-800/70 font-tajawal">
                <span className="flex items-center gap-1.5"><BadgeCheck className="w-4 h-4" /> بدون بطاقة ائتمان</span>
                <span className="flex items-center gap-1.5"><Users className="w-4 h-4" /> +150 ألف عضو يثقون بنا</span>
                <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4" /> بيئة آمنة وموثوقة</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
