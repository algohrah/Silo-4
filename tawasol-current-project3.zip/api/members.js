import supabase from './db-client.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function toDb(m = {}) {
  return {
    id: m.id ? String(m.id) : `m${Date.now()}`,
    nickname: m.nickname || m.realName || m.real_name || m.name || 'عضو جديد',
    username: m.username || '',
    gender: m.gender || '',
    age: Number(m.age) || 0,
    country: m.country || '',
    city: m.city || '',
    district: m.district || '',
    nationality: m.nationality || '',
    sect: m.sect || '',
    marital_status: m.maritalStatus || m.marital_status || 'single',
    marital_label: m.maritalLabel || m.marital_label || '',
    has_children: !!(m.hasChildren ?? m.has_children),
    children_count: m.childrenCount || m.children_count || '',
    height: Number(m.height) || 0,
    weight: Number(m.weight) || 0,
    skin_color: m.skinColor || m.skin_color || '',
    health: m.health || '',
    smoking: m.smoking || '',
    ethnicity: m.ethnicity || '',
    education: m.education || '',
    work_type: m.workType || m.work_type || '',
    job_title: m.jobTitle || m.job_title || '',
    housing: m.housing || '',
    bio: m.bio || '',
    about_partner: m.aboutPartner || m.about_partner || m.pNotes || m.p_notes || m.partner_notes || '',
    verified: !!m.verified,
    premium: !!m.premium,
    online: !!m.online,
    last_active: m.lastActive || m.last_active || new Date().toISOString(),
    match_score: Number(m.matchScore ?? m.match_score) || 90,
    has_seriousness_badge: !!(m.hasSeriousnessBadge ?? m.has_seriousness_badge),
    plan: m.plan || 'free',
    pinned: !!m.pinned,
    status: m.status || 'active',
    status_reason: m.statusReason || m.status_reason || '',
    status_by: m.statusBy || m.status_by || '',
    notes: m.adminNote || m.notes || '',
    flagged: !!m.flagged,
    source_type: m.sourceType || m.source_type || 'registered',
    import_batch_id: m.importBatchId || m.import_batch_id || '',
    import_office_name: m.importOfficeName || m.import_office_name || '',
    import_date: m.importDate || m.import_date || '',
    import_notes: m.importNotes || m.import_notes || '',
    real_name: m.realName || m.real_name || m.nickname || '',
    email: m.email || '',
    phone: m.phone || '',
    whatsapp: m.whatsapp || '',
    password: m.password || '',
    birth_date: m.birthDate || m.birth_date || '',
    is_profile_incomplete: !!(m.isProfileIncomplete ?? m.is_profile_incomplete),
    updated_at: new Date().toISOString(),
  };
}

function toDbPartial(fields = {}) {
  const mapping = {
    nickname: 'nickname', realName: 'real_name', real_name: 'real_name', username: 'username', gender: 'gender', age: 'age',
    country: 'country', city: 'city', district: 'district', nationality: 'nationality', sect: 'sect',
    maritalStatus: 'marital_status', marital_status: 'marital_status', maritalLabel: 'marital_label', marital_label: 'marital_label',
    hasChildren: 'has_children', has_children: 'has_children', childrenCount: 'children_count', children_count: 'children_count',
    height: 'height', weight: 'weight', skinColor: 'skin_color', skin_color: 'skin_color', health: 'health', smoking: 'smoking', ethnicity: 'ethnicity',
    education: 'education', workType: 'work_type', work_type: 'work_type', jobTitle: 'job_title', job_title: 'job_title', housing: 'housing',
    bio: 'bio', aboutPartner: 'about_partner', about_partner: 'about_partner', pNotes: 'about_partner', p_notes: 'about_partner', partner_notes: 'about_partner',
    verified: 'verified', premium: 'premium', online: 'online', lastActive: 'last_active', last_active: 'last_active',
    matchScore: 'match_score', match_score: 'match_score', hasSeriousnessBadge: 'has_seriousness_badge', has_seriousness_badge: 'has_seriousness_badge',
    plan: 'plan', pinned: 'pinned', status: 'status', statusReason: 'status_reason', status_reason: 'status_reason', statusBy: 'status_by', status_by: 'status_by',
    adminNote: 'notes', notes: 'notes', flagged: 'flagged', sourceType: 'source_type', source_type: 'source_type',
    importBatchId: 'import_batch_id', import_batch_id: 'import_batch_id', importOfficeName: 'import_office_name', import_office_name: 'import_office_name',
    importDate: 'import_date', import_date: 'import_date', importNotes: 'import_notes', import_notes: 'import_notes',
    email: 'email', phone: 'phone', whatsapp: 'whatsapp', password: 'password', birthDate: 'birth_date', birth_date: 'birth_date',
    isProfileIncomplete: 'is_profile_incomplete', is_profile_incomplete: 'is_profile_incomplete', details: 'details',
  };
  const out = {};
  for (const [key, value] of Object.entries(fields)) {
    if (key === 'id' || value === undefined) continue;
    const dbKey = mapping[key] || key;
    if (['age', 'height', 'weight', 'match_score'].includes(dbKey)) out[dbKey] = Number(value) || 0;
    else if (['has_children', 'verified', 'premium', 'online', 'has_seriousness_badge', 'pinned', 'flagged', 'is_profile_incomplete'].includes(dbKey)) out[dbKey] = !!value;
    else out[dbKey] = value;
  }
  out.updated_at = new Date().toISOString();
  return out;
}

function compact(obj) {
  return Object.fromEntries(Object.entries(obj).filter(([, value]) => value !== undefined));
}

function fromDb(r) {
  if (!r) return r;
  return {
    ...r,
    id: String(r.id),
    nickname: r.nickname || r.real_name || r.id,
    username: r.username || '',
    gender: r.gender || '',
    age: Number(r.age) || 0,
    birthDate: r.birth_date || '',
    country: r.country || '',
    city: r.city || '',
    district: r.district || '',
    nationality: r.nationality || '',
    sect: r.sect || '',
    maritalStatus: r.marital_status || 'single',
    maritalLabel: r.marital_label || '',
    hasChildren: !!r.has_children,
    childrenCount: r.children_count || '',
    skinColor: r.skin_color || '',
    workType: r.work_type || '',
    jobTitle: r.job_title || '',
    aboutPartner: r.about_partner || '',
    lastActive: r.last_active || '',
    matchScore: Number(r.match_score) || 90,
    hasSeriousnessBadge: !!r.has_seriousness_badge,
    statusReason: r.status_reason || '',
    statusBy: r.status_by || '',
    adminNote: r.notes || '',
    sourceType: r.source_type || 'registered',
    importBatchId: r.import_batch_id || '',
    importOfficeName: r.import_office_name || '',
    importDate: r.import_date || '',
    importNotes: r.import_notes || '',
    realName: r.real_name || '',
    birthDate: r.birth_date || '',
    isProfileIncomplete: !!r.is_profile_incomplete,
  };
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, admin, limit } = req.query;
      let query = supabase.from('members').select('*');
      if (id) query = query.eq('id', String(id)).maybeSingle();
      else {
        if (!admin) query = query.in('status', ['active', 'pending']);
        query = query.order('pinned', { ascending: false }).order('created_at', { ascending: false });
        if (limit) query = query.limit(Number(limit));
      }
      const { data, error } = await query;
      if (error) throw error;
      if (id) return res.status(200).json(fromDb(data));
      return res.status(200).json((data || []).map(fromDb));
    }

    if (req.method === 'POST') {
      const payload = compact(toDb(req.body || {}));
      const { data, error } = await supabase.from('members').upsert(payload).select().single();
      if (error) throw error;
      return res.status(201).json(fromDb(data));
    }

    if (req.method === 'PUT') {
      const { id, ...fields } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const payload = compact(toDbPartial(fields));
      const { data, error } = await supabase.from('members').update(payload).eq('id', String(id)).select().single();
      if (error) throw error;
      return res.status(200).json(fromDb(data));
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('members').delete().eq('id', String(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Members API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
