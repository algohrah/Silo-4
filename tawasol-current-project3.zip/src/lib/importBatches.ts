import { dataService } from './data/DataService';
// ====================================================================
//  نظام الخطابات والدفعات — إدارة أسماء الخطابات وعمليات الاستيراد
//  جميع البيانات تُخزن في localStorage
// ====================================================================

// ===== أنواع البيانات =====

export interface ImportOffice {
  id: string;
  name: string;           // اسم الخطابة أو المكتب
  createdAt: string;      // تاريخ الإنشاء
  usageCount: number;     // عدد مرات الاستخدام
  lastUsedAt?: string;    // آخر استخدام
  notes?: string;         // ملاحظات
}

export interface ImportBatch {
  id: string;
  batchNumber: string;    // رقم الدفعة (مثال: IMP-001)
  officeId?: string;      // معرف الخطابة (اختياري)
  officeName?: string;    // اسم الخطابة (للعرض)
  importDate: string;     // تاريخ الاستيراد
  membersCount: number;   // عدد الأعضاء المستوردين
  duplicatesCount: number;// عدد المكررات
  skippedCount: number;   // عدد السجلات المتجاهلة
  errorsCount: number;    // عدد الأخطاء
  notes?: string;         // ملاحظات الاستيراد
  sourceType: 'csv' | 'paste' | 'api';  // طريقة الاستيراد
  createdAt: string;
}

export interface ImportReport {
  batchId: string;
  totalRows: number;      // إجمالي الصفوف في الملف
  importedCount: number;  // تم استيرادهم
  duplicatesCount: number;// مكررات
  skippedCount: number;   // متجاهلة
  errorsCount: number;    // أخطاء
  errors: ImportError[];  // تفاصيل الأخطاء
  warnings: ImportWarning[]; // التحذيرات
  officeName?: string;
  batchNumber?: string;
  importDate?: string;
}

export interface ImportError {
  row: number;            // رقم الصف
  field?: string;         // الحقل المشكل
  message: string;        // رسالة الخطأ
  value?: any;            // القيمة المشكلة
}

export interface ImportWarning {
  row: number;
  field?: string;
  message: string;
}

// ===== ثوابت =====

const STORAGE_KEYS = {
  offices: 'import_offices_list',
  batches: 'import_batches_list',
};

// ===== دوال الخطابات =====

export function getImportOffices(): ImportOffice[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = dataService.db.settings.get(STORAGE_KEYS.offices);
    if (saved) return JSON.parse(saved);
  } catch { /* ignore */ }
  return [];
}

export function saveImportOffices(offices: ImportOffice[]): void {
  if (typeof window === 'undefined') return;
  dataService.db.settings.set(STORAGE_KEYS.offices, JSON.stringify(offices));
}

export function addImportOffice(name: string, notes?: string): ImportOffice {
  const offices = getImportOffices();
  const newOffice: ImportOffice = {
    id: 'office_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
    name: name.trim(),
    createdAt: new Date().toISOString(),
    usageCount: 0,
    notes: notes?.trim(),
  }; 
  offices.push(newOffice);
  saveImportOffices(offices);
  return newOffice;
}

export function updateImportOffice(id: string, updates: Partial<ImportOffice>): void {
  const offices = getImportOffices();
  const idx = offices.findIndex(o => o.id === id);
  if (idx !== -1) {
    offices[idx] = { ...offices[idx], ...updates }; 
    saveImportOffices(offices);
  }
}

export function deleteImportOffice(id: string): void {
  const offices = getImportOffices().filter(o => o.id !== id);
  saveImportOffices(offices);
}

export function incrementOfficeUsage(id: string): void {
  const offices = getImportOffices();
  const idx = offices.findIndex(o => o.id === id);
  if (idx !== -1) {
    offices[idx].usageCount += 1;
    offices[idx].lastUsedAt = new Date().toISOString();
    saveImportOffices(offices);
  }
}

export function getImportOfficeById(id: string): ImportOffice | undefined {
  return getImportOffices().find(o => o.id === id);
}

export function getImportOfficeByName(name: string): ImportOffice | undefined {
  return getImportOffices().find(o => o.name.toLowerCase() === name.toLowerCase());
}

// ===== دوال الدفعات =====

export function getImportBatches(): ImportBatch[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = dataService.db.settings.get(STORAGE_KEYS.batches);
    if (saved) return JSON.parse(saved);
  } catch { /* ignore */ }
  return [];
}

export function saveImportBatches(batches: ImportBatch[]): void {
  if (typeof window === 'undefined') return;
  dataService.db.settings.set(STORAGE_KEYS.batches, JSON.stringify(batches));
}

export function generateBatchNumber(): string {
  const batches = getImportBatches();
  const lastNum = batches.length > 0 
    ? Math.max(...batches.map(b => parseInt(b.batchNumber.replace('IMP-', '')) || 0)) 
    : 0;
  return `IMP-${String(lastNum + 1).padStart(3, '0')}`;
}

export function createImportBatch(data: {
  batchNumber?: string;
  officeId?: string;
  officeName?: string;
  importDate?: string;
  membersCount: number;
  duplicatesCount: number;
  skippedCount: number;
  errorsCount: number;
  notes?: string;
  sourceType: 'csv' | 'paste' | 'api';
}): ImportBatch {
  const batches = getImportBatches();
  const batchNumber = data.batchNumber ? data.batchNumber.trim() : generateBatchNumber();
  const newBatch: ImportBatch = {
    id: 'batch_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
    batchNumber,
    officeId: data.officeId,
    officeName: data.officeName,
    importDate: data.importDate || new Date().toISOString(),
    membersCount: data.membersCount,
    duplicatesCount: data.duplicatesCount,
    skippedCount: data.skippedCount,
    errorsCount: data.errorsCount,
    notes: data.notes?.trim(),
    sourceType: data.sourceType,
    createdAt: new Date().toISOString(),
  }; 
  batches.unshift(newBatch);
  saveImportBatches(batches);
  
  // تحديث استخدام الخطابة
  if (data.officeId) incrementOfficeUsage(data.officeId);
  
  return newBatch;
}

export function getImportBatchById(id: string): ImportBatch | undefined {
  return getImportBatches().find(b => b.id === id);
}

export function getImportBatchByNumber(batchNumber: string): ImportBatch | undefined {
  return getImportBatches().find(b => b.batchNumber === batchNumber);
}

export function deleteImportBatch(id: string): void {
  const batches = getImportBatches().filter(b => b.id !== id);
  saveImportBatches(batches);
}

// ===== دوال الاستيراد =====

// تنظيف وتقليم النص الخام للاستيراد من علامات Markdown والشروحات التمهيدية
export function cleanRawImportText(raw: string): string {
  if (!raw) return '';
  let text = raw.trim();

  // 1. تنظيف علامات Markdown code block (مثل ```csv أو ```json)
  text = text.replace(/^```[a-z0-9_]*\r?\n/gi, '').replace(/\r?\n```$/gi, '').trim();
  text = text.replace(/```[a-z0-9_]*/gi, '').replace(/```/g, '').trim();

  // 2. إذا كانت هناك أسطر شروحات قبل صف العناوين الرئيسي، ابحث عن بداية صف العناوين
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  let headerIndex = 0;
  for (let i = 0; i < Math.min(lines.length, 10); i++) {
    const l = lines[i];
    if (
      l.startsWith('[') || l.startsWith('{') ||
      l.includes('real_name') || l.includes('realName') || l.includes('nickname') || l.includes('phone') ||
      l.includes('gender') || l.includes('الجنس') || l.includes('الاسم') || l.includes('العمر') ||
      (l.includes(',') && l.split(',').length >= 2) ||
      (l.includes('\t') && l.split('\t').length >= 2)
    ) {
      headerIndex = i;
      break;
    }
  }

  if (headerIndex > 0) {
    text = lines.slice(headerIndex).join('\n');
  }

  return text;
}

// فحص ما إذا كان الصف عبارة عن صف توضيحي للقالب (مثل "الاسم الكامل,الجنس (ذكر/أنثى)...")
function isTemplateLabelRow(rowValues: string[]): boolean {
  const str = rowValues.join(' ');
  return (
    str.includes('(YYYY-MM-DD)') ||
    str.includes('(ذكر/أنثى)') ||
    str.includes('أعزب/عزباء/مطلق/مطلقة') ||
    str.includes('تاريخ الميلاد (YYYY-MM-DD)') ||
    str.includes('الاسم الكامل')
  );
}

// تحليل CSV
export function parseCSV(csvText: string): { headers: string[]; rows: string[][]; errors: string[] } {
  const errors: string[] = []; 
  const cleanText = cleanRawImportText(csvText);

  // دعم صيغة JSON المباشرة
  if (cleanText.startsWith('[') || cleanText.startsWith('{')) {
    try {
      let parsedJson = JSON.parse(cleanText);
      if (!Array.isArray(parsedJson) && typeof parsedJson === 'object' && parsedJson !== null) {
        const possibleArr = Object.values(parsedJson).find(val => Array.isArray(val));
        if (possibleArr) parsedJson = possibleArr;
        else parsedJson = [parsedJson];
      }
      if (Array.isArray(parsedJson) && parsedJson.length > 0) {
        const allKeys = new Set<string>();
        parsedJson.forEach(obj => {
          if (obj && typeof obj === 'object') {
            Object.keys(obj).forEach(k => allKeys.add(k));
          }
        });
        const headers = Array.from(allKeys);
        const rows = parsedJson.map(obj => headers.map(h => (obj[h] ?? '').toString()));
        return { headers, rows, errors: [] };
      }
    } catch {
      // ليس JSON، نواصل مع تحليل CSV Standard
    }
  }

  const lines = cleanText.split(/\r?\n/).filter(line => line.trim().length > 0);
  
  if (lines.length < 2) {
    errors.push('الملف يجب أن يحتوي على صف العناوين وصف البيانات على الأقل');
    return { headers: [], rows: [], errors }; 
  }
  
  // تحليل العناوين مع دعم CSV و Excel TSV و Semicolon CSV
  const firstLine = lines[0];
  const delimiter = firstLine.includes('\t') ? '\t' : firstLine.includes(';') && !firstLine.includes(',') ? ';' : ',';
  const headers = parseCSVLine(firstLine, delimiter);
  
  // تحليل الصفوف
  const rows: string[][] = []; 
  for (let i = 1; i < lines.length; i++) {
    try {
      let row = parseCSVLine(lines[i], delimiter);
      if (isTemplateLabelRow(row)) {
        continue; // صف توضيحي للقالب، يتم تجاهله
      }
      if (row.length < headers.length) {
        while (row.length < headers.length) row.push('');
      } else if (row.length > headers.length) {
        row = row.slice(0, headers.length);
      }
      rows.push(row); 
    } catch (e) {
      errors.push(`الصف ${i + 1}: خطأ في تحليل البيانات`); 
    }
  }
  
  return { headers, rows, errors }; 
}

// تحليل صف CSV واحد
function parseCSVLine(line: string, delimiter = ','): string[] {
  const result: string[] = []; 
  let current = ''; 
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"'; 
        i++; 
      } else {
        inQuotes = !inQuotes; 
      }
    } else if (char === delimiter && !inQuotes) {
      result.push(current.trim()); 
      current = ''; 
    } else {
      current += char; 
    }
  }
  
  result.push(current.trim()); 
  return result; 
}

const SMART_IMPORT_HEADERS = [
  'real_name', 'nickname', 'gender', 'age', 'birth_date', 'nationality', 'country', 'city', 'district',
  'marital_status', 'phone', 'whatsapp', 'sect', 'height', 'weight', 'skin_color', 'education',
  'work_type', 'job_title', 'housing', 'bio', 'p_notes'
];

const COUNTRY_HINTS = [
  'السعودية', 'الإمارات', 'الكويت', 'قطر', 'البحرين', 'عمان', 'سلطنة عمان', 'مصر', 'الأردن',
  'اليمن', 'العراق', 'سوريا', 'لبنان', 'فلسطين', 'السودان', 'المغرب', 'الجزائر', 'تونس'
];

function stripWhatsappMeta(text: string): string {
  return text
    .replace(/\[[^\]]*\]/g, ' ')
    .replace(/\b\d{1,2}:\d{2}\s*(?:ص|م|AM|PM)?\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function pickByLabels(block: string, labels: string[]): string {
  for (const label of labels) {
    const pattern = new RegExp(`${label}\\s*[:：=\-–]?\\s*([^\\n،,|؛]+)`, 'i');
    const match = block.match(pattern);
    if (match?.[1]) return match[1].trim();
  }
  return '';
}

function normalizeGenderSmart(value: string, fullText: string): string {
  const raw = `${value} ${fullText}`.toLowerCase();
  if (/\bmale\b|\bm\b|ذكر|رجل|شاب|زوج/.test(raw) && !/أنثى|انثى|female|فتاة|بنت|زوجة/.test(raw)) return 'ذكر';
  if (/\bfemale\b|\bf\b|أنثى|انثى|امرأة|فتاة|بنت|زوجة/.test(raw)) return 'أنثى';
  if (/أعزب|مطلق|أرمل|متزوج/.test(raw)) return 'ذكر';
  if (/عزباء|مطلقة|أرملة|متزوجة/.test(raw)) return 'أنثى';
  return value;
}

function normalizeMaritalSmart(value: string, fullText: string): string {
  const raw = `${value} ${fullText}`;
  if (/عزباء|single female/i.test(raw)) return 'عزباء';
  if (/أعزب|اعزب|single/i.test(raw)) return 'أعزب';
  if (/مطلقة|divorced female/i.test(raw)) return 'مطلقة';
  if (/مطلق|divorced/i.test(raw)) return 'مطلق';
  if (/أرملة|ارملة|widow/i.test(raw)) return 'أرملة';
  if (/أرمل|ارمل|widower/i.test(raw)) return 'أرمل';
  if (/متزوجة/.test(raw)) return 'متزوجة';
  if (/متزوج|married/i.test(raw)) return 'متزوج';
  return value;
}

function parseLooseProfileBlock(block: string, index: number): Record<string, string> | null {
  const clean = stripWhatsappMeta(block);
  if (!clean || clean.length < 8) return null;

  const phoneMatches = clean.match(/(?:\+?\d[\d\s\-()]{7,}\d|[٠-٩+][٠-٩\s\-()]{7,}[٠-٩])/g) || [];
  const normalizedPhones = phoneMatches
    .map((p) => normalizeArabicNumbers(p).replace(/[^0-9+]/g, ''))
    .filter((p) => p.replace(/\D/g, '').length >= 8);

  const explicitName = pickByLabels(block, ['الاسم الكامل', 'الاسم الحقيقي', 'الاسم', 'اسم العضو', 'name', 'real name']);
  const explicitGender = pickByLabels(block, ['الجنس', 'gender']);
  const explicitAge = pickByLabels(block, ['العمر', 'age']);
  const explicitCountry = pickByLabels(block, ['الدولة', 'بلد الإقامة', 'البلد', 'country']);
  const explicitCity = pickByLabels(block, ['المدينة', 'المنطقة', 'city']);
  const explicitNationality = pickByLabels(block, ['الجنسية', 'nationality']);
  const explicitMarital = pickByLabels(block, ['الحالة الاجتماعية', 'الحالة', 'marital status']);

  const ageMatch = explicitAge || (clean.match(/(?:العمر\s*)?([0-9٠-٩]{2})\s*(?:سنة|عام|سنه)/)?.[1] || '');
  const countryGuess = explicitCountry || COUNTRY_HINTS.find((country) => clean.includes(country)) || '';
  const row: Record<string, string> = {
    real_name: explicitName,
    nickname: explicitName || `عضو مستورد ${index + 1}`,
    gender: normalizeGenderSmart(explicitGender, clean),
    age: normalizeArabicNumbers(ageMatch),
    birth_date: pickByLabels(block, ['تاريخ الميلاد', 'birth date']),
    nationality: explicitNationality,
    country: countryGuess.replace('سلطنة عمان', 'عمان'),
    city: explicitCity,
    district: pickByLabels(block, ['الحي', 'district']),
    marital_status: normalizeMaritalSmart(explicitMarital, clean),
    phone: normalizedPhones[0] || '',
    whatsapp: normalizedPhones[1] || normalizedPhones[0] || '',
    sect: pickByLabels(block, ['المذهب', 'sect']),
    height: normalizeArabicNumbers(pickByLabels(block, ['الطول', 'height'])),
    weight: normalizeArabicNumbers(pickByLabels(block, ['الوزن', 'weight'])),
    skin_color: pickByLabels(block, ['لون البشرة', 'البشرة', 'skin color']),
    education: pickByLabels(block, ['المؤهل', 'التعليم', 'education']),
    work_type: pickByLabels(block, ['نوع العمل', 'العمل', 'work type']),
    job_title: pickByLabels(block, ['الوظيفة', 'المسمى الوظيفي', 'job']),
    housing: pickByLabels(block, ['السكن', 'housing']),
    bio: clean,
    p_notes: pickByLabels(block, ['مواصفات الشريك', 'شروط الشريك', 'المطلوب', 'p_notes']) || clean,
  };

  const hasUsefulData = row.real_name || row.gender || row.phone || row.age || row.country || row.marital_status || row.bio.length > 20;
  return hasUsefulData ? row : null;
}

function parseLooseProfilesData(text: string): { headers: string[]; rows: string[][] } {
  const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (lines.length === 0) return { headers: SMART_IMPORT_HEADERS, rows: [] };

  const blocks: string[] = [];
  let current: string[] = [];
  lines.forEach((line) => {
    const startsProfile = /(الاسم|name|profile|طلب\s*زواج|استمارة)/i.test(line) && current.length > 0;
    const separator = /^[-=_]{3,}$/.test(line) || /^#+\s*/.test(line);
    if (startsProfile || separator) {
      if (current.length > 0) blocks.push(current.join('\n'));
      current = separator ? [] : [line];
    } else {
      current.push(line);
    }
  });
  if (current.length > 0) blocks.push(current.join('\n'));

  const profiles = (blocks.length > 0 ? blocks : [text])
    .map((block, index) => parseLooseProfileBlock(block, index))
    .filter((row): row is Record<string, string> => !!row);

  return {
    headers: SMART_IMPORT_HEADERS,
    rows: profiles.map((profile) => SMART_IMPORT_HEADERS.map((h) => profile[h] || '')),
  };
}

// تحليل Paste (Tab-separated, CSV, or JSON)
export function parsePastedData(text: string): { headers: string[]; rows: string[][]; errors: string[] } {
  const errors: string[] = []; 
  const cleanText = cleanRawImportText(text);

  // دعم صيغة JSON المباشرة
  if (cleanText.startsWith('[') || cleanText.startsWith('{')) {
    try {
      let parsedJson = JSON.parse(cleanText);
      if (!Array.isArray(parsedJson) && typeof parsedJson === 'object' && parsedJson !== null) {
        const possibleArr = Object.values(parsedJson).find(val => Array.isArray(val));
        if (possibleArr) parsedJson = possibleArr;
        else parsedJson = [parsedJson];
      }
      if (Array.isArray(parsedJson) && parsedJson.length > 0) {
        const allKeys = new Set<string>();
        parsedJson.forEach(obj => {
          if (obj && typeof obj === 'object') {
            Object.keys(obj).forEach(k => allKeys.add(k));
          }
        });
        const headers = Array.from(allKeys);
        const rows = parsedJson.map(obj => headers.map(h => (obj[h] ?? '').toString()));
        return { headers, rows, errors: [] };
      }
    } catch {
      // ليس JSON، نواصل مع المفصول بفواصل أو Tab
    }
  }

  const lines = cleanText.split(/\r?\n/).filter(line => line.trim().length > 0);
  
  if (lines.length < 2) {
    const loose = parseLooseProfilesData(cleanText);
    if (loose.rows.length > 0) return { ...loose, errors: [] };
    errors.push('البيانات يجب أن تحتوي على صف العناوين وصف البيانات على الأقل، أو نصوص ملفات/محادثات واضحة');
    return { headers: [], rows: [], errors }; 
  }
  
  // تحديد الفاصل (Tab أو comma)
  const firstLine = lines[0];
  const looksStructured = firstLine.includes('\t') || firstLine.includes(',') || firstLine.includes(';') || SMART_IMPORT_HEADERS.some((h) => firstLine.toLowerCase().includes(h));
  if (!looksStructured) {
    const loose = parseLooseProfilesData(cleanText);
    if (loose.rows.length > 0) return { ...loose, errors: [] };
  }
  const separator = firstLine.includes('\t') ? '\t' : firstLine.includes(';') && !firstLine.includes(',') ? ';' : ',';
  
  const headers = parseCSVLine(firstLine, separator).map(h => h.trim());
  const rows: string[][] = []; 
  
  for (let i = 1; i < lines.length; i++) {
    let row = parseCSVLine(lines[i], separator).map(c => c.trim());
    if (isTemplateLabelRow(row)) {
      continue; // تجاهل صف شروحات القالب
    }
    if (row.length < headers.length) {
      while (row.length < headers.length) row.push('');
    } else if (row.length > headers.length) {
      row = row.slice(0, headers.length);
    }
    rows.push(row); 
  }
  
  return { headers, rows, errors }; 
}

// دالة للتحقق مما إذا كان سجلان متطابقين تماماً في كافة الحقول المتاحة
export function areRecordsIdentical(a: Record<string, any>, b: Record<string, any>): boolean {
  const getFirst = (obj: Record<string, any>, keys: string[]) => {
    for (const key of keys) {
      const value = obj[key];
      if (value !== undefined && value !== null && String(value).trim() !== '') return String(value).trim();
    }
    return '';
  };

  const normalizeIdentityPhone = (value: string) => normalizeArabicNumbers(value).replace(/[^0-9]/g, '').replace(/^00/, '');
  const aPhone = normalizeIdentityPhone(getFirst(a, ['phone', 'الهاتف', 'رقم الهاتف', 'الجوال']));
  const bPhone = normalizeIdentityPhone(getFirst(b, ['phone', 'الهاتف', 'رقم الهاتف', 'الجوال']));
  const aWhatsapp = normalizeIdentityPhone(getFirst(a, ['whatsapp', 'واتساب', 'رقم الواتساب']));
  const bWhatsapp = normalizeIdentityPhone(getFirst(b, ['whatsapp', 'واتساب', 'رقم الواتساب']));
  const aEmail = getFirst(a, ['email', 'البريد', 'البريد الإلكتروني']).toLowerCase();
  const bEmail = getFirst(b, ['email', 'البريد', 'البريد الإلكتروني']).toLowerCase();

  const phoneKeysA = [aPhone, aWhatsapp].filter((p) => p.length >= 8);
  const phoneKeysB = [bPhone, bWhatsapp].filter((p) => p.length >= 8);
  if (phoneKeysA.some((p) => phoneKeysB.includes(p))) return true;
  if (aEmail && bEmail && aEmail === bEmail) return true;

  const fieldsToCompare = [
    ['phone', 'الهاتف'],
    ['whatsapp', 'واتساب'],
    ['gender', 'الجنس'],
    ['nickname', 'الاسم المستعار', 'name', 'الاسم'],
    ['realName', 'real_name', 'الاسم الحقيقي'],
    ['age', 'العمر'],
    ['country', 'الدولة'],
    ['city', 'المدينة'],
    ['district', 'الحي', 'المنطقة'],
    ['nationality', 'الجنسية'],
    ['sect', 'المذهب'],
    ['maritalStatus', 'marital_status', 'الحالة الاجتماعية'],
    ['height', 'الطول'],
    ['weight', 'الوزن'],
    ['skinColor', 'skin_color', 'لون البشرة'],
    ['education', 'المؤهل'],
    ['workType', 'work_type', 'نوع العمل'],
    ['jobTitle', 'job_title', 'المسمى الوظيفي'],
    ['housing', 'السكن'],
    ['bio', 'نبذة'],
  ];

  const getValue = (obj: Record<string, any>, keys: string[]) => {
    for (const key of keys) {
      if (obj[key] !== undefined && obj[key] !== null && obj[key] !== '') {
        return normalizeArabicNumbers(obj[key].toString().trim().toLowerCase());
      }
    }
    return '';
  };

  let comparedCount = 0;
  for (const keys of fieldsToCompare) {
    const valA = getValue(a, keys);
    const valB = getValue(b, keys);

    // نتحقق إذا كان كلاهما يحتويان على قيم مختلفة
    if (valA !== '' || valB !== '') {
      comparedCount++;
      if (valA !== valB) {
        return false; // يختلفان في حقل واحد على الأقل -> ليس مكرراً!
      }
    }
  }

  return comparedCount > 0;
}

// التحقق من التكرار (يكون مكرراً فقط إذا كانت كافة البيانات في الصف متطابقة تماماً)
export function checkDuplicates(
  data: Record<string, any>[],
  existingMembers: Record<string, any>[]
): { duplicates: Record<string, any>[]; unique: Record<string, any>[]; duplicateIndices: number[] } {
  const duplicates: Record<string, any>[] = []; 
  const unique: Record<string, any>[] = []; 
  const duplicateIndices: number[] = []; 
  
  const processedUniqueInBatch: Record<string, any>[] = [];

  data.forEach((item, idx) => {
    const isDupInDb = existingMembers.some((existing) => areRecordsIdentical(item, existing));
    const isDupInBatch = processedUniqueInBatch.some((batchItem) => areRecordsIdentical(item, batchItem));

    if (isDupInDb || isDupInBatch) {
      duplicates.push(item);
      duplicateIndices.push(idx);
    } else {
      unique.push(item);
      processedUniqueInBatch.push(item);
    }
  });
  
  return { duplicates, unique, duplicateIndices }; 
}

// توليد ID فريد للعضو
export function generateMemberId(): string {
  return 'm_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// حساب العمر من تاريخ الميلاد
export function calculateAgeFromBirthDate(birthDate: string): number {
  if (!birthDate) return 0;
  let cleanDate = birthDate.trim();
  if (cleanDate.includes('/')) {
    const parts = cleanDate.split('/');
    if (parts.length === 3) {
      if (parts[0].length === 4) {
        cleanDate = `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
      } else if (parts[2].length === 4) {
        cleanDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      }
    }
  }
  const birth = new Date(cleanDate);
  if (isNaN(birth.getTime())) return 0;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--; 
  }
  return age > 0 ? age : 0;
}

// تحويل الحالة الاجتماعية إلى النص العربي
export function getMaritalLabel(status: string, gender: 'male' | 'female'): string {
  const labels: Record<string, Record<string, string>> = {
    male: { single: 'أعزب', divorced: 'مطلق', widower: 'أرمل', married: 'متزوج' },
    female: { single: 'عزباء', divorced: 'مطلقة', widow: 'أرملة' },
  }; 
  return labels[gender]?.[status] || status;
}

function translitArabicToEnglish(text: string): string {
  if (!text) return '';
  const arabicToEnglish: Record<string, string> = {
    'أ': 'a', 'إ': 'a', 'آ': 'a', 'ا': 'a',
    'ب': 'b',
    'ت': 't',
    'ث': 'th',
    'ج': 'j',
    'ح': 'h',
    'خ': 'kh',
    'د': 'd',
    'ذ': 'dh',
    'ر': 'r',
    'ز': 'z',
    'س': 's',
    'ش': 'sh',
    'ص': 's',
    'ض': 'd',
    'ط': 't',
    'ظ': 'z',
    'ع': 'a',
    'غ': 'gh',
    'ف': 'f',
    'ق': 'q',
    'ك': 'k',
    'ل': 'l',
    'م': 'm',
    'ن': 'n',
    'ه': 'h',
    'و': 'w',
    'ي': 'y', 'ى': 'a', 'ئ': 'e', 'ؤ': 'o', 'ء': 'a', 'ة': 'h'
  };

  let result = '';
  const lowerText = text.trim().toLowerCase();
  for (let i = 0; i < lowerText.length; i++) {
    const char = lowerText[i];
    if (arabicToEnglish[char] !== undefined) {
      result += arabicToEnglish[char];
    } else if (/[a-z0-9]/.test(char)) {
      result += char;
    } else if (char === ' ' || char === '_' || char === '-') {
      result += '_';
    }
  }
  return result.replace(/_+/g, '_').replace(/^_+|_+$/g, '');
}

// تنظيف وتحويل الأرقام العربية إلى أرقام إنجليزية وقراءة الأعداد بأمان
export function normalizeArabicNumbers(val: any): string {
  if (val === null || val === undefined) return '';
  const str = val.toString().trim();
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  let result = str;
  for (let i = 0; i < 10; i++) {
    result = result.replace(new RegExp(arabicDigits[i], 'g'), i.toString());
  }
  return result;
}

export function parseNumberSafely(val: any): number {
  if (!val) return 0;
  const normalized = normalizeArabicNumbers(val).replace(/[^0-9.]/g, '');
  const num = parseFloat(normalized);
  return isNaN(num) ? 0 : num;
}

// تنظيف وتجهيز بيانات العضو المستورد - مرن مع الحقول الناقصة
export function prepareImportedMember(
  data: Record<string, any>,
  batchId: string,
  officeName?: string,
  importDate?: string,
  notes?: string,
  sequenceIndex?: number
): Record<string, any> {
  // حساب وتطبيق حقول الاتصال والعناوين
  const email = (data.email || data['البريد'] || '').toString().trim();
  
  // تنظيف رقم الهاتف من ترويسة وتواريخ الواتساب مثل [19/11/2025, 6:54 م]
  let rawPhone = (data.phone || data['الهاتف'] || data['رقم الهاتف'] || data['الجوال'] || '').toString().trim();
  rawPhone = rawPhone.replace(/\[.*?\]/g, '').replace(/:\s*$/, '').trim();
  const phone = normalizeArabicNumbers(rawPhone);

  let rawWhatsapp = (data.whatsapp || data['واتساب'] || data['رقم الواتساب'] || '').toString().trim();
  rawWhatsapp = rawWhatsapp.replace(/\[.*?\]/g, '').replace(/:\s*$/, '').trim();
  const whatsapp = normalizeArabicNumbers(rawWhatsapp);

  const checkCountry = (data.country || data['الدولة'] || '').toString().trim();
  const checkCity = (data.city || data['المدينة'] || '').toString().trim();
  const checkRealName = (data.realName || data.real_name || data['الاسم الحقيقي'] || '').toString().trim();

  // تحديد الجنس دون تخمين أو فرض قيم افتراضية
  let rawGender = (data.gender || data['الجنس'] || data['الجنيس'] || '').toString().trim().toLowerCase();
  let isMale = rawGender === 'male' || rawGender === 'ذكر' || rawGender === 'm' || rawGender.includes('ذكر');
  let isFemale = rawGender === 'female' || rawGender === 'أنثى' || rawGender === 'انثى' || rawGender === 'f' || rawGender.includes('أنثى') || rawGender.includes('انثى');
  const finalGender = isMale ? 'male' : (isFemale ? 'female' : '');

  // حساب العمر من تاريخ الميلاد أو استخراج العدد
  const rawBirthDate = (data.birthDate || data.birth_date || data['تاريخ الميلاد'] || '').toString().trim();
  const age = parseNumberSafely(data.age || data['العمر']) || (rawBirthDate ? calculateAgeFromBirthDate(rawBirthDate) : 0);

  // توليد ID فريد
  const memberId = data.id || generateMemberId();

  // الاسم المستعار - يترك فارغاً إذا كان فارغاً بالملف حسب طلب المستخدم
  const checkNickname = (data.nickname || data['الاسم المستعار'] || data.name || data['الاسم'] || data.realName || data.real_name || data['القبيلة'] || '').toString().trim();

  // التحقق التلقائي من الحقول
  const checkMaritalStatus = (data.maritalStatus || data.marital_status || data['الحالة الاجتماعية'] || '').toString().trim();
  const checkHeight = parseNumberSafely(data.height || data['الطول']);
  const checkWeight = parseNumberSafely(data.weight || data['الوزن']);
  const checkSkinColor = (data.skinColor || data.skin_color || data['لون البشرة'] || '').toString().trim();
  const checkEducation = (data.education || data['المؤهل'] || data['المؤهل العلمي'] || data['المؤهل الدراسي'] || '').toString().trim();
  const checkWorkType = (data.workType || data.work_type || data['نوع العمل'] || data['الوظيفة'] || '').toString().trim();
  const checkHousing = (data.housing || data['السكن'] || '').toString().trim();

  // تجميع السيرة الذاتية والمواصفات الكاملة
  const bioParts = [
    data.bio,
    data['نبذة'],
    data['عني'],
    data['مواصفاتي'],
    data['المواصفات'],
    data['الشروط'],
    data['الشروط الخاصة'],
    data['بيانات إضافية'],
    data['ملاحظات']
  ].filter(Boolean).map(s => s.toString().trim());

  // دمج أي تفاصيل فريدة لتشمل كل نص أرسله المستخدم
  const bio = Array.from(new Set(bioParts)).join(' - ');

  // مواصفات الشريك
  const pNotesParts = [
    data.pNotes,
    data.p_notes,
    data.partner_notes,
    data['مواصفات الشريك'],
    data['مواصفات شريك العمر'],
    data['شريك العمر'],
    data['مواصفات الزوج'],
    data['مواصفات الزوجة']
  ].filter(Boolean).map(s => s.toString().trim());
  
  const pNotes = Array.from(new Set(pNotesParts)).join(' - ');

  // جلب أسماء المستخدمين الحالية من localStorage لتفادي التكرار
  const existingUsernames = new Set<string>();
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem('saved_members_list') || localStorage.getItem('twafok_members');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          parsed.forEach((m: any) => {
            if (m.username) existingUsernames.add(m.username.toLowerCase());
          });
        }
      }
    } catch { /* ignore */ }
  }

  // تحديد اسم المستخدم / اليوزر
  const checkUsername = (data.username || data['اسم المستخدم'] || data['اليوزر'] || '').toString().trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  
  let baseUsername = '';
  let isNumericSequence = false;
  
  if (checkUsername) {
    baseUsername = checkUsername;
  } else if (sequenceIndex !== undefined) {
    baseUsername = sequenceIndex.toString();
    isNumericSequence = true;
  } else {
    baseUsername = translitArabicToEnglish(checkNickname);
    if (!baseUsername || baseUsername === 'user') {
      baseUsername = 'user_' + memberId.slice(-4);
    }
  }
  
  let finalUsername = baseUsername;
  let counter = 1;
  while (existingUsernames.has(finalUsername)) {
    if (isNumericSequence) {
      const nextNum = parseInt(baseUsername, 10) + counter;
      finalUsername = nextNum.toString();
    } else {
      finalUsername = `${baseUsername}_${counter}`;
    }
    counter++;
  }
  existingUsernames.add(finalUsername);

  const isProfileIncomplete = !checkCity || (!checkHeight && !checkWeight);

  return {
    id: memberId,
    // ===== البيانات الأساسية =====
    nickname: checkNickname,
    username: finalUsername,
    gender: finalGender,
    age: age || 0,
    birthDate: rawBirthDate,
    country: checkCountry,
    city: checkCity,
    district: (data.district || data['الحي'] || data['المنطقة'] || '').toString().trim(),
    nationality: (data.nationality || data['الجنسية'] || '').toString().trim(),
    sect: (data.sect || data['المذهب'] || '').toString().trim(),
    sectOther: (data.sectOther || data.sect_other || '').toString().trim(),
    maritalStatus: checkMaritalStatus ? checkMaritalStatus.toLowerCase() : '',
    maritalLabel: (finalGender && checkMaritalStatus) ? getMaritalLabel(checkMaritalStatus, finalGender as 'male' | 'female') : '',
    hasChildren: data.hasChildren === 'yes' || data.has_children === 'yes' || data['أبناء'] === 'نعم' || data.hasChildren === true,
    childrenCount: (data.childrenCount || data.children_count || data['عدد الأبناء'] || '').toString().trim(),
    childrenLiveWith: (data.childrenLiveWith || data.children_live_with || '').toString().trim(),
    wifeCount: (data.wifeCount || data.wife_count || '').toString().trim(),
    seekingWife: (data.seekingWife || data.seeking_wife || '').toString().trim(),
    // ===== المواصفات الشخصية =====
    height: checkHeight,
    weight: checkWeight,
    skinColor: checkSkinColor,
    ethnicity: (data.ethnicity || data['العرق'] || '').toString().trim(),
    health: (data.health || data['الحالة الصحية'] || '').toString().trim(),
    smoking: (data.smoking || data['التدخين'] || '').toString().trim(),
    education: checkEducation,
    workType: checkWorkType,
    jobTitle: (data.jobTitle || data.job_title || data['المسمى الوظيفي'] || '').toString().trim(),
    housing: checkHousing,
    bio: bio || (data.bio || data['نبذة'] || data['عني'] || '').toString().trim(),
    // ===== خيارات النساء =====
    acceptPolygamy: (data.acceptPolygamy || data.accept_polygamy || '').toString().trim(),
    acceptDivorced: (data.acceptDivorced || data.accept_divorced || '').toString().trim(),
    acceptWithChildren: (data.acceptWithChildren || data.accept_with_children || '').toString().trim(),
    // ===== مواصفات الشريك =====
    pCountry: (data.pCountry || data.partner_country || data['دولة الشريك'] || '').toString().trim(),
    pCity: (data.pCity || data.partner_city || data['مدينة الشريك'] || '').toString().trim(),
    pAgeMin: parseNumberSafely(data.pAgeMin || data.partner_age_min || data['العمر من']),
    pAgeMax: parseNumberSafely(data.pAgeMax || data.partner_age_max || data['العمر إلى']),
    pNationality: (data.pNationality || data.partner_nationality || '').toString().trim(),
    pMaritalStatus: (data.pMaritalStatus || data.partner_marital_status || '').toString().trim(),
    pAcceptChildren: (data.pAcceptChildren || data.partner_accept_children || '').toString().trim(),
    pSect: (data.pSect || data.partner_sect || '').toString().trim(),
    pSectOther: (data.pSectOther || data.partner_sect_other || '').toString().trim(),
    pEducation: (data.pEducation || data.partner_education || '').toString().trim(),
    pWorkType: (data.pWorkType || data.partner_work_type || '').toString().trim(),
    pReligionLevel: (data.pReligionLevel || data.partner_religion_level || '').toString().trim(),
    pSkinColor: (data.pSkinColor || data.partner_skin_color || '').toString().trim(),
    pHeight: parseNumberSafely(data.pHeight || data.partner_height),
    pHeightNoMatter: data.pHeightNoMatter === true || data.partner_height_no_matter === 'true',
    pHousing: (data.pHousing || data.partner_housing || '').toString().trim(),
    pNotes: pNotes || (data.pNotes || data.partner_notes || '').toString().trim(),
    // ===== بيانات الحساب والاتصال =====
    realName: checkRealName,
    phone: phone,
    whatsapp: whatsapp,
    email: email,
    password: (data.password || data['كلمة المرور'] || '').toString().trim(),
    // ===== حالة الحساب =====
    verified: false,
    premium: false,
    online: false,
    status: 'active',
    plan: 'free',
    lastActive: new Date().toISOString(),
    aboutPartner: (data.aboutPartner || data.partner_notes || '').toString().trim(),
    // ===== بيانات الاستيراد وعلم عدم الاكتمال =====
    sourceType: 'imported',
    importBatchId: batchId,
    importOfficeName: officeName || '',
    importDate: importDate || new Date().toISOString(),
    importNotes: notes || '',
    isProfileIncomplete: isProfileIncomplete,
    // ===== بيانات الإدارة =====
    joinedAt: new Date().toLocaleDateString('ar-SA'),
    requestsCount: 0,
  }; 
}

// إنشاء تقرير الاستيراد
export function createImportReport(
  totalRows: number,
  imported: number,
  duplicates: number,
  skipped: number,
  errors: ImportError[],
  warnings: ImportWarning[],
  batch: ImportBatch
): ImportReport {
  return {
    batchId: batch.id,
    totalRows,
    importedCount: imported,
    duplicatesCount: duplicates,
    skippedCount: skipped,
    errorsCount: errors.length,
    errors,
    warnings,
    officeName: batch.officeName,
    batchNumber: batch.batchNumber,
    importDate: batch.importDate,
  }; 
}

// إعادة تعيين جميع البيانات
export function resetImportData(): void {
  if (typeof window === 'undefined') return;
  dataService.db.settings.remove(STORAGE_KEYS.offices);
  dataService.db.settings.remove(STORAGE_KEYS.batches);
}
