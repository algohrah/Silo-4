# هيكلة وقواعد البيانات — DATABASE

يتناول هذا الملف بنية البيانات المستخدمة في منصة **توافق للزواج**، ووصف الكيانات الرئيسية، وتصميم الواجهات البرمجية وطرق تخرين واستدعاء المعلومات محلياً وسحابياً.

---

## 1. تصميم طبقة البيانات الموحدة (Unified Repository Schema)

تم بناء هيكلية البيانات بالاعتماد على واجهة تكرارية موحدة `IRepository<T>` تفرض العمليات الأساسية لقاعدة البيانات:
- `getAll()`: استعادة جميع السجلات.
- `getById(id)`: استرجاع سجل محدد برقم الهوية المعرف.
- `create(item)`: إنشاء سجل جديد.
- `update(id, item)`: تحديث حقول معينة في سجل قائم.
- `delete(id)`: مسح السجل من المخزن.

تتوزع الجداول والمستودعات في المنصة إلى 5 وحدات رئيسية زائد مستودع الإعدادات العام:
```typescript
export interface IDatabaseAdapter {
  members: IRepository<any>;
  requests: IRepository<any>;
  transactions: IRepository<any>;
  tickets: IRepository<any>;
  adminUsers: IRepository<any>;
  settings: ISettingsRepository;
}
```

---

## 2. تفاصيل الكيانات والجداول الرئيسية (Core Entities)

### أ. كيان العضو (Member Entity)
يمثل الملف الشخصي الكامل للشخص الراغب بالزواج ويحتوي على البيانات الديموغرافية والاجتماعية والشروط المطلوبة:
- `id` (string): الهوية التعريفية الفريدة.
- `nickname` (string): اللقب المختار للعرض بدلاً من الاسم الحقيقي لضمان الخصوصية.
- `gender` (string): الجنس (`male` / `female`).
- `age` (number): العمر بالسنوات.
- `country` / `city` / `district` (strings): التوزيع الجغرافي والإقامة.
- `maritalStatus` (string): الحالة الاجتماعية (أعزب، مطلق، أرمل، متزوج).
- `profileCompletion` (number): نسبة اكتمال البيانات من 0 إلى 100%.
- `verified` (boolean): تأكيد توثيق الهوية عبر الإدارة.
- `plan` (string): الباقة المشترك بها العضو (`free` / `gold` / `elite`).

### ب. كيان طلب الاهتمام ورحلة الوساطة (Interest Request Entity)
يمثل الطلبات المتبادلة بين الأعضاء ويسجل تقدم رحلة التعارف الشرعية:
- `id` (string): معرف الطلب.
- `sender_id` (string): هوية مرسل الطلب.
- `receiver_id` (string): هوية متلقي الطلب.
- `status` (string): حالة الطلب (`pending` / `accepted` / `declined` / `paid` / `completed` / `cancelled`).
- `mediationStage` (string): مرحلة التنسيق والوساطة (`none` / `scheduling` / `meet_arranged` / `contract_signed` / `finished`).
- `sender_paid` / `receiver_paid` (boolean): مؤشرات دفع رسوم الجدية من كلا الطرفين.

### ج. كيان المعاملات المالية (Transaction Entity)
يرصد المدفوعات والاشتراكات وطلبات الإعفاء المالي:
- `id` (string): معرف الفاتورة.
- `memberId` (string): معرف العضو دافع الفاتورة.
- `amount` (number): القيمة المالية.
- `planId` (string): الباقة المرتبطة بالدفع.
- `status` (string): حالة الدفعة (`pending` / `completed` / `failed` / `exempted`).

---

## 3. تفاصيل التخزين المحلي (LocalStorage Database Keys)

في بيئة العمل المحلية والتجريبية، يتم استخدام `LocalStorageAdapter` الذي يحفظ السجلات في المتصفح تحت مفاتيح مخصصة كالتالي:
- `twafok_members`: جدول قائمة جميع الأعضاء.
- `twafok_requests`: جدول تتبع طلبات التوافق والوساطة الشرعية.
- `twafok_transactions`: جدول الإيصالات المالية والمشتريات.
- `twafok_tickets`: جدول تذاكر الدعم والاتصال الإداري.
- `twafok_admin_users`: سجل الإداريين والوسطاء المعتمدين وصلاحياتهم.
- `twafok_settings`: مخزن مفاتيح التكوين (مثل تفاصيل المصادقة النشطة والإعدادات العامة للموقع).

---

## 4. التحويل السحابي ومرونة التهيئة

يتحكم متغير البيئة `VITE_DATABASE_PROVIDER` في تحديد مزود قاعدة البيانات النشط:
1. **`local`:** تفعيل التخزين المتصفحي المحلي (مثالي للتطوير السريع دون إنترنت).
2. **`supabase`:** الاتصال بقاعدة بيانات Supabase الموثوقة والمدعومة بنظام مصادقة سحابي وقواعد حماية RLS لربط المستخدمين بالخادم الفعلي.
3. **`appwrite`:** محول بديل متصل بسحابة Appwrite لإدارة الوثائق وتحديث الحالات.
