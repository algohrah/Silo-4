import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../lib/AppContext';
import {
  Search as SearchIcon, SlidersHorizontal, MapPin, Calendar,
  Briefcase, GraduationCap, Users, ChevronDown, ChevronUp,
  Globe, BookOpen, Heart, ShieldCheck, Baby, Building2,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import {
  ARAB_COUNTRIES, ARAB_CITIES, EDUCATION_LEVELS, JOB_TITLES,
  SECTS, CHILDREN_COUNTS, getMaritalOptions,
} from '../lib/types';
import MemberCard from '../components/MemberCard';

type GenderFilter = 'male' | 'female' | 'all';

export default function Search() {
  const navigate = useNavigate();
  const { checkLimit, incrementUsage, showToast, members, calculateCompatDetailed } = useApp();

  // ===== الفلاتر الأساسية =====
  const [gender, setGender] = useState<GenderFilter>('all');
  const [ageRange, setAgeRange] = useState<[number, number]>([22, 40]);
  const [country, setCountry] = useState('');
  const [city, setCity] = useState('');

  // ===== الفلاتر المتقدمة =====
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [nationality, setNationality] = useState('');
  const [education, setEducation] = useState('');
  const [job, setJob] = useState('');
  const [maritalStatus, setMaritalStatus] = useState('');
  const [sect, setSect] = useState('');
  const [hasChildren, setHasChildren] = useState('');
  const [childrenCount, setChildrenCount] = useState('');

  // خيارات الحالة الاجتماعية حسب الجنس المختار
  const maritalOptions = gender === 'all' ? [] : getMaritalOptions(gender);

  // عند تغيير الجنس: نعيد ضبط الحالة الاجتماعية لأن الخيارات تختلف
  const handleGenderChange = (g: GenderFilter) => {
    setGender(g);
    setMaritalStatus(''); // إعادة ضبط الحالة الاجتماعية
    setHasChildren('');
    setChildrenCount('');
  };

  // عند اختيار "مطلق/مطلقة" نظهر خيارات الأبناء
  const showChildrenOptions = maritalStatus === 'divorced' || maritalStatus === 'widower' || maritalStatus === 'widow';

  // Live filtering (replaces separate results page - Red Priority #2)
  const filteredMembers = members.filter(m => {
    if (m.status && m.status !== 'active') return false;
    if (m.isProfileIncomplete) return false;
    if (gender !== 'all' && m.gender !== gender) return false;
    if (m.age < ageRange[0] || m.age > ageRange[1]) return false;
    if (country && m.country !== country) return false;
    if (city && m.city !== city) return false;
    if (education && m.education !== education) return false;
    if (job && m.workType !== job) return false;
    if (maritalStatus && m.maritalStatus !== maritalStatus) return false;
    if (sect && m.sect !== sect) return false;
    if (hasChildren && ((hasChildren === 'true' && !m.hasChildren) || (hasChildren === 'false' && m.hasChildren))) return false;
    return true;
  }).sort((a, b) => {
    // Priority: Seriousness Badge and Premium Package first
    const scoreA = (a.hasSeriousnessBadge ? 2 : 0) + (a.premium ? 1 : 0);
    const scoreB = (b.hasSeriousnessBadge ? 2 : 0) + (b.premium ? 1 : 0);

    if (scoreA !== scoreB) {
      return scoreB - scoreA; // higher score first
    }

    // Secondary: Sort by latest (newest ID first)
    const numA = parseInt(a.id.replace(/\D/g, '')) || 0;
    const numB = parseInt(b.id.replace(/\D/g, '')) || 0;
    if (numA !== numB) {
      return numB - numA;
    }

    // Tertiary: fallback comparison
    return b.id.localeCompare(a.id);
  });

  const handleSearch = () => {
    // Live results already shown below - no navigation needed
    showToast('تم تحديث النتائج فوراً حسب الفلاتر', 'success');
    incrementUsage('search');
  };

  return (
    <div className="bg-cream-50 min-h-screen pb-12">
      {/* Header banner */}
      <div className="bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="absolute -top-20 -left-20 w-72 h-72 bg-gold-500/20 rounded-full blur-3xl" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 py-12 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gold-300/15 mb-4">
              <SlidersHorizontal className="w-7 h-7 text-gold-300" />
            </div>
            <h1 className="font-cairo font-extrabold text-3xl sm:text-4xl text-white">البحث المتقدم</h1>
            <p className="mt-3 text-cream-200/80 font-tajawal">خصّص بحثك بدقة للعثور على شريك الحياة المناسب</p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 -mt-6 relative">
        <div className="bg-white rounded-3xl shadow-luxe border border-cream-200/60 p-5 sm:p-7 space-y-6">

          {/* ===== الخطوة 1: الجنس (أول خيار) ===== */}
          <FilterSection icon={Users} title="أبحث عن" step={1}>
            <div className="grid grid-cols-3 gap-3">
              <GenderButton
                active={gender === 'all'} onClick={() => handleGenderChange('all')}
                label="الجميع" color="gold"
              />
              <GenderButton
                active={gender === 'male'} onClick={() => handleGenderChange('male')}
                label="رجال" color="blue"
              />
              <GenderButton
                active={gender === 'female'} onClick={() => handleGenderChange('female')}
                label="نساء" color="rose"
              />
            </div>
            {gender === 'all' && (
              <p className="text-xs text-navy-400 font-tajawal mt-2.5 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                عند اختيار «الجميع» تتوفر خيارات الدولة والمدينة والعمر فقط
              </p>
            )}
          </FilterSection>

          {/* ===== الخطوة 2: العمر ===== */}
          <FilterSection icon={Calendar} title="الفئة العمرية" step={2}>
            <div className="bg-cream-50 rounded-2xl p-4 border border-cream-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-navy-500 font-tajawal">من</span>
                <span className="font-cairo font-bold text-lg text-gold-700 bg-gold-300/15 px-3 py-1 rounded-lg">{ageRange[0]} سنة</span>
              </div>
              <input type="range" min="18" max="70" value={ageRange[0]}
                onChange={(e) => setAgeRange([Math.min(Number(e.target.value), ageRange[1]), ageRange[1]])}
                className="w-full accent-gold-500" />
            </div>
            <div className="bg-cream-50 rounded-2xl p-4 border border-cream-200 mt-3">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-navy-500 font-tajawal">إلى</span>
                <span className="font-cairo font-bold text-lg text-gold-700 bg-gold-300/15 px-3 py-1 rounded-lg">{ageRange[1]} سنة</span>
              </div>
              <input type="range" min="18" max="70" value={ageRange[1]}
                onChange={(e) => setAgeRange([ageRange[0], Math.max(Number(e.target.value), ageRange[0])])}
                className="w-full accent-gold-500" />
            </div>
          </FilterSection>

          {/* ===== الخطوة 3: الدولة والمدينة ===== */}
          <FilterSection icon={MapPin} title="الدولة والمدينة" step={3}>
            <div className="grid sm:grid-cols-2 gap-3">
              <SelectField icon={Globe} label="الدولة" value={country} onChange={setCountry}
                options={ARAB_COUNTRIES} placeholder="كل الدول" />
              <SelectField icon={MapPin} label="المدينة" value={city} onChange={setCity}
                options={ARAB_CITIES} placeholder="كل المدن" />
            </div>
          </FilterSection>

          {/* ===== زر المزيد من الخيارات ===== */}
          {gender !== 'all' && (
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="w-full flex items-center justify-between p-4 rounded-2xl bg-navy-gradient text-white font-cairo font-bold transition-all hover:shadow-luxe relative overflow-hidden"
            >
              <div className="absolute inset-0 pattern-arabesque opacity-20" />
              <span className="relative flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-gold-300" />
                {showAdvanced ? 'إخفاء الخيارات المتقدمة' : 'مزيد من الخيارات'}
              </span>
              <span className="relative">
                {showAdvanced ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
              </span>
            </button>
          )}

          {/* ===== الخيارات المتقدمة ===== */}
          <AnimatePresence>
            {showAdvanced && gender !== 'all' && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="space-y-5 pt-2 border-t border-cream-200">

                  {/* الحالة الاجتماعية — تتغير حسب الجنس */}
                  <div>
                    <label className="flex items-center gap-2 text-sm font-cairo font-bold text-navy-800 mb-2.5">
                      <Heart className="w-4 h-4 text-gold-600" /> الحالة الاجتماعية
                      <span className="text-[11px] font-normal text-navy-400">
                        ({gender === 'male' ? 'خيارات الرجال' : 'خيارات النساء'})
                      </span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {maritalOptions.map((opt) => (
                        <button
                          key={opt.value}
                          onClick={() => setMaritalStatus(maritalStatus === opt.value ? '' : opt.value)}
                          className={`py-2.5 px-2 rounded-xl font-cairo font-semibold text-sm transition-all no-tap-highlight ${
                            maritalStatus === opt.value
                              ? 'bg-gold-gradient text-navy-900 shadow-soft'
                              : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* عدد الأبناء — يظهر فقط للمطلق/الأرمل */}
                  {showChildrenOptions && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <label className="flex items-center gap-2 text-sm font-cairo font-bold text-navy-800 mb-2.5">
                        <Baby className="w-4 h-4 text-gold-600" /> الأبناء
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        <button
                          onClick={() => { setHasChildren('false'); setChildrenCount(''); }}
                          className={`py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all ${
                            hasChildren === 'false' ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
                          }`}
                        >
                          بدون أبناء
                        </button>
                        <button
                          onClick={() => setHasChildren('true')}
                          className={`py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all ${
                            hasChildren === 'true' ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
                          }`}
                        >
                          لديه أبناء
                        </button>
                      </div>
                      {hasChildren === 'true' && (
                        <div className="mt-2">
                          <SelectField icon={Baby} label="عدد الأبناء" value={childrenCount} onChange={setChildrenCount}
                            options={CHILDREN_COUNTS.filter(c => c !== 'لا يوجد')} placeholder="اختر العدد" />
                        </div>
                      )}
                    </motion.div>
                  )}

                  {/* المذهب */}
                  <SelectField icon={BookOpen} label="المذهب" value={sect} onChange={setSect}
                    options={SECTS} placeholder="كل المذاهب" />

                  {/* الجنسية */}
                  <SelectField icon={Globe} label="الجنسية" value={nationality} onChange={setNationality}
                    options={ARAB_COUNTRIES} placeholder="كل الجنسيات" />

                  {/* التعليم والوظيفة */}
                  <div className="grid sm:grid-cols-2 gap-3">
                    <SelectField icon={GraduationCap} label="التعليم" value={education} onChange={setEducation}
                      options={EDUCATION_LEVELS} placeholder="الكل" />
                    <SelectField icon={Briefcase} label="نوع العمل" value={job} onChange={setJob}
                      options={['حكومي', 'عمل حر', 'باحث عن عمل', 'طالب', 'بدون وظيفة']} placeholder="الكل" />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* زر البحث */}
          <Button onClick={handleSearch} fullWidth size="lg" className="shadow-gold">
            <SearchIcon className="w-5 h-5" /> ابحث الآن
          </Button>
        </div>
      </div>

      {/* عرض النتائج */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 mt-12 border-t border-cream-200/60">
        <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-cairo font-extrabold text-2xl text-navy-900">
              نتائج البحث ({filteredMembers.length})
            </h2>
            <p className="mt-1 text-sm text-navy-500 font-tajawal">
              {filteredMembers.length > 0
                ? 'مرتبة حسب الجدية والتميز — الأحدث أولاً'
                : 'لا توجد نتائج مطابقة. جرّب تعديل الفلاتر.'}
            </p>
          </div>
          {filteredMembers.length > 0 && (
            <div className="text-xs font-tajawal text-navy-500 bg-cream-100 px-4 py-2 rounded-2xl flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-gold-600" />
              نتائج مفلترة حسب اختيارك
            </div>
          )}
        </div>

        {filteredMembers.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-5">
            {filteredMembers.map((m) => (
              <MemberCard key={m.id} member={m} />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center">
            <SearchIcon className="w-16 h-16 text-navy-200 mx-auto mb-4" />
            <p className="font-cairo font-bold text-navy-700 text-lg mb-1">لا توجد نتائج مطابقة</p>
            <p className="text-sm text-navy-400 font-tajawal mb-6">جرّب توسيع نطاق البحث أو تعديل الفلاتر</p>
            <Button
              onClick={() => {
                setGender('all');
                setAgeRange([22, 40]);
                setCountry('');
                setCity('');
                setEducation('');
                setJob('');
                setMaritalStatus('');
                setSect('');
                setHasChildren('');
                setShowAdvanced(false);
              }}
              variant="outline"
              size="md"
            >
              إعادة ضبط الفلاتر
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ===== مكوّنات مساعدة ===== */

function FilterSection({ icon: Icon, title, step, children }: { icon: typeof Users; title: string; step: number; children: React.ReactNode }) {
  return (
    <div>
      <label className="flex items-center gap-2.5 mb-3">
        <span className="flex items-center justify-center w-7 h-7 rounded-lg bg-gold-300/20 text-gold-700 font-cairo font-bold text-sm flex-shrink-0">
          {step}
        </span>
        <span className="flex items-center gap-2 text-sm font-cairo font-bold text-navy-800">
          <Icon className="w-4 h-4 text-gold-600" /> {title}
        </span>
      </label>
      {children}
    </div>
  );
}

function GenderButton({ active, onClick, label, color }: { active: boolean; onClick: () => void; label: string; color: 'gold' | 'blue' | 'rose' }) {
  const colors = {
    gold: active ? 'bg-gold-gradient text-navy-900 shadow-soft' : '',
    blue: active ? 'bg-blue-500 text-white shadow-soft' : '',
    rose: active ? 'bg-rose-500 text-white shadow-soft' : '',
  };
  return (
    <button
      onClick={onClick}
      className={`py-3.5 rounded-xl font-cairo font-bold text-sm transition-all no-tap-highlight ${
        active ? colors[color] : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
      }`}
    >
      {label}
    </button>
  );
}

function SelectField({ icon: Icon, label, value, onChange, options, placeholder }: {
  icon: typeof Globe; label: string; value: string; onChange: (v: string) => void; options: string[]; placeholder: string;
}) {
  return (
    <div>
      <label className="flex items-center gap-2 text-xs font-cairo font-semibold text-navy-600 mb-1.5">
        <Icon className="w-3.5 h-3.5 text-gold-600" /> {label}
      </label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 appearance-none cursor-pointer"
        >
          <option value="">{placeholder}</option>
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
        <ChevronDown className="w-4 h-4 text-navy-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
      </div>
    </div>
  );
}
