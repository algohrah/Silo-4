import { useState, useMemo, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Check, User, FileText, Heart, ShieldCheck,
  Venus, Mars, Lock, Eye, EyeOff,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import {
  Field, TextInput, SelectInput, TextArea,
  RadioGroup, ChoiceCard, RangeSlider, ProgressBar, DateSelect,
  SelectWithOther, PhoneInputWithCountryCode,
} from '../components/ui/FormFields';
import SearchableSelect from '../components/ui/SearchableSelect';
import MultiSearchableSelect from '../components/ui/MultiSearchableSelect';
import { useApp } from '../lib/AppContext';
import supabase from '../lib/supabase';
import { translitArabicToEnglish } from '../lib/types';
import * as C from '../lib/constants';
import {
  getNationalityForCountry,
  getNationalityOptions,
  getPartnerMaritalOptions,
  getPartnerTerms,
  getSelfMaritalOptions,
  isMarriedMale,
  normalizeMaritalLabel,
  shouldAskChildren,
} from '../lib/registrationOptions';
import { dataService } from '../lib/data/DataService';
const { getCountries, getCities, addPendingCity, getAllPendingCities } = dataService.db;



// ====================================================================
//  صفحة التسجيل الديناميكي — نموذج متعدد الخطوات
// ====================================================================

interface FormData {
  // أساسي
  gender: string;
  nickname: string;
  username: string;
  birthDate: string;
  age: number;
  country: string;
  city: string;
  district: string;
  sect: string;
  sectOther: string;
  nationalityMode: string; // 'same' | 'other'
  nationality: string;
  nationalityOther: string;
  // الحالة الاجتماعية
  maritalStatus: string;
  marriageType: string; // 'announced' | 'misyar' | 'both'
  tribe: string;
  childrenCount: string;
  childrenLiveWith: string;
  hasChildren: string;
  wifeCount: string;
  seekingWife: string;
  // شخصية
  height: number;
  weight: number;
  skinColor: string;
  skinColorOther: string;
  ethnicity: string;
  health: string;
  smoking: string;
  // نساء فقط
  acceptPolygamy: string;
  acceptDivorced: string;
  acceptWithChildren: string;
  // تعليم وعمل
  education: string;
  workType: string;
  jobTitle: string;
  housing: string;
  // نبذة
  bio: string;
  // مواصفات الشريك
  pCountry: string;
  pCity: string;
  pAgeMin: number | string;
  pAgeMax: number | string;
  pNationality: string;
  pNationalityOther: string;
  pMaritalStatus: string;
  pAcceptChildren: string;
  pSect: string;
  pSectOther: string;
  pEducation: string;
  pWorkType: string;
  pReligionLevel: string;
  pSkinColor: string;
  pHeightNoMatter: boolean;
  pHeight: number;
  pHousing: string;
  pNotes: string;
  // بيانات الإدارة
  realName: string;
  phone: string;
  whatsapp: string;
  email: string;
  // كلمة المرور
  password: string;
  passwordConfirm: string;
}

const emptyForm: FormData = {
  gender: '', nickname: '', username: '', birthDate: '', age: 0, country: '', city: '',
  district: '', sect: '', sectOther: '', nationalityMode: '', nationality: '', nationalityOther: '',
  maritalStatus: '', marriageType: 'announced', tribe: '', childrenCount: '', childrenLiveWith: '',
  hasChildren: '', wifeCount: '', seekingWife: '',
  height: 0, weight: 0, skinColor: '', skinColorOther: '', ethnicity: '', health: '', smoking: '',
  acceptPolygamy: '', acceptDivorced: '', acceptWithChildren: '',
  education: '', workType: '', jobTitle: '', housing: '',
  bio: '',
  pCountry: '', pCity: '', pAgeMin: '', pAgeMax: '', pNationality: '', pNationalityOther: '',
  pMaritalStatus: '', pAcceptChildren: '', pSect: '', pSectOther: '',
  pEducation: '', pWorkType: '', pReligionLevel: '', pSkinColor: '', pHeightNoMatter: false, pHeight: 170, pHousing: '', pNotes: '',
  realName: '', phone: '', whatsapp: '', email: '',
  password: '', passwordConfirm: '',
};

const STEPS = [
  { id: 0, title: 'الهوية والإقامة', icon: User },
  { id: 1, title: 'المظهر والعمل والنبذة', icon: FileText },
  { id: 2, title: 'مواصفات الشريك', icon: Heart },
  { id: 3, title: 'بيانات الحساب والأمان', icon: ShieldCheck },
  { id: 4, title: 'المراجعة والتأكيد', icon: Check },
];

export default function Register() {
  const navigate = useNavigate();
  const { registerNewMember, members } = useApp();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormData>(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPass, setShowPass] = useState(false);
  const [showPassConfirm, setShowPassConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  // حالات فتح النوافذ المخصصة لمواصفات الشريك (تحديد عدة دول/مدن/جنسيات)
  const [pCountryCustomOpen, setPCountryCustomOpen] = useState(false);
  const [pCityCustomOpen, setPCityCustomOpen] = useState(false);
  const [pNationalityCustomOpen, setPNationalityCustomOpen] = useState(false);
  // التحقق من تكرار البريد الإلكتروني عبر الخادم — الحقول الحسّاسة (email) لم تعد ضمن قائمة
  // الأعضاء العامة في الواجهة، لذا لا يمكن التحقق محلياً؛ نستخدم مسار /api/members?checkEmail= المخصّص لذلك.
  const [emailTaken, setEmailTaken] = useState(false);
  const [checkingEmail, setCheckingEmail] = useState(false);
  const lastCheckedEmail = useRef('');

  const checkEmailAvailability = async (email: string) => {
    const clean = email.trim().toLowerCase();
    if (!clean || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean) || clean === lastCheckedEmail.current) return;
    lastCheckedEmail.current = clean;
    setCheckingEmail(true);
    try {
      const res = await fetch(`/api/members?checkEmail=${encodeURIComponent(clean)}`);
      const data = await res.json();
      setEmailTaken(!!data?.exists);
    } catch {
      setEmailTaken(false);
    } finally {
      setCheckingEmail(false);
    }
  };

  // نضمن تحميل قوائم الجغرافيا الرسمية من قاعدة البيانات قبل عرض خيارات المدن/الجنسيات
  useEffect(() => { dataService.db.ensureGeoLoaded?.().catch(() => undefined); }, []);

  const isMale = form.gender === 'male';
  const isFemale = form.gender === 'female';
  const partnerTerms = useMemo(() => getPartnerTerms(form.gender as any), [form.gender]);

  const set = (key: keyof FormData, value: any) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: '' }));
  };

  const setCountryAndSyncNationality = (country: string) => {
    setForm((prev) => ({
      ...prev,
      country,
      city: '',
      nationality: prev.nationalityMode === 'same' ? getNationalityForCountry(country, prev.gender as any) : prev.nationality,
    }));
    setErrors((prev) => ({ ...prev, country: '', city: '', nationality: '' }));
  };

  // حساب قوة كلمة المرور
  const passwordStrength = useMemo(() => {
    const pass = form.password;
    if (!pass) return { score: 0, label: '', color: 'bg-slate-200', percentage: 0 };
    if (pass.length < 6) return { score: 1, label: 'ضعيفة جدًا (اقل من 6 أحرف)', color: 'bg-rose-500', percentage: 25 };
    
    let score = 1;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass) || /[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass) && pass.length >= 8) score++;

    if (score <= 2) return { score: 2, label: 'مقبولة', color: 'bg-amber-500', percentage: 50 };
    if (score === 3) return { score: 3, label: 'جيدة جداً', color: 'bg-blue-500', percentage: 75 };
    return { score: 4, label: 'قوية وآمنة', color: 'bg-emerald-500', percentage: 100 };
  }, [form.password]);

  // حساب العمر تلقائيًا من تاريخ الميلاد
  const handleBirthDateChange = (date: string) => {
    set('birthDate', date);
    const parts = date ? date.split('-') : [];
    if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
      const birth = new Date(date);
      const today = new Date();
      let calculatedAge = today.getFullYear() - birth.getFullYear();
      const monthDiff = today.getMonth() - birth.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        calculatedAge--;
      }
      set('age', calculatedAge);
    } else {
      set('age', 0);
    }
  };

  // المدن حسب الدولة المختارة
  const cities = useMemo(() => {
    if (!form.country) return [];
    let official: string[] = [];
    try {
      official = getCities(form.country);
    } catch (e) {}
    if (!official || official.length === 0) {
      official = C.CITIES_BY_COUNTRY[form.country] || [];
    }
    const pending = (getAllPendingCities() || [])
      .filter((p) => p.country === form.country && p.status === 'pending')
      .map((p) => p.name);
    const combined = Array.from(new Set([...official, ...pending.filter((c) => !official.includes(c))]));
    const list = combined.length > 0 ? combined : (C.CITIES_BY_COUNTRY[form.country] || []);
    return list.filter((c) => c !== 'أخرى' && !c.includes('أخرى'));
  }, [form.country]);

  const pCities = useMemo(() => {
    if (!form.pCountry || form.pCountry === 'لا تفضيل' || form.pCountry === 'لا يهم') {
      const userCountry = form.country || 'السعودية';
      let defaultList: string[] = [];
      try { defaultList = getCities(userCountry); } catch (e) {}
      if (!defaultList || defaultList.length === 0) defaultList = C.CITIES_BY_COUNTRY[userCountry] || [];
      return defaultList.filter((c) => c !== 'أخرى' && !c.includes('أخرى'));
    }

    const selectedCountriesList = form.pCountry.split('،').map((s) => s.trim()).filter(Boolean);
    const accumulatedCities: string[] = [];

    for (const cnt of selectedCountriesList) {
      let list: string[] = [];
      try { list = getCities(cnt); } catch (e) {}
      if (!list || list.length === 0) { list = C.CITIES_BY_COUNTRY[cnt] || []; }
      accumulatedCities.push(...list);
    }

    return Array.from(new Set(accumulatedCities)).filter((c) => c !== 'أخرى' && !c.includes('أخرى'));
  }, [form.pCountry, form.country]);

  const pSelectedCountries = useMemo(() => {
    if (!form.pCountry || form.pCountry === 'لا يهم') return [];
    return form.pCountry.split('،').map((s) => s.trim()).filter(Boolean);
  }, [form.pCountry]);

  const pSelectedCities = useMemo(() => {
    if (!form.pCity || form.pCity === 'لا يهم') return [];
    return form.pCity.split('،').map((s) => s.trim()).filter(Boolean);
  }, [form.pCity]);

  const pSelectedNationalities = useMemo(() => {
    if (
      !form.pNationality ||
      form.pNationality === 'لا يهم' ||
      form.pNationality === 'نفس جنسيتي' ||
      form.pNationality === 'اقبل اجنبي' ||
      form.pNationality === 'أقبل أجنبي'
    ) return [];
    return form.pNationality.split('،').map((s) => s.trim()).filter(Boolean);
  }, [form.pNationality]);

  const pSelectedMarital = useMemo(() => {
    if (!form.pMaritalStatus || form.pMaritalStatus === 'لا يهم') return ['لا يهم'];
    return form.pMaritalStatus.split('،').map((s) => s.trim()).filter(Boolean);
  }, [form.pMaritalStatus]);

  const isSingleOnly = useMemo(() => {
    if (!form.pMaritalStatus || form.pMaritalStatus === 'لا يهم') return false;
    const items = form.pMaritalStatus.split('،').map((s) => s.trim()).filter(Boolean);
    if (items.length === 0) return false;
    return items.every((item) => item === 'عزباء' || item === 'أعزب');
  }, [form.pMaritalStatus]);

  // قائمة الدول الحيّة من قاعدة البيانات
  const countryOptions = useMemo(() => {
    let list: string[] = [];
    try {
      const dbCountries = getCountries();
      if (Array.isArray(dbCountries) && dbCountries.length > 0) {
        list = dbCountries.map((c) => (typeof c === 'string' ? c : c?.name || c?.label || String(c))).filter(Boolean);
      }
    } catch (err) {}
    if (!list || list.length === 0) {
      list = C.COUNTRIES;
    }
    const combined = Array.from(new Set([...list, ...C.COUNTRIES]));
    return combined.filter((c) => c !== 'أخرى' && c !== 'دولة أخرى');
  }, []);

  // قائمة الجنسيات مربوطة بقاعدة البيانات
  const nationalityOptions = useMemo(() => {
    const official = dataService.db.getNationalities?.() || [];
    const combined = Array.from(new Set([...official, ...getNationalityOptions(form.gender as any, countryOptions)]));
    return combined.filter((n) => n !== 'أخرى' && n !== 'جنسية أخرى');
  }, [countryOptions, form.gender]);

  const partnerNationalityOptions = useMemo(() => {
    const official = dataService.db.getNationalities?.() || [];
    const combined = Array.from(new Set([...official, ...getNationalityOptions(isMale ? 'female' : 'male', countryOptions)]));
    return combined.filter((n) => n !== 'أخرى' && n !== 'جنسية أخرى');
  }, [countryOptions, isMale]);

  // قائمة المذاهب الدينيه من قاعدة البيانات
  const sectOptions = useMemo(() => {
    try {
      const dbSects = dataService.db.getSects();
      if (Array.isArray(dbSects) && dbSects.length > 0) {
        const filtered = dbSects.filter((s) => s !== 'أخرى' && s !== 'مذهب آخر');
        return [...filtered, 'أخرى'];
      }
    } catch (err) {}
    return C.SECTS;
  }, []);

  // خيارات المظهر والعمل والتعليم من قاعدة البيانات
  const skinColorOptions = useMemo(() => {
    let raw: any[] = [];
    try {
      const opts = dataService.db.getRegistrationOptions('skinColors');
      if (Array.isArray(opts) && opts.length > 0) raw = opts;
    } catch (err) {}
    if (!raw || raw.length === 0) raw = C.SKIN_COLORS;
    const list = raw.map((o) => (typeof o === 'string' ? o : o?.name || o?.label || o?.value || String(o))).filter(Boolean);
    return Array.from(new Set(list)).filter((s) => s !== 'أخرى' && s !== 'لون آخر');
  }, []);

  const educationOptions = useMemo(() => {
    let raw: any[] = [];
    try {
      const opts = dataService.db.getRegistrationOptions('educationLevels');
      if (Array.isArray(opts) && opts.length > 0) raw = opts;
    } catch (err) {}
    if (!raw || raw.length === 0) raw = C.EDUCATION_LEVELS;
    const list = raw.map((o) => (typeof o === 'string' ? o : o?.name || o?.label || o?.value || String(o))).filter(Boolean);
    return Array.from(new Set(list));
  }, []);

  const workTypeOptions = useMemo(() => {
    let raw: any[] = [];
    try {
      const opts = dataService.db.getRegistrationOptions('workTypes');
      if (Array.isArray(opts) && opts.length > 0) raw = opts;
    } catch (err) {}
    if (!raw || raw.length === 0) raw = C.WORK_TYPES;
    const list = raw.map((o) => (typeof o === 'string' ? o : o?.name || o?.label || o?.value || String(o))).filter(Boolean);
    return Array.from(new Set(list));
  }, []);

  const housingOptions = useMemo(() => {
    let raw: any[] = [];
    try {
      const opts = dataService.db.getRegistrationOptions('housingTypes');
      if (Array.isArray(opts) && opts.length > 0) raw = opts;
    } catch (err) {}
    if (!raw || raw.length === 0) raw = C.HOUSING_TYPES;
    const list = raw.map((o) => (typeof o === 'string' ? o : o?.name || o?.label || o?.value || String(o))).filter(Boolean);
    return Array.from(new Set(list));
  }, []);

  const childrenCountOptions = useMemo(() => {
    return Array.from({ length: 20 }, (_, i) => {
      const num = i + 1;
      let label = `${num}`;
      if (num === 1) label = '1 (طفل واحد)';
      else if (num === 2) label = '2 (طفلان)';
      else if (num <= 10) label = `${num} أطفال`;
      else label = `${num} طفلًا`;
      return { value: String(num), label };
    });
  }, []);

  const smokingOptions = useMemo(() => {
    let raw: any[] = [];
    try {
      const opts = dataService.db.getRegistrationOptions('smokingOptions');
      if (Array.isArray(opts) && opts.length > 0) raw = opts;
    } catch (err) {}
    if (!raw || raw.length === 0) raw = C.SMOKING_OPTIONS;
    const list = raw.map((o) => (typeof o === 'string' ? o : o?.name || o?.label || o?.value || String(o))).filter(Boolean);
    return Array.from(new Set(list));
  }, []);

  const religionLevelOptions = useMemo(() => {
    try {
      const opts = dataService.db.getRegistrationOptions('religionLevels');
      if (Array.isArray(opts) && opts.length > 0) return opts;
    } catch (err) {}
    return C.RELIGION_LEVELS;
  }, []);

  const maritalMaleOptions = useMemo(() => {
    let opts: any[] = [];
    try {
      opts = dataService.db.getRegistrationOptions('maritalMale');
    } catch (err) {}
    if (!Array.isArray(opts) || opts.length === 0) opts = getSelfMaritalOptions('male');
    return opts.map((item) => {
      if (typeof item === 'string') {
        let val = item;
        if (item === 'أعزب') val = 'single';
        else if (item === 'مطلق') val = 'divorced';
        else if (item === 'أرمل') val = 'widower';
        else if (item === 'متزوج') val = 'married';
        return { value: val, label: item };
      }
      return item;
    });
  }, []);

  const maritalFemaleOptions = useMemo(() => {
    let opts: any[] = [];
    try {
      opts = dataService.db.getRegistrationOptions('maritalFemale');
    } catch (err) {}
    if (!Array.isArray(opts) || opts.length === 0) opts = getSelfMaritalOptions('female');
    return opts.map((item) => {
      if (typeof item === 'string') {
        let val = item;
        if (item === 'عزباء') val = 'single';
        else if (item === 'مطلقة') val = 'divorced';
        else if (item === 'أرملة') val = 'widow';
        return { value: val, label: item };
      }
      return item;
    });
  }, []);

  // إضافة مدينة مقترحة
  const handleAddCity = (country: string) => (name: string) => {
    return dataService.db.addPendingGeo('city', name, country, form.nickname || form.realName || 'عضو جديد', 'register');
  };

  const handleAddCountry = (name: string) => {
    return dataService.db.addPendingGeo('country', name, '', form.nickname || form.realName || 'عضو جديد', 'register');
  };

  const handleAddNationality = (name: string) => {
    return dataService.db.addPendingGeo('nationality', name, form.country || '', form.nickname || form.realName || 'عضو جديد', 'register');
  };

  // التحقق من صحة كل خطوة
  const validateStep = (s: number): boolean => {
    const e: Record<string, string> = {};

    // ====== الخطوة 0: الهوية الأساسية والإقامة ======
    if (s === 0) {
      if (!form.gender) e.gender = 'الرجاء تحديد الجنس (ذكر / أنثى)';
      if (!form.nickname.trim()) e.nickname = 'الرجاء إدخال الاسم المستعار (اسم العرض)';

      const dateParts = form.birthDate ? form.birthDate.split('-') : [];
      const dateComplete = dateParts.length === 3 && dateParts[0] && dateParts[1] && dateParts[2];
      if (!dateComplete) e.birthDate = 'الرجاء اختيار السنة والشهر واليوم';
      else if (form.age < 16) e.birthDate = 'يجب أن يكون عمرك 16 سنة على الأقل لإنشاء حساب';

      if (!form.country) e.country = 'الرجاء اختيار دولة الإقامة';
      if (!form.city) e.city = 'الرجاء اختيار المدينة';
      if (!form.district.trim()) e.district = 'الرجاء إدخال المنطقة / الحي';

      if (!form.nationalityMode) e.nationalityMode = 'الرجاء تحديد الجنسية';
      if (form.nationalityMode === 'byCountry') {
        if (!form.nationality.trim()) e.nationality = 'الرجاء اختيار الجنسية';
        if ((form.nationality === 'أخرى' || form.nationality === 'جنسية أخرى') && !form.nationalityOther.trim()) {
          e.nationalityOther = 'الرجاء كتابة اسم الجنسية';
        }
      }

      if (!form.sect) e.sect = 'الرجاء اختيار المذهب الديني';
      if ((form.sect === 'أخرى' || form.sect === 'مذهب آخر') && !form.sectOther.trim()) e.sectOther = 'الرجاء كتابة المذهب';

      if (!form.maritalStatus) e.maritalStatus = 'الرجاء اختيار الحالة الاجتماعية';
    }

    // ====== الخطوة 1: المظهر، التعليم والعمل، والنبذة ======
    if (s === 1) {
      if (!form.height || Number(form.height) < 80 || Number(form.height) > 300) {
        e.height = 'الرجاء كتابة الطول الصحيح (بين 80 و 300 سم)';
      }
      if (!form.weight || Number(form.weight) < 20 || Number(form.weight) > 300) {
        e.weight = 'الرجاء كتابة الوزن الصحيح (بين 20 و 300 كجم)';
      }
      if (!form.skinColor) e.skinColor = 'الرجاء اختيار لون البشرة';
      if (!form.ethnicity?.trim()) e.ethnicity = 'الرجاء كتابة العرق / الأصل';
      if (!form.health?.trim()) e.health = 'الرجاء كتابة الحالة الصحية';
      if (!form.smoking) e.smoking = 'الرجاء اختيار حالة التدخين';
      if (!form.education) e.education = 'الرجاء اختيار المؤهل الدراسي';
      if (!form.workType) e.workType = 'الرجاء اختيار نوع جهة العمل';
      if (form.workType && form.workType !== 'بدون عمل' && !form.jobTitle.trim()) e.jobTitle = 'الرجاء كتابة المسمى الوظيفي';
      if (!form.housing) e.housing = 'الرجاء اختيار نوع السكن';
      if (form.bio.trim().length < 20) e.bio = 'النبذة قصيرة جدًا (20 حرفًا على الأقل)';
    }

    // ====== الخطوة 2: مواصفات الشريك ======
    if (s === 2) {
      // لا توجد قيود إجبارية معطلة لحرية اختيار الشريك
    }

    // ====== الخطوة 3: بيانات الحساب والأمان ======
    if (s === 3) {
      if (!form.realName.trim()) e.realName = 'الرجاء إدخال الاسم الكامل (الرباعي الحقيقي)';
      
      // تحقق من اسم المستخدم / اليوزر
      if (!form.username.trim()) {
        e.username = 'الرجاء إدخال اسم المستخدم (اليوزر)';
      } else if (!/^[a-z0-9_]{3,20}$/.test(form.username)) {
        e.username = 'يجب أن يتكون اسم المستخدم من 3 إلى 20 حرفًا إنجليزيًا أو أرقام أو شرطة سفلية (_) فقط';
      } else {
        const usernameExists = members.some((m) => m.username?.toLowerCase() === form.username.toLowerCase());
        if (usernameExists) {
          e.username = 'اسم المستخدم هذا محجوز بالفعل، يرجى اختيار اسم مستخدم آخر';
        }
      }

      if (!form.whatsapp || !form.whatsapp.trim()) {
        e.whatsapp = 'الرجاء إدخال رقم الواتساب الخاص بك للتواصل مع الإدارة';
      } else {
        const digitsOnly = form.whatsapp.replace(/\D/g, '');
        if (digitsOnly.length < 7) {
          e.whatsapp = 'رقم الواتساب غير مكتمل، يرجى التأكد من اختيار رمز الدولة وكتابة الرقم بشكل صحيح';
        }
      }

      if (!form.email.trim()) e.email = 'الرجاء إدخال البريد الإلكتروني';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'صيغة البريد الإلكتروني غير صحيحة';
      else if (emailTaken && lastCheckedEmail.current === form.email.trim().toLowerCase()) {
        e.email = 'البريد الإلكتروني هذا مستخدم بالفعل بحساب آخر';
      }

      if (!form.password) e.password = 'الرجاء إدخال كلمة المرور';
      else if (form.password.length < 6) e.password = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';

      if (!form.passwordConfirm) e.passwordConfirm = 'الرجاء تأكيد كلمة المرور';
      else if (form.password !== form.passwordConfirm) e.passwordConfirm = 'كلمتا المرور غير متطابقتين';
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNext = () => {
    if (!validateStep(step)) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    if (step < STEPS.length - 1) setStep(step + 1);
    else handleSubmit();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStepClick = (targetStep: number) => {
    if (targetStep < step) {
      setStep(targetStep);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (targetStep === step + 1) {
      handleNext();
    }
  };

  const handleSubmit = async () => {
    setSubmitError('');
    setSubmitting(true);
    try {
      // 1) إنشاء حساب مصادقة حقيقي عبر Supabase Auth (بريد + كلمة مرور)
      const { data, error: signUpError } = await supabase.auth.signUp({ email: form.email.trim(), password: form.password });
      if (signUpError) {
        setSubmitError(signUpError.message.includes('already') ? 'البريد الإلكتروني هذا مستخدم بالفعل بحساب آخر' : signUpError.message);
        setSubmitting(false);
        return;
      }
      if (!data.session) {
        // يتطلب المشروع تأكيد البريد الإلكتروني قبل تفعيل الجلسة
        setSubmitError('تم إنشاء الحساب! يرجى تأكيد بريدك الإلكتروني من الرسالة المُرسلة إليك ثم تسجيل الدخول.');
        setSubmitting(false);
        return;
      }
      // 2) إنشاء الملف الشخصي الفعلي مرتبطاً بحساب المصادقة (الجلسة تُرفق تلقائياً مع الطلب)
      const result = await registerNewMember(form);
      if (!result.ok) {
        setSubmitError(result.error || 'تعذّر إنشاء الملف الشخصي، حاول مرة أخرى');
        setSubmitting(false);
        return;
      }
      navigate('/profile');
    } catch (err: any) {
      setSubmitError(err?.message || 'حدث خطأ غير متوقع، حاول مرة أخرى');
    } finally {
      setSubmitting(false);
    }
  };

  const progress = ((step + 1) / STEPS.length) * 100;

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-cream-50 py-6 px-4">
      <div className="max-w-2xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-navy-600 hover:text-gold-700 font-cairo font-semibold text-sm mb-5 transition-colors">
          <ArrowLeft className="w-4 h-4" /> العودة للرئيسية
        </Link>

        <div className="bg-white rounded-3xl shadow-luxe border border-cream-200/60 overflow-hidden">
          {/* Header مع شريط التقدم النقر الذكي */}
          <div className="bg-navy-gradient p-5 sm:p-6">
            <div className="flex items-center justify-between mb-3">
              <h1 className="font-cairo font-bold text-white text-lg">إنشاء حساب جديد</h1>
              <span className="text-gold-300 font-cairo font-bold text-sm">
                الخطوة {step + 1} من {STEPS.length}
              </span>
            </div>
            <ProgressBar value={progress} />
            <div className="flex justify-between mt-3">
              {STEPS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => handleStepClick(i)}
                  disabled={i > step + 1}
                  className={`flex flex-col items-center gap-1 flex-1 transition-all ${
                    i <= step ? 'cursor-pointer hover:opacity-90' : 'cursor-not-allowed opacity-60'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    i < step ? 'bg-emerald-500 text-white shadow-sm' :
                    i === step ? 'bg-gold-gradient text-navy-900 shadow-md ring-2 ring-gold-300/50' :
                    'bg-white/10 text-cream-200/50'
                  }`}>
                    {i < step ? <Check className="w-4 h-4" /> : i + 1}
                  </div>
                  <span className={`text-[10px] font-cairo font-semibold hidden sm:block ${i <= step ? 'text-gold-300' : 'text-cream-200/40'}`}>
                    {s.title}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* محتوى الخطوة */}
          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              {/* ====== الخطوة 0: الهوية الأساسية والإقامة ====== */}
              {step === 0 && (
                <motion.div key="s0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={User} title="الهوية الأساسية والإقامة" desc="حدد بياناتك الاجتماعية والجغرافية الأساسية لتخصيص البحث والتوافق" />

                  {/* 1. تحديد الجنس أولاً */}
                  <Field label="الجنس" required error={errors.gender} hint="لتخصيص الخيارات ونظام المطابقة المعتمد">
                    <div className="grid grid-cols-2 gap-3">
                      <ChoiceCard
                        active={isMale}
                        onClick={() => {
                          setForm((prev) => ({
                            ...prev,
                            gender: 'male',
                            maritalStatus: '',
                            pMaritalStatus: '',
                            nationality: prev.nationalityMode === 'same' && prev.country ? getNationalityForCountry(prev.country, 'male') : prev.nationality,
                          }));
                          setErrors((prev) => ({ ...prev, gender: '', maritalStatus: '', nationality: '' }));
                        }}
                        icon={<div className={`w-12 h-12 rounded-full flex items-center justify-center ${isMale ? 'bg-blue-500' : 'bg-cream-100'}`}><Mars className={`w-6 h-6 ${isMale ? 'text-white' : 'text-navy-400'}`} /></div>}
                        title="ذكر"
                      />
                      <ChoiceCard
                        active={isFemale}
                        onClick={() => {
                          setForm((prev) => ({
                            ...prev,
                            gender: 'female',
                            maritalStatus: '',
                            pMaritalStatus: '',
                            nationality: prev.nationalityMode === 'same' && prev.country ? getNationalityForCountry(prev.country, 'female') : prev.nationality,
                          }));
                          setErrors((prev) => ({ ...prev, gender: '', maritalStatus: '', nationality: '' }));
                        }}
                        icon={<div className={`w-12 h-12 rounded-full flex items-center justify-center ${isFemale ? 'bg-rose-500' : 'bg-cream-100'}`}><Venus className={`w-6 h-6 ${isFemale ? 'text-white' : 'text-navy-400'}`} /></div>}
                        title="أنثى"
                      />
                    </div>
                  </Field>

                  {/* 2. الاسم المستعار / اسم العرض */}
                  <Field
                    label={
                      <div className="flex items-center justify-between w-full">
                        <span>الاسم المستعار (اسم العرض بالمنصة)</span>
                        <span className="text-[10px] bg-blue-100 text-blue-800 px-2 py-0.5 rounded-md font-cairo font-bold">👁️ ظاهر بالأعضاء</span>
                      </div>
                    }
                    required
                    error={errors.nickname}
                    hint="الاسم الظاهر للأعضاء في بحث المنصة والملف الشخصي العام (مثال: أبو عبدالله، باحثة عن الستر)"
                  >
                    <TextInput
                      value={form.nickname}
                      onChange={(v) => {
                        set('nickname', v);
                        if (!form.username) {
                          const cleanedNick = v.trim();
                          if (cleanedNick) set('username', translitArabicToEnglish(cleanedNick));
                        }
                      }}
                      placeholder={isMale ? 'مثال: أبو عبدالله، القحطاني' : 'مثال: باحثة عن الستر، أم محمد'}
                    />
                  </Field>

                  {/* 3. تاريخ الميلاد والعمر */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="تاريخ الميلاد" required error={errors.birthDate} hint="اختر السنة ثم الشهر ثم اليوم">
                      <DateSelect value={form.birthDate} onChange={handleBirthDateChange} />
                    </Field>
                    <Field label="العمر (محسوب تلقائيًا)">
                      <div className="px-4 py-3 rounded-xl bg-gold-300/10 border-2 border-gold-300/40 flex items-center justify-between h-full">
                        <span className="text-xs text-navy-600 font-cairo">العمر الحالي:</span>
                        <div className="flex items-baseline gap-1">
                          <span className="font-cairo font-extrabold text-2xl text-gradient-gold">
                            {form.age > 0 ? form.age : '—'}
                          </span>
                          {form.age > 0 && <span className="text-navy-500 font-tajawal text-xs">سنة</span>}
                        </div>
                      </div>
                    </Field>
                  </div>

                  {/* 4. دولة الإقامة والمدينة والحي */}
                  <Field label="دولة الإقامة الحالية" required error={errors.country} hint="الدولة التي تقيم فيها حالياً">
                    <SearchableSelect
                      value={form.country}
                      onChange={setCountryAndSyncNationality}
                      options={countryOptions}
                      placeholder="ابحث واختر الدولة"
                      searchPlaceholder="اكتب اسم الدولة..."
                      allowAddNew
                      onAddNew={(newCountry) => {
                        setCountryAndSyncNationality(newCountry);
                        set('countryOther', newCountry);
                        handleAddCountry(newCountry);
                        return { ok: true };
                      }}
                      addNewLabel="إذا لم تجد دولتك؟ اضغط هنا لكتابة اسم الدولة"
                      addNewPlaceholder="اكتب اسم الدولة..."
                    />
                  </Field>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="المدينة" required error={errors.city || errors.cityOther}>
                      <SearchableSelect
                        value={form.city}
                        onChange={(v) => {
                          set('city', v);
                          if (v !== 'أخرى') set('cityOther', '');
                        }}
                        options={cities}
                        placeholder={form.country ? 'ابحث واختر المدينة' : 'اختر الدولة أولًا'}
                        searchPlaceholder="اكتب اسم المدينة..."
                        disabled={!form.country}
                        allowAddNew={!!form.country}
                        onAddNew={(newCity) => {
                          set('city', newCity);
                          set('cityOther', newCity);
                          handleAddCity(form.country)(newCity);
                          return { ok: true };
                        }}
                        addNewLabel="إذا لم تجد مدينتك؟ اضغط هنا لكتابة اسم المدينة"
                        addNewPlaceholder="اكتب اسم مدينتك..."
                      />
                    </Field>
                    <Field label="المنطقة / الحي" required error={errors.district} hint="الحي أو المنطقة التفصيلية">
                      <TextInput value={form.district} onChange={(v) => set('district', v)} placeholder="مثال: حي العليا، الملقا..." />
                    </Field>
                  </div>

                  {/* 5. الجنسية والمذهب */}
                  <Field label="الجنسية" required error={errors.nationalityMode || errors.nationality}>
                    <div className="space-y-3">
                      <RadioGroup
                        options={[
                          { value: 'same', label: form.country ? `نعم، جنسيتي ${getNationalityForCountry(form.country, form.gender as any) || form.country}` : 'نعم، نفس دولة الإقامة' },
                          { value: 'byCountry', label: 'اختر الجنسية / الدولة' },
                        ]}
                        value={form.nationalityMode}
                        onChange={(v) => {
                          set('nationalityMode', v);
                          if (v === 'same' && form.country) {
                            set('nationality', getNationalityForCountry(form.country, form.gender as any));
                          } else {
                            set('nationality', '');
                          }
                        }}
                        columns={2}
                      />

                      {form.nationalityMode === 'byCountry' && (
                        <div className="space-y-2 p-3 bg-cream-50 rounded-xl border border-cream-200">
                          <label className="text-xs text-navy-700 font-cairo font-bold block">اختر جنسيتك أو الدولة التي تحمل جنسيتها:</label>
                          <SearchableSelect
                            value={form.nationality}
                            onChange={(v) => {
                              set('nationality', v);
                              set('nationalityOther', '');
                            }}
                            options={nationalityOptions}
                            placeholder="ابحث واختر الجنسية..."
                            searchPlaceholder="اكتب اسم الجنسية أو الدولة..."
                            allowAddNew
                            onAddNew={(newNat) => {
                              set('nationality', newNat);
                              set('nationalityOther', newNat);
                              handleAddNationality(newNat);
                              return { ok: true };
                            }}
                            addNewLabel="إذا لم تجد جنسيتك؟ اضغط هنا لكتابتها"
                            addNewPlaceholder="اكتب اسم الجنسية أو الدولة..."
                          />
                          {form.nationality && (
                            <p className="text-xs text-emerald-700 font-tajawal">
                              الجنسية المحددة: <span className="font-bold">{form.nationalityOther || form.nationality}</span>
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </Field>

                  <Field label="المذهب" required error={errors.sect} hint="المذهب الديني المتبع">
                    <RadioGroup
                      options={sectOptions.map((s) => ({ value: s, label: s }))}
                      value={form.sect}
                      onChange={(v) => set('sect', v)}
                      columns={3}
                    />
                    {(form.sect === 'أخرى' || form.sect === 'مذهب آخر') && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-2">
                        <TextInput
                          value={form.sectOther}
                          onChange={(v) => set('sectOther', v)}
                          placeholder="اكتب المذهب بالتفصيل..."
                        />
                        {errors.sectOther && <p className="text-xs text-rose-deep font-tajawal mt-1">{errors.sectOther}</p>}
                      </motion.div>
                    )}
                  </Field>

                  {/* 6. الحالة الاجتماعية ونوع الزواج */}
                  <Field label="الحالة الاجتماعية" required error={errors.maritalStatus}>
                    <RadioGroup
                      options={isMale ? maritalMaleOptions : maritalFemaleOptions}
                      value={form.maritalStatus}
                      onChange={(v) => set('maritalStatus', v)}
                      columns={isMale ? 4 : 3}
                    />
                  </Field>

                  <Field label="نوع الزواج المطلوب" required error={errors.marriageType} hint="اختر نوع الزواج المطلوب (معلن، مسيار، أو لا مانع لكلا النوعين)">
                    <RadioGroup
                      options={[
                        { value: 'announced', label: 'معلن' },
                        { value: 'misyar', label: 'مسيار' },
                        { value: 'both', label: 'لا مانع (معلن أو مسيار)' },
                      ]}
                      value={form.marriageType || 'announced'}
                      onChange={(v) => set('marriageType', v)}
                      columns={3}
                    />
                  </Field>

                  {/* حقول مطلقة/أرملة/أرمل — الأبناء */}
                  {['divorced', 'widower', 'widow', 'widowed', 'مطلق', 'مطلقة', 'أرمل', 'أرملة'].includes(form.maritalStatus) && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
                      <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                        <User className="w-4 h-4 text-gold-600" /> معلومات الأبناء
                      </h4>
                      <Field label={isMale ? 'هل لديك أبناء؟' : 'هل لديكِ أبناء؟'}>
                        <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
                      </Field>
                      {form.hasChildren === 'yes' && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid sm:grid-cols-2 gap-4">
                          <Field label="عدد الأبناء (اختر من 1 إلى 20)">
                            <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={childrenCountOptions} placeholder="اختر عدد الأبناء" />
                          </Field>
                          <Field label={isMale ? 'هل الأبناء يعيشون معك؟' : 'هل الأبناء يعيشون معكِ؟'}>
                            <RadioGroup options={C.YES_NO} value={form.childrenLiveWith} onChange={(v) => set('childrenLiveWith', v)} />
                          </Field>
                        </motion.div>
                      )}
                    </motion.div>
                  )}

                  {/* حقول متزوج (للرجال) */}
                  {isMale && ['married', 'متزوج'].includes(form.maritalStatus) && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
                      <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                        <User className="w-4 h-4 text-gold-600" /> تفاصيل الزواج الحالي
                      </h4>
                      <Field label="عدد الزوجات الحالي" required>
                        <RadioGroup options={C.WIFE_COUNT} value={form.wifeCount} onChange={(v) => set('wifeCount', v)} columns={3} />
                      </Field>
                      <Field label="هل لديك أبناء؟">
                        <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
                      </Field>
                      {form.hasChildren === 'yes' && (
                        <Field label="كم عدد الأبناء؟ (من 1 إلى 20)">
                          <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={childrenCountOptions} placeholder="اختر عدد الأبناء" />
                        </Field>
                      )}
                      <Field label="هل تبحث عن زوجة أخرى؟">
                        <RadioGroup options={C.YES_NO} value={form.seekingWife} onChange={(v) => set('seekingWife', v)} />
                      </Field>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* ====== الخطوة 1: المظهر والعمل والنبذة ====== */}
              {step === 1 && (
                <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={FileText} title="المظهر والعمل والتعليم" desc="المواصفات الجسدية والوظيفية والنبذة التعريفية" />

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="الطول (كتابة)" required error={errors.height} hint="أدخل طولك بالسنتيمتر (من 80 إلى 300 سم)">
                      <div className="relative">
                        <TextInput
                          type="number"
                          min={80}
                          max={300}
                          value={form.height ? String(form.height) : ''}
                          onChange={(v) => set('height', v ? Number(v) : '')}
                          placeholder="اكتب الطول (80 - 300)"
                          className="pl-12"
                        />
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-navy-400 font-tajawal pointer-events-none">سم</span>
                      </div>
                    </Field>
                    <Field label="الوزن (كتابة)" required error={errors.weight} hint="أدخل وزنك بالكيلوغرام (من 20 إلى 300 كجم)">
                      <div className="relative">
                        <TextInput
                          type="number"
                          min={20}
                          max={300}
                          value={form.weight ? String(form.weight) : ''}
                          onChange={(v) => set('weight', v ? Number(v) : '')}
                          placeholder="اكتب الوزن (20 - 300)"
                          className="pl-12"
                        />
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-navy-400 font-tajawal pointer-events-none">كجم</span>
                      </div>
                    </Field>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="لون البشرة" required error={errors.skinColor}>
                      <SearchableSelect
                        value={form.skinColor}
                        onChange={(v) => {
                          set('skinColor', v);
                          set('skinColorOther', '');
                        }}
                        options={skinColorOptions}
                        placeholder="اختر لون البشرة"
                        searchPlaceholder="ابحث في ألوان البشرة..."
                        allowAddNew
                        onAddNew={(newColor) => {
                          set('skinColor', newColor);
                          set('skinColorOther', newColor);
                          try {
                            dataService.db.addPendingGeo('skinColor', newColor, '', form.nickname || form.realName || 'عضو جديد', 'register');
                          } catch (e) {}
                          return { ok: true };
                        }}
                        addNewLabel="إذا لم تجد لون بشرتك؟ اضغط هنا لكتابته"
                        addNewPlaceholder="اكتب لون بشرتك..."
                      />
                      {form.skinColor && form.skinColorOther && (
                        <p className="text-xs text-emerald-700 font-tajawal mt-1">
                          لون البشرة المحدد: <span className="font-bold">{form.skinColorOther}</span>
                        </p>
                      )}
                    </Field>
                    <Field label="العرق / الأصل" required error={errors.ethnicity} hint="اختر من القائمة المتاحة أو اكتب أصلك/عرقك بالتفصيل">
                      <div className="space-y-2">
                        <div className="flex flex-wrap gap-1.5">
                          {C.ETHNICITIES.map((eth) => (
                            <button
                              key={eth}
                              type="button"
                              onClick={() => {
                                if (eth === 'أخرى') {
                                  set('ethnicity', '');
                                } else {
                                  set('ethnicity', eth);
                                }
                              }}
                              className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold border transition-all ${
                                form.ethnicity === eth
                                  ? 'bg-gold-500 text-navy-950 border-gold-600 shadow-2xs'
                                  : 'bg-cream-50 text-navy-700 border-cream-200 hover:bg-cream-100'
                              }`}
                            >
                              {eth}
                            </button>
                          ))}
                        </div>
                        <TextInput
                          value={form.ethnicity}
                          onChange={(v) => set('ethnicity', v)}
                          placeholder="اكتب الأصل/العرق (مثال: قبيلي أصل وفصل، خضيري، عربي...)"
                        />
                      </div>
                    </Field>
                  </div>

                  <Field label="القبيلة / النسب" hint="اختياري — اكتب اسم القبيلة أو انتسابك">
                    <TextInput value={form.tribe} onChange={(v) => set('tribe', v)} placeholder="مثال: قبيلي، عتيبي، مطيري، قحطاني، خضيري..." />
                  </Field>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="الحالة الصحية" required error={errors.health}>
                      <TextInput value={form.health} onChange={(v) => set('health', v)} placeholder="ممتازة، سليم الحمد لله..." />
                    </Field>
                    <Field label={isFemale ? 'هل تدخنين؟' : 'هل تدخن؟'} required error={errors.smoking}>
                      <SelectInput value={form.smoking} onChange={(v) => set('smoking', v)} options={smokingOptions} placeholder="اختر" />
                    </Field>
                  </div>

                  <Field label="المؤهل الدراسي" required error={errors.education}>
                    <SelectInput value={form.education} onChange={(v) => set('education', v)} options={educationOptions} placeholder="اختر المؤهل" />
                  </Field>

                  <Field label="نوع جهة العمل" required error={errors.workType}>
                    <RadioGroup
                      options={workTypeOptions.map((w: any) => (typeof w === 'string' ? { value: w, label: w } : w))}
                      value={form.workType}
                      onChange={(v) => { set('workType', v); set('jobTitle', ''); }}
                      columns={3}
                    />
                  </Field>

                  {form.workType && form.workType !== 'بدون عمل' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                      <Field label="المسمى الوظيفي" required error={errors.jobTitle}>
                        <TextInput value={form.jobTitle} onChange={(v) => set('jobTitle', v)} placeholder="مثال: معلم، مهندس، موظف إداري..." />
                      </Field>
                    </motion.div>
                  )}

                  <Field label="نوع السكن" required error={errors.housing}>
                    <RadioGroup
                      options={housingOptions.map((h: any) => typeof h === 'string' ? { value: h, label: h } : h)}
                      value={form.housing}
                      onChange={(v) => set('housing', v)}
                      columns={2}
                    />
                  </Field>

                  {isFemale && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-rose-50 rounded-2xl p-4 border border-rose-200">
                      <h4 className="font-cairo font-bold text-rose-700 text-sm flex items-center gap-2">
                        <Heart className="w-4 h-4" /> خيارات خاصة
                      </h4>
                      <Field label="هل تقبلين التعدد؟">
                        <RadioGroup options={C.POLYGAMY_ACCEPT} value={form.acceptPolygamy} onChange={(v) => set('acceptPolygamy', v)} columns={1} />
                      </Field>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="هل تقبلين زوجًا مطلقًا؟">
                          <RadioGroup options={C.YES_NO} value={form.acceptDivorced} onChange={(v) => set('acceptDivorced', v)} />
                        </Field>
                        <Field label="هل تقبلين زوجًا لديه أبناء؟">
                          <RadioGroup options={C.YES_NO} value={form.acceptWithChildren} onChange={(v) => set('acceptWithChildren', v)} />
                        </Field>
                      </div>
                    </motion.div>
                  )}

                  <Field label="نبذة تعريفية عن نفسك" required error={errors.bio} hint={`${form.bio.length}/500 حرف (20 حرفًا على الأقل)`}>
                    <TextArea value={form.bio} onChange={(v) => set('bio', v)} placeholder="اكتب نبذة مختصرة عن شخصيتك، قيمك، وأهدافك المستقبليّة..." rows={4} />
                  </Field>
                </motion.div>
              )}

              {/* ====== الخطوة 2: مواصفات الشريك ====== */}
              {step === 2 && (
                <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={Heart} title={`مواصفات ${partnerTerms.partnerFullLabel} المطلوبة`} desc="حدد الخيارات الأساسية المطلوبة لشريك حياتك باختصار وسهولة" />

                  {/* 1. دولة الشريك المطلوبة */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
                    <label className="block text-xs font-cairo font-bold text-slate-800">
                      1. {partnerTerms.countryLabel}
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          set('pCountry', form.country || 'السعودية');
                          setPCountryCustomOpen(false);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          !pCountryCustomOpen && (form.pCountry === (form.country || 'السعودية') || form.pCountry === 'نفس دولتي')
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        ✓ نفس دولتي ({form.country || 'السعودية'})
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          set('pCountry', 'لا يهم');
                          setPCountryCustomOpen(false);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          !pCountryCustomOpen && form.pCountry === 'لا يهم'
                            ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        أي دولة / لا يهم
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setPCountryCustomOpen(true);
                          if (form.pCountry === 'لا يهم') {
                            set('pCountry', form.country || 'السعودية');
                          }
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          pCountryCustomOpen || (form.pCountry && form.pCountry !== 'لا يهم' && form.pCountry !== 'نفس دولتي')
                            ? 'bg-amber-500 text-white border-amber-500 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        تحديد دول معينة (دولة أو أكثر)
                      </button>
                    </div>

                    {(pCountryCustomOpen || (form.pCountry && form.pCountry !== 'لا يهم' && form.pCountry !== 'نفس دولتي')) && (
                      <div className="pt-2">
                        <Field label="الدول المطلوبة (يمكنك اختيار دولة واحدة أو عدة دول)" hint="اختر دولة أو عدة دول من القائمة">
                          <MultiSearchableSelect
                            values={pSelectedCountries}
                            onChange={(newCountries) => {
                              set('pCountry', newCountries.length > 0 ? newCountries.join('، ') : 'لا يهم');
                            }}
                            options={countryOptions}
                            placeholder="ابحث واختر الدول المطلوبة..."
                            searchPlaceholder="ابحث عن دولة..."
                            allowAddNew
                            onAddNew={(newCountry) => {
                              handleAddCountry(newCountry);
                              return { ok: true };
                            }}
                            addNewLabel="إذا لم تجد الدولة؟ اضغط هنا لكتابتها"
                          />
                        </Field>
                      </div>
                    )}
                  </div>

                  {/* 2. مدينة الشريك المطلوبة */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
                    <label className="block text-xs font-cairo font-bold text-slate-800">
                      2. {partnerTerms.cityLabel}
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          set('pCity', form.city || 'الرياض');
                          setPCityCustomOpen(false);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          !pCityCustomOpen && (form.pCity === (form.city || 'الرياض') || form.pCity === 'نفس مدينتي')
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        ✓ نفس مدينتي ({form.city || 'الرياض'})
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          set('pCity', 'لا يهم');
                          setPCityCustomOpen(false);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          !pCityCustomOpen && form.pCity === 'لا يهم'
                            ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        أي مدينة / لا يهم
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setPCityCustomOpen(true);
                          if (form.pCity === 'لا يهم') {
                            set('pCity', form.city || 'الرياض');
                          }
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          pCityCustomOpen || (form.pCity && form.pCity !== 'لا يهم' && form.pCity !== 'نفس مدينتي')
                            ? 'bg-amber-500 text-white border-amber-500 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        تحديد مدن معينة (مدينة أو أكثر)
                      </button>
                    </div>

                    {(pCityCustomOpen || (form.pCity && form.pCity !== 'لا يهم' && form.pCity !== 'نفس مدينتي')) && (
                      <div className="pt-2">
                        <Field label="المدن المطلوبة (يمكنك اختيار مدينة واحدة أو عدة مدن)" hint="اختر مدينة أو عدة مدن من القائمة">
                          <MultiSearchableSelect
                            values={pSelectedCities}
                            onChange={(newCities) => {
                              set('pCity', newCities.length > 0 ? newCities.join('، ') : 'لا يهم');
                            }}
                            options={pCities}
                            placeholder="ابحث واختر المدن المطلوبة..."
                            searchPlaceholder="ابحث عن مدينة..."
                            allowAddNew
                            onAddNew={(newCity) => {
                              handleAddCity(form.pCountry || form.country)(newCity);
                              return { ok: true };
                            }}
                            addNewLabel="إذا لم تجد المدينة؟ اضغط هنا لكتابتها"
                          />
                        </Field>
                      </div>
                    )}
                  </div>

                  {/* 3. الجنسية */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
                    <label className="block text-xs font-cairo font-bold text-slate-800">
                      3. {partnerTerms.nationalityLabel}
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          set('pNationality', 'نفس جنسيتي');
                          setPNationalityCustomOpen(false);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          !pNationalityCustomOpen && form.pNationality === 'نفس جنسيتي'
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        ✓ نفس جنسيتي
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          set('pNationality', 'اقبل اجنبي');
                          setPNationalityCustomOpen(false);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          !pNationalityCustomOpen && (form.pNationality === 'اقبل اجنبي' || form.pNationality === 'أقبل أجنبي' || form.pNationality === 'لا يهم')
                            ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        اقبل اجنبي (أية جنسية)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setPNationalityCustomOpen(true);
                          if (form.pNationality === 'نفس جنسيتي' || form.pNationality === 'اقبل اجنبي' || form.pNationality === 'أقبل أجنبي' || form.pNationality === 'لا يهم') {
                            set('pNationality', '');
                          }
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          pNationalityCustomOpen || (form.pNationality && form.pNationality !== 'نفس جنسيتي' && form.pNationality !== 'اقبل اجنبي' && form.pNationality !== 'أقبل أجنبي' && form.pNationality !== 'لا يهم')
                            ? 'bg-amber-500 text-white border-amber-500 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        تحديد جنسيات معينة
                      </button>
                    </div>

                    {(pNationalityCustomOpen || (form.pNationality && form.pNationality !== 'نفس جنسيتي' && form.pNationality !== 'اقبل اجنبي' && form.pNationality !== 'أقبل أجنبي' && form.pNationality !== 'لا يهم')) && (
                      <div className="pt-2">
                        <Field label="الجنسيات المطلوبة (يمكنك اختيار جنسية واحدة أو عدة جنسيات)" hint="اختر جنسية واحدة أو أكثر">
                          <MultiSearchableSelect
                            values={pSelectedNationalities}
                            onChange={(newNats) => {
                              set('pNationality', newNats.length > 0 ? newNats.join('، ') : 'اقبل اجنبي');
                            }}
                            options={partnerNationalityOptions}
                            placeholder="ابحث واختر الجنسيات المطلوبة..."
                            searchPlaceholder="ابحث عن جنسية..."
                            allowAddNew
                            onAddNew={(newNat) => {
                              handleAddNationality(newNat);
                              return { ok: true };
                            }}
                            addNewLabel="إذا لم تجد الجنسية؟ اضغط هنا لكتابتها"
                          />
                        </Field>
                      </div>
                    )}
                  </div>

                  {/* 4. العمر */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <label className="block text-xs font-cairo font-bold text-slate-800">
                        4. {partnerTerms.ageLabel}
                      </label>
                      <span className="text-xs font-cairo font-extrabold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                        {(!form.pAgeMin && !form.pAgeMax) || (Number(form.pAgeMin) === 0 && Number(form.pAgeMax) === 0)
                          ? 'غير محدد (أي عمر)'
                          : `من ${form.pAgeMin || 'أي عمر'} إلى ${form.pAgeMax || 'أي عمر'} سنة`}
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => { set('pAgeMin', ''); set('pAgeMax', ''); }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold border transition-all ${
                          (!form.pAgeMin && !form.pAgeMax) || (Number(form.pAgeMin) === 0 && Number(form.pAgeMax) === 0)
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        غير محدد / أي عمر
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="text-[11px] text-slate-600 font-cairo font-bold mb-1 block">الحد الأدنى للعمر (من)</label>
                        <input
                          type="number"
                          min={16}
                          max={90}
                          value={form.pAgeMin || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            set('pAgeMin', val === '' ? '' : Number(val));
                          }}
                          placeholder="مثال: 20 (أو اتركه فارغاً)"
                          className="w-full px-4 py-2.5 rounded-xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-slate-600 font-cairo font-bold mb-1 block">الحد الأقصى للعمر (إلى)</label>
                        <input
                          type="number"
                          min={16}
                          max={90}
                          value={form.pAgeMax || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            set('pAgeMax', val === '' ? '' : Number(val));
                          }}
                          placeholder="مثال: 45 (أو اتركه فارغاً)"
                          className="w-full px-4 py-2.5 rounded-xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900"
                        />
                      </div>
                    </div>
                  </div>

                  {/* 5. الحالة الاجتماعية (خيارات متعددة) */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
                    <label className="block text-xs font-cairo font-bold text-slate-800">
                      5. {partnerTerms.maritalLabel} (يمكنك اختيار أكثر من خيار)
                    </label>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => set('pMaritalStatus', 'لا يهم')}
                        className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                          pSelectedMarital.includes('لا يهم')
                            ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        لا يهم / الجميع
                      </button>
                      {getPartnerMaritalOptions(form.gender as any).map((opt) => {
                        const isSelected = pSelectedMarital.includes(opt);
                        return (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => {
                              let updated: string[];
                              if (isSelected) {
                                updated = pSelectedMarital.filter((m) => m !== opt && m !== 'لا يهم');
                              } else {
                                updated = [...pSelectedMarital.filter((m) => m !== 'لا يهم'), opt];
                              }
                              if (updated.length === 0) updated = ['لا يهم'];
                              set('pMaritalStatus', updated.join('، '));
                            }}
                            className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold transition-all border flex items-center gap-1.5 ${
                              isSelected
                                ? 'bg-gold-300/30 text-navy-900 border-gold-500 shadow-2xs'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5 text-navy-900" />}
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 6. قبول الأطفال (لا يظهر إذا تم اختيار عزباء/أعزب فقط) */}
                  {!isSingleOnly && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
                      <label className="block text-xs font-cairo font-bold text-slate-800">
                        6. {partnerTerms.childrenLabel}
                      </label>
                      <RadioGroup
                        options={[
                          { value: 'نعم', label: 'نعم (أقبل)' },
                          { value: 'لا', label: 'لا (أفضل بدون أطفال)' },
                          { value: 'لا يهم', label: 'لا يهم' },
                          { value: 'بشرط ألا يعيشوا معنا', label: 'بشرط ألا يعيشوا معنا' },
                        ]}
                        value={form.pAcceptChildren || 'لا يهم'}
                        onChange={(v) => set('pAcceptChildren', v)}
                        columns={2}
                      />
                    </motion.div>
                  )}

                  {/* 7. ملاحظات وصفات إضافية */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-2">
                    <label className="block text-xs font-cairo font-bold text-slate-800">
                      7. ملاحظات وصفات إضافية مرغوبة
                    </label>
                    <TextArea
                      value={form.pNotes}
                      onChange={(v) => set('pNotes', v)}
                      placeholder={partnerTerms.notesPlaceholder || "اكتب أي مواصفات أو تفاصيل إضافية ترغب بها في شريك حياتك..."}
                      rows={3}
                    />
                  </div>
                </motion.div>
              )}

              {/* ====== الخطوة 3: بيانات الحساب والأمان ====== */}
              {step === 3 && (
                <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={ShieldCheck} title="بيانات الحساب والأمان" desc="بيانات الحساب ووسائل التواصل الخاصة مع إدارة المنصة" />

                  {/* الاسم الكامل الحقيقي (سري) */}
                  <Field
                    label={
                      <div className="flex items-center justify-between w-full">
                        <span>الاسم الكامل الرباعي الحقيقي</span>
                        <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md font-cairo font-bold">🔒 سري للإدارة فقط</span>
                      </div>
                    }
                    required
                    error={errors.realName}
                    hint="سري بالكامل — للإدارة فقط للتحقق من هوية صاحب الحساب"
                  >
                    <TextInput
                      value={form.realName}
                      onChange={(v) => {
                        set('realName', v);
                        if (!form.username) {
                          const first = v.trim().split(' ')[0];
                          if (first) set('username', translitArabicToEnglish(first));
                        }
                      }}
                      placeholder="أدخل اسمك الرباعي الحقيقي"
                    />
                  </Field>

                  {/* اسم المستخدم / اليوزر الفريد */}
                  <Field
                    label={
                      <div className="flex items-center justify-between w-full">
                        <span>اسم المستخدم / اليوزر الفريد</span>
                        <span className="text-[10px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded-md font-cairo font-bold">🔒 معرف الحساب</span>
                      </div>
                    }
                    required
                    error={errors.username}
                    hint="معرف إنجليزي لملفك الشخصي بالمنصة (3-20 حرف/رقم بدون مسافات)"
                  >
                    <div className="flex gap-2 items-center">
                      <div className="relative flex-1">
                        <span className="absolute right-4 top-1/2 -translate-y-1/2 font-mono text-sm text-slate-400">@</span>
                        <TextInput
                          value={form.username}
                          onChange={(v) => {
                            const cleaned = v.toLowerCase().replace(/[^a-z0-9_]/g, '');
                            set('username', cleaned);
                          }}
                          placeholder="abu_abdullah"
                          className="pr-9 font-mono"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const base = form.nickname || form.realName || 'user';
                          const sug = translitArabicToEnglish(base) + '_' + Math.floor(100 + Math.random() * 900);
                          set('username', sug);
                        }}
                        className="px-3 py-3 rounded-xl bg-cream-100 text-navy-800 text-xs font-cairo font-bold hover:bg-cream-200 transition-colors whitespace-nowrap"
                      >
                        اقترح اسمًا
                      </button>
                    </div>
                  </Field>

                  {/* البريد الإلكتروني ورقم الواتساب */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field
                      label="البريد الإلكتروني"
                      required
                      error={errors.email}
                      hint={checkingEmail ? 'جارٍ التحقق من توفر البريد...' : 'لتسجيل الدخول واستعادة الحساب'}
                    >
                      <TextInput
                        value={form.email}
                        onChange={(v) => set('email', v)}
                        onBlur={() => checkEmailAvailability(form.email)}
                        placeholder="name@example.com"
                        type="email"
                      />
                    </Field>

                    <Field
                      label={
                        <div className="flex items-center justify-between w-full">
                          <span>رقم الواتساب للتواصل والإدارة</span>
                          <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md font-cairo font-bold">🔒 سري للإدارة</span>
                        </div>
                      }
                      required
                      error={errors.whatsapp}
                      hint="لتواصل الإدارة المباشر معك للتوفيق عند وجود اهتمام متطابق"
                    >
                      <PhoneInputWithCountryCode
                        value={form.whatsapp || ''}
                        onChange={(v) => {
                          set('whatsapp', v);
                          set('phone', v);
                        }}
                        placeholder="501234567"
                      />
                    </Field>
                  </div>

                  {/* كلمة المرور وتأكيدها ومقياس القوة */}
                  <div className="pt-3 border-t border-cream-200 space-y-4">
                    <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                      <Lock className="w-4 h-4 text-gold-600" /> تعيين كلمة المرور
                    </h4>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <Field label="كلمة المرور" required error={errors.password}>
                        <div className="relative">
                          <input
                            type={showPass ? 'text' : 'password'}
                            value={form.password}
                            onChange={(e) => set('password', e.target.value)}
                            placeholder="••••••••"
                            className="w-full pr-4 pl-12 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 text-sm transition-colors"
                          />
                          <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                            {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </Field>

                      <Field label="تأكيد كلمة المرور" required error={errors.passwordConfirm}>
                        <div className="relative">
                          <input
                            type={showPassConfirm ? 'text' : 'password'}
                            value={form.passwordConfirm}
                            onChange={(e) => set('passwordConfirm', e.target.value)}
                            placeholder="••••••••"
                            className="w-full pr-4 pl-12 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 text-sm transition-colors"
                          />
                          <button type="button" onClick={() => setShowPassConfirm(!showPassConfirm)} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                            {showPassConfirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </Field>
                    </div>

                    {/* مؤشر قوة كلمة المرور */}
                    {form.password && (
                      <div className="bg-cream-50 p-3 rounded-xl border border-cream-200 space-y-1.5">
                        <div className="flex justify-between items-center text-xs font-cairo">
                          <span className="text-slate-600">قوة كلمة المرور:</span>
                          <span className="font-bold text-slate-800">{passwordStrength.label}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className={`h-full ${passwordStrength.color} transition-all duration-300`} style={{ width: `${passwordStrength.percentage}%` }} />
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* ====== الخطوة 4: المراجعة النهائية ====== */}
              {step === 4 && (
                <motion.div key="s4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={Check} title="المراجعة والتأكيد" desc="راجع بياناتك قبل إكمال التسجيل ويمكنك التعديل على أي قسم" />

                  <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 flex items-start gap-3">
                    <Check className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-cairo font-bold text-emerald-800 text-sm">جاهز لإنشاء الحساب</p>
                      <p className="font-tajawal text-xs text-emerald-700 mt-1 leading-relaxed">
                        سيظهر حسابك مباشرة في البحث ولوحة الإدارة، ويمكنك تعديل التفاصيل لاحقاً من صفحة الملف الشخصي.
                      </p>
                    </div>
                  </div>

                  <ReviewSection title="الهوية والإقامة" onEdit={() => setStep(0)} rows={[
                    ['الجنس', form.gender === 'male' ? 'ذكر' : form.gender === 'female' ? 'أنثى' : '—'],
                    ['الاسم المستعار', form.nickname || '—'],
                    ['العمر وتاريخ الميلاد', form.birthDate ? `${form.birthDate} (${form.age} سنة)` : '—'],
                    ['الإقامة والمدينة', [form.country, form.city, form.district].filter(Boolean).join(' - ') || '—'],
                    ['الجنسية', form.nationalityMode === 'same' ? getNationalityForCountry(form.country, form.gender as any) : (form.nationalityOther || form.nationality || '—')],
                    ['الحالة الاجتماعية ونوع الزواج', `${normalizeMaritalLabel(form.maritalStatus, form.gender as any) || '—'} (${form.marriageType === 'misyar' ? 'مسيار' : form.marriageType === 'both' ? 'معلن أو مسيار' : 'معلن'})`],
                    ['المذهب', form.sectOther || form.sect || '—'],
                  ]} />

                  <ReviewSection title="المظهر والعمل والنبذة" onEdit={() => setStep(1)} rows={[
                    ['الطول والوزن', `${form.height || '—'} سم / ${form.weight || '—'} كجم`],
                    ['البشرة والعرق', `${form.skinColorOther || form.skinColor || '—'} - ${form.ethnicity || '—'}`],
                    ['التعليم', form.education || '—'],
                    ['العمل', [form.workType, form.jobTitle].filter(Boolean).join(' - ') || '—'],
                    ['السكن', form.housing || '—'],
                    ['نبذة', form.bio || '—'],
                  ]} />

                  <ReviewSection title={`مواصفات ${partnerTerms.partnerLabel}`} onEdit={() => setStep(2)} rows={[
                    ['الدولة والمدينة', [form.pCountry || 'لا يهم', form.pCity].filter(Boolean).join(' - ')],
                    ['الجنسية المطلوبة', form.pNationalityOther || form.pNationality || 'لا يهم'],
                    ['العمر المطلوبة', `من ${form.pAgeMin || 18} إلى ${form.pAgeMax || 80} سنة`],
                    ['الحالة الاجتماعية', form.pMaritalStatus || 'لا يهم'],
                    ['ملاحظات', form.pNotes || '—'],
                  ]} />

                  <ReviewSection title="بيانات الحساب والأمان" onEdit={() => setStep(3)} rows={[
                    ['الاسم الكامل الحقيقي', `${form.realName || '—'} (🔒 سري للإدارة)`],
                    ['اسم المستخدم / اليوزر', `@${form.username}`],
                    ['البريد الإلكتروني', form.email || '—'],
                    ['رقم الواتساب', `${form.whatsapp || '—'} (🔒 سري للإدارة)`],
                  ]} />
                </motion.div>
              )}
            </AnimatePresence>

            {submitError && (
              <div className="mt-5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-3 text-sm font-tajawal text-center">
                {submitError}
              </div>
            )}

            {/* أزرار التنقل */}
            <div className="flex items-center gap-3 mt-7">
              {step > 0 && (
                <button onClick={() => { setStep(step - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="flex items-center gap-1 px-5 py-3 rounded-2xl text-navy-600 font-cairo font-semibold hover:bg-cream-100 transition-colors">
                  <ArrowRight className="w-4 h-4" /> السابق
                </button>
              )}
              {step < STEPS.length - 1 ? (
                <Button onClick={handleNext} fullWidth size="lg">
                  التالي <ArrowLeft className="w-4 h-4" />
                </Button>
              ) : (
                <Button onClick={handleNext} fullWidth size="lg" className="shadow-gold" disabled={submitting}>
                  <Check className="w-5 h-5" /> {submitting ? 'جارٍ إنشاء الحساب...' : 'إكمال التسجيل وإنشاء الحساب'}
                </Button>
              )}
            </div>

            {step === 0 && (
              <p className="text-center text-sm text-navy-500 font-tajawal mt-5">
                لديك حساب بالفعل؟ <Link to="/login" className="text-gold-700 font-cairo font-bold hover:underline">سجّل الدخول</Link>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ icon: Icon, title, desc }: { icon: typeof User; title: string; desc: string }) {
  return (
    <div className="flex items-center gap-3 pb-4 border-b border-cream-200">
      <div className="w-11 h-11 rounded-xl bg-gold-300/15 flex items-center justify-center flex-shrink-0">
        <Icon className="w-6 h-6 text-gold-600" />
      </div>
      <div>
        <h2 className="font-cairo font-bold text-xl text-navy-900">{title}</h2>
        <p className="text-sm text-navy-500 font-tajawal">{desc}</p>
      </div>
    </div>
  );
}

function ReviewSection({ title, rows, onEdit }: { title: string; rows: Array<[string, string]>; onEdit: () => void }) {
  return (
    <div className="rounded-2xl bg-cream-50 border border-cream-200 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-cream-200">
        <h3 className="font-cairo font-bold text-navy-900 text-sm">{title}</h3>
        <button type="button" onClick={onEdit} className="text-xs font-cairo font-bold text-gold-700 hover:underline">
          تعديل
        </button>
      </div>
      <div className="divide-y divide-cream-200/70">
        {rows.map(([label, value]) => (
          <div key={label} className="grid grid-cols-3 gap-3 px-4 py-2.5">
            <span className="text-xs font-cairo font-bold text-navy-500">{label}</span>
            <span className="col-span-2 text-xs sm:text-sm font-tajawal text-navy-900 leading-relaxed break-words">{value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
