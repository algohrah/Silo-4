import { dataService } from '../../lib/data/DataService';
import { useState, useRef } from 'react';
import { Shield, Save, Check, Bell, Database, Settings, Lock, Clock, Download, Upload, RefreshCw, CheckCircle2, FileText } from 'lucide-react';
import PageHeader from '../../components/admin/PageHeader';
import { downloadFullSystemBackup, restoreFullSystemBackup, createFullSystemBackupData } from '../../lib/systemBackup';
import { useApp } from '../../lib/AppContext';

const SETTINGS_KEY = 'twafok_admin_security_settings_v1';

interface SecuritySettings {
  emailNotifs: boolean;
  smsNotifs: boolean;
  twoFactor: boolean;
  autoBackup: boolean;
  debugMode: boolean;
  cacheTimeout: string;
}

const DEFAULT_SETTINGS: SecuritySettings = {
  emailNotifs: true,
  smsNotifs: false,
  twoFactor: true,
  autoBackup: true,
  debugMode: false,
  cacheTimeout: '60',
};

function loadSettings(): SecuritySettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = dataService.db.settings.get(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return DEFAULT_SETTINGS;
}

function saveSettings(settings: SecuritySettings) {
  if (typeof window !== 'undefined') {
    try { dataService.db.settings.set(SETTINGS_KEY, JSON.stringify(settings)); } catch { /* ignore */ }
  }
}

interface ToggleProps {
  label: string;
  desc: string;
  icon: React.ElementType;
  value: boolean;
  onChange: (val: boolean) => void;
}

const Toggle = ({ label, desc, icon: Icon, value, onChange }: ToggleProps) => {
  return (
    <div className="flex items-center gap-3 py-3">
      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-slate-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-cairo font-semibold text-slate-800 text-sm pl-2">{label}</p>
        <p className="text-xs text-slate-400 font-tajawal">{desc}</p>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`w-12 h-7 rounded-full transition-colors relative flex-shrink-0 ${
          value ? 'bg-emerald-500' : 'bg-slate-300'
        }`}
      >
        <div
          className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${
            value ? 'right-1' : 'right-6'
          }`}
        />
      </button>
    </div>
  );
};

export default function AdminSecuritySettings() {
  const { showToast } = useApp();
  const [saved, setSaved] = useState(false);
  const [settings, setSettings] = useState<SecuritySettings>(loadSettings);
  const [importing, setImporting] = useState(false);
  const [previewBackup, setPreviewBackup] = useState<Record<string, unknown> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    saveSettings(settings);
    setSaved(true);
    showToast('تم حفظ إعدادات الأمان بنجاح', 'success');
    setTimeout(() => setSaved(false), 2500);
  };

  const handleExportBackup = () => {
    try {
      downloadFullSystemBackup();
      showToast('تم تصدير النسخة الاحتياطية الشاملة للبيانات بنجاح ✓', 'success');
    } catch {
      showToast('حدث خطأ أثناء تصدير النسخة الاحتياطية', 'error');
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        setPreviewBackup(parsed);
      } catch {
        showToast('ملف التصدير غير صريح، يرجى التأكد من اختيار ملف JSON صحيح', 'error');
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = () => {
    if (!previewBackup) return;
    setImporting(true);
    setTimeout(() => {
      const res = restoreFullSystemBackup(previewBackup);
      setImporting(false);
      if (res.success) {
        showToast(res.message, 'success');
        setPreviewBackup(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      } else {
        showToast(res.message, 'error');
      }
    }, 400);
  };

  const stats = createFullSystemBackupData().counts;

  return (
    <div className="space-y-5 text-right" dir="rtl">
      <PageHeader
        icon={Shield}
        title="الأمان والنظام"
        subtitle="إعدادات الأمان، الإشعارات، والنسخ الاحتياطي — تصدير واستيراد شامل لكافة البيانات"
        action={
          <button
            onClick={handleSave}
            aria-label="حفظ إعدادات الأمان"
            className={`flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm hover:bg-slate-800 transition-colors ${
              saved ? 'bg-emerald-500 hover:bg-emerald-600' : ''
            }`}
          >
            {saved ? <><Check className="w-4 h-4" /> تم الحفظ</> : <><Save className="w-4 h-4" /> حفظ</>}
          </button>
        }
      />

      {/* النسخ الاحتياطي الشامل والتصدير والاستيراد */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="font-cairo font-bold text-lg text-slate-900 flex items-center gap-2">
              <Database className="w-5 h-5 text-amber-500" /> النسخ الاحتياطي والتصدير/الاستيراد الشامل
            </h3>
            <p className="text-xs text-slate-500 font-tajawal mt-1">
              تصدير كافة بيانات المنصة في ملف موحد (الأعضاء، أسماء الخطابات والمكاتب، أرقام وتفاصيل الدفعات، المعاملات المالية، طلبات الاهتمام، والرحلات)، أو استعادتها مرة أخرى بالكامل.
            </p>
          </div>
          <button
            onClick={handleExportBackup}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 text-slate-900 font-cairo font-bold text-sm hover:bg-amber-400 transition-colors shadow-sm flex-shrink-0"
          >
            <Download className="w-4 h-4" /> تصدير كل البيانات (JSON)
          </button>
        </div>

        {/* إحصائيات البيانات الجاهزة للتصدير */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
            <div className="font-cairo font-bold text-slate-900 text-lg">{stats.membersCount}</div>
            <div className="text-[11px] text-slate-500 font-tajawal">عضو مسجل</div>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
            <div className="font-cairo font-bold text-slate-900 text-lg">{stats.officesCount}</div>
            <div className="text-[11px] text-slate-500 font-tajawal">خطابة ومكتب</div>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
            <div className="font-cairo font-bold text-slate-900 text-lg">{stats.batchesCount}</div>
            <div className="text-[11px] text-slate-500 font-tajawal">دفعة استيراد</div>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
            <div className="font-cairo font-bold text-slate-900 text-lg">{stats.transactionsCount}</div>
            <div className="text-[11px] text-slate-500 font-tajawal">معاملة مالية</div>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
            <div className="font-cairo font-bold text-slate-900 text-lg">{stats.requestsCount}</div>
            <div className="text-[11px] text-slate-500 font-tajawal">طلب ورحلة</div>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
            <div className="font-cairo font-bold text-slate-900 text-lg">{stats.inquiryMessagesCount}</div>
            <div className="text-[11px] text-slate-500 font-tajawal">رسالة استفسار</div>
          </div>
        </div>

        {/* قسم استعادة النسخة الاحتياطية */}
        <div className="bg-amber-50/40 rounded-xl p-4 border border-amber-200/60 space-y-3">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-amber-600" />
            <h4 className="font-cairo font-bold text-slate-900 text-sm">استيراد واستعادة نسخة احتياطية كاملة</h4>
          </div>
          <p className="text-xs text-slate-600 font-tajawal">
            قم باختيار ملف النسخة الاحتياطية المصدّر سابقاً لاستعادة جميع البيانات والإعدادات والخطابات والدفعات والمعاملات المالية فوراً.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-3 pt-1">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
              id="full-backup-upload"
            />
            <label
              htmlFor="full-backup-upload"
              className="cursor-pointer flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-300 font-cairo font-semibold text-xs text-slate-700 hover:bg-slate-50 transition-colors shadow-sm"
            >
              <FileText className="w-4 h-4 text-amber-500" /> اختيار ملف النسخة الاحتياطية (JSON)
            </label>

            {previewBackup && (
              <button
                onClick={handleConfirmRestore}
                disabled={importing}
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-emerald-600 text-white font-cairo font-bold text-xs hover:bg-emerald-700 transition-colors shadow-sm disabled:opacity-50"
              >
                {importing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                تأكيد واستعادة البيانات الآن
              </button>
            )}
          </div>

          {previewBackup && (
            <div className="mt-3 p-3 bg-white rounded-lg border border-slate-200 text-xs font-tajawal space-y-1.5 text-slate-700">
              <div className="font-cairo font-bold text-slate-900 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" /> تم تحليل الملف بنجاح:
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-slate-600">
                <div>• الأعضاء: <span className="font-bold text-slate-900">{(previewBackup as { counts?: { membersCount?: number }, data?: { members?: unknown[] } }).counts?.membersCount ?? (previewBackup as { data?: { members?: unknown[] } }).data?.members?.length ?? 0}</span></div>
                <div>• الخطابات: <span className="font-bold text-slate-900">{(previewBackup as { counts?: { officesCount?: number }, data?: { offices?: unknown[] } }).counts?.officesCount ?? (previewBackup as { data?: { offices?: unknown[] } }).data?.offices?.length ?? 0}</span></div>
                <div>• الدفعات: <span className="font-bold text-slate-900">{(previewBackup as { counts?: { batchesCount?: number }, data?: { batches?: unknown[] } }).counts?.batchesCount ?? (previewBackup as { data?: { batches?: unknown[] } }).data?.batches?.length ?? 0}</span></div>
                <div>• المعاملات: <span className="font-bold text-slate-900">{(previewBackup as { counts?: { transactionsCount?: number }, data?: { transactions?: unknown[] } }).counts?.transactionsCount ?? (previewBackup as { data?: { transactions?: unknown[] } }).data?.transactions?.length ?? 0}</span></div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2">
          <Shield className="w-5 h-5 text-amber-500" /> الأمان
        </h3>
        <div className="divide-y divide-slate-50">
          <Toggle
            label="المصادقة الثنائية"
            desc="حماية إضافية لحساب الإدارة"
            icon={Lock}
            value={settings.twoFactor}
            onChange={(val) => setSettings({ ...settings, twoFactor: val })}
          />
          <Toggle
            label="وضع التصحيح"
            desc="عرض الأخطاء التفصيلية للمطورين"
            icon={Settings}
            value={settings.debugMode}
            onChange={(val) => setSettings({ ...settings, debugMode: val })}
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2">
          <Bell className="w-5 h-5 text-amber-500" /> الإشعارات
        </h3>
        <div className="divide-y divide-slate-50">
          <Toggle
            label="إشعارات البريد الإلكتروني"
            desc="استقبال تنبيهات الأعضاء الجدد والطلبات"
            icon={Bell}
            value={settings.emailNotifs}
            onChange={(val) => setSettings({ ...settings, emailNotifs: val })}
          />
          <Toggle
            label="إشعارات SMS"
            desc="استقبال تنبيهات فورية على الجوال"
            icon={Bell}
            value={settings.smsNotifs}
            onChange={(val) => setSettings({ ...settings, smsNotifs: val })}
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200">
        <h3 className="font-cairo font-bold text-slate-900 mb-2 flex items-center gap-2">
          <Database className="w-5 h-5 text-amber-500" /> النظام
        </h3>
        <div className="divide-y divide-slate-50">
          <Toggle
            label="النسخ الاحتياطي التلقائي"
            desc="نسخ احتياطي يومي للبيانات"
            icon={Database}
            value={settings.autoBackup}
            onChange={(val) => setSettings({ ...settings, autoBackup: val })}
          />
          <div className="flex items-center gap-3 py-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
              <Clock className="w-5 h-5 text-slate-600" />
            </div>
            <div className="flex-1">
              <p className="font-cairo font-semibold text-slate-800 text-sm pl-2">مدة التخزين المؤقت (دقائق)</p>
              <p className="text-xs text-slate-400 font-tajawal">تحكم في أداء الموقع</p>
            </div>
            <input
              type="number"
              value={settings.cacheTimeout}
              onChange={(e) => setSettings({ ...settings, cacheTimeout: e.target.value })}
              className="w-20 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none text-center font-cairo font-bold text-slate-900 text-sm"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
