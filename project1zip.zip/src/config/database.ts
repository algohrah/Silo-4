export type DatabaseProvider = 'api' | 'local' | 'supabase';

export const DATABASE_CONFIG = {
  // الوضع الافتراضي: API — البيانات تُحفظ في قاعدة البيانات عبر مسارات API الخلفية
  PROVIDER: ((import.meta.env.VITE_DATABASE_PROVIDER as DatabaseProvider) || 'api') as DatabaseProvider,
};
