const yazl = require('yazl');
const { createWriteStream, mkdirSync, statSync } = require('fs');
const { join, dirname } = require('path');
const { execSync } = require('child_process');

const ROOT = process.cwd();
const OUTPUT = join(ROOT, 'public/downloads/tawafoq-marriage-platform.zip');
mkdirSync(dirname(OUTPUT), { recursive: true });

const zipfile = new yazl.ZipFile();

const files = execSync(`find . -type f \
  -not -path "./node_modules/*" \
  -not -path "./dist/*" \
  -not -path "./.git/*" \
  -not -path "./.vercel/*" \
  -not -path "./public/downloads/*" \
  -not -path "./.env" \
  -not -path "./vercel.json" \
  -not -path "./.vite-source-tags.js" \
  -not -name "*.zip" \
  -not -name "bun.lock" \
  -not -name "package-lock.json"`, { encoding: 'utf8' })
  .trim().split('\n').filter(Boolean);

console.log('Adding ' + files.length + ' files...');
for (const f of files) {
  const p = f.startsWith('./') ? f.slice(2) : f;
  zipfile.addFile(p, p);
}

zipfile.addBuffer(Buffer.from(
  'NEXT_PUBLIC_SUPABASE_URL="https://YOUR_PROJECT_REF.supabase.co"\n' +
  'NEXT_PUBLIC_SUPABASE_ANON_KEY="YOUR_SUPABASE_ANON_KEY"\n' +
  'SUPABASE_SERVICE_ROLE_KEY="YOUR_SUPABASE_SERVICE_ROLE_KEY"\n' +
  'VITE_SUPABASE_URL="https://YOUR_PROJECT_REF.supabase.co"\n' +
  'VITE_SUPABASE_ANON_KEY="YOUR_SUPABASE_ANON_KEY"\n' +
  'VITE_GOOGLE_CLIENT_ID="YOUR_GOOGLE_OAUTH_CLIENT_ID"\n' +
  'VITE_GOOGLE_AUTH_PROXY="https://designarena.ai/auth/google/callback"\n' +
  'FULLSTACK_PROJECT_REF="YOUR_PROJECT_REF"\n' +
  'FULLSTACK_RESTORE_API_URL="https://designarena.ai/api/fullstack-restore"\n'
), '.env.example');

zipfile.addBuffer(Buffer.from(JSON.stringify({
  env: {
    NEXT_PUBLIC_SUPABASE_URL: "https://YOUR_PROJECT_REF.supabase.co",
    NEXT_PUBLIC_SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY",
    SUPABASE_SERVICE_ROLE_KEY: "YOUR_SUPABASE_SERVICE_ROLE_KEY",
    VITE_SUPABASE_URL: "https://YOUR_PROJECT_REF.supabase.co",
    VITE_SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY",
    VITE_GOOGLE_CLIENT_ID: "YOUR_GOOGLE_OAUTH_CLIENT_ID",
    VITE_GOOGLE_AUTH_PROXY: "https://designarena.ai/auth/google/callback",
    FULLSTACK_PROJECT_REF: "YOUR_PROJECT_REF",
    FULLSTACK_RESTORE_API_URL: "https://designarena.ai/api/fullstack-restore"
  }
}, null, 2)), 'vercel.json.example');

zipfile.end();
const output = createWriteStream(OUTPUT);
zipfile.outputStream.pipe(output);
output.on('close', function() {
  const s = (statSync(OUTPUT).size / 1024 / 1024).toFixed(2);
  console.log('Done: ' + s + ' MB, ' + files.length + ' files');
});
