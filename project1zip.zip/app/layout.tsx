import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Imported Project',
  description: 'Ready to import user project files.',
  openGraph: {
    title: 'Imported Project',
    description: 'Ready to import user project files.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Imported Project',
    description: 'Ready to import user project files.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
