import { useState, useEffect, useMemo, useRef, ChangeEvent } from 'react';
import {
  Globe, MapPin, Plus, Trash2, Check, X, Search, Download, Upload,
  Clock, AlertCircle, CheckCircle2, XCircle, Edit3, FileJson, RefreshCw, GitMerge, FileText,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Modal from '../../components/ui/Modal';
import { type PendingCity, type ImportResult } from '../../lib/data/adapters/local/geoStore';
import { dataService } from '../../lib/data/DataService';

import { useApp } from '../../lib/AppContext';
const getCountries = () => dataService.db.getCountries();
const getCountryNames = () => dataService.db.getCountryNames();
const getCities = (country: string) => dataService.db.getCities(country);
const getNationalities = () => dataService.db.getNationalities();
const addCountry = (name: string, code?: string, flag?: string) => dataService.db.addCountry(name, code, flag);
const addNationality = (name: string, country?: string, gender?: string) => dataService.db.addNationality(name, country, gender);
const removeNationality = (name: string) => dataService.db.removeNationality(name);
const renameNationality = (oldName: string, newName: string) => dataService.db.renameNationality(oldName, newName);
const removeCountry = (name: string) => dataService.db.removeCountry(name);
const renameCountry = (oldName: string, newName: string) => dataService.db.renameCountry(oldName, newName);
const addCityToCountry = (country: string, city: string) => dataService.db.addCityToCountry(country, city);
const removeCityFromCountry = (country: string, city: string) => dataService.db.removeCityFromCountry(country, city);
const renameCity = (country: string, oldName: string, newName: string) => dataService.db.renameCity(country, oldName, newName);
const adminMergeCities = (sourceCountry: string, sourceCity: string, targetCountry: string, targetCity: string) => dataService.db.adminMergeCities(sourceCountry, sourceCity, targetCountry, targetCity);
const adminMergeCountries = (sourceCountry: string, targetCountry: string) => dataService.db.adminMergeCountries(sourceCountry, targetCountry);
const getPendingCities = () => dataService.db.getPendingCities();
const getAllPendingCities = () => dataService.db.getAllPendingCities();
const getPendingCitiesCount = () => dataService.db.getPendingCitiesCount();
const getPendingGeoSuggestions = () => dataService.db.getPendingGeoSuggestions();
const approvePendingGeo = (id: string, editedName?: string) => dataService.db.approvePendingGeo(id, editedName);
const mergePendingGeo = (id: string, targetName: string, targetCountry?: string) => dataService.db.mergePendingGeo(id, targetName, targetCountry);
const rejectPendingGeo = (id: string, reason?: string) => dataService.db.rejectPendingGeo(id, reason);
const deletePendingGeo = (id: string) => dataService.db.deletePendingGeo(id);
const approvePendingCity = (id: string, reviewer: string, editedName?: string) => dataService.db.approvePendingCity(id, reviewer, editedName);
const rejectPendingCity = (id: string, reviewer: string, reason?: string) => dataService.db.rejectPendingCity(id, reviewer, reason);
const deletePendingCity = (id: string) => dataService.db.deletePendingCity(id);
const exportAllCountries = () => dataService.db.exportAllCountries();
const exportCitiesForCountry = (country: string) => dataService.db.exportCitiesForCountry(country);
const exportAllGeo = () => dataService.db.exportAllGeo();
const importCountries = (json: string, mode?: 'merge' | 'replace') => dataService.db.importCountries(json, mode);
const importCitiesForCountry = (country: string, json: string, mode?: 'merge' | 'replace') => dataService.db.importCitiesForCountry(country, json, mode);
const importFullGeo = (json: string, mode?: 'merge' | 'replace') => dataService.db.importFullGeo(json, mode);
const resetGeoDB = () => dataService.db.resetGeoDB();
const refreshGeoDB = () => dataService.db.refreshGeoDB();


type Tab = 'pending' | 'countries' | 'cities' | 'nationalities' | 'import-export';

export default function AdminCities() {
  const { showToast } = useApp();
  const [tab, setTab] = useState<Tab>('pending');
  const [tick, setTick] = useState(0); // لإعادة التحميل بعد التعديلات
  const refresh = () => { refreshGeoDB(); setTick((t) => t + 1); };

  const pendingCount = useMemo(() => getPendingCitiesCount(), [tick]);

  const tabs: { id: Tab; label: string; icon: typeof Globe; badge?: number }[] = [
    { id: 'pending', label: 'المدن المقترحة', icon: Clock, badge: pendingCount },
    { id: 'countries', label: 'الدول', icon: Globe },
    { id: 'cities', label: 'المدن', icon: MapPin },
    { id: 'nationalities', label: 'الجنسيات', icon: FileText },
    { id: 'import-export', label: 'استيراد / تصدير', icon: FileJson },
  ];

  return (
    <div className="space-y-6" key={tick}>
      {/* العنوان */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-sm">
            <Globe className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="font-cairo font-extrabold text-xl text-slate-900">إدارة الدول والمدن</h2>
            <p className="text-xs text-slate-400 font-tajawal">إدارة القوائم الرسمية ومراجعة المدن المقترحة من المستخدمين</p>
          </div>
        </div>
        <button
          onClick={() => { resetGeoDB(); refresh(); showToast('تمت إعادة التعيين لبيانات الدول والمدن الافتراضية', 'success'); }}
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-600 hover:bg-slate-100 transition-colors"
        >
          <RefreshCw className="w-4 h-4" /> إعادة تعيين
        </button>
      </div>

      {/* التبويبات */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t-lg font-cairo font-bold text-xs transition-all border-b-2 -mb-px
              ${tab === t.id ? 'border-amber-500 text-amber-600 bg-amber-50/50' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}
          >
            <t.icon className="w-3.5 h-3.5" />
            {t.label}
            {t.badge !== undefined && t.badge > 0 && (
              <span className="bg-rose-500 text-white text-[9px] font-bold min-w-4.5 h-4.5 px-1 rounded-full flex items-center justify-center">
                {t.badge > 9 ? '9+' : t.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.15 }}
        >
          {tab === 'pending' && <PendingCitiesTab onAction={refresh} showToast={showToast} />}
          {tab === 'countries' && <CountriesTab onAction={refresh} showToast={showToast} />}
          {tab === 'cities' && <CitiesTab onAction={refresh} showToast={showToast} />}
          {tab === 'nationalities' && <NationalitiesTab onAction={refresh} showToast={showToast} />}
          {tab === 'import-export' && <ImportExportTab onAction={refresh} showToast={showToast} />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ====================================================================
//  تبويب المدن المقترحة
// ====================================================================
function PendingCitiesTab({ onAction, showToast }: { onAction: () => void; showToast: (m: string, t?: 'success' | 'error' | 'info') => void }) {
  const [filter, setFilter] = useState<'pending' | 'all'>('pending');
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editedName, setEditedName] = useState('');
  const [mergeTarget, setMergeTarget] = useState<Record<string, string>>({});
  const [selectedSuggestionIds, setSelectedSuggestionIds] = useState<Set<string>>(new Set());
  const [bulkMergeTarget, setBulkMergeTarget] = useState('');
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  const all = useMemo(() => getAllPendingCities(), [filter, onAction]);
  const list = useMemo(() => {
    let l = filter === 'pending' ? all.filter((p) => p.status === 'pending') : all;
    if (search.trim()) {
      const q = search.toLowerCase();
      l = l.filter((p) => p.name.toLowerCase().includes(q) || p.country.toLowerCase().includes(q) || p.suggestedBy.toLowerCase().includes(q));
    }
    return l.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [all, search, filter]);

  const geoSuggestions = useMemo(() => {
    let l = getPendingGeoSuggestions();
    if (filter === 'pending') l = l.filter((p: any) => p.status === 'pending');
    if (search.trim()) {
      const q = search.toLowerCase();
      l = l.filter((p: any) => String(p.name || '').toLowerCase().includes(q) || String(p.country || '').toLowerCase().includes(q));
    }
    return l.sort((a: any, b: any) => String(b.created_at || b.createdAt || '').localeCompare(String(a.created_at || a.createdAt || '')));
  }, [search, filter]);

  const suggestionKindLabel: Record<string, string> = {
    country: 'دولة',
    city: 'مدينة',
    nationality: 'جنسية',
  };

  const getMergeOptionsForSuggestion = (s: any) => {
    if (s.kind === 'country') return getCountryNames();
    if (s.kind === 'city') return getCities(s.country || '').length ? getCities(s.country || '') : [];
    if (s.kind === 'nationality') return dataService.db.getNationalities();
    return [];
  };

  const pendingGeoSuggestions = geoSuggestions.filter((s: any) => s.status === 'pending');
  const selectedSuggestions = pendingGeoSuggestions.filter((s: any) => selectedSuggestionIds.has(s.id));
  const selectedKind = selectedSuggestions[0]?.kind || '';
  const selectedSameKind = selectedSuggestions.length > 0 && selectedSuggestions.every((s: any) => s.kind === selectedKind);
  const bulkMergeOptions = selectedSameKind ? getMergeOptionsForSuggestion(selectedSuggestions[0]) : [];

  const toggleSuggestion = (id: string) => {
    setSelectedSuggestionIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleAllSuggestions = () => {
    setSelectedSuggestionIds((prev) => {
      const allSelected = pendingGeoSuggestions.length > 0 && pendingGeoSuggestions.every((s: any) => prev.has(s.id));
      return allSelected ? new Set() : new Set(pendingGeoSuggestions.map((s: any) => s.id));
    });
  };

  const runBulkSuggestions = (action: 'approve' | 'merge' | 'reject' | 'delete') => {
    const items = selectedSuggestions;
    if (items.length === 0) { showToast('حدد اقتراحاً واحداً على الأقل', 'error'); return; }
    if (action === 'merge' && !bulkMergeTarget) { showToast('اختر قيمة رسمية للدمج', 'error'); return; }
    if (action === 'merge' && !selectedSameKind) { showToast('للدمج الجماعي يجب اختيار عناصر من نفس النوع فقط', 'error'); return; }
    items.forEach((s: any) => {
      if (action === 'approve') approvePendingGeo(s.id);
      if (action === 'merge') mergePendingGeo(s.id, bulkMergeTarget, s.country || '');
      if (action === 'reject') rejectPendingGeo(s.id, 'تم رفض الإضافة للقوائم الرسمية؛ ستبقى القيمة في حساب العضو فقط.');
      if (action === 'delete') deletePendingGeo(s.id);
    });
    showToast(`تم تنفيذ الإجراء على ${items.length} اقتراح`, action === 'reject' || action === 'delete' ? 'info' : 'success');
    setSelectedSuggestionIds(new Set());
    setBulkMergeTarget('');
    onAction();
  };

  const approveSuggestion = (s: any) => {
    const result = approvePendingGeo(s.id, editingId === s.id ? editedName.trim() : undefined);
    if (result.ok) {
      showToast(`تمت إضافة ${suggestionKindLabel[s.kind] || 'العنصر'} «${editedName || s.name}» للقوائم الرسمية`, 'success');
      setEditingId(null); setEditedName(''); onAction();
    }
  };

  const mergeSuggestion = (s: any) => {
    const target = mergeTarget[s.id];
    if (!target) { showToast('اختر عنصراً رسمياً للدمج معه', 'error'); return; }
    const result = mergePendingGeo(s.id, target, s.country || '');
    if (result.ok) { showToast(`تم دمج «${s.name}» مع «${target}» وتحديث بيانات الأعضاء`, 'success'); onAction(); }
  };

  const rejectSuggestion = (s: any) => {
    const result = rejectPendingGeo(s.id, 'تم رفض الإضافة للقائمة الرسمية؛ ستبقى القيمة في حساب العضو فقط.');
    if (result.ok) { showToast('تم رفض الاقتراح وسيبقى في حساب العضو فقط', 'info'); onAction(); }
  };

  const handleApprove = (p: PendingCity) => {
    const name = editingId === p.id ? editedName.trim() : undefined;
    const result = approvePendingCity(p.id, 'الإدارة', name);
    if (result.ok) {
      showToast(`تمت الموافقة على «${name || p.name}» وإضافتها لمدن ${p.country}`, 'success');
      setEditingId(null);
      setEditedName('');
      onAction();
    } else {
      showToast(result.error || 'تعذّرت الموافقة', 'error');
    }
  };

  const handleReject = (p: PendingCity) => {
    const result = rejectPendingCity(p.id, 'الإدارة', rejectReason);
    if (result.ok) {
      showToast('تم رفض الاقتراح', 'info');
      setRejectingId(null);
      setRejectReason('');
      onAction();
    } else {
      showToast(result.error || 'تعذّر الرفض', 'error');
    }
  };

  const sourceLabel: Record<string, { text: string; color: string }> = {
    register: { text: 'تسجيل', color: 'bg-blue-50 text-blue-600' },
    import: { text: 'استيراد', color: 'bg-purple-50 text-purple-600' },
    admin: { text: 'إدارة', color: 'bg-amber-50 text-amber-600' },
  };

  return (
    <div className="space-y-4">
      {/* أدوات التصفية */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1 bg-slate-100 rounded-xl p-1">
          {(['pending', 'all'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-bold transition-colors
                ${filter === f ? 'bg-white text-amber-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {f === 'pending' ? 'بانتظار المراجعة' : 'الكل'}
            </button>
          ))}
        </div>
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالاسم أو الدولة أو المُقترح..."
            className="w-full pr-9 pl-3 py-2 rounded-xl bg-white border border-slate-200 focus:border-amber-400 focus:outline-none text-sm font-tajawal"
          />
        </div>
      </div>

      {geoSuggestions.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-slate-800 font-cairo font-bold text-sm">
            <GitMerge className="w-4 h-4 text-amber-500" /> اقتراحات الدول والمدن والجنسيات ({geoSuggestions.length})
          </div>
          {pendingGeoSuggestions.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 flex flex-wrap items-center gap-2">
              <label className="flex items-center gap-2 text-xs font-cairo font-bold text-amber-900">
                <input type="checkbox" checked={pendingGeoSuggestions.every((s: any) => selectedSuggestionIds.has(s.id))} onChange={toggleAllSuggestions} className="w-4 h-4 accent-amber-500" />
                تحديد كل الظاهر ({pendingGeoSuggestions.length})
              </label>
              {selectedSuggestions.length > 0 && (
                <>
                  <span className="text-xs font-cairo font-bold text-amber-800">محدد: {selectedSuggestions.length}</span>
                  <button onClick={() => runBulkSuggestions('approve')} className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-cairo font-bold">إضافة رسمية</button>
                  <select value={bulkMergeTarget} onChange={(e) => setBulkMergeTarget(e.target.value)} disabled={!selectedSameKind} className="px-3 py-1.5 rounded-lg border border-amber-200 text-xs font-tajawal bg-white min-w-40 disabled:opacity-50">
                    <option value="">دمج المحدد مع...</option>
                    {bulkMergeOptions.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                  <button onClick={() => runBulkSuggestions('merge')} className="px-3 py-1.5 rounded-lg bg-sky-600 text-white text-xs font-cairo font-bold">دمج المحدد</button>
                  <button onClick={() => runBulkSuggestions('reject')} className="px-3 py-1.5 rounded-lg bg-rose-100 text-rose-700 text-xs font-cairo font-bold">رفض للقوائم</button>
                  <button onClick={() => runBulkSuggestions('delete')} className="px-3 py-1.5 rounded-lg bg-slate-200 text-slate-700 text-xs font-cairo font-bold">حذف الإشعار</button>
                </>
              )}
            </div>
          )}
          {geoSuggestions.map((s: any) => {
            const options = getMergeOptionsForSuggestion(s);
            return (
              <div key={s.id} className="bg-white rounded-2xl border border-amber-100 p-4 flex flex-wrap items-center gap-3">
                {s.status === 'pending' && (
                  <input type="checkbox" checked={selectedSuggestionIds.has(s.id)} onChange={() => toggleSuggestion(s.id)} className="w-4 h-4 accent-amber-500" />
                )}
                <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center flex-shrink-0">
                  {s.kind === 'country' ? <Globe className="w-5 h-5 text-amber-600" /> : s.kind === 'nationality' ? <FileText className="w-5 h-5 text-amber-600" /> : <MapPin className="w-5 h-5 text-amber-600" />}
                </div>
                <div className="flex-1 min-w-56">
                  {editingId === s.id ? (
                    <input value={editedName} onChange={(e) => setEditedName(e.target.value)} autoFocus className="px-3 py-1.5 rounded-lg border-2 border-amber-400 focus:outline-none font-cairo font-bold text-slate-900 text-sm w-full max-w-64" />
                  ) : (
                    <p className="font-cairo font-bold text-slate-900 text-sm">{s.name}</p>
                  )}
                  <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] font-tajawal text-slate-500">
                    <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 font-cairo font-bold">{suggestionKindLabel[s.kind] || s.kind}</span>
                    {s.country && <span>ضمن: {s.country}</span>}
                    <span>المصدر: {s.source === 'import' ? 'استيراد' : 'تسجيل'}</span>
                    <span>المقترح: {s.suggested_by || s.suggestedBy || '—'}</span>
                    {s.status !== 'pending' && <span className="font-cairo font-bold">الحالة: {s.status === 'approved' ? 'مقبول' : s.status === 'merged' ? 'مدمج' : 'مرفوض'}</span>}
                  </div>
                </div>
                {s.status === 'pending' ? (
                  <div className="flex flex-wrap items-center gap-2">
                    <select
                      value={mergeTarget[s.id] || ''}
                      onChange={(e) => setMergeTarget((prev) => ({ ...prev, [s.id]: e.target.value }))}
                      className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-tajawal min-w-40"
                    >
                      <option value="">دمج مع موجود...</option>
                      {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
                    </select>
                    <button onClick={() => mergeSuggestion(s)} className="px-3 py-2 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 text-xs font-cairo font-bold flex items-center gap-1"><GitMerge className="w-3.5 h-3.5" /> دمج</button>
                    <button onClick={() => editingId === s.id ? approveSuggestion(s) : (setEditingId(s.id), setEditedName(s.name))} className="px-3 py-2 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-cairo font-bold flex items-center gap-1"><Check className="w-3.5 h-3.5" /> {editingId === s.id ? 'حفظ وقبول' : 'قبول للقائمة'}</button>
                    <button onClick={() => rejectSuggestion(s)} className="px-3 py-2 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-cairo font-bold flex items-center gap-1"><X className="w-3.5 h-3.5" /> رفض للقائمة</button>
                  </div>
                ) : (
                  <button onClick={() => { deletePendingGeo(s.id); onAction(); }} className="p-2 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-500 transition-colors" title="حذف الإشعار فقط"><Trash2 className="w-4 h-4" /></button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {list.length === 0 && geoSuggestions.length === 0 ? (
        <EmptyState icon={Clock} title="لا توجد اقتراحات" desc="ستظهر هنا الدول والمدن والجنسيات المقترحة من التسجيل أو الاستيراد" />
      ) : list.length > 0 ? (
        <div className="grid gap-3">
          {list.map((p) => {
            const sl = sourceLabel[p.source] || sourceLabel.register;
            return (
              <div key={p.id} className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-wrap items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0
                  ${p.status === 'pending' ? 'bg-amber-50' : p.status === 'approved' ? 'bg-emerald-50' : 'bg-rose-50'}`}>
                  {p.status === 'pending' ? <Clock className="w-5 h-5 text-amber-500" /> :
                   p.status === 'approved' ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> :
                   <XCircle className="w-5 h-5 text-rose-500" />}
                </div>
                <div className="flex-1 min-w-40">
                  {editingId === p.id ? (
                    <input
                      value={editedName}
                      onChange={(e) => setEditedName(e.target.value)}
                      autoFocus
                      className="px-3 py-1.5 rounded-lg border-2 border-amber-400 focus:outline-none font-cairo font-bold text-slate-900 text-sm w-full max-w-56"
                    />
                  ) : (
                    <p className="font-cairo font-bold text-slate-900 text-sm">{p.name}</p>
                  )}
                  <div className="flex flex-wrap items-center gap-2 mt-0.5">
                    <span className="text-xs text-slate-500 font-tajawal flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {p.country}
                    </span>
                    <span className={`text-[10px] font-cairo font-bold px-2 py-0.5 rounded-full ${sl.color}`}>{sl.text}</span>
                    <span className="text-[11px] text-slate-400 font-tajawal">اقترحها: {p.suggestedBy}</span>
                    {p.reviewedAt && (
                      <span className="text-[11px] text-slate-400 font-tajawal">
                        {p.status === 'approved' ? '✅ مقبولة' : '❌ مرفوضة'} {p.rejectionReason ? `(${p.rejectionReason})` : ''}
                      </span>
                    )}
                  </div>
                </div>
                {p.status === 'pending' && (
                  <div className="flex items-center gap-2">
                    {editingId === p.id ? (
                      <button onClick={() => handleApprove(p)} className="p-2 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600 transition-colors" title="حفظ الاسم المعدل والموافقة">
                        <Check className="w-4 h-4" />
                      </button>
                    ) : (
                      <button onClick={() => { setEditingId(p.id); setEditedName(p.name); }} className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700 transition-colors" title="تعديل الاسم قبل القبول">
                        <Edit3 className="w-4 h-4" />
                      </button>
                    )}
                    <button onClick={() => handleApprove(p)} className="flex items-center gap-1 px-3 py-2 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors text-xs font-cairo font-bold">
                      <Check className="w-4 h-4" /> قبول
                    </button>
                    <button onClick={() => setRejectingId(p.id)} className="flex items-center gap-1 px-3 py-2 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors text-xs font-cairo font-bold">
                      <X className="w-4 h-4" /> رفض
                    </button>
                  </div>
                )}
                {p.status !== 'pending' && (
                  <button onClick={() => { deletePendingCity(p.id); onAction(); }} className="p-2 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-500 transition-colors" title="حذف">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      ) : null}

      {/* مودال رفض مع سبب */}
      <Modal open={!!rejectingId} onClose={() => { setRejectingId(null); setRejectReason(''); }} title="رفض المدينة المقترحة" size="sm">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 font-tajawal">اكتب سبب الرفض (اختياري) — سيظهر للمستخدم:</p>
          <textarea
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            placeholder="مثال: المدينة موجودة باسم آخر..."
            rows={3}
            className="w-full px-3 py-2.5 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm resize-none"
          />
          <div className="flex gap-2 justify-end">
            <button onClick={() => { setRejectingId(null); setRejectReason(''); }} className="px-4 py-2 rounded-lg text-slate-500 hover:bg-slate-100 font-cairo font-bold text-sm">إلغاء</button>
            <button
              onClick={() => {
                const p = list.find((x) => x.id === rejectingId);
                if (p) handleReject(p);
              }}
              className="px-4 py-2 rounded-lg bg-rose-500 text-white hover:bg-rose-600 font-cairo font-bold text-sm"
            >
              تأكيد الرفض
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ====================================================================
//  تبويب الدول
// ====================================================================
function CountriesTab({ onAction, showToast }: { onAction: () => void; showToast: (m: string, t?: 'success' | 'error' | 'info') => void }) {
  const [search, setSearch] = useState('');
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newCode, setNewCode] = useState('');
  const [editing, setEditing] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  // دمج الدول
  const [mergingCountry, setMergingCountry] = useState<string | null>(null);
  const [targetCountry, setTargetCountry] = useState('');

  const countries = useMemo(() => getCountries(), [onAction]);
  const filtered = useMemo(() => {
    if (!search.trim()) return countries;
    const q = search.toLowerCase();
    return countries.filter((c) => c.name.toLowerCase().includes(q));
  }, [countries, search]);

  const handleAdd = () => {
    const result = addCountry(newName, newCode || undefined);
    if (result.ok) {
      showToast(`تمت إضافة دولة «${newName}»`, 'success');
      setNewName(''); setNewCode(''); setAdding(false);
      onAction();
    } else showToast(result.error || 'تعذّرت الإضافة', 'error');
  };

  const handleRename = (oldName: string) => {
    const result = renameCountry(oldName, editName);
    if (result.ok) {
      showToast('تم تحديث اسم الدولة', 'success');
      setEditing(null); setEditName('');
      onAction();
    } else showToast(result.error || 'تعذّر التحديث', 'error');
  };

  const handleMergeCountries = () => {
    if (!mergingCountry || !targetCountry) {
      showToast('يرجى اختيار الدولة المستهدفة', 'error');
      return;
    }
    const result = adminMergeCountries(mergingCountry, targetCountry);
    if (result.ok) {
      showToast(`تم دمج «${mergingCountry}» بنجاح في «${targetCountry}» وتم تحويل كافة أعضائها`, 'success');
      setMergingCountry(null);
      setTargetCountry('');
      onAction();
    } else {
      showToast(result.error || 'فشل دمج الدولة', 'error');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن دولة..."
            className="w-full pr-9 pl-3 py-2 rounded-xl bg-white border border-slate-200 focus:border-amber-400 focus:outline-none text-sm font-tajawal"
          />
        </div>
        <button onClick={() => setAdding(true)} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500 text-white hover:bg-amber-600 transition-colors font-cairo font-bold text-sm">
          <Plus className="w-4 h-4" /> دولة جديدة
        </button>
      </div>

      {adding && (
        <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-40">
            <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">اسم الدولة</label>
            <input value={newName} onChange={(e) => setNewName(e.target.value)} autoFocus placeholder="مثال: تركيا" className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm" />
          </div>
          <div className="w-32">
            <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">الرمز (اختياري)</label>
            <input value={newCode} onChange={(e) => setNewCode(e.target.value)} placeholder="TR" className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm uppercase" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => { setAdding(false); setNewName(''); setNewCode(''); }} className="px-3 py-2 rounded-lg text-slate-500 hover:bg-slate-100 font-cairo font-bold text-sm">إلغاء</button>
            <button onClick={handleAdd} className="px-4 py-2 rounded-lg bg-amber-500 text-white hover:bg-amber-600 font-cairo font-bold text-sm">إضافة</button>
          </div>
        </div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map((c) => (
          <div key={c.name} className="bg-white rounded-2xl border border-slate-200 p-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-100 to-amber-200 flex items-center justify-center flex-shrink-0">
              <Globe className="w-5 h-5 text-amber-600" />
            </div>
            <div className="flex-1 min-w-0">
              {editing === c.name ? (
                <input value={editName} onChange={(e) => setEditName(e.target.value)} autoFocus onKeyDown={(e) => e.key === 'Enter' && handleRename(c.name)} className="w-full px-2 py-1 rounded border border-amber-400 focus:outline-none font-cairo font-bold text-sm" />
              ) : (
                <p className="font-cairo font-bold text-slate-900 text-sm truncate">{c.name}</p>
              )}
              <p className="text-[11px] text-slate-400 font-tajawal">{getCities(c.name).length} مدينة</p>
            </div>
            {editing === c.name ? (
              <div className="flex gap-1">
                <button onClick={() => handleRename(c.name)} className="p-1.5 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600"><Check className="w-3.5 h-3.5" /></button>
                <button onClick={() => { setEditing(null); setEditName(''); }} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100"><X className="w-3.5 h-3.5" /></button>
              </div>
            ) : (
              <div className="flex gap-1">
                <button onClick={() => { setEditing(c.name); setEditName(c.name); }} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700" title="تعديل الاسم"><Edit3 className="w-3.5 h-3.5" /></button>
                <button onClick={() => { setMergingCountry(c.name); setTargetCountry(''); }} className="p-1.5 rounded-lg text-slate-400 hover:bg-amber-50 hover:text-amber-600" title="دمج مع دولة أخرى"><GitMerge className="w-3.5 h-3.5" /></button>
                <button onClick={() => { if (confirm(`حذف «${c.name}» وكل مدنها؟`)) { removeCountry(c.name); onAction(); showToast('تم حذف الدولة', 'info'); } }} className="p-1.5 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-500" title="حذف نهائي"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* مودال دمج الدول */}
      <Modal open={!!mergingCountry} onClose={() => { setMergingCountry(null); setTargetCountry(''); }} title={`دمج الدولة «${mergingCountry}»`} size="sm">
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex gap-2">
            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 font-tajawal leading-relaxed">
              <strong>تنبيه هام جداً:</strong> هذا الإجراء سيقوم بنقل كافة المدن التابعة لـ <strong>«{mergingCountry}»</strong> لتصبح تابعة للدولة المستهدفة، وسيتم تلقائياً تحديث بيانات الإقامة والجنسية لكافة الأعضاء المنسوبين لـ <strong>«{mergingCountry}»</strong> في النظام، ثم سيتم حذف <strong>«{mergingCountry}»</strong> نهائياً من القوائم.
            </p>
          </div>

          <div>
            <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">اختر الدولة المستهدفة للدمج إليها</label>
            <select
              value={targetCountry}
              onChange={(e) => setTargetCountry(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm bg-white"
            >
              <option value="">-- اختر دولة --</option>
              {countries
                .filter((x) => x.name !== mergingCountry)
                .map((x) => (
                  <option key={x.name} value={x.name}>{x.name}</option>
                ))}
            </select>
          </div>

          <div className="flex gap-2 justify-end pt-2">
            <button onClick={() => { setMergingCountry(null); setTargetCountry(''); }} className="px-4 py-2 rounded-lg text-slate-500 hover:bg-slate-100 font-cairo font-bold text-sm">إلغاء</button>
            <button
              onClick={handleMergeCountries}
              disabled={!targetCountry}
              className="px-4 py-2 rounded-lg bg-amber-500 text-white hover:bg-amber-600 disabled:opacity-50 font-cairo font-bold text-sm"
            >
              دمج وحذف المصدر
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ====================================================================
//  تبويب المدن
// ====================================================================
function CitiesTab({ onAction, showToast }: { onAction: () => void; showToast: (m: string, t?: 'success' | 'error' | 'info') => void }) {
  const [selectedCountry, setSelectedCountry] = useState('');
  const [search, setSearch] = useState('');
  const [newCity, setNewCity] = useState('');
  const [editing, setEditing] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  // دمج المدن
  const [mergingCity, setMergingCity] = useState<string | null>(null);
  const [targetCountryName, setTargetCountryName] = useState('');
  const [targetCityName, setTargetCityName] = useState('');
  const [isNewTargetCity, setIsNewTargetCity] = useState(false);
  const [newTargetCityInput, setNewTargetCityInput] = useState('');

  const countries = useMemo(() => getCountryNames(), [onAction]);
  useEffect(() => {
    if (!selectedCountry && countries.length > 0) setSelectedCountry(countries[0]);
  }, [countries, selectedCountry]);

  useEffect(() => {
    if (mergingCity && !targetCountryName) {
      setTargetCountryName(selectedCountry);
    }
  }, [mergingCity, selectedCountry, targetCountryName]);

  const cities = useMemo(() => selectedCountry ? getCities(selectedCountry) : [], [selectedCountry, onAction]);
  const filtered = useMemo(() => {
    if (!search.trim()) return cities;
    const q = search.toLowerCase();
    return cities.filter((c) => c.toLowerCase().includes(q));
  }, [cities, search]);

  const targetCountryCities = useMemo(() => {
    if (!targetCountryName) return [];
    return getCities(targetCountryName).filter(c => !(targetCountryName === selectedCountry && c === mergingCity));
  }, [targetCountryName, selectedCountry, mergingCity, onAction]);

  const handleAdd = () => {
    const result = addCityToCountry(selectedCountry, newCity);
    if (result.ok) {
      showToast(`تمت إضافة «${newCity}» لمدن ${selectedCountry}`, 'success');
      setNewCity('');
      onAction();
    } else showToast(result.error || 'تعذّرت الإضافة', 'error');
  };

  const handleRename = (oldName: string) => {
    const result = renameCity(selectedCountry, oldName, editName);
    if (result.ok) {
      showToast('تم تحديث اسم المدينة', 'success');
      setEditing(null); setEditName('');
      onAction();
    } else showToast(result.error || 'تعذّر التحديث', 'error');
  };

  const handleMergeCities = () => {
    if (!mergingCity) return;
    const destCity = isNewTargetCity ? newTargetCityInput.trim() : targetCityName;
    if (!targetCountryName || !destCity) {
      showToast('يرجى تحديد المدينة والدولة المستهدفة للدمج', 'error');
      return;
    }
    const result = adminMergeCities(selectedCountry, mergingCity, targetCountryName, destCity);
    if (result.ok) {
      showToast(`تم دمج المدينة «${mergingCity}» بنجاح في «${destCity} - ${targetCountryName}» وتم تحديث بيانات كافة الأعضاء`, 'success');
      setMergingCity(null);
      setTargetCityName('');
      setNewTargetCityInput('');
      setIsNewTargetCity(false);
      onAction();
    } else {
      showToast(result.error || 'فشل دمج المدينة', 'error');
    }
  };

  return (
    <div className="space-y-4">
      {/* اختيار الدولة + بحث + إضافة */}
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-48 flex-1">
          <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">الدولة</label>
          <select value={selectedCountry} onChange={(e) => { setSelectedCountry(e.target.value); setSearch(''); }} className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm bg-white">
            {countries.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="relative flex-1 min-w-40">
          <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">بحث</label>
          <Search className="absolute right-3 top-[34px] -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث عن مدينة..." className="w-full pr-9 pl-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm" />
        </div>
        <div className="flex gap-2">
          <input value={newCity} onChange={(e) => setNewCity(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAdd()} placeholder="مدينة جديدة..." className="px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm" />
          <button onClick={handleAdd} disabled={!selectedCountry} className="flex items-center gap-1 px-3 py-2 rounded-lg bg-amber-500 text-white hover:bg-amber-600 disabled:opacity-50 font-cairo font-bold text-sm">
            <Plus className="w-4 h-4" /> إضافة
          </button>
        </div>
      </div>

      {/* إحصائيات */}
      <div className="flex items-center gap-2 text-xs text-slate-500 font-tajawal">
        <MapPin className="w-4 h-4 text-amber-500" />
        {cities.length} مدينة في {selectedCountry}
      </div>

      {/* قائمة المدن */}
      {filtered.length === 0 ? (
        <EmptyState icon={MapPin} title="لا توجد مدن" desc="أضف مدناً لهذه الدولة أو استورد قائمة" />
      ) : (
        <div className="flex flex-wrap gap-2">
          {filtered.map((c) => (
            <div key={c} className="bg-white rounded-xl border border-slate-200 pl-2 pr-3 py-1.5 flex items-center gap-2 group">
              {editing === c ? (
                <>
                  <input value={editName} onChange={(e) => setEditName(e.target.value)} autoFocus onKeyDown={(e) => e.key === 'Enter' && handleRename(c)} className="px-2 py-0.5 rounded border border-amber-400 focus:outline-none font-tajawal text-sm w-32" />
                  <button onClick={() => handleRename(c)} className="text-emerald-500 hover:text-emerald-600"><Check className="w-3.5 h-3.5" /></button>
                  <button onClick={() => { setEditing(null); }} className="text-slate-400 hover:text-slate-600"><X className="w-3.5 h-3.5" /></button>
                </>
              ) : (
                <>
                  <span className="font-tajawal text-sm text-slate-700">{c}</span>
                  <button onClick={() => { setEditing(c); setEditName(c); }} className="text-slate-300 hover:text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" title="تعديل"><Edit3 className="w-3.5 h-3.5" /></button>
                  <button onClick={() => { setMergingCity(c); setTargetCountryName(selectedCountry); setTargetCityName(''); setIsNewTargetCity(false); setNewTargetCityInput(''); }} className="text-slate-300 hover:text-amber-500 opacity-0 group-hover:opacity-100 transition-opacity" title="دمج"><GitMerge className="w-3.5 h-3.5" /></button>
                  <button onClick={() => { if (confirm(`حذف «${c}»؟`)) { removeCityFromCountry(selectedCountry, c); onAction(); } }} className="text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity" title="حذف"><X className="w-3.5 h-3.5" /></button>
                </>
              )}
            </div>
          ))}
        </div>
      )}

      {/* مودال دمج المدينة */}
      <Modal open={!!mergingCity} onClose={() => { setMergingCity(null); }} title={`دمج المدينة «${mergingCity}»`} size="sm">
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex gap-2">
            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 font-tajawal leading-relaxed">
              <strong>تنبيه دمج المدينة:</strong> سيتم تحويل كافة الأعضاء المنتمين لمدينة <strong>«{mergingCity}»</strong> (في {selectedCountry}) ليصبحوا منتمين للمدينة والدولة المستهدفة، وسيتم حذف <strong>«{mergingCity}»</strong> نهائياً من قائمة مدن {selectedCountry}.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">الدولة المستهدفة</label>
              <select
                value={targetCountryName}
                onChange={(e) => { setTargetCountryName(e.target.value); setTargetCityName(''); }}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-xs bg-white"
              >
                {countries.map((x) => (
                  <option key={x} value={x}>{x}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">نوع المدينة المستهدفة</label>
              <div className="flex gap-2 h-9 items-center">
                <button
                  type="button"
                  onClick={() => setIsNewTargetCity(false)}
                  className={`flex-1 text-[11px] font-bold py-1.5 px-2 rounded-lg transition-all ${!isNewTargetCity ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                >
                  مدينة موجودة
                </button>
                <button
                  type="button"
                  onClick={() => setIsNewTargetCity(true)}
                  className={`flex-1 text-[11px] font-bold py-1.5 px-2 rounded-lg transition-all ${isNewTargetCity ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                >
                  مدينة جديدة
                </button>
              </div>
            </div>
          </div>

          {isNewTargetCity ? (
            <div>
              <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">اكتب اسم المدينة الجديدة المستهدفة</label>
              <input
                value={newTargetCityInput}
                onChange={(e) => setNewTargetCityInput(e.target.value)}
                placeholder="مثال: مكة المكرمة"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm"
              />
            </div>
          ) : (
            <div>
              <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">اختر المدينة المستهدفة</label>
              <select
                value={targetCityName}
                onChange={(e) => setTargetCityName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm bg-white"
              >
                <option value="">-- اختر مدينة --</option>
                {targetCountryCities.map((x) => (
                  <option key={x} value={x}>{x}</option>
                ))}
              </select>
            </div>
          )}

          <div className="flex gap-2 justify-end pt-2">
            <button onClick={() => { setMergingCity(null); }} className="px-4 py-2 rounded-lg text-slate-500 hover:bg-slate-100 font-cairo font-bold text-sm">إلغاء</button>
            <button
              onClick={handleMergeCities}
              disabled={isNewTargetCity ? !newTargetCityInput.trim() : !targetCityName}
              className="px-4 py-2 rounded-lg bg-amber-500 text-white hover:bg-amber-600 disabled:opacity-50 font-cairo font-bold text-sm"
            >
              تأكيد الدمج والحذف
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ====================================================================
//  تبويب الجنسيات الرسمية
// ====================================================================
function NationalitiesTab({ onAction, showToast }: { onAction: () => void; showToast: (m: string, t?: 'success' | 'error' | 'info') => void }) {
  const [search, setSearch] = useState('');
  const [newName, setNewName] = useState('');
  const [newMaleName, setNewMaleName] = useState('');
  const [newFemaleName, setNewFemaleName] = useState('');
  const [newCountry, setNewCountry] = useState('');
  const [editing, setEditing] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [nationalityRows, setNationalityRows] = useState<Array<{ name: string; country?: string; gender?: string }>>([]);

  const refreshNationalityRows = async () => {
    try {
      const res = await fetch('/api/geo-nationalities');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) setNationalityRows(data);
      }
    } catch {
      setNationalityRows([]);
    }
  };

  useEffect(() => { refreshNationalityRows(); }, []);

  const nationalities = useMemo(() => {
    const fromRows = nationalityRows.map((row) => row.name).filter(Boolean);
    return Array.from(new Set([...(fromRows.length ? fromRows : getNationalities())]));
  }, [nationalityRows, onAction]);
  const groupedNationalities = useMemo(() => {
    const map = new Map<string, { country: string; male?: string; female?: string; both: string[] }>();
    nationalityRows.forEach((row) => {
      const country = row.country || 'غير مرتبطة بدولة';
      if (!map.has(country)) map.set(country, { country, both: [] });
      const item = map.get(country)!;
      if (row.gender === 'male') item.male = row.name;
      else if (row.gender === 'female') item.female = row.name;
      else item.both.push(row.name);
    });
    return Array.from(map.values()).sort((a, b) => a.country.localeCompare(b.country, 'ar'));
  }, [nationalityRows]);
  const filtered = useMemo(() => {
    if (!search.trim()) return nationalities;
    const q = search.toLowerCase();
    return nationalities.filter((n) => n.toLowerCase().includes(q));
  }, [nationalities, search]);

  const handleAdd = () => {
    const names = [newName.trim(), newMaleName.trim(), newFemaleName.trim()].filter(Boolean);
    if (names.length === 0) { showToast('اكتب اسم الجنسية أو صيغتي الذكر والأنثى', 'error'); return; }
    if (newMaleName.trim()) addNationality(newMaleName.trim(), newCountry || undefined, 'male');
    if (newFemaleName.trim()) addNationality(newFemaleName.trim(), newCountry || undefined, 'female');
    if (newName.trim()) addNationality(newName.trim(), newCountry || undefined, 'both');
    setTimeout(refreshNationalityRows, 350);
    setNewName(''); setNewMaleName(''); setNewFemaleName(''); setNewCountry(''); onAction();
    showToast('تمت إضافة الجنسية/الجنسيات للقائمة الرسمية', 'success');
  };

  const exportNationalities = () => {
    const content = JSON.stringify({
      exportedAt: new Date().toISOString(),
      nationalities: nationalityRows.length ? nationalityRows : nationalities.map((name) => ({ name })),
      groupedByCountry: groupedNationalities,
      template: [{ country: 'السعودية', male: 'سعودي', female: 'سعودية' }],
    }, null, 2);
    const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `twafok-nationalities-${Date.now()}.json`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('تم تصدير الجنسيات', 'success');
  };

  const importNationalities = () => {
    try {
      const parsed = JSON.parse(importText);
      const rows = Array.isArray(parsed) ? parsed : Array.isArray(parsed.nationalities) ? parsed.nationalities : [];
      if (rows.length === 0) { showToast('الملف لا يحتوي على جنسيات', 'error'); return; }
      let count = 0;
      rows.forEach((row: any) => {
        if (typeof row === 'string') { addNationality(row); count++; return; }
        const country = row.country || row.countryName || '';
        if (row.name) { addNationality(String(row.name).trim(), country, row.gender || 'both'); count++; }
        if (row.male) { addNationality(String(row.male).trim(), country, 'male'); count++; }
        if (row.female) { addNationality(String(row.female).trim(), country, 'female'); count++; }
      });
      setTimeout(refreshNationalityRows, 500);
      setImportText(''); setImportOpen(false); onAction();
      showToast(`تم استيراد ${count} جنسية للذكور والإناث`, 'success');
    } catch {
      showToast('تعذر قراءة JSON. استخدم الصيغة: [{"country":"السعودية","male":"سعودي","female":"سعودية"}]', 'error');
    }
  };

  const handleRename = (oldName: string) => {
    if (!editName.trim()) return;
    renameNationality(oldName, editName.trim());
    setTimeout(refreshNationalityRows, 350);
    setEditing(null); setEditName(''); onAction();
    showToast('تم تعديل الجنسية وتحديث القائمة', 'success');
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2 justify-end">
        <button onClick={exportNationalities} className="px-3 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors font-cairo font-bold text-xs flex items-center gap-2">
          <Download className="w-4 h-4" /> تصدير الجنسيات
        </button>
        <button onClick={() => setImportOpen((v) => !v)} className="px-3 py-2 rounded-xl bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-colors font-cairo font-bold text-xs flex items-center gap-2">
          <Upload className="w-4 h-4" /> استيراد جنسيات ذكور/إناث
        </button>
      </div>

      {importOpen && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 space-y-3">
          <p className="text-xs font-cairo font-bold text-emerald-800">صيغة الاستيراد: JSON مثل [{'{'}"country":"السعودية","male":"سعودي","female":"سعودية"{'}'}]</p>
          <textarea value={importText} onChange={(e) => setImportText(e.target.value)} rows={6} placeholder='[{"country":"السعودية","male":"سعودي","female":"سعودية"}]' className="w-full px-3 py-2 rounded-xl border border-emerald-200 focus:border-emerald-500 focus:outline-none font-mono text-xs" dir="ltr" />
          <button onClick={importNationalities} className="px-4 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 font-cairo font-bold text-sm">تنفيذ الاستيراد</button>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 p-4 grid md:grid-cols-[1fr_1fr_1fr_1fr_auto] gap-3 items-end">
        <div className="md:col-span-1">
          <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">بحث في الجنسيات</label>
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث..." className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 focus:border-amber-400 focus:outline-none text-sm font-tajawal" />
          </div>
        </div>
        <div>
          <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">جنسية عامة</label>
          <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="مثال: سعودي / سعودية" className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-amber-400 focus:outline-none text-sm font-tajawal" />
        </div>
        <div>
          <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">صيغة الذكر</label>
          <input value={newMaleName} onChange={(e) => setNewMaleName(e.target.value)} placeholder="مثال: سعودي" className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-amber-400 focus:outline-none text-sm font-tajawal" />
        </div>
        <div>
          <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">صيغة الأنثى</label>
          <input value={newFemaleName} onChange={(e) => setNewFemaleName(e.target.value)} placeholder="مثال: سعودية" className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-amber-400 focus:outline-none text-sm font-tajawal" />
        </div>
        <div>
          <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">الدولة المرتبطة (اختياري)</label>
          <select value={newCountry} onChange={(e) => setNewCountry(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-amber-400 focus:outline-none text-sm font-tajawal bg-white">
            <option value="">بدون ربط</option>
            {getCountryNames().map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <button onClick={handleAdd} className="px-4 py-2 rounded-xl bg-amber-500 text-white hover:bg-amber-600 transition-colors font-cairo font-bold text-sm flex items-center justify-center gap-2">
          <Plus className="w-4 h-4" /> إضافة
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {groupedNationalities.length > 0 && !search.trim() && groupedNationalities.map((group) => (
          <div key={`group-${group.country}`} className="bg-gradient-to-br from-sky-50 to-white rounded-2xl border border-sky-100 p-3 sm:col-span-2 lg:col-span-3">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="font-cairo font-extrabold text-slate-900 text-sm">{group.country}</span>
              {group.male && <span className="px-2 py-0.5 rounded-lg bg-blue-50 text-blue-700 text-xs font-cairo font-bold">ذكر: {group.male}</span>}
              {group.female && <span className="px-2 py-0.5 rounded-lg bg-rose-50 text-rose-700 text-xs font-cairo font-bold">أنثى: {group.female}</span>}
              {group.both.map((name) => <span key={name} className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-600 text-xs font-cairo font-bold">عام: {name}</span>)}
            </div>
            <p className="text-[11px] text-slate-400 font-tajawal">تُستخدم هذه الصيغ تلقائياً في التسجيل حسب جنس المستخدم.</p>
          </div>
        ))}
        {filtered.map((name) => (
          <div key={name} className="bg-white rounded-2xl border border-slate-200 p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-sky-50 flex items-center justify-center flex-shrink-0">
              <FileText className="w-4.5 h-4.5 text-sky-600" />
            </div>
            <div className="flex-1 min-w-0">
              {editing === name ? (
                <input value={editName} onChange={(e) => setEditName(e.target.value)} autoFocus onKeyDown={(e) => e.key === 'Enter' && handleRename(name)} className="w-full px-2 py-1 rounded border border-amber-400 focus:outline-none font-cairo font-bold text-sm" />
              ) : (
                <p className="font-cairo font-bold text-slate-900 text-sm truncate">{name}</p>
              )}
              <p className="text-[11px] text-slate-400 font-tajawal">تظهر في التسجيل وفلاتر البحث</p>
            </div>
            {editing === name ? (
              <div className="flex gap-1">
                <button onClick={() => handleRename(name)} className="p-1.5 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600"><Check className="w-3.5 h-3.5" /></button>
                <button onClick={() => { setEditing(null); setEditName(''); }} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100"><X className="w-3.5 h-3.5" /></button>
              </div>
            ) : (
              <div className="flex gap-1">
                <button onClick={() => { setEditing(name); setEditName(name); }} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"><Edit3 className="w-3.5 h-3.5" /></button>
                <button onClick={() => { removeNationality(name); setTimeout(refreshNationalityRows, 350); onAction(); showToast('تم حذف الجنسية من القائمة الرسمية فقط', 'info'); }} className="p-1.5 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-500"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ====================================================================
//  تبويب الاستيراد والتصدير
// ====================================================================
function ImportExportTab({ onAction, showToast }: { onAction: () => void; showToast: (m: string, t?: 'success' | 'error' | 'info') => void }) {
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [importType, setImportType] = useState<'full' | 'countries' | 'cities'>('full');
  const [importCountry, setImportCountry] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const [importPreview, setImportPreview] = useState<{ name: string; content: string } | null>(null);
  const countries = useMemo(() => getCountryNames(), [onAction]);

  useEffect(() => {
    if (!importCountry && countries.length > 0) setImportCountry(countries[0]);
  }, [countries, importCountry]);

  const downloadFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExport = (type: 'full' | 'countries' | 'cities') => {
    if (type === 'full') {
      downloadFile(exportAllGeo(), `twafok-geo-full-${Date.now()}.json`);
      showToast('تم تصدير كل الدول والمدن', 'success');
    } else if (type === 'countries') {
      downloadFile(exportAllCountries(), `twafok-countries-${Date.now()}.json`);
      showToast('تم تصدير قائمة الدول', 'success');
    } else {
      if (!importCountry) { showToast('اختر دولة أولاً', 'error'); return; }
      downloadFile(exportCitiesForCountry(importCountry), `twafok-cities-${importCountry}-${Date.now()}.json`);
      showToast(`تم تصدير مدن ${importCountry}`, 'success');
    }
  };

  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const content = String(reader.result || '');
      setImportPreview({ name: file.name, content });
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const doImport = () => {
    if (!importPreview) return;
    let result: ImportResult;
    if (importType === 'full') {
      result = importFullGeo(importPreview.content, importMode);
    } else if (importType === 'countries') {
      result = importCountries(importPreview.content, importMode);
    } else {
      if (!importCountry) { showToast('اختر دولة أولاً', 'error'); return; }
      result = importCitiesForCountry(importCountry, importPreview.content, importMode);
    }
    if (result.ok) {
      showToast(`تم استيراد ${result.imported} عنصر (${result.skipped} مكرر/متخطى)`, 'success');
      setImportPreview(null);
      onAction();
    } else {
      showToast(result.errors.join(' — ') || 'فشل الاستيراد', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* التصدير */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <h3 className="font-cairo font-bold text-slate-900 text-sm mb-1 flex items-center gap-2">
          <Download className="w-4 h-4 text-emerald-500" /> تصدير البيانات
        </h3>
        <p className="text-xs text-slate-400 font-tajawal mb-4">نزّل نسخة JSON من الدول أو المدن للاحتفاظ بها أو نقلها</p>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => handleExport('full')} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors font-cairo font-bold text-sm">
            <FileJson className="w-4 h-4" /> تصدير الكل (دول + مدن)
          </button>
          <button onClick={() => handleExport('countries')} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors font-cairo font-bold text-sm">
            <Globe className="w-4 h-4" /> تصدير الدول فقط
          </button>
          <div className="flex items-center gap-2">
            <select value={importCountry} onChange={(e) => setImportCountry(e.target.value)} className="px-3 py-2.5 rounded-xl border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm bg-white">
              {countries.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <button onClick={() => handleExport('cities')} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-50 text-amber-600 hover:bg-amber-100 transition-colors font-cairo font-bold text-sm">
              <MapPin className="w-4 h-4" /> تصدير مدن الدولة
            </button>
          </div>
        </div>
      </div>

      {/* الاستيراد */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <h3 className="font-cairo font-bold text-slate-900 text-sm mb-1 flex items-center gap-2">
          <Upload className="w-4 h-4 text-amber-500" /> استيراد البيانات
        </h3>
        <p className="text-xs text-slate-400 font-tajawal mb-4">ارفع ملف JSON لاستيراد دول أو مدن</p>

        <div className="space-y-4">
          {/* نوع الاستيراد */}
          <div className="flex flex-wrap gap-2">
            {([
              { id: 'full', label: 'الكل (دول + مدن)', icon: FileJson },
              { id: 'countries', label: 'دول فقط', icon: Globe },
              { id: 'cities', label: 'مدن دولة معينة', icon: MapPin },
            ] as const).map((t) => (
              <button key={t.id} onClick={() => setImportType(t.id)} className={`flex items-center gap-2 px-3 py-2 rounded-xl font-cairo font-bold text-sm transition-colors
                ${importType === t.id ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                <t.icon className="w-4 h-4" /> {t.label}
              </button>
            ))}
          </div>

          {importType === 'cities' && (
            <div>
              <label className="block text-xs font-cairo font-bold text-slate-600 mb-1">الدولة المستهدفة</label>
              <select value={importCountry} onChange={(e) => setImportCountry(e.target.value)} className="px-3 py-2 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-sm bg-white">
                {countries.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          )}

          {/* وضع الاستيراد */}
          <div className="flex gap-2">
            {([
              { id: 'merge', label: 'دمج (إضافة للموجود)' },
              { id: 'replace', label: 'استبدال (حذف الموجود)' },
            ] as const).map((m) => (
              <button key={m.id} onClick={() => setImportMode(m.id)} className={`px-3 py-2 rounded-lg font-cairo font-bold text-xs transition-colors
                ${importMode === m.id ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                {m.label}
              </button>
            ))}
          </div>

          {/* رفع الملف */}
          <input ref={fileRef} type="file" accept=".json" onChange={handleFileSelect} className="hidden" />
          <button onClick={() => fileRef.current?.click()} className="w-full border-2 border-dashed border-slate-300 rounded-2xl py-8 flex flex-col items-center gap-2 text-slate-500 hover:border-amber-400 hover:bg-amber-50/30 transition-colors">
            <Upload className="w-8 h-8" />
            <span className="font-cairo font-bold text-sm">اختر ملف JSON</span>
            <span className="text-xs font-tajawal text-slate-400">يدعم ملفات التصدير من هذا النظام</span>
          </button>

          {importPreview && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 min-w-0">
                <FileJson className="w-5 h-5 text-amber-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="font-cairo font-bold text-sm text-slate-800 truncate">{importPreview.name}</p>
                  <p className="text-xs text-slate-500 font-tajawal">{(importPreview.content.length / 1024).toFixed(1)} كيلوبايت — جاهز للاستيراد</p>
                </div>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => setImportPreview(null)} className="px-3 py-2 rounded-lg text-slate-500 hover:bg-slate-100 font-cairo font-bold text-sm">إلغاء</button>
                <button onClick={doImport} className="px-4 py-2 rounded-lg bg-amber-500 text-white hover:bg-amber-600 font-cairo font-bold text-sm">استيراد الآن</button>
              </div>
            </div>
          )}

          <div className="flex items-start gap-2 bg-blue-50 border border-blue-200 rounded-xl p-3">
            <AlertCircle className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-blue-700 font-tajawal leading-relaxed">
              صيغة الملف المتوقوعة: JSON يحتوي على <code className="bg-blue-100 px-1 rounded">{'{ "countries": [...], "citiesByCountry": {...} }'}</code> للتصدير الكامل، أو <code className="bg-blue-100 px-1 rounded">{'{ "cities": [...] }'}</code> لمدن دولة معينة. عند اختيار «استبدال» تُحذف البيانات الحالية للقسم المُستورد.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ====================================================================
//  حالة فارغة
// ====================================================================
function EmptyState({ icon: Icon, title, desc }: { icon: typeof Globe; title: string; desc: string }) {
  return (
    <div className="py-12 text-center">
      <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-3">
        <Icon className="w-8 h-8 text-slate-300" />
      </div>
      <p className="font-cairo font-bold text-slate-600">{title}</p>
      <p className="text-xs text-slate-400 font-tajawal mt-1">{desc}</p>
    </div>
  );
}
