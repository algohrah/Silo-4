import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  MapPin, ShieldCheck, Crown, Bookmark, Eye,
  Briefcase, Calendar, Users, Heart,
} from 'lucide-react';
import type { Member } from '../lib/members';
import { getAvatar, getGenderColors } from '../lib/types';
import { useApp } from '../lib/AppContext';
import { getCompatBadgeColor } from '../lib/compatibility';

export default function MemberCard({ member }: { member: Member; key?: any }) {
  const { likedMembers, toggleLike, calculateCompatDetailed } = useApp();
  const liked = likedMembers.has(member.id);
  const safeGender = (member.gender === 'male' || member.gender === 'female' ? member.gender : 'female') as any;
  const avatar = getAvatar(safeGender);
  const c = getGenderColors(safeGender);
  const isMale = member.gender === 'male';
  const displayName = member.nickname || member.realName || member.id;

  // حساب نسبة التوافق التفصيلي مع الأسباب والألوان
  const compat = calculateCompatDetailed(member);
  const compatScore = compat.score;
  const badge = getCompatBadgeColor(compatScore, compat.isGenderMatch);

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 300, damping: 22 }}
      className="group bg-white rounded-2xl overflow-hidden shadow-soft hover:shadow-luxe transition-shadow duration-500 border border-cream-200/70 flex flex-col h-full"
    >
      <Link to={`/member/${member.id}`} className="block flex flex-col flex-1 no-tap-highlight">
        {/* ===== الرأس المبسّط: الصورة + الاسم + صف الشارات ===== */}
        <div className={`relative ${c.bg} p-3 sm:p-4`}>
          <div className="flex items-center gap-2.5 sm:gap-3">
            {/* الصورة الافتراضية */}
            <div className="relative flex-shrink-0">
              <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white flex items-center justify-center overflow-hidden ring-2 ${c.ring} ring-opacity-30 shadow-sm`}>
                <img src={avatar} alt="" className="w-full h-full object-contain p-1.5" />
              </div>
              {member.online && (
                <span className="absolute -bottom-0.5 -left-0.5 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-emerald-500 ring-2 ring-white" />
              )}
            </div>

            {/* الاسم + صف الشارات المرتّب */}
            <div className="flex-1 min-w-0 pr-1">
              <h3 className="font-cairo font-bold text-navy-900 text-sm sm:text-base leading-tight truncate">
                {displayName}
              </h3>
              {/* صف واحد مرتّب لجميع الشارات */}
              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md ${c.badgeBg} text-white`}>
                  <GenderIcon isMale={isMale} white />
                  <span className="text-[9px] sm:text-[10px] font-cairo font-bold">{isMale ? 'رجل' : 'امرأة'}</span>
                </span>
                {member.verified && (
                  <span className="inline-flex items-center gap-0.5 bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded-md" title="موثّق">
                    <ShieldCheck className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  </span>
                )}
                {(member.plan === 'elite' || (member.premium && member.plan !== 'gold')) && (
                  <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-600 border border-rose-200/50 px-1.5 py-0.5 rounded-md font-cairo font-extrabold text-[9px] sm:text-[10px]" title="الباقة المميزة">
                    <span>⭐</span>
                    <span>مميز</span>
                  </span>
                )}
                {member.plan === 'gold' && (
                  <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-600 border border-amber-200/50 px-1.5 py-0.5 rounded-md font-cairo font-extrabold text-[9px] sm:text-[10px]" title="الباقة الذهبية">
                    <Crown className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-500" />
                    <span>ذهبي</span>
                  </span>
                )}
                {member.hasSeriousnessBadge && (
                  <span className="inline-flex items-center gap-0.5 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-extrabold text-[8px] md:text-[9px] px-1.5 py-0.5 rounded-md font-cairo" title="وسام الجدية المعتمد">
                    🏅 جاد
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* ===== جسم البطاقة ===== */}
        <div className="p-3 sm:p-4 flex flex-col flex-1">
          {/* الموقع */}
          <div className="flex items-center gap-1.5 bg-cream-50 rounded-lg px-2.5 py-2 border border-cream-200/60 mb-2.5">
            <MapPin className={`w-3.5 h-3.5 ${c.text} flex-shrink-0`} />
            <span className="font-tajawal text-xs sm:text-sm text-navy-700 truncate">
              {[member.city, member.country].filter(Boolean).join('، ') || 'الموقع غير محدد'}
            </span>
          </div>

          {/* شبكة المعلومات: العمر + الحالة + الوظيفة */}
          <div className="grid grid-cols-3 gap-1 sm:gap-2 mb-2.5">
            {[
              { icon: Calendar, label: 'العمر', value: `${member.age} سنة`, sub: '' },
              { icon: Users, label: 'الحالة', value: member.maritalLabel, sub: '' },
              { icon: Briefcase, label: 'العمل', value: member.jobTitle || member.workType || '—', sub: '' },
            ].map((item, idx) => (
              <div key={idx} className="bg-cream-50 rounded-lg p-1 sm:p-2 text-center border border-cream-200/60 h-full flex flex-col justify-between">
                <div>
                  <item.icon className={`w-3 h-3 sm:w-3.5 sm:h-3.5 ${c.text} mx-auto mb-1 flex-shrink-0`} />
                  <div className="text-[10px] sm:text-[11px] font-cairo font-extrabold text-navy-900 leading-[1.1] break-words whitespace-normal line-clamp-2 px-0.5" title={item.value}>
                    {item.value}
                  </div>
                </div>
                <div className="text-[8px] sm:text-[9px] text-navy-400 font-tajawal break-words whitespace-normal line-clamp-1 mt-1">
                  {item.label}
                </div>
              </div>
            ))}
          </div>

          {/* قسم "أبحث عن" */}
          <div className={`rounded-xl ${c.bg} p-2.5 sm:p-3 mb-3 flex-1`}>
            <div className="flex items-center gap-1 mb-0.5">
              <Heart className={`w-3 h-3 ${c.text}`} />
              <span className={`text-[10px] sm:text-[11px] font-cairo font-bold ${c.textStrong}`}>أبحث عن</span>
            </div>
            <p className="text-[11px] sm:text-[12px] text-navy-600 font-tajawal leading-snug line-clamp-2">
              {member.aboutPartner || (member as any).pNotes || (member as any).p_notes || 'لم تُضف مواصفات الشريك بعد'}
            </p>
          </div>

          {/* الأزرار — زر الحفظ أيقونة فقط + زر العرض موسّع */}
          <div className="mt-auto flex items-center gap-2">
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggleLike(member.id);
              }}
              aria-label="حفظ الملف"
              className={`flex items-center justify-center w-11 h-11 sm:w-12 sm:h-12 rounded-xl transition-all duration-300 no-tap-highlight flex-shrink-0 ${
                liked ? 'bg-gold-500 text-white shadow-soft' : 'bg-cream-100 text-navy-500 hover:bg-cream-200'
              }`}
            >
              <Bookmark className={`w-4.5 h-4.5 sm:w-5 sm:h-5 ${liked ? 'fill-white' : ''}`} />
            </button>
            <div className={`flex-1 h-11 sm:h-12 flex items-center justify-center gap-2 rounded-xl ${c.bgStrong} text-white font-cairo font-bold text-xs sm:text-sm transition-all hover:brightness-110 shadow-sm cursor-pointer`}>
              <Eye className="w-4.5 h-4.5 sm:w-5 sm:h-5" />
              عرض
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

/* أيقونة جنس مخصصة */
function GenderIcon({ isMale, white }: { isMale: boolean; white?: boolean }) {
  const color = white ? 'white' : 'currentColor';
  return (
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
      {isMale ? (
        <path d="M14 6h6v6M20 6l-7 7M10 6H4v6M4 6l7 7M14 18h6M10 18H4" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      ) : (
        <circle cx="12" cy="12" r="6" stroke={color} strokeWidth="2.2" />
      )}
    </svg>
  );
}
