import supabase from './db-client.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function isSchemaCacheError(error) {
  return !!error && (
    error.code === 'PGRST204' ||
    String(error.message || '').toLowerCase().includes('schema cache') ||
    String(error.details || '').toLowerCase().includes('schema cache')
  );
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, userId, requestId } = req.query;
      let query = supabase.from('transactions').select('*');
      if (id) query = query.eq('id', Number(id)).maybeSingle();
      else {
        if (userId) query = query.eq('user_id', String(userId));
        if (requestId) query = query.eq('request_id', Number(requestId));
        query = query.order('created_at', { ascending: false });
      }
      const { data, error } = await query;
      if (isSchemaCacheError(error) && requestId) return res.status(200).json([]);
      if (error) throw error;
      return res.status(200).json(data || (id ? null : []));
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const row = {
        user_id: body.user_id || body.userId || 'system',
        request_id: body.request_id || body.requestId || null,
        amount: Number(body.amount || body.price || 0),
        type: body.type || 'payment',
        description: body.description || '',
        status: body.status || 'completed',
        metadata: body.metadata || body.details || {},
      };
      let { data, error } = await supabase.from('transactions').insert(row).select().single();
      if (isSchemaCacheError(error)) {
        const { request_id, metadata, ...minimalRow } = row;
        const fallback = await supabase.from('transactions').insert(minimalRow).select().single();
        data = fallback.data;
        error = fallback.error;
      }
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...fields } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase.from('transactions').update(fields).eq('id', Number(id)).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('transactions').delete().eq('id', Number(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Transactions API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
