import supabase from './db-client.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { requestId } = req.query;
      let query = supabase.from('inquiry_messages').select('*');
      if (requestId) query = query.eq('request_id', Number(requestId));
      query = query.order('created_at', { ascending: true });
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const row = {
        request_id: Number(body.request_id || body.requestId),
        sender_id: body.sender_id || body.senderId || 'admin',
        text: body.text || '',
        charged_to: body.charged_to || body.chargedTo || null,
        status: body.status || 'approved',
        moderated_by: body.moderated_by || null,
      };
      if (!row.request_id || !row.text) return res.status(400).json({ error: 'requestId and text are required' });
      const { data, error } = await supabase.from('inquiry_messages').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, action, moderatorName, ...fields } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const update = action ? { status: action === 'approve' ? 'approved' : 'rejected', moderated_by: moderatorName || 'الإدارة' } : fields;
      const { data, error } = await supabase.from('inquiry_messages').update(update).eq('id', Number(id)).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('inquiry_messages').delete().eq('id', Number(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Inquiry messages API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
