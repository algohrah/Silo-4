import supabase from './db-client.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, memberId } = req.query;
      let query = supabase.from('verification_docs').select('*');
      if (id) query = query.eq('id', String(id)).maybeSingle();
      else {
        if (memberId) query = query.eq('member_id', String(memberId));
        query = query.order('created_at', { ascending: false });
      }
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || (id ? null : []));
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const docId = body.id || `doc_${Date.now()}`;
      let fileUrl = body.file_url || body.fileUrl || '';

      if (body.docBase64 || body.fileBase64) {
        const raw = body.docBase64 || body.fileBase64;
        const match = String(raw).match(/^data:([^;]+);base64,(.+)$/);
        const contentType = body.contentType || (match ? match[1] : 'image/jpeg');
        const base64 = match ? match[2] : raw;
        const extension = contentType.includes('png') ? 'png' : contentType.includes('webp') ? 'webp' : 'jpg';
        const fileName = `${body.member_id || body.memberId || 'member'}/${docId}.${extension}`;
        const buffer = Buffer.from(base64, 'base64');
        const { error: uploadError } = await supabase.storage
          .from('verification-docs')
          .upload(fileName, buffer, { contentType, upsert: true });
        if (!uploadError) {
          const { data: urlData } = supabase.storage.from('verification-docs').getPublicUrl(fileName);
          fileUrl = urlData.publicUrl;
        }
      }

      const row = {
        id: docId,
        member_id: body.member_id || body.memberId,
        doc_type: body.doc_type || body.docType || 'identity',
        file_url: fileUrl,
        status: body.status || 'pending',
        reviewer_name: body.reviewer_name || body.reviewerName || '',
        rejection_reason: body.rejection_reason || body.rejectionReason || '',
        details: {
          ...(body.details || {}),
          docName: body.docName || body.doc_name || '',
          docSizeKB: body.docSizeKB || body.doc_size_kb || null,
          memberNickname: body.memberNickname || '',
          memberRealName: body.memberRealName || '',
          memberEmail: body.memberEmail || '',
        },
        updated_at: new Date().toISOString(),
      };
      if (!row.member_id) return res.status(400).json({ error: 'memberId is required' });
      const { data, error } = await supabase.from('verification_docs').upsert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...fields } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const update = { ...fields, updated_at: new Date().toISOString() };
      const { data, error } = await supabase.from('verification_docs').update(update).eq('id', String(id)).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('verification_docs').delete().eq('id', String(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Verification docs API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
