import supabase from './db-client.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { key } = req.query;
      let query = supabase.from('settings').select('*');
      if (key) query = query.eq('key', String(key)).maybeSingle();
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || (key ? null : []));
    }

    if (req.method === 'POST' || req.method === 'PUT') {
      const { key, value } = req.body || {};
      if (!key) return res.status(400).json({ error: 'key is required' });
      const { data, error } = await supabase.from('settings').upsert({ key, value: String(value ?? ''), updated_at: new Date().toISOString() }).select().single();
      if (error) throw error;
      return res.status(req.method === 'POST' ? 201 : 200).json(data);
    }

    if (req.method === 'DELETE') {
      const { key } = req.body || {};
      if (!key) return res.status(400).json({ error: 'key is required' });
      const { error } = await supabase.from('settings').delete().eq('key', String(key));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Settings API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
