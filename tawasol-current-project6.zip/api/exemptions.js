import supabase from './db-client.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function fromDb(r) {
  if (!r) return r;
  return {
    id: r.id,
    requestId: r.request_id || '',
    userId: r.user_id || '',
    userNickname: r.user_nickname || '',
    reason: r.reason || '',
    status: r.status || 'pending',
    createdAt: r.created_at ? new Date(r.created_at).getTime() : Date.now(),
  };
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id, userId } = req.query;
      let query = supabase.from('exemption_requests').select('*');
      if (id) query = query.eq('id', String(id)).maybeSingle();
      else {
        if (userId) query = query.eq('user_id', String(userId));
        query = query.order('created_at', { ascending: false });
      }
      const { data, error } = await query;
      if (error) throw error;
      if (id) return res.status(200).json(fromDb(data));
      return res.status(200).json((data || []).map(fromDb));
    }

    if (req.method === 'POST') {
      const b = req.body || {};
      const row = {
        id: b.id || `ex_${Date.now()}`,
        request_id: b.requestId || b.request_id || '',
        user_id: b.userId || b.user_id || '',
        user_nickname: b.userNickname || b.user_nickname || '',
        reason: b.reason || '',
        status: b.status || 'pending',
      };
      const { data, error } = await supabase.from('exemption_requests').upsert(row).select().single();
      if (error) throw error;
      return res.status(201).json(fromDb(data));
    }

    if (req.method === 'PUT') {
      const { id, status, reason } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const update = {};
      if (status !== undefined) update.status = status;
      if (reason !== undefined) update.reason = reason;
      const { data, error } = await supabase.from('exemption_requests').update(update).eq('id', String(id)).select().single();
      if (error) throw error;
      return res.status(200).json(fromDb(data));
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('exemption_requests').delete().eq('id', String(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Exemptions API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
