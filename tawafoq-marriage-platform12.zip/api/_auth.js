import supabase from './db-client.js';

// ============================================================
//  مساعد المصادقة والصلاحيات المشتركة (Server-side only)
//  ملاحظة: هذا الملف محمي بالشرطة السفلية (_) فلا يتحول إلى
//  مسار API منفصل في Vercel — يُستورد فقط من ملفات api/*.js الأخرى.
// ============================================================

/**
 * التحقق من توكن Bearer واسترداد المستخدم الحقيقي من Supabase Auth.
 * ملاحظة: بعض الطلبات (مثل navigator.sendBeacon عند إغلاق/تبديل التبويب) لا يمكنها إرفاق
 * ترويسة Authorization، لذا نقبل الرمز أيضاً كحقل احتياطي `_authToken` داخل نص الطلب (body).
 */
export async function getAuthUser(req) {
  const headerToken = req.headers.authorization?.replace('Bearer ', '').trim();
  const bodyToken = req.body && typeof req.body === 'object' ? req.body._authToken : undefined;
  const token = headerToken || bodyToken;
  if (!token) return null;
  try {
    const { data, error } = await supabase.auth.getUser(token);
    if (error || !data?.user) return null;
    return data.user;
  } catch {
    return null;
  }
}

/** هل هذا البريد مسجّل في جدول المشرفين admin_users؟ */
export async function isAdminEmail(email) {
  if (!email) return false;
  const { data } = await supabase.from('admin_users').select('id').eq('email', String(email).toLowerCase()).maybeSingle();
  return !!data;
}

/** الربط بين حساب Supabase Auth ومعرف العضو في جدول members */
export async function getMemberLink(authUserId) {
  if (!authUserId) return null;
  const { data } = await supabase.from('member_auth_links').select('*').eq('auth_user_id', authUserId).maybeSingle();
  return data;
}

/** يتطلّب صلاحية إدارية حقيقية فقط — يُرد الرد 401/403 تلقائياً ويُرجع null إذا ممنوع */
export async function requireAdmin(req, res) {
  const user = await getAuthUser(req);
  if (!user) { res.status(401).json({ error: 'يجب تسجيل الدخول للقيام بهذا الإجراء' }); return null; }
  const admin = await isAdminEmail(user.email);
  if (!admin) { res.status(403).json({ error: 'لا تملك الصلاحية الإدارية اللازمة لهذا الإجراء' }); return null; }
  return user;
}

/**
 * يخوّل إجراءات يدعي فيها الطرف ملكية memberId معيّنة (إرسال اهتمام/توثيق/بلاف...):
 *  - يسمح إذا كان المستخدم مشرفًا حقيقيًا (يشمل وضع "تصفح كـ" الإداري)
 *  - أو إذا كان المستخدم هو العضو نفسه المرتبط بحساب Supabase Auth الخاص به
 */
export async function authorizeMemberAction(req, res, claimedMemberId) {
  const user = await getAuthUser(req);
  if (!user) { res.status(401).json({ error: 'يجب تسجيل الدخول للقيام بهذا الإجراء' }); return null; }
  if (await isAdminEmail(user.email)) return { user, memberId: claimedMemberId, isAdmin: true };
  const link = await getMemberLink(user.id);
  if (link && String(link.member_id) === String(claimedMemberId)) return { user, memberId: claimedMemberId, isAdmin: false };
  res.status(403).json({ error: 'لا تملك صلاحية لتنفيذ هذا الإجراء لهذا الحساب' }); return null;
}
