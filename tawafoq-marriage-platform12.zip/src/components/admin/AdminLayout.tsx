import { dataService } from '../../lib/data/DataService';
import { useState, useMemo, useEffect, useRef } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Users, Heart, ShieldCheck, Settings, LogOut, Menu,
  MessageSquare, FileText, CreditCard, BarChart3, Bell, Globe,
  ShieldAlert, ClipboardList, Ticket, BadgeCheck, UserCog, FileMinus,
  Upload, Table, DollarSign, Tag, MapPin, Mail, Lock, Eye, EyeOff,
  AlertCircle, Key
} from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { useReviewMarkers } from '../../lib/useReviewMarkers';
import supabaseClient from '../../lib/supabase';

import AdminErrorBoundary from './AdminErrorBoundary';
const { getPendingCitiesCount } = dataService.db;

/** يتحقق من صلاحية الإدارة الحقيقية عبر الجلسة الحالية + /api/whoami (لا يعتمد على أي علم محلي قابل للتلاعب) */
async function verifyAdminSession(): Promise<boolean> {
  try {
    const { data: { session } } = await supabaseClient.auth.getSession();
    if (!session?.access_token) return false;
    const res = await fetch('/api/whoami', { headers: { Authorization: `Bearer ${session.access_token}` } });
    if (!res.ok) return false;
    const who = await res.json();
    return !!who?.isAdmin;
  } catch {
    return false;
  }
}

export default function AdminLayout() {
  const [authState, setAuthState] = useState<'checking' | 'authed' | 'denied'>('checking');

  useEffect(() => {
    let mounted = true;
    verifyAdminSession().then((ok) => { if (mounted) setAuthState(ok ? 'authed' : 'denied'); });
    const { data: { subscription } } = supabaseClient.auth.onAuthStateChange(() => {
      verifyAdminSession().then((ok) => { if (mounted) setAuthState(ok ? 'authed' : 'denied'); });
    });
    return () => { mounted = false; subscription.unsubscribe(); };
  }, []);

  const handleAdminLogout = () => {
    supabaseClient.auth.signOut().catch(() => undefined);
    setAuthState('denied');
  };

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  const {
    interestRequests,
    reports,
    supportTickets,
    currentAdminPermissions,
    currentAdminRole,
    user,
    adminMembers,
    exemptRequests,
  } = useApp();

  // كشف وضع الانتحال
  const [impersonating, setImpersonating] = useState<string | null>(null);
  useEffect(() => {
    const check = () => {
      if (typeof window !== 'undefined') {
        const id = dataService.db.settings.get('active_member_id');
        setImpersonating(id && id !== 'm2' ? id : null);
      }
    };
    check();
    window.addEventListener('storage', check);
    const interval = setInterval(check, 5000);
    return () => { window.removeEventListener('storage', check); clearInterval(interval); };
  }, []);

  // ملاحظة مهمة (إصلاح خطأ React #310 "hooks count mismatch"):
  // لا نضع أي return مبكر هنا قبل استدعاء كل الخطّافات (hooks) بالأسفل — يجب أن يُستدعى
  // العدد نفسه من الخطّافات في كل تصيير (render) بغض النظر عن حالة authState. التفريع
  // الشرطي (checking/denied/authed) يتم فقط عند بناء الـ JSX النهائي في نهاية الدالة.
  const pendingRequests = interestRequests.filter((r) => r.status === 'pending').length;

  // عدّ العناصر غير المُراجَعة (التي تحتاج انتباه) من تتبّع المراجعة الدائم
  const { isReviewed: isReportReviewed } = useReviewMarkers('twafok_reviewed_reports');
  const { isReviewed: isTicketReviewed } = useReviewMarkers('twafok_reviewed_tickets');
  const pendingReports = reports.filter((r) => r.status === 'pending' && !isReportReviewed(r.id)).length;
  const openTickets = supportTickets.filter(
    (t) => (t.status === 'open' || t.status === 'in_progress') && !isTicketReviewed(t.id)
  ).length;
  const pendingCities = getPendingCitiesCount();

  // طلبات التوثيق المعلقة
  const pendingVerifications = useMemo(() => {
    let statusMap: Record<string, string> = {};
    if (typeof window !== 'undefined') {
      try {
        const raw = dataService.db.settings.get('twafok_verif_status');
        if (raw) statusMap = JSON.parse(raw);
      } catch { /* تجاهل */ }
    }
    const list = adminMembers || [];
    return list.filter((m) => {
      const status = m.verified ? 'verified' : (statusMap[m.id] || 'pending');
      return status === 'pending';
    }).length;
  }, [adminMembers]);

  // طلبات الإعفاء المعلقة
  const pendingExemptions = useMemo(() => {
    const list = exemptRequests || [];
    return list.filter((e) => e.status === 'pending').length;
  }, [exemptRequests]);

  // عدد طلبات التنسيق النشطة للمستوردين
  const pendingImportedCoordination = useMemo(() => {
    const list = interestRequests || [];
    const membersList = adminMembers || [];
    return list.filter((r) => {
      const sender = membersList.find((m) => m.id === r.senderId);
      const receiver = membersList.find((m) => m.id === r.receiverId);
      const hasImported = sender?.sourceType === 'imported' || receiver?.sourceType === 'imported';
      const isActive = !['declined', 'cancelled', 'completed'].includes(r.status);
      return hasImported && isActive;
    }).length;
  }, [interestRequests, adminMembers]);

  const navSections: NavSection[] = [
    {
      title: 'الرؤية العامة',
      icon: LayoutDashboard,
      items: [
        { to: '/admin', label: 'لوحة المعلومات', icon: LayoutDashboard, end: true },
        { to: '/admin/analytics', label: 'التحليلات المتقدمة', icon: BarChart3, end: false },
      ],
    },
    ...(currentAdminPermissions.manage_members
      ? [
          {
            title: 'إدارة المستخدمين',
            icon: Users,
            items: [
              { to: '/admin/members', label: 'الأعضاء', icon: Users, end: false },
              { to: '/admin/import-members', label: 'استيراد الأعضاء', icon: Upload, end: false },
              { to: '/admin/cities', label: 'الدول والمدن', icon: MapPin, end: false, badge: pendingCities, badgeColor: 'bg-amber-500' },
              { to: '/admin/verifications', label: 'طلبات التوثيق', icon: BadgeCheck, end: false, badge: pendingVerifications, badgeColor: 'bg-rose-500' },
              { to: '/admin/moderators', label: 'المشرفين والصلاحيات', icon: UserCog, end: false },
            ],
          },
        ]
      : []),
    ...(currentAdminPermissions.manage_requests
      ? [
          {
            title: 'إدارة الرحلات',
            icon: Heart,
            items: [
              {
                to: '/admin/requests',
                label: 'طلبات الاهتمام',
                icon: Heart,
                end: false,
                badge: pendingRequests,
                badgeColor: 'bg-rose-500',
              },
              {
                to: '/admin/imported-coordination',
                label: 'التنسيق للمستوردين',
                icon: Heart,
                end: false,
                badge: pendingImportedCoordination,
                badgeColor: 'bg-emerald-600',
              },
            ],
          },
        ]
      : []),
    ...(currentAdminPermissions.manage_support
      ? [
          {
            title: 'الدعم والسلامة',
            icon: ShieldCheck,
            items: [
              { to: '/admin/messages', label: 'تذاكر الدعم الفني', icon: Ticket, end: false, badge: openTickets, badgeColor: 'bg-amber-500' },
              { to: '/admin/reports', label: 'البلاغات والشكاوى', icon: ShieldAlert, end: false, badge: pendingReports, badgeColor: 'bg-red-500' },
              { to: '/admin/audit-log', label: 'سجل التدقيق', icon: ClipboardList, end: false },
            ],
          },
        ]
      : []),
    ...(currentAdminPermissions.manage_members
      ? [
          {
            title: 'الإيرادات والاشتراكات',
            icon: DollarSign,
            items: [
              { to: '/admin/plans', label: 'الباقات والأسعار', icon: CreditCard, end: false },
              { to: '/admin/transactions', label: 'المعاملات المالية', icon: DollarSign, end: false },
              { to: '/admin/coupons', label: 'الكوبونات والعروض', icon: Tag, end: false },
              { to: '/admin/exemptions', label: 'الإعفاءات والتسهيلات', icon: FileMinus, end: false, badge: pendingExemptions, badgeColor: 'bg-amber-500' },
            ],
          },
        ]
      : []),
    ...(currentAdminPermissions.manage_content
      ? [
          {
            title: 'المحتوى والتسويق',
            icon: FileText,
            items: [
              { to: '/admin/notifications', label: 'الإشعارات والحملات', icon: Bell, end: false },
            ],
          },
        ]
      : []),
    ...(currentAdminRole === 'super_admin'
      ? [
          {
            title: 'الإعدادات',
            icon: Settings,
            items: [
              { to: '/admin/settings/platform', label: 'إعدادات المنصة', icon: Globe, end: false },
              { to: '/admin/settings/payments', label: 'إعدادات الدفع', icon: CreditCard, end: false },
              { to: '/admin/settings/features', label: 'إعدادات الميزات', icon: Settings, end: false },
              { to: '/admin/settings/security', label: 'الأمان والنظام', icon: ShieldCheck, end: false },
              { to: '/admin/cities', label: 'إدارة الدول والمدن', icon: Globe, end: false },
            ],
          },
        ]
      : []),
  ];

  const activeSection = useMemo(() => {
    for (const section of navSections) {
      for (const item of section.items) {
        if (item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)) {
          return section.title;
        }
      }
    }
    return 'الرؤية العامة';
  }, [location.pathname, navSections]);

  const [openSections, setOpenSections] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = { 'الرؤية العامة': true };
    navSections.forEach((s) => {
      init[s.title] = s.title === activeSection || s.title === 'الرؤية العامة';
    });
    return init;
  });

  useEffect(() => {
    setOpenSections((prev) => ({ ...prev, [activeSection]: true }));
  }, [activeSection]);

  const toggleSection = (title: string) => {
    setOpenSections((prev) => ({ ...prev, [title]: !prev[title] }));
  };

  const filteredSections = useMemo(() => {
    if (!searchQuery.trim()) return navSections;
    return navSections
      .map((section) => ({
        ...section,
        items: section.items.filter(
          (item) => item.label.includes(searchQuery) || section.title.includes(searchQuery)
        ),
      }))
      .filter((section) => section.items.length > 0);
  }, [searchQuery, navSections]);

  const currentTitle = (() => {
    for (const section of navSections) {
      for (const item of section.items) {
        if (item.end ? location.pathname === item.to : location.pathname.startsWith(item.to)) {
          return item.label;
        }
      }
    }
    return 'لوحة التحكم';
  })();

  const sidebarContent = (
    <AdminSidebarContent
      sections={filteredSections}
      openSections={openSections}
      toggleSection={toggleSection}
      onNavigate={() => setSidebarOpen(false)}
      searchQuery={searchQuery}
      setSearchQuery={setSearchQuery}
      onLogout={handleAdminLogout}
    />
  );

  // التفريع الشرطي لحالة المصادقة يحدث هنا فقط — بعد استدعاء كل الخطّافات أعلاه بلا استثناء،
  // لتفادي خطأ React #310 (اختلاف عدد الخطّافات المستدعاة بين التصييرات المتتالية).
  if (authState === 'checking') {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center" dir="rtl">
        <div className="w-10 h-10 border-4 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (authState === 'denied') {
    return <AdminLoginScreen onLoginSuccess={() => setAuthState('authed')} />;
  }

  return (
    <div className="min-h-screen bg-slate-100" dir="rtl">
      <aside className="hidden lg:flex fixed top-0 right-0 bottom-0 w-60 bg-gradient-to-b from-navy-950 to-navy-900 flex-col z-50 border-l border-white/5 shadow-xl">
        {sidebarContent}
      </aside>

      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-[60]">
          <div className="absolute inset-0 bg-navy-950/70 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute top-0 right-0 bottom-0 w-72 bg-gradient-to-b from-navy-950 to-navy-900 flex flex-col animate-float-up shadow-2xl">
            {sidebarContent}
          </aside>
        </div>
      )}

      <div className="lg:mr-60">
        <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between px-4 sm:px-6 h-14">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-lg hover:bg-slate-100 text-slate-700 transition-colors"
                title="القائمة"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-tajawal">
                  <span>لوحة الإدارة</span>
                  <span>/</span>
                  <span className="text-amber-600 font-bold">{activeSection}</span>
                </div>
                <h1 className="font-cairo font-black text-sm sm:text-base text-slate-900 leading-tight">
                  {currentTitle}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2.5 sm:gap-3">
              {/* شارة حالة قاعدة البيانات */}
              <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200/60 text-emerald-700 text-[11px] font-tajawal font-bold shadow-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>الخادم نشط</span>
              </div>

              <Link
                to="/"
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-cairo font-bold text-slate-700 bg-slate-100/80 hover:bg-slate-200/80 transition-colors"
              >
                <Globe className="w-3.5 h-3.5 text-slate-500" /> عرض المنصة
              </Link>

              <NotificationsBell
                pendingRequests={pendingRequests}
                pendingReports={pendingReports}
                openTickets={openTickets}
                pendingCities={pendingCities}
              />

              <div className="flex items-center gap-2 pr-1 border-r border-slate-200/80 pl-1">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white font-bold text-xs shadow-xs">
                  إ
                </div>
                <div className="hidden sm:block text-right">
                  <p className="text-xs font-cairo font-bold text-slate-800 leading-none">الإدارة</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {currentAdminRole === 'super_admin' ? 'مدير عام' : 'مشرف'}
                  </p>
                </div>
              </div>

              <button
                onClick={handleAdminLogout}
                title="تسجيل الخروج من لوحة الإدارة"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-cairo font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 transition-colors border border-rose-200/60"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">خروج</span>
              </button>
            </div>
          </div>

          {impersonating && (
            <div className="bg-gradient-to-l from-amber-500 to-amber-400 px-4 py-2 flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 font-cairo font-bold text-xs text-navy-950">
                <UserCog className="w-4 h-4 flex-shrink-0" />
                أنت تتصفّح بحساب عضو: <strong>{user?.name || impersonating}</strong>
              </span>
              <Link
                to="/"
                className="flex items-center gap-1.5 bg-navy-950 text-amber-300 font-cairo font-bold text-xs px-3 py-1.5 rounded-lg hover:bg-navy-800 transition-colors flex-shrink-0"
              >
                <Globe className="w-3.5 h-3.5" /> عرض كالعضو
              </Link>
            </div>
          )}
        </header>

        <main className="p-3 sm:p-5 lg:p-6 max-w-[1500px] mx-auto">
          <AdminErrorBoundary resetKey={location.pathname}>
            <Outlet />
          </AdminErrorBoundary>
        </main>
      </div>
    </div>
  );
}

function AdminSidebarContent({
  sections,
  openSections,
  toggleSection,
  onNavigate,
  searchQuery,
  setSearchQuery,
  onLogout,
}: {
  sections: NavSection[];
  openSections: Record<string, boolean>;
  toggleSection: (title: string) => void;
  onNavigate?: () => void;
  searchQuery: string;
  setSearchQuery: (v: string) => void;
  onLogout?: () => void;
}) {
  return (
    <>
      <div className="flex items-center justify-between p-4 border-b border-slate-700/50">
        <Link to="/admin" onClick={onNavigate} className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-cairo font-bold text-white">لوحة الإدارة</div>
            <div className="text-[10px] text-amber-400">توافق</div>
          </div>
        </Link>
      </div>

      <div className="p-2.5 border-b border-slate-700/50">
        <div className="relative">
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">🔍</span>
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في القائمة..."
            className="w-full pr-9 pl-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-tajawal placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-2.5 space-y-1">
        {sections.map((section) => {
          const isOpen = openSections[section.title] !== false;
          const totalSectionBadges = section.items.reduce((acc, item) => acc + (item.badge || 0), 0);
          return (
            <div key={section.title} className="rounded-2xl overflow-hidden">
              <button
                onClick={() => toggleSection(section.title)}
                className={`w-full flex items-center justify-between px-2.5 py-2 text-[11px] font-cairo font-bold rounded-xl transition-colors ${
                  isOpen ? 'text-amber-400 bg-white/5' : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-2">
                  <section.icon className="w-4 h-4" />
                  {section.title}
                </div>
                <div className="flex items-center gap-2">
                  {totalSectionBadges > 0 && !isOpen && (
                    <span className="w-2 h-2 rounded-full bg-rose-500 ring-4 ring-rose-500/30 animate-pulse" />
                  )}
                  {totalSectionBadges > 0 && isOpen && (
                    <span className="text-[10px] text-white bg-rose-500/90 px-1.5 py-0.5 rounded-full font-sans">
                      {totalSectionBadges}
                    </span>
                  )}
                  <span className={`text-[10px] transition-transform ${isOpen ? 'rotate-180' : ''}`}>▼</span>
                </div>
              </button>
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="space-y-1 mt-1 pr-2">
                      {section.items.map((item) => (
                        <NavLink
                          key={item.to}
                          to={item.to}
                          end={item.end}
                          onClick={onNavigate}
                          label={item.label}
                          icon={item.icon}
                          badge={item.badge}
                          badgeColor={item.badgeColor}
                        />
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </nav>

      <div className="p-2.5 border-t border-slate-700/50 space-y-1">
        {onLogout && (
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition-colors cursor-pointer text-right"
          >
            <LogOut className="w-4.5 h-4.5 text-rose-400" />
            <span className="font-cairo font-semibold text-xs">تسجيل الخروج</span>
          </button>
        )}
        <Link
          to="/"
          onClick={onNavigate}
          className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <Globe className="w-4.5 h-4.5" />
          <span className="font-cairo font-semibold text-xs">العودة للموقع</span>
        </Link>
      </div>
    </>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  end,
  onClick,
  badge,
  badgeColor,
}: {
  key?: string;
  to: string;
  label: string;
  icon: any;
  end: boolean;
  onClick?: () => void;
  badge?: number;
  badgeColor?: string;
}) {
  const location = useLocation();
  const active = end ? location.pathname === to : location.pathname.startsWith(to);
  return (
    <Link
      to={to}
      onClick={onClick}
      className={`group flex items-center gap-2.5 px-3 py-2 rounded-xl font-cairo font-semibold text-xs transition-all no-tap-highlight ${
        active
          ? 'bg-gold-gradient text-navy-950 shadow-gold'
          : 'text-slate-400 hover:bg-white/5 hover:text-white'
      }`}
    >
      <Icon className={`w-4.5 h-4.5 flex-shrink-0 ${active ? 'text-navy-900' : 'group-hover:text-amber-400'}`} />
      <span className="flex-1">{label}</span>
      {badge !== undefined && badge > 0 && (
        <span
          className={`text-white text-[10px] font-bold min-w-5 h-5 px-1 rounded-full flex items-center justify-center ${
            active ? 'bg-navy-900 text-amber-300' : badgeColor || 'bg-rose-500'
          }`}
        >
          {badge > 9 ? '9+' : badge}
        </span>
      )}
    </Link>
  );
}

function NotificationsBell({
  pendingRequests,
  pendingReports,
  openTickets,
  pendingCities,
}: {
  pendingRequests: number;
  pendingReports: number;
  openTickets: number;
  pendingCities: number;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const total = pendingRequests + pendingReports + openTickets + pendingCities;

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const items = [
    {
      show: pendingRequests > 0,
      to: '/admin/requests',
      icon: Heart,
      color: 'text-rose-500 bg-rose-50',
      label: 'طلبات اهتمام معلّقة',
      count: pendingRequests,
    },
    {
      show: openTickets > 0,
      to: '/admin/messages',
      icon: MessageSquare,
      color: 'text-amber-500 bg-amber-50',
      label: 'تذاكر دعم مفتوحة',
      count: openTickets,
    },
    {
      show: pendingReports > 0,
      to: '/admin/reports',
      icon: ShieldAlert,
      color: 'text-red-500 bg-red-50',
      label: 'بلاغات بانتظار المراجعة',
      count: pendingReports,
    },
    {
      show: pendingCities > 0,
      to: '/admin/cities',
      icon: MapPin,
      color: 'text-amber-500 bg-amber-50',
      label: 'مدن مقترحة بانتظار المراجعة',
      count: pendingCities,
    },
  ].filter((i) => i.show);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className={`relative p-2.5 rounded-xl transition-colors ${open ? 'bg-slate-100' : 'hover:bg-slate-100'}`}
      >
        <Bell className="w-5 h-5 text-slate-600" />
        {total > 0 && (
          <span className="absolute -top-0.5 -left-0.5 bg-rose-500 text-white text-[9px] font-bold min-w-4 h-4 px-1 rounded-full flex items-center justify-center ring-2 ring-white">
            {total > 9 ? '9+' : total}
          </span>
        )}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.96 }}
            className="absolute left-0 mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden z-50"
          >
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="font-cairo font-bold text-sm text-slate-900">الإشعارات</span>
              {total > 0 && (
                <span className="text-[10px] font-bold text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full">
                  {total} جديد
                </span>
              )}
            </div>
            <div className="max-h-80 overflow-y-auto">
              {items.length === 0 ? (
                <div className="py-10 text-center">
                  <Bell className="w-8 h-8 text-slate-200 mx-auto mb-2" />
                  <p className="text-xs text-slate-400 font-tajawal">لا توجد إشعارات جديدة</p>
                </div>
              ) : (
                items.map((it) => {
                  const Icon = it.icon;
                  return (
                    <Link
                      key={it.to}
                      to={it.to}
                      onClick={() => setOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0"
                    >
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${it.color}`}>
                        <Icon className="w-4.5 h-4.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-cairo font-bold text-slate-800">{it.label}</p>
                        <p className="text-[10px] text-slate-400 font-tajawal">اضغط للانتقال والمعالجة</p>
                      </div>
                      <span className="text-sm font-bold text-slate-900">{it.count}</span>
                    </Link>
                  );
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AdminLoginScreen({ onLoginSuccess }: { onLoginSuccess: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const normalizeArabicDigits = (str: string) => {
    const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    return str.replace(/[٠-٩]/g, (w) => arabicDigits.indexOf(w).toString());
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const cleanEmail = email.trim().toLowerCase();
      const cleanPassword = normalizeArabicDigits(password.trim());

      // مصادقة حقيقية عبر Supabase Auth
      const { error: signInError } = await supabaseClient.auth.signInWithPassword({ email: cleanEmail, password: cleanPassword });
      if (signInError) {
        setError('البريد الإلكتروني أو كلمة السر غير صحيحة. يرجى إعادة المحاولة.');
        setLoading(false);
        return;
      }

      // التحقق من أن هذا الحساب مُدرَج فعلاً في جدول المشرفين admin_users
      const isAdmin = await verifyAdminSession();
      if (!isAdmin) {
        setError('هذا الحساب غير مخوّل بالدخول للوحة الإدارة.');
        await supabaseClient.auth.signOut();
        setLoading(false);
        return;
      }

      onLoginSuccess();
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ غير متوقع، حاول مرة أخرى');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden" dir="rtl">
      {/* خلفية جمالية */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/10 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-md bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative z-10"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-500/20 ring-4 ring-amber-500/10">
            <ShieldCheck className="w-8 h-8 text-slate-950" />
          </div>
          <h1 className="font-cairo font-black text-2xl text-white mb-1">لوحة الإدارة والتنسيق</h1>
          <p className="text-xs font-tajawal text-slate-400">منصة توافق لتيسير الزواج - الدخول للمشرفين والوساطة</p>
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs font-cairo font-bold text-rose-300 leading-relaxed">{error}</p>
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-cairo font-bold text-slate-300 mb-1.5">البريد الإلكتروني</label>
            <div className="relative">
              <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="algohrah4u@gmail.com"
                className="w-full pr-10 pl-4 py-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-white text-sm font-sans placeholder:text-slate-600 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all text-right"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-cairo font-bold text-slate-300 mb-1.5">كلمة السر</label>
            <div className="relative">
              <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pr-10 pl-10 py-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-white text-sm font-sans placeholder:text-slate-600 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all text-right"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-cairo font-extrabold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-70 cursor-pointer"
          >
            {loading ? (
              <span className="inline-block w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Key className="w-4 h-4" />
                <span>تسجيل الدخول للوحة الإدارة</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-800 text-center">
          <Link to="/" className="inline-flex items-center gap-2 text-xs font-cairo text-slate-400 hover:text-amber-400 transition-colors">
            <Globe className="w-3.5 h-3.5" /> العودة للواجهة الرئيسية للموقع
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
