# هيكل قاعدة البيانات وبيانات المشرفين — منصة توافق

هذا المستند يوفر توثيقاً شاملاً لقاعدة البيانات وحقول النظام لتوجيه نماذج الذكاء الاصطناعي والمطورين عند قراءة أو تحديث المشروع.

---

## 1. بيانات دخول لوحة الإدارة (Admin Credentials)

* **البريد الإلكتروني:** `algohrah4u@gmail.com`
* **كلمة السر:** `12345678`
* **المسار:** `/admin`
* **حماية الوصول:** تتم الحماية عبر مكون `AdminLoginScreen` بداخل `src/components/admin/AdminLayout.tsx`.

---

## 2. جدول الأعضاء (`members`) وحقول مواصفات الشريك

تحتوي شاشة التسجيل والتعديل الموحدة (`src/lib/fieldSchema.ts`) على كافة الحقول التالية لجدول الأعضاء:

### أ. البيانات الأساسية والشخصية:
* `id` (string): معرف العضو الفريد
* `gender` ('male' | 'female'): الجنس
* `nickname` (string): الاسم المستعار
* `realName` (string): الاسم الحقيقي (حساس/للإدارة)
* `birthDate` (string YYYY-MM-DD) & `age` (number)
* `country` (string) & `city` (string) & `district` (string)
* `nationalityMode` ('same' | 'other') & `nationality` (string)
* `sect` (string) & `religionLevel` (string)
* `maritalStatus` (string) & `childrenCount` (string)
* `housingType` (string) & `skinColor` (string) & `height` (number) & `weight` (number)
* `education` (string) & `workType` (string) & `jobTitle` (string) & `incomeRange` (string)
* `healthStatus` (string) & `prayer` (string) & `smoking` (string)
* `bio` (string): نبذة عن النفس

### ب. مواصفات الشريك المطلوب (Partner Preferences):
* `pCountry` (string): بلد إقامة الشريك المطلوب
* `pCity` (string): مدينة إقامة الشريك المطلوب
* `pNationality` (string): جنسية الشريك المطلوب
* `pAgeMin` (number): حد العمر الأدنى المطلوب للشريك
* `pAgeMax` (number): حد العمر الأقصى المطلوب للشريك
* `pMaritalStatus` (string): الحالة الاجتماعية المطلوبة للشريك
* `pAcceptChildren` ('yes' | 'no' | 'conditional'): قبول وجود أطفال
* `pNotes` / `aboutPartner` (string): مواصفات وملاحظات تفصيلية بالشريك المطلوب

### ج. بيانات الحساب والاشتراك:
* `email` (string) & `phone` (string)
* `verified` (boolean) & `hasSeriousnessBadge` (boolean)
* `plan` ('free' | 'gold' | 'elite')
* `status` ('active' | 'suspended' | 'pending' | 'banned')

---

## 3. قائمة جداول النظام (Supabase / LocalStorage Adapter)

1. **`members`**: سجلات الأعضاء وبياناتهم.
2. **`admin_users`**: حسابات مشرفي ومدراء المنصة.
3. **`interest_requests`**: طلبات الاهتمام ومراحل التوافق (المرحلة، الأطراف، التنسيق، الرسوم، اللقاء الشرعي).
4. **`notifications`**: الإشعارات والتنبيهات المستهدفة للأعضاء.
5. **`transactions`**: عمليات الدفع وترقيات الباقات والاشتراكات.
6. **`coupons`**: كبونات الخصم والعروض.
7. **`support_tickets`**: تذاكر الدعم الفني والوساطة.
8. **`inquiry_messages`**: رسائل الاستفسارات المتبادلة بين الطرفين عبر الوسيطة.
9. **`verification_docs`**: مستندات توثيق الهوية والجدية.
10. **`geo_countries`**: الدول المعتمدة في النظام.
11. **`geo_cities`**: المدن التابعة للدول.
12. **`pending_cities`**: المدن المضافة من المستخدمين وبانتظار مراجعة الإدارة.
13. **`geo_nationalities`**: قائمة الجنسيات.
14. **`geo_suggestions`**: مقترحات الموقع الجغرافي.
15. **`settings`**: إعدادات المنصة (بوابات الدفع، الشروط، سياسة الخصوصية، تفعيل الميزات).
16. **`member_reports`**: بلاغات وشكاوى الأعضاء.
17. **`exemption_requests`**: طلبات إعفاء الرسوم المالية.

---

## 4. قيود وتوجيهات واجهة المستخدم المعتمدة

* **عدم عرض شارات نسبة التوافق**: تم إلغاء حساب وعرض أي نسبة مئوية للتوافق (`matchScore`).
* **عدم عرض حالة الاتصال والنشاط**: تم إلغاء شارات "متصل الآن" وتاريخ آخر ظهور للخصوصية.
* **عدم عرض عدد مشاهدات الملف**: تم إخفاء واستبعاد عدّاد زيارات الملف الشخصي (`profileVisits`).
* **تأمين لوحة الإدارة**: يمنع فتح لوحة الإدارة إلا بعد إدخال البريد الإلكتروني والرمز السري المحدد.
