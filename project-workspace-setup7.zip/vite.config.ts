import { defineConfig, Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';
import fs from 'fs';

function apiDevServerPlugin(): Plugin {
  return {
    name: 'api-dev-server',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url?.startsWith('/api/')) return next();

        try {
          const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
          const routeName = urlObj.pathname.replace('/api/', '').split('?')[0];
          const fileRelPath = `./api/${routeName}.js`;
          const fileAbsPath = path.resolve(process.cwd(), fileRelPath);

          if (!fs.existsSync(fileAbsPath)) {
            return next();
          }

          // Parse query parameters
          const query = Object.fromEntries(urlObj.searchParams.entries());
          Object.assign(req, { query });

          // Parse body for state-mutating HTTP methods
          if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method || '')) {
            const buffers: Uint8Array[] = [];
            for await (const chunk of req) {
              buffers.push(chunk);
            }
            const bodyText = Buffer.concat(buffers).toString('utf-8');
            try {
              Object.assign(req, { body: JSON.parse(bodyText) });
            } catch {
              Object.assign(req, { body: bodyText });
            }
          }

          // Express-like response helper functions
          Object.assign(res, {
            status(code: number) {
              res.statusCode = code;
              return res;
            },
            json(data: unknown) {
              if (!res.headersSent) {
                res.setHeader('Content-Type', 'application/json; charset=utf-8');
              }
              res.end(JSON.stringify(data));
              return res;
            },
          });

          // SSR load module
          const mod = await server.ssrLoadModule(fileRelPath);
          const handler = mod.default || mod;

          if (typeof handler === 'function') {
            await handler(req, res);
            return;
          }
        } catch (err: unknown) {
          const errMsg = err instanceof Error ? err.message : 'API handler internal error';
          console.error(`API Handler Error (${req.url}):`, err);
          if (!res.headersSent) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            res.end(JSON.stringify({ error: errMsg }));
          }
          return;
        }

        next();
      });
    },
  };
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss(), apiDevServerPlugin()],
  build: {
    sourcemap: false,
    cssCodeSplit: true,
    target: 'es2020',
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes('node_modules')) return undefined;
          if (id.includes('react') || id.includes('react-dom') || id.includes('react-router-dom')) return 'vendor-react';
          if (id.includes('framer-motion')) return 'vendor-motion';
          if (id.includes('lucide-react')) return 'vendor-icons';
          if (id.includes('@supabase')) return 'vendor-supabase';
          return 'vendor';
        },
      },
    },
  },
  optimizeDeps: {
    include: ['react', 'react-dom', 'react-router-dom', 'framer-motion', 'lucide-react'],
  },
  server: {
    port: 3000,
    host: '0.0.0.0',
  }
});
