import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { id, sender_id, receiver_id, journey_stage, status } = req.query;
      if (id) {
        const { data, error } = await supabase.from('requests').select('*').eq('id', id).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      let query = supabase.from('requests').select('*');
      if (sender_id) query = query.eq('sender_id', sender_id);
      if (receiver_id) query = query.eq('receiver_id', receiver_id);
      if (journey_stage) query = query.eq('journey_stage', journey_stage);
      if (status) query = query.eq('status', status);
      const { data, error } = await query.order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const request = { ...req.body, created_at: req.body.created_at || new Date().toISOString(), updated_at: new Date().toISOString() };
      const { data, error } = await supabase.from('requests').insert(request).select().single();
      if (error) throw error;
      await supabase.from('events').insert({ request_id: data.id, actor_id: data.sender_id || 'system', type: 'sent', note: 'تم إرسال طلب اهتمام' });
      if (data.receiver_id) await supabase.from('notifications').insert({ user_id: data.receiver_id, request_id: data.id, type: 'request', text: 'وصلك طلب اهتمام جديد', read: false });
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, action, actor_id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const patch = { ...updates, updated_at: new Date().toISOString() };
      if (action === 'accept') patch.status = 'accepted_pending_admin';
      if (action === 'decline') patch.status = 'declined';
      if (action === 'cancel') patch.status = 'cancelled';
      if (action === 'pay_deposit') patch.status = 'paid';
      const { data, error } = await supabase.from('requests').update(patch).eq('id', id).select().single();
      if (error) throw error;
      await supabase.from('events').insert({ request_id: id, actor_id: actor_id || 'system', type: action || 'update', note: 'تم تحديث الطلب' });
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      await supabase.from('events').delete().eq('request_id', id);
      await supabase.from('notifications').delete().eq('request_id', id);
      const { error } = await supabase.from('requests').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Requests API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
