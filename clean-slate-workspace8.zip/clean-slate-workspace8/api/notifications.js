import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { user_id, request_id, unread_only } = req.query;
      let query = supabase.from('notifications').select('*');
      if (user_id) query = query.eq('user_id', user_id);
      if (request_id) query = query.eq('request_id', request_id);
      if (unread_only === 'true') query = query.eq('read', false);
      const { data, error } = await query.order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const { data, error } = await supabase.from('notifications').insert({ ...req.body, created_at: req.body.created_at || new Date().toISOString() }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, user_id, mark_all_read, read = true } = req.body;
      if (mark_all_read && user_id) {
        const { error } = await supabase.from('notifications').update({ read: true }).eq('user_id', user_id).eq('read', false);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase.from('notifications').update({ read }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id, user_id } = req.body;
      if (id) {
        const { error } = await supabase.from('notifications').delete().eq('id', id);
        if (error) throw error;
      } else if (user_id) {
        const { error } = await supabase.from('notifications').delete().eq('user_id', user_id);
        if (error) throw error;
      } else return res.status(400).json({ error: 'id or user_id is required' });
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Notifications API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
