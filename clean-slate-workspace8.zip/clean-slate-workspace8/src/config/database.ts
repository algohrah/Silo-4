export type DatabaseProvider = 'local';

export const DATABASE_CONFIG = {
  // الوضع الحالي مقصود: localStorage فقط لتقليل استهلاك الإنترنت وتشغيل AI Studio بثبات.
  // يمكن لاحقًا توسيع طبقة DataService بإضافة Adapter حي دون تعديل الصفحات.
  PROVIDER: 'local' as DatabaseProvider,
};
