import { Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Header from '../ui/Header';
import Footer from './Footer';
import MobileNav from './MobileNav';
import ToastContainer from '../ui/Toast';
import ImpersonationBar from '../ImpersonationBar';

export default function Layout() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  const hideFooter = pathname === '/search' ||
                     pathname.startsWith('/checkout') ||
                     pathname === '/requests' ||
                     pathname === '/admin-chat' ||
                     pathname === '/notifications' ||
                     pathname.startsWith('/profile');

  return (
    <div className="min-h-screen flex flex-col bg-cream-50 text-navy-950 dark:bg-navy-950 dark:text-cream-50 transition-colors duration-300">
      <ImpersonationBar />
      <Header />
      <main className="flex-1 relative">
        <div className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-[38rem] bg-[radial-gradient(circle_at_top_right,rgba(239,194,91,0.12),transparent_38rem)]" />
        <Outlet />
      </main>
      {!hideFooter && <Footer />}
      <MobileNav />
      <ToastContainer />
    </div>
  );
}
