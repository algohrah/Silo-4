import type { ReactNode } from 'react';
import { ChevronDown, Check } from 'lucide-react';

// ====================================================================
//  مكونات حقول النموذج — قابلة لإعادة الاستخدام
// ====================================================================

interface FieldProps {
  label: string;
  required?: boolean;
  hint?: string;
  children: ReactNode;
  error?: string;
}

export function Field({ label, required, hint, children, error }: FieldProps) {
  return (
    <div>
      <label className="block text-sm font-cairo font-semibold text-navy-800 mb-1.5">
        {label}
        {required && <span className="text-rose-deep mr-1">*</span>}
      </label>
      {children}
      {hint && !error && <p className="text-xs text-navy-400 font-tajawal mt-1">{hint}</p>}
      {error && <p className="text-xs text-rose-deep font-tajawal mt-1">{error}</p>}
    </div>
  );
}

// حقل نصي
export function TextInput({
  value, onChange, placeholder, type = 'text',
}: {
  value: string; onChange: (v: string) => void; placeholder?: string; type?: string;
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors"
    />
  );
}

// قائمة منسدلة
export function SelectInput({
  value, onChange, options, placeholder = 'اختر',
}: {
  value: string; onChange: (v: string) => void; options: string[] | { value: string; label: string }[]; placeholder?: string;
}) {
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-3 pl-10 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 appearance-none transition-colors"
      >
        <option value="">{placeholder}</option>
        {opts.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
      <ChevronDown className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
    </div>
  );
}

// منطقة نص
export function TextArea({
  value, onChange, placeholder, rows = 3,
}: {
  value: string; onChange: (v: string) => void; placeholder?: string; rows?: number;
}) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 resize-none transition-colors"
    />
  );
}

// خيارات اختيار من متعدد (chips)
export function MultiChips({
  values, selected, onChange, max,
}: {
  values: string[]; selected: string[]; onChange: (v: string[]) => void; max?: number;
}) {
  const toggle = (item: string) => {
    if (selected.includes(item)) {
      onChange(selected.filter((x) => x !== item));
    } else {
      if (max && selected.length >= max) return;
      onChange([...selected, item]);
    }
  };
  return (
    <div className="flex flex-wrap gap-2">
      {values.map((item) => {
        const active = selected.includes(item);
        return (
          <button
            key={item}
            type="button"
            onClick={() => toggle(item)}
            className={`px-3.5 py-2 rounded-full text-sm font-cairo font-semibold transition-all no-tap-highlight ${
              active
                ? 'bg-navy-900 text-white shadow-soft'
                : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
            }`}
          >
            {active && <Check className="w-3.5 h-3.5 inline ml-1" />}
            {item}
          </button>
        );
      })}
    </div>
  );
}

// خيارات اختيار فردي (radio cards)
export function RadioGroup({
  options, value, onChange, columns = 2,
}: {
  options: { value: string; label: string }[]; value: string; onChange: (v: string) => void; columns?: number;
}) {
  const gridClass = columns === 1 ? 'grid-cols-1' : columns === 3 ? 'grid-cols-3' : columns === 4 ? 'grid-cols-4' : 'grid-cols-2';
  return (
    <div className={`grid ${gridClass} gap-2`}>
      {options.map((opt) => (
        <button
          key={opt.value}
          type="button"
          onClick={() => onChange(opt.value)}
          className={`px-4 py-2.5 rounded-xl text-sm font-cairo font-semibold transition-all border-2 no-tap-highlight text-center ${
            value === opt.value
              ? 'border-gold-500 bg-gold-300/10 text-navy-900'
              : 'border-cream-200 bg-cream-50 text-navy-600 hover:border-gold-300'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

// بطاقة اختيار كبيرة (للجنس مثلاً)
export function ChoiceCard({
  active, onClick, icon, title, subtitle,
}: {
  active: boolean; onClick: () => void; icon: ReactNode; title: string; subtitle?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative p-5 rounded-2xl border-2 transition-all duration-300 no-tap-highlight text-center ${
        active ? 'border-gold-500 bg-gold-300/10 shadow-soft' : 'border-cream-200 hover:border-gold-300'
      }`}
    >
      {active && (
        <span className="absolute top-2 left-2 w-5 h-5 rounded-full bg-gold-gradient flex items-center justify-center">
          <Check className="w-3 h-3 text-navy-900" />
        </span>
      )}
      <div className="flex flex-col items-center gap-2">
        {icon}
        <span className="font-cairo font-bold text-navy-900">{title}</span>
        {subtitle && <span className="text-xs text-navy-500 font-tajawal">{subtitle}</span>}
      </div>
    </button>
  );
}

// شريط التدرج (slider)
export function RangeSlider({
  value, onChange, min, max, unit,
}: {
  value: number; onChange: (v: number) => void; min: number; max: number; unit?: string;
}) {
  return (
    <div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-gold-500"
      />
      <div className="flex justify-between text-xs text-navy-400 font-tajawal mt-1">
        <span>{min}{unit}</span>
        <span className="font-bold text-gold-700">{value}{unit}</span>
        <span>{max}{unit}</span>
      </div>
    </div>
  );
}

// شريط تقدم
export function ProgressBar({ value }: { value: number }) {
  return (
    <div className="h-2 bg-cream-200 rounded-full overflow-hidden">
      <div
        className="h-full bg-gold-gradient rounded-full transition-all duration-500"
        style={{ width: `${value}%` }}
      />
    </div>
  );
}

// قائمة منسدلة مع خيار "أخرى" يُظهر حقل نص
export function SelectWithOther({
  value, otherValue, onChange, onOtherChange, options, placeholder = 'اختر',
}: {
  value: string;
  otherValue: string;
  onChange: (v: string) => void;
  onOtherChange: (v: string) => void;
  options: string[];
  placeholder?: string;
}) {
  const isOther = value === 'أخرى';
  return (
    <div className="space-y-2">
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full px-4 py-3 pl-10 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 appearance-none transition-colors"
        >
          <option value="">{placeholder}</option>
          {options.map((o) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
      </div>
      {isOther && (
        <input
          type="text"
          value={otherValue}
          onChange={(e) => onOtherChange(e.target.value)}
          placeholder="اكتب هنا..."
          className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-gold-400 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors"
        />
      )}
    </div>
  );
}

// ====================================================================
//  اختيار التاريخ بثلاث قوائم منسدلة (سنة / شهر / يوم)
//  - لا يسمح باختيار سنين مستقبلية
//  - عدد الأيام يتكيف تلقائيًا حسب الشهر والسنة (كبسولة فبراير)
// ====================================================================

const MONTHS_AR = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];

// عدد أيام شهر معيّن في سنة معيّنة
function getDaysInMonth(year: number, month: number): number {
  // month هنا 1-12
  if (month === 2) {
    // فبراير: 29 يوم في السنة الكبيسة، وإلا 28
    const isLeap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    return isLeap ? 29 : 28;
  }
  // أشهر 31 يومًا
  if ([1, 3, 5, 7, 8, 10, 12].includes(month)) return 31;
  return 30;
}

interface DateSelectProps {
  value: string; // بصيغة yyyy-mm-dd
  onChange: (date: string) => void;
  minYear?: number; // أقدم سنة مسموح بها (افتراضي: قبل 100 سنة)
  placeholder?: { year?: string; month?: string; day?: string };
}

export function DateSelect({
  value,
  onChange,
  minYear = new Date().getFullYear() - 100,
  placeholder = { year: 'السنة', month: 'الشهر', day: 'اليوم' },
}: DateSelectProps) {
  const currentYear = new Date().getFullYear();

  // تحليل القيمة الحالية
  const parts = value ? value.split('-') : [];
  const selectedYear = parts[0] ? parseInt(parts[0]) : 0;
  const selectedMonth = parts[1] ? parseInt(parts[1]) : 0;
  const selectedDay = parts[2] ? parseInt(parts[2]) : 0;

  // قائمة السنين: من السنة الحالية إلى minYear (تنازليًا)
  const years: number[] = [];
  for (let y = currentYear; y >= minYear; y--) {
    years.push(y);
  }

  // قائمة الأيام: تعتمد على الشهر والسنة المختارَين
  const maxDay = selectedYear && selectedMonth ? getDaysInMonth(selectedYear, selectedMonth) : 31;
  const days: number[] = [];
  for (let d = 1; d <= maxDay; d++) {
    days.push(d);
  }

  // تحديث القيمة عند تغيير أي من القوائم
  const updateValue = (newYear: number, newMonth: number, newDay: number) => {
    // إذا تغيّر الشهر أو السنة، تأكد أن اليوم صالح
    let finalDay = newDay;
    if (newYear && newMonth) {
      const daysInThisMonth = getDaysInMonth(newYear, newMonth);
      if (finalDay > daysInThisMonth) finalDay = daysInThisMonth;
    }

    // بناء التاريخ بصيغة yyyy-mm-dd
    if (newYear && newMonth && finalDay) {
      const dateStr = `${newYear}-${String(newMonth).padStart(2, '0')}-${String(finalDay).padStart(2, '0')}`;
      onChange(dateStr);
    } else {
      // حفظ القيم الجزئية مؤقتًا في data attribute عبر callback
      // نبني تاريخًا مؤقتًا حتى لو غير مكتمل
      const y = newYear || '';
      const m = newMonth ? String(newMonth).padStart(2, '0') : '';
      const d = finalDay ? String(finalDay).padStart(2, '0') : '';
      onChange(`${y}-${m}-${d}`);
    }
  };

  const selectClass =
    'w-full px-3 py-3 pl-9 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 appearance-none transition-colors text-center';

  return (
    <div className="grid grid-cols-3 gap-2">
      {/* السنة */}
      <div className="relative">
        <select
          value={selectedYear || ''}
          onChange={(e) => updateValue(parseInt(e.target.value) || 0, selectedMonth, selectedDay)}
          className={selectClass}
        >
          <option value="">{placeholder.year}</option>
          {years.map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
      </div>

      {/* الشهر */}
      <div className="relative">
        <select
          value={selectedMonth || ''}
          onChange={(e) => updateValue(selectedYear, parseInt(e.target.value) || 0, selectedDay)}
          className={selectClass}
        >
          <option value="">{placeholder.month}</option>
          {MONTHS_AR.map((m, i) => (
            <option key={i + 1} value={i + 1}>{m}</option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
      </div>

      {/* اليوم */}
      <div className="relative">
        <select
          value={selectedDay || ''}
          onChange={(e) => updateValue(selectedYear, selectedMonth, parseInt(e.target.value) || 0)}
          className={selectClass}
        >
          <option value="">{placeholder.day}</option>
          {days.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
      </div>
    </div>
  );
}
