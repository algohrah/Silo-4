import { useState } from 'react';
import { ShieldCheck, Save, Check, CreditCard, Moon, Sun, Eye, Heart } from 'lucide-react';
import { useApp } from '../../lib/AppContext';

interface ToggleProps {
  label: string;
  desc: string;
  icon: any;
  value: boolean;
  onChange: (val: boolean) => void;
}

const Toggle = ({ label, desc, icon: Icon, value, onChange }: ToggleProps) => {
  return (
    <div className="flex items-center gap-3 py-3">
      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
        <Icon className="w-5 h-5 text-slate-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-cairo font-semibold text-slate-800 text-sm pl-2">{label}</p>
        <p className="text-xs text-slate-400 font-tajawal">{desc}</p>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`w-12 h-7 rounded-full transition-colors relative flex-shrink-0 ${
          value ? 'bg-emerald-500' : 'bg-slate-300'
        }`}
      >
        <div
          className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${
            value ? 'right-1' : 'right-6'
          }`}
        />
      </button>
    </div>
  );
};

export default function AdminFeatureSettings() {
  const {
    showDarkModeToggle,
    updateShowDarkModeToggle,
    showToast,
  } = useApp();
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    showToast('تم حفظ إعدادات الميزات بنجاح', 'success');
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="space-y-5 text-right" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">إعدادات الميزات</h2>
          <p className="text-sm text-slate-500 font-tajawal">تحكم في ميزات المنصة المرئية والوظيفية</p>
        </div>
        <button
          onClick={handleSave}
          className={`flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm hover:bg-slate-800 transition-colors ${
            saved ? 'bg-emerald-500 hover:bg-emerald-600' : ''
          }`}
        >
          {saved ? <><Check className="w-4 h-4" /> تم الحفظ</> : <><Save className="w-4 h-4" /> حفظ</>}
        </button>
      </div>

      {/* Dark mode */}
      <div className="bg-gradient-to-br from-indigo-50 to-white border border-indigo-200 rounded-3xl p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-indigo-100 rounded-2xl flex items-center justify-center">
            <Moon className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h3 className="font-cairo font-bold text-2xl text-indigo-900">الوضع الليلي</h3>
            <p className="text-indigo-700 text-sm">تحكم في ظهور زر الوضع الليلي</p>
          </div>
        </div>

        <div className="space-y-5">
          <Toggle
            label="إظهار زر الوضع الليلي في الموقع"
            desc="عند التفعيل يظهر زر التبديل في شريط التنقل"
            icon={showDarkModeToggle ? Moon : Sun}
            value={showDarkModeToggle}
            onChange={(val) => updateShowDarkModeToggle(val)}
          />

          <div
            className={`flex items-center gap-3 p-4 rounded-2xl border transition-all ${
              showDarkModeToggle ? 'bg-indigo-50/50 border-indigo-200' : 'bg-slate-50 border-slate-200 opacity-60'
            }`}
          >
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                showDarkModeToggle ? 'bg-indigo-100' : 'bg-slate-200'
              }`}
            >
              {showDarkModeToggle ? (
                <Moon className="w-6 h-6 text-indigo-600" />
              ) : (
                <Sun className="w-6 h-6 text-amber-500" />
              )}
            </div>
            <div className="flex-1">
              <p className="font-cairo font-bold text-sm text-slate-800">
                {showDarkModeToggle ? 'الزر ظاهر حالياً' : 'الزر مخفي حالياً'}
              </p>
              <p className="text-xs text-slate-500 font-tajawal mt-0.5">
                {showDarkModeToggle
                  ? 'يمكن للمستخدمين التبديل بين الوضعين'
                  : 'المستخدمون لا يستطيعون تغيير الوضع'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
