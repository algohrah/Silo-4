import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Upload, FileSpreadsheet, Clipboard, CheckCircle2, AlertCircle, XCircle,
  Users, Building2, Calendar, Hash, StickyNote, Download, Eye, EyeOff,
  ChevronDown, ChevronUp, RefreshCw, Trash2, Plus, Search, Loader2,
  FileDown, Table, AlertTriangle, Info, Sparkles, Ban, BadgeCheck,
  Copy, FileText, BookOpen,
} from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import Modal from '../../components/ui/Modal';
import {
  REGISTRATION_FIELDS, getCSVFields, generateCSVTemplate,
  generateFullTemplateWithOptions,
  parseCSVRow, validateField, parseCSVValue, FieldDefinition,
} from '../../lib/fieldSchema';
import {
  getImportOffices, addImportOffice, getImportOfficeById,
  getImportBatches, createImportBatch, generateBatchNumber, parseCSV, parsePastedData,
  checkDuplicates, prepareImportedMember, createImportReport,
  ImportOffice, ImportBatch, ImportReport, ImportError, ImportWarning,
} from '../../lib/importBatches';
import type { AdminMember } from '../../lib/admin-data';
import { dataService } from '../../lib/data/DataService';
const { checkAndRegisterUnknownGeo } = dataService.db;



type ImportMethod = 'csv' | 'paste';
type ImportStep = 'setup' | 'upload' | 'preview' | 'validate' | 'confirm' | 'result';

export default function AdminImportMembers() {
  const { adminMembers, setAdminMembers, importMembers, showToast: contextToast } = useApp();
  
  // ===== الحالات =====
  const [step, setStep] = useState<ImportStep>('setup');
  const [method, setMethod] = useState<ImportMethod>('csv');
  
  // بيانات إدارية
  const [officeMode, setOfficeMode] = useState<'new' | 'existing' | 'none'>('none');
  const [newOfficeName, setNewOfficeName] = useState('');
  const [selectedOfficeId, setSelectedOfficeId] = useState('');
  const [importDate, setImportDate] = useState(new Date().toISOString().split('T')[0]);
  const [batchNumberPreview, setBatchNumberPreview] = useState('');
  const [importNotes, setImportNotes] = useState('');
  
  useEffect(() => {
    setBatchNumberPreview(generateBatchNumber());
  }, []);
  
  // البيانات
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [pastedText, setPastedText] = useState('');
  const [parsedData, setParsedData] = useState<Record<string, any>[]>([]);
  const [parsedHeaders, setParsedHeaders] = useState<string[]>([]);
  const [parseErrors, setParseErrors] = useState<string[]>([]);
  
  // التحقق
  const [validationErrors, setValidationErrors] = useState<ImportError[]>([]);
  const [validationWarnings, setValidationWarnings] = useState<ImportWarning[]>([]);
  const [duplicates, setDuplicates] = useState<Record<string, any>[]>([]);
  const [uniqueData, setUniqueData] = useState<Record<string, any>[]>([]);
  const [replaceMode, setReplaceMode] = useState(false);
  const [showPreview, setShowPreview] = useState(true);
  
  // النتيجة
  const [importReport, setImportReport] = useState<ImportReport | null>(null);
  const [createdBatch, setCreatedBatch] = useState<ImportBatch | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  // ===== القالب الكامل =====
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [templateText, setTemplateText] = useState('');
  const [templateCopied, setTemplateCopied] = useState(false);
  
  // الخطابات
  const offices = useMemo(() => getImportOffices(), []);
  const batches = useMemo(() => getImportBatches(), []);
  
  // ===== دوال =====
  
  const localToast = useCallback((msg: string, type: 'success' | 'error' | 'info' = 'success') => {
    contextToast(msg, type);
  }, [contextToast]);
  
  // تحميل قالب CSV
  const downloadTemplate = () => {
    const template = generateCSVTemplate();
    const blob = new Blob(['\uFEFF' + template], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tawfok_import_template.csv';
    a.click();
    URL.revokeObjectURL(url);
    localToast('تم تحميل قالب CSV ✓', 'success');
  };
  
  // عرض القالب الكامل مع الخيارات
  const showFullTemplate = () => {
    const fullTemplate = generateFullTemplateWithOptions();
    setTemplateText(fullTemplate);
    setShowTemplateModal(true);
    setTemplateCopied(false);
  };
  
  // نسخ القالب الكامل
  const copyFullTemplate = async () => {
    try {
      await navigator.clipboard.writeText(templateText);
      setTemplateCopied(true);
      localToast('تم نسخ القالب ✓', 'success');
      setTimeout(() => setTemplateCopied(false), 3000);
    } catch {
      // fallback for older browsers
      const textarea = document.createElement('textarea');
      textarea.value = templateText;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setTemplateCopied(true);
      localToast('تم نسخ القالب ✓', 'success');
    }
  }; 
  
  // معالجة ملف CSV
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setCsvFile(file);
    setIsProcessing(true);
    
    try {
      const text = await file.text();
      const result = parseCSV(text);
      
      setParsedHeaders(result.headers);
      setParseErrors(result.errors);
      
      if (result.errors.length === 0 && result.rows.length > 0) {
        const data = result.rows.map(row => parseCSVRow(result.headers, row));
        setParsedData(data);
        setStep('preview');
      } else {
        setStep('upload');
      }
    } catch (err) {
      setParseErrors(['خطأ في قراءة الملف']);
      setStep('upload');
    }
    
    setIsProcessing(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    
    if (!file.name.endsWith('.csv')) {
      localToast('الرجاء رفع ملف بصيغة CSV فقط', 'error');
      return;
    }
    
    setCsvFile(file);
    setIsProcessing(true);
    
    try {
      const text = await file.text();
      const result = parseCSV(text);
      
      setParsedHeaders(result.headers);
      setParseErrors(result.errors);
      
      if (result.errors.length === 0 && result.rows.length > 0) {
        const data = result.rows.map(row => parseCSVRow(result.headers, row));
        setParsedData(data);
        setStep('preview');
      } else {
        setStep('upload');
      }
    } catch (err) {
      setParseErrors(['خطأ في قراءة الملف']);
      setStep('upload');
    }
    
    setIsProcessing(false);
  }; 
  
  // معالجة Paste
  const handlePasteParse = () => {
    if (!pastedText.trim()) {
      localToast('الرجاء إدخال البيانات', 'error');
      return;
    }
    
    setIsProcessing(true);
    const result = parsePastedData(pastedText);
    
    setParsedHeaders(result.headers);
    setParseErrors(result.errors);
    
    if (result.errors.length === 0 && result.rows.length > 0) {
      const data = result.rows.map(row => parseCSVRow(result.headers, row));
      setParsedData(data);
      setStep('preview');
    }
    
    setIsProcessing(false);
  }; 
  
  // التحقق من البيانات - مرن، لا يوقف الاستيراد
  const validateData = () => {
    const errors: ImportError[] = []; 
    const warnings: ImportWarning[] = []; 
    const fields = getCSVFields();
    
    parsedData.forEach((row, idx) => {
      // فقط تحقق من الحقول المطلوبة الأساسية
      // الحقول الناقصة ستملأ بقيم افتراضية
      const requiredFields = ['gender', 'age', 'country', 'city'];
      
      fields.forEach(field => {
        const value = row[field.key] || row[field.csvColumn!];
        
        // الحقول المطلوبة الأساسية فقط
        if (requiredFields.includes(field.key) && field.required && !value) {
          warnings.push({ row: idx + 2, field: field.label, message: `${field.label} غير موجود — سيتم استخدام قيمة افتراضية` });
        } else if (!value && field.required) {
          // الحقول المطلوبة الأخرى -> تحذير فقط، لا خطأ
          warnings.push({ row: idx + 2, field: field.label, message: `${field.label} غير موجود — سيتم استخدام قيمة افتراضية` });
        }
      });
      
      // تحذيرات مفيدة
      if (!row.email && !row.phone) {
        warnings.push({ row: idx + 2, message: 'لا يوجد بريد أو هاتف — سيتم إنشاء بيانات افتراضية' });
      }
      if (!row.gender) {
        warnings.push({ row: idx + 2, field: 'الجنس', message: 'الجنس غير محدد — سيتم افتراض ذكر' });
      }
      if (!row.realName && !row.nickname) {
        warnings.push({ row: idx + 2, message: 'لا يوجد اسم — سيتم توليد اسم افتراضي' });
      }
    });
    
    // التحقق من التكرارات (بناءً على البريد أو الهاتف فقط)
    const dupResult = checkDuplicates(parsedData, adminMembers);
    setDuplicates(dupResult.duplicates);
    setUniqueData(dupResult.unique);
    
    setValidationErrors(errors); // لا أخطاء - الاستيراد سيستمر
    setValidationWarnings(warnings);
    setStep('validate');
  }; 
  
  // تنفيذ الاستيراد
  const executeImport = async () => {
    setIsProcessing(true);
    
    try {
      // إنشاء/الحصول على الخطابة
      let officeId = '';
      let officeName = '';
      
      if (officeMode === 'new' && newOfficeName.trim()) {
        const newOffice = addImportOffice(newOfficeName.trim());
        officeId = newOffice.id;
        officeName = newOffice.name;
      } else if (officeMode === 'existing' && selectedOfficeId) {
        const office = getImportOfficeById(selectedOfficeId);
        officeId = selectedOfficeId;
        officeName = office?.name || '';
      }
      
      // تجهيز الأعضاء
      const batchId = 'batch_' + Date.now();
      
      const importDataList = replaceMode 
        ? [...uniqueData, ...duplicates].map(data => {
            const email = data.email?.toLowerCase();
            const phone = data.phone;
            const match = adminMembers.find(m => 
              (email && m.email?.toLowerCase() === email) || 
              (phone && m.phone === phone)
            );
            if (match) {
              return { ...data, id: match.id };
            }
            return data;
          })
        : uniqueData;

      const newMembers = importDataList.map((data, index) => 
        prepareImportedMember(data, batchId, officeName, importDate, importNotes, index + 1)
      ) as AdminMember[];
      
      // إنشاء الدفعة
      const batch = createImportBatch({
        batchNumber: batchNumberPreview || undefined,
        officeId,
        officeName,
        importDate,
        membersCount: newMembers.length,
        duplicatesCount: replaceMode ? 0 : duplicates.length,
        skippedCount: validationErrors.length,
        errorsCount: validationErrors.length,
        notes: importNotes,
        sourceType: method,
      });
      
      // تحديث معرف الدفعة في الأعضاء
      newMembers.forEach(m => m.importBatchId = batch.id);
      
      // إضافة الأعضاء إلى النظام بشكل موحد
      importMembers(newMembers, replaceMode);

      // فحص وتسجيل المدن/الدول غير المعروفة في geoStore
      let geoNote = '';
      try {
        const geoResult = checkAndRegisterUnknownGeo(newMembers, 'import');
        if (geoResult.addedPending > 0) {
          geoNote = ` — ${geoResult.addedPending} مدينة جديدة بانتظار المراجعة في «الدول والمدن»`;
        }
      } catch { /* تجاهل */ }
      
      // إنشاء التقرير
      const report = createImportReport(
        parsedData.length,
        newMembers.length,
        duplicates.length,
        validationErrors.length,
        validationErrors,
        validationWarnings,
        batch
      );
      
      setImportReport(report);
      setCreatedBatch(batch);
      setStep('result');
      
      localToast(`تم استيراد ${newMembers.length} عضو بنجاح ✓${geoNote}`, 'success');
    } catch (err) {
      localToast('حدث خطأ أثناء الاستيراد', 'error');
    }
    
    setIsProcessing(false);
  }; 
  
  // إعادة التعيين
  const resetImport = () => {
    setStep('setup');
    setMethod('csv');
    setCsvFile(null);
    setPastedText('');
    setParsedData([]);
    setParsedHeaders([]);
    setParseErrors([]);
    setValidationErrors([]);
    setValidationWarnings([]);
    setDuplicates([]);
    setUniqueData([]);
    setImportReport(null);
    setCreatedBatch(null);
    setOfficeMode('none');
    setNewOfficeName('');
    setSelectedOfficeId('');
    setImportNotes('');
  }; 
  
  // ===== العرض =====
  
  const stepsConfig = [
    { id: 'setup', label: 'إعدادات الاستيراد', icon: Building2 },
    { id: 'upload', label: 'رفع البيانات', icon: Upload },
    { id: 'preview', label: 'معاينة', icon: Eye },
    { id: 'validate', label: 'التحقق', icon: AlertCircle },
    { id: 'result', label: 'النتيجة', icon: CheckCircle2 },
  ];
  
  const currentStepIdx = stepsConfig.findIndex(s => s.id === step);
  
  return (
    <div className="space-y-5">
      {/* العنوان */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
            <Upload className="w-5 h-5 text-amber-500" /> استيراد الأعضاء
          </h2>
          <p className="text-sm text-slate-500 font-tajawal">استيراد أعضاء من ملف CSV أو لصق البيانات مباشرة</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={showFullTemplate}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-100 text-purple-700 font-cairo font-semibold text-sm hover:bg-purple-200 transition-colors"
          >
            <BookOpen className="w-4 h-4" /> عرض القالب الكامل
          </button>
          <button
            onClick={downloadTemplate}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-100 text-emerald-700 font-cairo font-semibold text-sm hover:bg-emerald-200 transition-colors"
          >
            <FileDown className="w-4 h-4" /> تحميل قالب CSV
          </button>
          {step !== 'setup' && (
            <button
              onClick={resetImport}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-cairo font-semibold text-sm hover:bg-slate-200 transition-colors"
            >
            <RefreshCw className="w-4 h-4" /> إعادة التعيين
            </button>
          )}
        </div>
      </div>
      
      {/* شريط الخطوات */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between md:justify-around gap-2 overflow-x-auto pb-1 scrollbar-none">
          {stepsConfig.map((s, idx) => {
            const Icon = s.icon;
            const isActive = idx === currentStepIdx;
            const isPast = idx < currentStepIdx;
            
            return (
              <div key={s.id} className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
                <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center transition-all ${
                  isActive ? 'bg-amber-500 text-white shadow-sm ring-2 ring-amber-500/20' :
                  isPast ? 'bg-emerald-500 text-white' :
                  'bg-slate-100 text-slate-400'
                }`}
                >
                  {isPast ? <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5" /> : <Icon className="w-4 h-4 sm:w-5 sm:h-5" />}
                </div>
                <span className={`font-cairo font-semibold text-xs sm:text-sm ${
                  isActive ? 'text-amber-600 font-bold' : isPast ? 'text-emerald-600' : 'text-slate-400'
                } ${isActive ? 'inline-block' : 'hidden sm:inline-block'}`}>
                  {s.label}
                </span>
                {idx < stepsConfig.length - 1 && (
                  <div className={`w-3 sm:w-8 h-0.5 mx-1 sm:mx-2 ${isPast ? 'bg-emerald-500' : 'bg-slate-200'}`} />
                )}
              </div>
            );
          })}
        </div>
      </div>
      
      {/* المحتوى */}
      <AnimatePresence mode="wait">
        {/* ===== الخطوة 1: الإعدادات ===== */}
        {step === 'setup' && (
          <motion.div
            key="setup"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-5"
          >
            <h3 className="font-cairo font-bold text-lg text-slate-800 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-amber-500" /> بيانات الاستيراد الإدارية
            </h3>
            <p className="text-sm text-slate-500 font-tajawal">
              هذه البيانات للإدارة فقط ولا تظهر للأعضاء. اختيارية.
            </p>
            
            {/* الخطابة */}
            <div className="space-y-3">
              <label className="font-cairo font-semibold text-sm text-slate-700">
                اسم الخطابة أو المكتب (اختياري)
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setOfficeMode('none')}
                  className={`px-4 py-2 rounded-xl font-cairo font-semibold text-sm transition-all ${
                    officeMode === 'none' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  بدون خطابة
                </button>
                <button
                  onClick={() => setOfficeMode('existing')}
                  className={`px-4 py-2 rounded-xl font-cairo font-semibold text-sm transition-all ${
                    officeMode === 'existing' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  خطابة موجودة
                </button>
                <button
                  onClick={() => setOfficeMode('new')}
                  className={`px-4 py-2 rounded-xl font-cairo font-semibold text-sm transition-all flex items-center gap-1 ${
                    officeMode === 'new' ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  <Plus className="w-4 h-4" /> خطابة جديدة
                </button>
              </div>
              
              {officeMode === 'existing' && (
                <div className="mt-3">
                  <select
                    value={selectedOfficeId}
                    onChange={e => setSelectedOfficeId(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal"
                  >
                    <option value="">اختر الخطابة...</option>
                    {offices.map(o => (
                      <option key={o.id} value={o.id}>{o.name} ({o.usageCount} استخدام)</option>
                    ))}
                  </select>
                </div>
              )}
              
              {officeMode === 'new' && (
                <div className="mt-3">
                  <input
                    type="text"
                    value={newOfficeName}
                    onChange={e => setNewOfficeName(e.target.value)}
                    placeholder="اسم الخطابة أو المكتب..."
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal"
                  />
                </div>
              )}
            </div>
            
            {/* تاريخ الاستيراد */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="font-cairo font-semibold text-sm text-slate-700 flex items-center gap-1">
                  <Calendar className="w-4 h-4" /> تاريخ الاستيراد
                </label>
                <input
                  type="date"
                  value={importDate}
                  onChange={e => setImportDate(e.target.value)}
                  className="w-full mt-2 px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal"
                />
              </div>
              <div>
                <label className="font-cairo font-semibold text-sm text-slate-700 flex items-center gap-1">
                  <Hash className="w-4 h-4" /> رقم الدفعة <span className="text-xs text-slate-400 font-normal">(تلقائي وقابل للتعديل)</span>
                </label>
                <input
                  type="text"
                  value={batchNumberPreview}
                  onChange={e => setBatchNumberPreview(e.target.value)}
                  placeholder="مثال: IMP-001 أو دفعة-خاصة"
                  className="w-full mt-2 px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-cairo font-bold"
                />
              </div>
            </div>
            
            {/* ملاحظات */}
            <div>
              <label className="font-cairo font-semibold text-sm text-slate-700 flex items-center gap-1">
                <StickyNote className="w-4 h-4" /> ملاحظات الاستيراد (اختياري)
              </label>
              <textarea
                value={importNotes}
                onChange={e => setImportNotes(e.target.value)}
                rows={3}
                placeholder="ملاحظات حول هذه الدفعة..."
                className="w-full mt-2 px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal"
              />
            </div>
            
            {/* زر الانتقال */}
            <button
              onClick={() => setStep('upload')}
              className="w-full py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm hover:bg-amber-600 transition-colors flex items-center justify-center gap-2"
            >
              التالي: رفع البيانات <ChevronDown className="w-4 h-4 rotate-[-90deg]" />
            </button>
          </motion.div>
        )}
        
        {/* ===== الخطوة 2: رفع البيانات ===== */}
        {step === 'upload' && (
          <motion.div
            key="upload"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-5"
          >
            {/* اختيار الطريقة */}
            <div className="flex gap-2">
              <button
                onClick={() => setMethod('csv')}
                className={`flex-1 py-4 rounded-xl font-cairo font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                  method === 'csv' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <FileSpreadsheet className="w-5 h-5" /> رفع ملف CSV
              </button>
              <button
                onClick={() => setMethod('paste')}
                className={`flex-1 py-4 rounded-xl font-cairo font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                  method === 'paste' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Clipboard className="w-5 h-5" /> لصق البيانات
              </button>
            </div>
            
            {/* رفع CSV */}
            {method === 'csv' && (
              <div className="space-y-3">
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all ${
                    isDragging
                      ? 'border-amber-500 bg-amber-50/50 scale-[1.01] shadow-inner'
                      : 'border-slate-200 hover:border-amber-400'
                  }`}
                >
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="csv-upload"
                  />
                  <label htmlFor="csv-upload" className="cursor-pointer">
                    <Upload className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                    <p className="font-cairo font-bold text-slate-700">اضغط لرفع ملف CSV</p>
                    <p className="text-sm text-slate-500 font-tajawal mt-1">أو اسحب الملف وأفلته هنا</p>
                  </label>
                </div>
                {csvFile && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span className="font-cairo font-semibold text-emerald-700">{csvFile.name}</span>
                    <span className="text-sm text-slate-500 font-tajawal">({(csvFile.size / 1024).toFixed(1)} KB)</span>
                  </div>
                )}
              </div>
            )}
            
            {/* لصق البيانات */}
            {method === 'paste' && (
              <div className="space-y-3">
                <textarea
                  value={pastedText}
                  onChange={e => setPastedText(e.target.value)}
                  rows={10}
                  placeholder="لصق البيانات هنا...

التنسيق: العناوين في الصف الأول، البيانات في الصفوف التالية
الفاصل: Tab أو comma

مثال:
nickname,gender,age,country,city,email,phone
أبو محمد,male,30,السعودية,الرياض,example@email.com,05xxxxxxxx"
                  className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-mono text-sm"
                />
                <button
                  onClick={handlePasteParse}
                  disabled={!pastedText.trim() || isProcessing}
                  className="w-full py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm hover:bg-amber-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Table className="w-5 h-5" />}
                  تحليل البيانات
                </button>
              </div>
            )}
            
            {/* أخطاء التحليل */}
            {parseErrors.length > 0 && (
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-rose-700 font-cairo font-bold">
                  <AlertCircle className="w-5 h-5" /> أخطاء في التحليل
                </div>
                {parseErrors.map((err, idx) => (
                  <p key={idx} className="text-sm text-rose-600 font-tajawal">• {err}</p>
                ))}
              </div>
            )}
          </motion.div>
        )}
        
        {/* ===== الخطوة 3: المعاينة ===== */}
        {step === 'preview' && parsedData.length > 0 && (
          <motion.div
            key="preview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-5"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-cairo font-bold text-lg text-slate-800 flex items-center gap-2">
                <Eye className="w-5 h-5 text-amber-500" /> معاينة البيانات
              </h3>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-lg bg-slate-100 text-slate-600 font-cairo font-bold text-sm">
                  {parsedData.length} صف
                </span>
                <button
                  onClick={() => setShowPreview(!showPreview)}
                  className="p-2 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200"
                >
                  {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            
            {showPreview && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-slate-50">
                      {parsedHeaders.slice(0, 10).map(h => (
                        <th key={h} className="px-3 py-2 text-right font-cairo font-bold text-slate-600 whitespace-nowrap">
                          {h}
                        </th>
                      ))}
                      {parsedHeaders.length > 10 && (
                        <th className="px-3 py-2 font-cairo font-bold text-slate-400">+{parsedHeaders.length - 10}</th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {parsedData.slice(0, 5).map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        {parsedHeaders.slice(0, 10).map(h => (
                          <td key={h} className="px-3 py-2 text-slate-700 font-tajawal whitespace-nowrap">
                            {row[h] || row[REGISTRATION_FIELDS.find(f => f.label === h)?.key || h] || '—'}
                          </td>
                        ))}
                      </tr>
                    ))}
                    {parsedData.length > 5 && (
                      <tr>
                        <td colSpan={Math.min(parsedHeaders.length, 11)} className="px-3 py-2 text-center text-slate-400 font-tajawal">
                          ... و {parsedData.length - 5} صفوف أخرى
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
            
            {/* زر التحقق */}
            <button
              onClick={validateData}
              disabled={isProcessing}
              className="w-full py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm hover:bg-amber-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <AlertCircle className="w-5 h-5" />}
              التحقق من البيانات
            </button>
          </motion.div>
        )}
        
        {/* ===== الخطوة 4: التحقق ===== */}
        {step === 'validate' && (
          <motion.div
            key="validate"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-5"
          >
            {/* ملخص */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <h3 className="font-cairo font-bold text-lg text-slate-800 flex items-center gap-2 mb-4">
                <AlertCircle className="w-5 h-5 text-amber-500" /> ملخص التحقق
              </h3>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 rounded-xl p-4 text-center">
                  <p className="font-cairo font-extrabold text-2xl text-slate-700">{parsedData.length}</p>
                  <p className="text-xs text-slate-500 font-cairo">إجمالي الصفوف</p>
                </div>
                <div className="bg-emerald-50 rounded-xl p-4 text-center">
                  <p className="font-cairo font-extrabold text-2xl text-emerald-600">{uniqueData.length}</p>
                  <p className="text-xs text-emerald-600 font-cairo">صالح للاستيراد</p>
                </div>
                <div className="bg-amber-50 rounded-xl p-4 text-center">
                  <p className="font-cairo font-extrabold text-2xl text-amber-600">{duplicates.length}</p>
                  <p className="text-xs text-amber-600 font-cairo">مكررات</p>
                </div>
                <div className="bg-rose-50 rounded-xl p-4 text-center">
                  <p className="font-cairo font-extrabold text-2xl text-rose-600">{validationErrors.length}</p>
                  <p className="text-xs text-rose-600 font-cairo">أخطاء</p>
                </div>
              </div>
            </div>
            
            {/* الأخطاء */}
            {validationErrors.length > 0 && (
              <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-rose-700 font-cairo font-bold">
                  <XCircle className="w-5 h-5" /> أخطاء يجب تصحيحها ({validationErrors.length})
                </div>
                <div className="max-h-60 overflow-y-auto space-y-2">
                  {validationErrors.slice(0, 20).map((err, idx) => (
                    <div key={idx} className="bg-white rounded-lg p-2 flex items-start gap-2">
                      <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-700 font-cairo font-bold text-xs">صف {err.row}</span>
                      <span className="text-sm text-rose-600 font-tajawal">
                        {err.field ? `${err.field}: ` : ''}{err.message}
                      </span>
                    </div>
                  ))}
                  {validationErrors.length > 20 && (
                    <p className="text-sm text-rose-500 font-tajawal text-center">
                      ... و {validationErrors.length - 20} أخطاء أخرى
                    </p>
                  )}
                </div>
              </div>
            )}
            
            {/* التحذيرات */}
            {validationWarnings.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-amber-700 font-cairo font-bold">
                  <AlertTriangle className="w-5 h-5" /> تحذيرات ({validationWarnings.length})
                </div>
                <div className="max-h-40 overflow-y-auto space-y-2">
                  {validationWarnings.map((warn, idx) => (
                    <div key={idx} className="bg-white rounded-lg p-2 flex items-start gap-2">
                      <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-700 font-cairo font-bold text-xs">صف {warn.row}</span>
                      <span className="text-sm text-amber-600 font-tajawal">
                        {warn.field ? `${warn.field}: ` : ''}{warn.message}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* خيارات التعامل مع السجلات المكررة */}
            {duplicates.length > 0 && (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4">
                <div className="flex items-center gap-2 text-slate-800 font-cairo font-bold">
                  <Info className="w-5 h-5 text-amber-500" />
                  <span>تم اكتشاف سجلات مكررة ({duplicates.length} عضو)</span>
                </div>
                
                <p className="text-xs text-slate-500 font-tajawal">
                  بعض الأعضاء في الملف لديهم بريد إلكتروني أو رقم هاتف مسجل مسبقاً في النظام. يرجى تحديد طريقة التعامل معهم لتمكين الاستيراد:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                  {/* Option 1: Replace/Update */}
                  <div 
                    onClick={() => setReplaceMode(true)}
                    className={`cursor-pointer p-4 rounded-xl border-2 transition-all duration-200 flex flex-col justify-between ${
                      replaceMode 
                        ? 'border-amber-500 bg-amber-50/45 ring-2 ring-amber-500/20' 
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center ${
                        replaceMode ? 'border-amber-600 bg-amber-600' : 'border-slate-300'
                      }`}>
                        {replaceMode && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <div>
                        <h4 className="font-cairo font-bold text-sm text-slate-800">تحديث واستبدال الحسابات القائمة</h4>
                        <p className="text-xs text-slate-500 font-tajawal mt-1 leading-relaxed">
                          سيتم استبدال وتحديث كافة بيانات الأعضاء المكررين بالمعلومات الجديدة الواردة في الملف المرفوع بالكامل مع المحافظة على معرّفاتهم الأصلية.
                        </p>
                      </div>
                    </div>
                    <span className="self-end mt-2 text-[10px] font-cairo font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">موصى به عند تحديث القوائم</span>
                  </div>

                  {/* Option 2: Skip/Ignore */}
                  <div 
                    onClick={() => setReplaceMode(false)}
                    className={`cursor-pointer p-4 rounded-xl border-2 transition-all duration-200 flex flex-col justify-between ${
                      !replaceMode 
                        ? 'border-slate-500 bg-slate-50 ring-2 ring-slate-500/20' 
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center ${
                        !replaceMode ? 'border-slate-600 bg-slate-600' : 'border-slate-300'
                      }`}>
                        {!replaceMode && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <div>
                        <h4 className="font-cairo font-bold text-sm text-slate-800">تجاهل المكرر (استيراد الجديد فقط)</h4>
                        <p className="text-xs text-slate-500 font-tajawal mt-1 leading-relaxed">
                          تخطي أي سجل مكرر بشكل تلقائي، واستيراد الأعضاء الجدد فقط ({uniqueData.length} عضو) الذين لا يملكون أي تكرار مسبق في النظام.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* أزرار */}
            <div className="flex gap-3">
              <button
                onClick={() => setStep('upload')}
                className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-700 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
              >
                إعادة رفع البيانات
              </button>
              <button
                onClick={executeImport}
                disabled={((uniqueData.length === 0 && !replaceMode) || (replaceMode && duplicates.length === 0 && uniqueData.length === 0)) || isProcessing}
                className={`flex-1 py-3 rounded-xl font-cairo font-bold text-sm transition-colors disabled:opacity-50 flex items-center justify-center gap-2 text-white ${
                  replaceMode ? 'bg-amber-500 hover:bg-amber-600' : 'bg-emerald-500 hover:bg-emerald-600'
                }`}
              >
                {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                {replaceMode 
                  ? `تنفيذ الاستيراد مع الاستبدال (${uniqueData.length + duplicates.length} عضو)`
                  : `تنفيذ الاستيراد وتجاهل المكرر (${uniqueData.length} عضو)`
                }
              </button>
            </div>
          </motion.div>
        )}
        
        {/* ===== الخطوة 5: النتيجة ===== */}
        {step === 'result' && importReport && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-5"
          >
            {/* تقرير النتيجة */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7 text-emerald-600" />
                </div>
                <div>
                  <h3 className="font-cairo font-bold text-lg text-slate-800">تم الاستيراد بنجاح!</h3>
                  <p className="text-sm text-slate-500 font-tajawal">{createdBatch?.batchNumber} — {createdBatch?.importDate}</p>
                </div>
              </div>
              
              {/* الإحصائيات */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-5">
                <div className="bg-slate-50 rounded-xl p-3 text-center">
                  <p className="font-cairo font-extrabold text-xl text-slate-700">{importReport.totalRows}</p>
                  <p className="text-xs text-slate-500 font-cairo">إجمالي</p>
                </div>
                <div className="bg-emerald-50 rounded-xl p-3 text-center">
                  <p className="font-cairo font-extrabold text-xl text-emerald-600">{importReport.importedCount}</p>
                  <p className="text-xs text-emerald-600 font-cairo">تم استيرادهم</p>
                </div>
                <div className="bg-amber-50 rounded-xl p-3 text-center">
                  <p className="font-cairo font-extrabold text-xl text-amber-600">{importReport.duplicatesCount}</p>
                  <p className="text-xs text-amber-600 font-cairo">مكررات</p>
                </div>
                <div className="bg-sky-50 rounded-xl p-3 text-center">
                  <p className="font-cairo font-extrabold text-xl text-sky-600">{importReport.skippedCount}</p>
                  <p className="text-xs text-sky-600 font-cairo">تجاهل</p>
                </div>
                <div className="bg-rose-50 rounded-xl p-3 text-center">
                  <p className="font-cairo font-extrabold text-xl text-rose-600">{importReport.errorsCount}</p>
                  <p className="text-xs text-rose-600 font-cairo">أخطاء</p>
                </div>
              </div>
              
              {/* تفاصيل الدفعة */}
              {createdBatch && (
                <div className="bg-slate-50 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-slate-400" />
                    <span className="font-cairo font-semibold text-sm text-slate-700">رقم الدفعة:</span>
                    <span className="font-cairo font-bold text-amber-600">{createdBatch.batchNumber}</span>
                  </div>
                  {createdBatch.officeName && (
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      <span className="font-cairo font-semibold text-sm text-slate-700">الخطابة:</span>
                      <span className="font-cairo font-bold text-slate-800">{createdBatch.officeName}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span className="font-cairo font-semibold text-sm text-slate-700">تاريخ الاستيراد:</span>
                    <span className="font-tajawal text-slate-800">{new Date(createdBatch.importDate).toLocaleDateString('ar-SA')}</span>
                  </div>
                  {createdBatch.notes && (
                    <div className="flex items-center gap-2">
                      <StickyNote className="w-4 h-4 text-slate-400" />
                      <span className="font-cairo font-semibold text-sm text-slate-700">ملاحظات:</span>
                      <span className="font-tajawal text-slate-800">{createdBatch.notes}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            {/* أزرار */}
            <div className="flex gap-3">
              <button
                onClick={resetImport}
                className="flex-1 py-3 rounded-xl bg-amber-500 text-white font-cairo font-bold text-sm hover:bg-amber-600 transition-colors flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" /> استيراد جديد
              </button>
              <button
                onClick={() => window.location.href = '/admin/members'}
                className="flex-1 py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
              >
                <Users className="w-5 h-5" /> عرض الأعضاء
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* سجل الدفعات */}
      {batches.length > 0 && step === 'setup' && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <h3 className="font-cairo font-bold text-lg text-slate-800 flex items-center gap-2 mb-4">
            <Table className="w-5 h-5 text-amber-500" /> سجل الدفعات السابقة
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50">
                  <th className="px-4 py-2 text-right font-cairo font-bold text-slate-600">رقم الدفعة</th>
                  <th className="px-4 py-2 text-right font-cairo font-bold text-slate-600">الخطابة</th>
                  <th className="px-4 py-2 text-right font-cairo font-bold text-slate-600">التاريخ</th>
                  <th className="px-4 py-2 text-right font-cairo font-bold text-slate-600">الأعضاء</th>
                  <th className="px-4 py-2 text-right font-cairo font-bold text-slate-600">المكررات</th>
                  <th className="px-4 py-2 text-right font-cairo font-bold text-slate-600">الأخطاء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {batches.slice(0, 5).map(b => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="px-4 py-2 font-cairo font-bold text-amber-600">{b.batchNumber}</td>
                    <td className="px-4 py-2 font-tajawal text-slate-700">{b.officeName || '—'}</td>
                    <td className="px-4 py-2 font-tajawal text-slate-700">{new Date(b.importDate).toLocaleDateString('ar-SA')}</td>
                    <td className="px-4 py-2 font-cairo font-bold text-emerald-600">{b.membersCount}</td>
                    <td className="px-4 py-2 font-cairo font-bold text-amber-600">{b.duplicatesCount}</td>
                    <td className="px-4 py-2 font-cairo font-bold text-rose-600">{b.errorsCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Modal عرض القالب الكامل */}
      <Modal open={showTemplateModal} onClose={() => setShowTemplateModal(false)} title="القالب الكامل لاستيراد الأعضاء" size="lg">
        <div className="space-y-4">
          <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <span className="font-cairo font-bold text-purple-700">هذا القالب للذكاء الاصطناعي</span>
            </div>
            <p className="text-sm text-purple-600 font-tajawal">
              يمكنك نسخ هذا القالب وإرساله للذكاء الاصطناعي (ChatGPT, Claude, Gemini) ليقوم بإنشاء ملفات الأعضاء بنفس التنسيق المطلوب.
            </p>
          </div>
          
          <div className="bg-slate-50 rounded-xl p-4 max-h-[60vh] overflow-y-auto">
            <pre className="text-sm text-slate-700 font-tajawal whitespace-pre-wrap leading-relaxed" dir="rtl">
              {templateText}
            </pre>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={copyFullTemplate}
              className={`flex-1 py-3 rounded-xl font-cairo font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                templateCopied 
                  ? 'bg-emerald-500 text-white' 
                  : 'bg-purple-500 text-white hover:bg-purple-600'
              }`}
            >
              {templateCopied ? (
                <>
                  <CheckCircle2 className="w-5 h-5" /> تم النسخ ✓
                </>
              ) : (
                <>
                  <Copy className="w-5 h-5" /> نسخ القالب
                </>
              )}
            </button>
            <button
              onClick={() => setShowTemplateModal(false)}
              className="flex-1 py-3 rounded-xl bg-slate-100 text-slate-700 font-cairo font-bold text-sm hover:bg-slate-200 transition-colors"
            >
              إغلاق
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
