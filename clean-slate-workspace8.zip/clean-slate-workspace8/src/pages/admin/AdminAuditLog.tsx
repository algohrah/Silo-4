import { useState, useMemo } from 'react';
import { ClipboardList, Search, UserX, CheckCircle2, Trash2, Edit3, ShieldCheck, Flag } from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import FilterDropdown from '../../components/admin/FilterDropdown';

const actionConfig: Record<string, { label: string; icon: any; color: string }> = {
  suspend: { label: 'إيقاف عضو', icon: UserX, color: 'text-rose-600 bg-rose-50' },
  verify: { label: 'توثيق عضو', icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50' },
  delete: { label: 'حذف عضو', icon: Trash2, color: 'text-red-600 bg-red-50' },
  edit: { label: 'تعديل بيانات', icon: Edit3, color: 'text-amber-600 bg-amber-50' },
  admin_action: { label: 'إجراء إداري', icon: ShieldCheck, color: 'text-blue-600 bg-blue-50' },
  report: { label: 'معالجة بلاغ', icon: Flag, color: 'text-purple-600 bg-purple-50' },
};

export default function AdminAuditLog() {
  const { reports, adminUsers } = useApp();
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<string>('all');

  // ميز وهمية من سجل الأخطاء المشتقة من البلاغات
  const logs = useMemo(() => {
    const list: any[] = [];
    reports.forEach((r) => {
      (r.actionLog || []).forEach((log) => {
        list.push({
          id: log.id,
          type: 'report',
          action: log.action,
          target: r.reportedName,
          by: log.by,
          note: log.adminNote,
          timestamp: log.timestamp,
        });
      });
    });
    return list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [reports]);

  const filtered = useMemo(() => {
    return logs.filter((log) => {
      const matchSearch =
        !search ||
        log.action.includes(search) ||
        log.target.includes(search) ||
        log.by.includes(search);
      const matchType = filterType === 'all' || log.type === filterType;
      return matchSearch && matchType;
    });
  }, [logs, search, filterType]);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          <ClipboardList className="w-5 h-5 text-amber-500" /> سجل التدقيق
        </h2>
        <p className="text-sm text-slate-500 font-tajawal">سجل بجميع الإجراءات الإدارية على المنصة</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالإجراء أو المسؤول..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterDropdown
            label="النوع:"
            value={filterType}
            onChange={(v) => setFilterType(v)}
            options={[
              { value: 'all', label: 'كل الأنواع' },
              { value: 'report', label: 'معالجة بلاغ' },
              { value: 'member', label: 'إجراء عضو' },
            ]}
          />
        </div>
      </div>

      {/* Logs */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {['الإجراء', 'الهدف', 'المسؤول', 'ملاحظات', 'التاريخ'].map((h) => (
                <th key={h} className="text-right px-5 py-3 text-xs font-cairo font-bold text-slate-500">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {filtered.map((log) => {
              const cfg = actionConfig[log.type] || actionConfig.admin_action;
              const Icon = cfg.icon;
              return (
                <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-cairo font-bold ${cfg.color}`}>
                      <Icon className="w-3 h-3" /> {cfg.label}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-xs font-cairo font-bold text-slate-900">{log.target}</td>
                  <td className="px-5 py-3 text-xs text-slate-600 font-tajawal">{log.by}</td>
                  <td className="px-5 py-3 text-xs text-slate-500 font-tajawal">{log.note || '—'}</td>
                  <td className="px-5 py-3 text-xs text-slate-400 font-tajawal">
                    {new Date(log.timestamp).toLocaleString('ar-SA')}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <p className="text-center py-10 text-slate-400 font-cairo text-sm">لا توجد سجلات مطابقة</p>
        )}
      </div>
    </div>
  );
}
