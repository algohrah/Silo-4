import { useParams, Link } from 'react-router-dom';
import { Clock, ArrowLeft, ArrowRight, Share2, Bookmark, Loader2 } from 'lucide-react';
import { useBlogPost, useBlogPosts } from '../lib/useContent';

export default function BlogPost() {
  const { id } = useParams();
  const { post, loading } = useBlogPost(id);
  const { posts: all } = useBlogPosts();

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <Loader2 className="w-8 h-8 animate-spin text-gold-500 mb-3" />
        <p className="font-cairo text-navy-500">جارٍ تحميل المقال...</p>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <h2 className="font-cairo font-bold text-2xl text-navy-900">المقال غير موجود</h2>
        <Link to="/blog" className="mt-4 text-gold-700 font-cairo font-bold">العودة للمدونة</Link>
      </div>
    );
  }

  const related = all.filter((p) => p.id !== post.id).slice(0, 3);

  return (
    <div className="bg-cream-50 min-h-screen">
      <article>
        {/* Hero */}
        <div className="relative h-64 sm:h-96 overflow-hidden">
          <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/50 to-transparent" />
          <div className="absolute bottom-0 right-0 left-0 p-6 sm:p-10">
            <div className="max-w-3xl mx-auto">
              <Link to="/blog" className="inline-flex items-center gap-1 text-gold-300 font-cairo font-semibold text-sm mb-3 hover:gap-2 transition-all">
                <ArrowRight className="w-4 h-4" /> العودة للمدونة
              </Link>
              <span className="inline-block px-3 py-1 rounded-full bg-gold-500/30 text-gold-200 text-xs font-cairo font-bold mb-3">{post.category}</span>
              <h1 className="font-cairo font-extrabold text-2xl sm:text-4xl text-white leading-tight">{post.title}</h1>
            </div>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
          {/* Meta */}
          <div className="flex items-center justify-between flex-wrap gap-4 pb-6 mb-8 border-b border-cream-200">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-gold-gradient flex items-center justify-center text-navy-900 font-cairo font-bold">{post.author.charAt(0)}</div>
              <div>
                <div className="font-cairo font-bold text-navy-900">{post.author}</div>
                <div className="text-xs text-navy-500 font-tajawal">{post.date} · {post.read_time}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="w-10 h-10 rounded-xl bg-white border border-cream-200 flex items-center justify-center text-navy-600 hover:text-gold-600 hover:border-gold-300 transition-colors"><Bookmark className="w-5 h-5" /></button>
              <button className="w-10 h-10 rounded-xl bg-white border border-cream-200 flex items-center justify-center text-navy-600 hover:text-gold-600 hover:border-gold-300 transition-colors"><Share2 className="w-5 h-5" /></button>
            </div>
          </div>

          {/* Content */}
          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-navy-700 font-tajawal leading-relaxed mb-6 font-semibold">{post.excerpt}</p>
            {post.content.split('\n').map((line, i) => {
              if (line.startsWith('## ')) {
                return <h2 key={i} className="font-cairo font-extrabold text-2xl text-navy-900 mt-8 mb-4">{line.replace('## ', '')}</h2>;
              }
              if (line.trim() === '') return null;
              return <p key={i} className="text-navy-700 font-tajawal leading-loose mb-4">{line}</p>;
            })}
          </div>

          {/* CTA */}
          <div className="mt-12 bg-navy-gradient rounded-3xl p-8 text-center relative overflow-hidden">
            <div className="absolute inset-0 pattern-arabesque opacity-30" />
            <div className="relative">
              <h3 className="font-cairo font-extrabold text-2xl text-white">جاهز لبدء رحلتك؟</h3>
              <p className="text-cream-200/80 font-tajawal mt-2 mb-5">انضم لتوافق اليوم وابدأ البحث عن شريك حياتك</p>
              <Link to="/register" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-gold-gradient text-navy-900 font-cairo font-bold shadow-gold">ابدأ مجانًا <ArrowLeft className="w-4 h-4" /></Link>
            </div>
          </div>
        </div>
      </article>

      {/* Related */}
      {related.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
          <h2 className="font-cairo font-extrabold text-2xl text-navy-900 mb-6">مقالات ذات صلة</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {related.map((p) => (
              <Link key={p.id} to={`/blog/${p.id}`} className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-luxe transition-all border border-cream-200/60">
                <div className="aspect-[16/10] overflow-hidden">
                  <img src={p.image} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="p-5">
                  <span className="text-xs text-gold-600 font-cairo font-bold">{p.category}</span>
                  <h3 className="font-cairo font-bold text-navy-900 mt-1 group-hover:text-gold-700 transition-colors line-clamp-2">{p.title}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
