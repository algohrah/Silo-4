import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Headphones, Plus, Send, Clock, CheckCircle2, AlertCircle,
  MessageSquare, ChevronLeft, Headphones as Support, Check,
} from 'lucide-react';
import { useApp } from '../lib/AppContext';
import type { SupportTicket } from '../lib/types';
import { Button } from '../components/ui/Button';
import Modal from '../components/ui/Modal';

const statusConfig = {
  open: { label: 'مفتوحة', color: 'text-sky-600 bg-sky-50', icon: Clock },
  in_progress: { label: 'قيد المعالجة', color: 'text-gold-600 bg-gold-300/15', icon: AlertCircle },
  resolved: { label: 'تم الحل', color: 'text-emerald-600 bg-emerald-50', icon: CheckCircle2 },
  closed: { label: 'مغلقة', color: 'text-navy-400 bg-cream-100', icon: CheckCircle2 },
};

const categories = ['استفسار عام', 'طلب ترقية', 'مشكلة تقنية', 'شكوى', 'اقتراح'] as const;

export default function AdminChat() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const {
    showToast,
    supportTickets,
    sendSupportMessage,
    createSupportTicket,
    members,
    interestRequests,
  } = useApp();

  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [newTicketOpen, setNewTicketOpen] = useState(false);
  const [newSubject, setNewSubject] = useState('');
  const [newCategory, setNewCategory] = useState<typeof categories[number]>('استفسار عام');
  const [newMessage, setNewMessage] = useState('');

  // Active ticket calculated reactively from shared state
  const activeTicket = supportTickets.find(t => t.id === activeTicketId) || null;

  // Sync / intercept partner coordination redirect parameters
  useEffect(() => {
    const partnerId = searchParams.get('partnerId');
    if (partnerId) {
      const partner = members.find(m => m.id === partnerId);
      if (partner) {
        const expectedSubject = `تنسيق اللقاء الشرعي - ${partner.nickname}`;
        // Try to find existing conversation
        const existing = supportTickets.find(
          t => t.userId === 'm2' && t.subject === expectedSubject
        );
        if (existing) {
          // eslint-disable-next-line react-hooks/set-state-in-effect
          setActiveTicketId(existing.id);
        } else {
          // Find original match request text
          const req = interestRequests.find(
            r =>
              (r.senderId === 'm2' && r.receiverId === partnerId) ||
              (r.senderId === partnerId && r.receiverId === 'm2')
          );
          const originalMsg = req ? req.message : 'رغبة في التواصل والتقريب من خلال إشراف الإدارة الموقرة.';

          const partnerBio = partner.bio || 'لم تتم كتابة نبذة بعد.';
          const initialText = `السلام عليكم ورحمة الله وبركاته،
يسعدنا في إدارة «توافق» البدء في تنسيق اللقاء الشرعي والتقريب المبارك بينكما.

بطاقة العضو المطلوب التنسيق معه:
• الاسم المستعار: ${partner.nickname}
• العمر: ${partner.age} سنة
• المدينة: ${partner.city}
• المؤهل الدراسي: ${partner.education}
• جهة العمل: ${partner.workType}
• النبذة التعريفية للطرف الآخر: ${partnerBio}

نص رسالة طلب الاهتمام الأصلية المرسلة:
« ${originalMsg} »

يرجى تأكيد رغبتكم بالبدء وسيقوم وسيط العلاقات بالتواصل مع عائلة العضو والبدء في الرؤية الشرعية الرسمية للطرفين.`;

          const created = createSupportTicket(expectedSubject, 'استفسار عام', initialText, 'm2');
          setActiveTicketId(created.id);
          showToast('تم فتح محادثة تنسيق اللقاء الشرعي مع الإدارة 🌸', 'success');
        }
      }
      // Clean query parameter
      searchParams.delete('partnerId');
      setSearchParams(searchParams);
    }
  }, [searchParams, members, interestRequests, supportTickets, createSupportTicket, setSearchParams, showToast]);

  const sendMessage = () => {
    if (!draft.trim() || !activeTicketId) return;
    sendSupportMessage(activeTicketId, draft, 'user');
    setDraft('');

    // Simulated helper reply after 2.5 seconds
    setTimeout(() => {
      sendSupportMessage(
        activeTicketId,
        'شكرًا لتواصلك معنا الدائم في توافق. تم استلام تدوينك، وسلَّم وسيط العلاقات الطلب لمراجعته وسيتم إفادتك فور الاتصال المباشر مع الأطراف. 🌸',
        'admin'
      );
    }, 2500);
  };

  const createTicket = () => {
    if (!newSubject.trim() || !newMessage.trim()) return;
    const created = createSupportTicket(newSubject, newCategory, newMessage, 'm2');
    setNewTicketOpen(false);
    setNewSubject('');
    setNewMessage('');
    showToast('تم إنشاء تذكرة الدعم بنجاح! 🎫', 'success');
    setActiveTicketId(created.id);
  };

  // Only show tickets relevant to the demo user 'm2'
  const userTickets = supportTickets.filter(t => t.userId === 'm2');

  if (activeTicket) {
    const sc = statusConfig[activeTicket.status] || statusConfig.open;
    return (
      <div className="bg-cream-50 min-h-[calc(100vh-5rem)] lg:min-h-screen" dir="rtl">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6">
          <button
            onClick={() => setActiveTicketId(null)}
            className="flex items-center gap-2 text-navy-600 hover:text-gold-700 font-cairo font-semibold text-sm mb-4 transition-colors"
          >
            <ChevronLeft className="w-4 h-4 rotate-180" /> رجوع للتذاكر
          </button>

          <div className="bg-white rounded-3xl shadow-soft border border-cream-200/60 overflow-hidden flex flex-col h-[70vh]">
            {/* Header */}
            <div className="flex items-center gap-3 p-4 border-b border-cream-200 bg-cream-50/40">
              <div className="w-11 h-11 rounded-xl bg-navy-gradient flex items-center justify-center flex-shrink-0">
                <Headphones className="w-6 h-6 text-gold-300" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-cairo font-bold text-navy-900 truncate">{activeTicket.subject}</h3>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${sc.color} flex items-center gap-1`}>
                    <sc.icon className="w-3 h-3" /> {sc.label}
                  </span>
                  <span className="text-xs text-navy-400 font-tajawal">{activeTicket.category}</span>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-cream-50/20">
              {activeTicket.messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.sender === 'user' ? 'justify-start' : 'justify-end'}`}
                >
                  <div className="flex gap-2 max-w-[85%]">
                    {msg.sender === 'admin' && (
                      <div className="w-8 h-8 rounded-full bg-navy-gradient flex items-center justify-center flex-shrink-0 mt-1">
                        <Headphones className="w-4 h-4 text-gold-300" />
                      </div>
                    )}
                    <div>
                      <div className={`px-4 py-2.5 rounded-2xl whitespace-pre-line ${
                        msg.sender === 'user'
                          ? 'bg-navy-900 text-white rounded-bl-md'
                          : 'bg-white text-navy-900 rounded-br-md shadow-soft border border-cream-200/80 font-semibold'
                      }`}>
                        <p className="font-tajawal text-sm leading-relaxed">{msg.text}</p>
                      </div>
                      <span className="text-[10px] mt-1 block text-navy-400 px-1">
                        {msg.sender === 'admin' ? 'مستشار العلاقات الشرعية' : 'أنت'} · {msg.time}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-cream-200 flex items-center gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="اكتب رسالتك للإدارة والوسيط الشرعي..."
                className="flex-1 px-4 py-3 rounded-xl bg-cream-50 border border-cream-200 focus:border-gold-400 focus:outline-none font-tajawal text-navy-950"
              />
              <button
                onClick={sendMessage}
                className="w-12 h-12 rounded-xl bg-gold-gradient flex items-center justify-center text-navy-900 flex-shrink-0 shadow-soft cursor-pointer hover:scale-[1.02] active:scale-[0.98] transition-transform"
              >
                <Send className="w-5 h-5 -scale-x-100" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8" dir="rtl">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 font-cairo">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-navy-gradient flex items-center justify-center">
              <Headphones className="w-6 h-6 text-gold-300" />
            </div>
            <div>
              <h1 className="font-cairo font-extrabold text-2xl text-navy-900">تواصل مع الإدارة</h1>
              <p className="text-navy-600 font-tajawal text-sm text-right">نحن هنا لمساعدتك والتوفيق بين العائلتين</p>
            </div>
          </div>
          <button
            onClick={() => setNewTicketOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold text-sm shadow-soft hover:shadow-gold transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> تذكرة جديدة
          </button>
        </div>

        {/* Info banner */}
        <div className="bg-navy-gradient rounded-2xl p-4 mb-5 relative overflow-hidden">
          <div className="absolute inset-0 pattern-arabesque opacity-30" />
          <div className="relative flex items-center gap-3">
            <MessageSquare className="w-6 h-6 text-gold-300 flex-shrink-0" />
            <p className="text-cream-200/90 font-tajawal text-sm text-right leading-relaxed">
              التواصل في توافق <span className="text-gold-300 font-bold">حكومي وخاص وسري بينك وبين الإدارة فقط</span>. يحظر التواصل المباشر لحفظ كرامة وخصوصية البيوت والعائلات.
            </p>
          </div>
        </div>

        {/* Tickets list */}
        <div className="space-y-3">
          {userTickets.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-cream-200">
              <Support className="w-12 h-12 text-cream-400 mx-auto mb-2" />
              <p className="text-navy-500 font-tajawal">لم تفتح أي تذاكر محادثة حالياً.</p>
            </div>
          ) : (
            userTickets.map((ticket) => {
              const sc = statusConfig[ticket.status] || statusConfig.open;
              const lastMsg = ticket.messages[ticket.messages.length - 1];
              return (
                <button
                  key={ticket.id}
                  onClick={() => setActiveTicketId(ticket.id)}
                  className="w-full flex items-start gap-3 p-4 bg-white rounded-2xl shadow-soft border border-cream-200/60 text-right hover:shadow-luxe hover:border-gold-300 transition-all cursor-pointer"
                >
                  <div className="w-11 h-11 rounded-xl bg-cream-100 flex items-center justify-center flex-shrink-0">
                    <Support className="w-5 h-5 text-navy-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h3 className="font-cairo font-bold text-navy-900 truncate">{ticket.subject}</h3>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${sc.color} flex items-center gap-1 flex-shrink-0`}>
                        <sc.icon className="w-3 h-3" /> {sc.label}
                      </span>
                    </div>
                    <p className="text-sm text-navy-500 font-tajawal truncate text-right">
                      {lastMsg ? lastMsg.text : 'لا توجد رسائل بعد'}
                    </p>
                    <p className="text-xs text-navy-400 font-tajawal mt-1 text-right">
                      {ticket.category} · {ticket.updatedAt}
                    </p>
                  </div>
                  <ChevronLeft className="w-5 h-5 text-navy-300 flex-shrink-0 mt-1" />
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* New ticket modal */}
      <Modal open={newTicketOpen} onClose={() => setNewTicketOpen(false)} title="تذكرة دعم جديدة">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2 text-right">الموضوع</label>
            <input
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              placeholder="موضوع الاستفسار أو طلب التنسيق"
              className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 text-right"
            />
          </div>
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2 text-right">التصنيف</label>
            <div className="flex flex-wrap gap-2 justify-start">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setNewCategory(cat)}
                  className={`px-3 py-2 rounded-xl text-sm font-cairo font-semibold transition-all ${
                    newCategory === cat ? 'bg-navy-900 text-white shadow-soft' : 'bg-cream-100 text-navy-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2 text-right">رسالتك</label>
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              rows={4}
              placeholder="اشرح استفسارك بالتفصيل..."
              className="w-full px-4 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 text-right resize-none"
            />
          </div>
          <Button fullWidth size="lg" onClick={createTicket}>
            <Send className="w-5 h-5 -scale-x-100" /> إرسال التذكرة
          </Button>
        </div>
      </Modal>
    </div>
  );
}
