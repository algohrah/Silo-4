import { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Check, User, FileText, Heart, ShieldCheck,
  Venus, Mars, Lock, Eye, EyeOff,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import {
  Field, TextInput, SelectInput, TextArea,
  RadioGroup, ChoiceCard, RangeSlider, ProgressBar, DateSelect,
  SelectWithOther,
} from '../components/ui/FormFields';
import SearchableSelect from '../components/ui/SearchableSelect';
import { useApp } from '../lib/AppContext';
import * as C from '../lib/constants';
import { dataService } from '../lib/data/DataService';
const { getCountries, getCities, addPendingCity, getAllPendingCities } = dataService.db;



// ====================================================================
//  صفحة التسجيل الديناميكي — نموذج متعدد الخطوات
// ====================================================================

interface FormData {
  // أساسي
  gender: string;
  nickname: string;
  username: string;
  birthDate: string;
  age: number;
  country: string;
  city: string;
  district: string;
  sect: string;
  sectOther: string;
  nationalityMode: string; // 'same' | 'other'
  nationality: string;
  // الحالة الاجتماعية
  maritalStatus: string;
  childrenCount: string;
  childrenLiveWith: string;
  hasChildren: string;
  wifeCount: string;
  seekingWife: string;
  // شخصية
  height: number;
  weight: number;
  skinColor: string;
  ethnicity: string;
  health: string;
  smoking: string;
  // نساء فقط
  acceptPolygamy: string;
  acceptDivorced: string;
  acceptWithChildren: string;
  // تعليم وعمل
  education: string;
  workType: string;
  jobTitle: string;
  housing: string;
  // نبذة
  bio: string;
  // مواصفات الشريك
  pCountry: string;
  pCity: string;
  pAgeMin: number;
  pAgeMax: number;
  pNationality: string;
  pMaritalStatus: string;
  pAcceptChildren: string;
  pSect: string;
  pSectOther: string;
  pEducation: string;
  pWorkType: string;
  pReligionLevel: string;
  pSkinColor: string;
  pHeightNoMatter: boolean;
  pHeight: number;
  pHousing: string;
  pNotes: string;
  // بيانات الإدارة
  realName: string;
  phone: string;
  whatsapp: string;
  email: string;
  // كلمة المرور
  password: string;
  passwordConfirm: string;
}

const emptyForm: FormData = {
  gender: '', nickname: '', username: '', birthDate: '', age: 0, country: '', city: '',
  district: '', sect: '', sectOther: '', nationalityMode: '', nationality: '',
  maritalStatus: '', childrenCount: '', childrenLiveWith: '',
  hasChildren: '', wifeCount: '', seekingWife: '',
  height: 0, weight: 0, skinColor: '', ethnicity: '', health: '', smoking: '',
  acceptPolygamy: '', acceptDivorced: '', acceptWithChildren: '',
  education: '', workType: '', jobTitle: '', housing: '',
  bio: '',
  pCountry: '', pCity: '', pAgeMin: 22, pAgeMax: 35, pNationality: '',
  pMaritalStatus: '', pAcceptChildren: '', pSect: '', pSectOther: '',
  pEducation: '', pWorkType: '', pReligionLevel: '', pSkinColor: '', pHeightNoMatter: false, pHeight: 170, pHousing: '', pNotes: '',
  realName: '', phone: '', whatsapp: '', email: '',
  password: '', passwordConfirm: '',
};

const STEPS = [
  { id: 0, title: 'البيانات الأساسية', icon: User },
  { id: 1, title: 'المواصفات الشخصية', icon: FileText },
  { id: 2, title: 'مواصفات الشريك', icon: Heart },
  { id: 3, title: 'بيانات الحساب', icon: ShieldCheck },
];

export default function Register() {
  const navigate = useNavigate();
  const { login, registerNewMember, members } = useApp();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormData>(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPass, setShowPass] = useState(false);
  const [showPassConfirm, setShowPassConfirm] = useState(false);

  const isMale = form.gender === 'male';
  const isFemale = form.gender === 'female';

  const set = (key: keyof FormData, value: any) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: '' }));
  };

  // حساب العمر تلقائيًا من تاريخ الميلاد
  const handleBirthDateChange = (date: string) => {
    set('birthDate', date);
    const parts = date ? date.split('-') : [];
    if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
      const birth = new Date(date);
      const today = new Date();
      let calculatedAge = today.getFullYear() - birth.getFullYear();
      const monthDiff = today.getMonth() - birth.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        calculatedAge--;
      }
      set('age', calculatedAge);
    } else {
      set('age', 0);
    }
  };

  // المدن حسب الدولة المختارة (تشمل المدن الرسمية + المدن المقترحة المعلّقة لهذا المستخدم)
  const cities = useMemo(() => {
    if (!form.country) return [];
    const official = getCities(form.country);
    // أضف المدن المقترحة المعلّقة المرتبطة بنفس الدولة كي يراها المستخدم ويختارها
    const pending = getAllPendingCities()
      .filter((p) => p.country === form.country && p.status === 'pending')
      .map((p) => p.name);
    return [...official, ...pending.filter((c) => !official.includes(c))];
  }, [form.country]);

  const pCities = useMemo(() => {
    return form.pCountry && form.pCountry !== 'لا تفضيل' && form.pCountry !== 'لا يهم' ? getCities(form.pCountry) : [];
  }, [form.pCountry]);

  // قائمة الدول الحيّة من geoStore
  const countryOptions = useMemo(() => getCountries().map((c) => c.name), []);

  // إضافة مدينة مقترحة (بانتظار مراجعة الإدارة)
  const handleAddCity = (country: string) => (name: string) => {
    return addPendingCity(name, country, form.nickname || 'عضو جديد', 'register');
  };

  // التحقق من صحة كل خطوة
  const validateStep = (s: number): boolean => {
    const e: Record<string, string> = {};

    if (s === 0) {
      if (!form.gender) e.gender = 'الرجاء اختيار الجنس';
      const dateParts = form.birthDate ? form.birthDate.split('-') : [];
      const dateComplete = dateParts.length === 3 && dateParts[0] && dateParts[1] && dateParts[2];
      if (!dateComplete) e.birthDate = 'الرجاء اختيار السنة والشهر واليوم';
      else if (form.age < 18) e.birthDate = 'يجب أن يكون عمرك 18 سنة على الأقل';
      if (!form.country) e.country = 'الرجاء اختيار الدولة';
      if (!form.city) e.city = 'الرجاء اختيار المدينة';
      if (!form.district.trim()) e.district = 'الرجاء إدخال المنطقة / الولاية';
      if (!form.nationalityMode) e.nationalityMode = 'الرجاء تحديد الجنسية';
      if (form.nationalityMode === 'other' && !form.nationality.trim()) e.nationality = 'الرجاء اختيار الجنسية';
      if (!form.sect) e.sect = 'الرجاء اختيار المذهب';
      if (form.sect === 'أخرى' && !form.sectOther.trim()) e.sectOther = 'الرجاء كتابة المذهب';
      if (!form.maritalStatus) e.maritalStatus = 'الرجاء اختيار الحالة الاجتماعية';
      
      // تحقق من اسم المستخدم / اليوزر
      if (!form.username.trim()) {
        e.username = 'الرجاء إدخال اسم المستخدم (اليوزر)';
      } else if (!/^[a-z0-9_]{3,20}$/.test(form.username)) {
        e.username = 'يجب أن يتكون اسم المستخدم من 3 إلى 20 حرفًا إنجليزيًا أو أرقام أو شرطة سفلية (_) فقط';
      } else {
        const usernameExists = members.some((m) => m.username?.toLowerCase() === form.username.toLowerCase());
        if (usernameExists) {
          e.username = 'اسم المستخدم هذا محجوز بالفعل، يرجى اختيار اسم مستخدم آخر';
        }
      }
    }

    if (s === 1) {
      if (!form.height) e.height = 'الرجاء اختيار الطول';
      if (!form.weight) e.weight = 'الرجاء اختيار الوزن';
      if (!form.skinColor) e.skinColor = 'الرجاء اختيار لون البشرة';
      if (!form.ethnicity?.trim()) e.ethnicity = 'الرجاء كتابة العرق';
      if (!form.health?.trim()) e.health = 'الرجاء كتابة الحالة الصحية بالتفصيل';
      if (!form.smoking) e.smoking = 'الرجاء اختيار حالة التدخين';
      if (!form.education) e.education = 'الرجاء اختيار المؤهل الدراسي';
      if (!form.workType) e.workType = 'الرجاء اختيار نوع جهة العمل';
      if (form.workType && form.workType !== 'بدون عمل' && !form.jobTitle.trim()) e.jobTitle = 'الرجاء كتابة المسمى الوظيفي';
      if (!form.housing) e.housing = 'الرجاء اختيار نوع السكن';
      if (form.bio.trim().length < 20) e.bio = 'النبذة قصيرة جدًا (20 حرف على الأقل)';
    }

    if (s === 3) {
      if (!form.realName.trim()) e.realName = 'الرجاء إدخال الاسم الرباعي';
      if (!form.phone.trim()) e.phone = 'الرجاء إدخال رقم الهاتف';
      if (!/^[0-9+\s-]{8,}$/.test(form.phone)) e.phone = 'رقم الهاتف غير صحيح';
      if (!form.email.trim()) e.email = 'الرجاء إدخال البريد الإلكتروني';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'البريد الإلكتروني غير صحيح';
      if (form.password.length < 6) e.password = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
      if (form.password !== form.passwordConfirm) e.passwordConfirm = 'كلمتا المرور غير متطابقتين';
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNext = () => {
    if (!validateStep(step)) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    if (step < STEPS.length - 1) setStep(step + 1);
    else handleSubmit();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = () => {
    registerNewMember(form);
    navigate('/profile');
  };

  const progress = ((step + 1) / STEPS.length) * 100;

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-cream-50 py-6 px-4">
      <div className="max-w-2xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-navy-600 hover:text-gold-700 font-cairo font-semibold text-sm mb-5 transition-colors">
          <ArrowLeft className="w-4 h-4" /> العودة للرئيسية
        </Link>

        <div className="bg-white rounded-3xl shadow-luxe border border-cream-200/60 overflow-hidden">
          {/* Header مع شريط التقدم */}
          <div className="bg-navy-gradient p-5 sm:p-6">
            <div className="flex items-center justify-between mb-3">
              <h1 className="font-cairo font-bold text-white text-lg">إنشاء حساب جديد</h1>
              <span className="text-gold-300 font-cairo font-bold text-sm">
                الخطوة {step + 1} من {STEPS.length}
              </span>
            </div>
            <ProgressBar value={progress} />
            <div className="flex justify-between mt-3">
              {STEPS.map((s, i) => (
                <div key={s.id} className="flex flex-col items-center gap-1 flex-1">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    i < step ? 'bg-emerald-500 text-white' :
                    i === step ? 'bg-gold-gradient text-navy-900' :
                    'bg-white/10 text-cream-200/50'
                  }`}>
                    {i < step ? <Check className="w-4 h-4" /> : i + 1}
                  </div>
                  <span className={`text-[10px] font-cairo font-semibold hidden sm:block ${i <= step ? 'text-gold-300' : 'text-cream-200/40'}`}>
                    {s.title}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* محتوى الخطوة */}
          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              {/* ====== الخطوة 0: البيانات الأساسية ====== */}
              {step === 0 && (
                <motion.div key="s0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={User} title="البيانات الأساسية" desc="لنبدأ بمعلوماتك الأساسية" />

                  <Field label="الجنس" required error={errors.gender}>
                    <div className="grid grid-cols-2 gap-3">
                      <ChoiceCard
                        active={isMale}
                        onClick={() => { set('gender', 'male'); set('maritalStatus', ''); }}
                        icon={<div className={`w-14 h-14 rounded-full flex items-center justify-center ${isMale ? 'bg-blue-500' : 'bg-cream-100'}`}><Mars className={`w-7 h-7 ${isMale ? 'text-white' : 'text-navy-400'}`} /></div>}
                        title="ذكر"
                      />
                      <ChoiceCard
                        active={isFemale}
                        onClick={() => { set('gender', 'female'); set('maritalStatus', ''); }}
                        icon={<div className={`w-14 h-14 rounded-full flex items-center justify-center ${isFemale ? 'bg-rose-500' : 'bg-cream-100'}`}><Venus className={`w-7 h-7 ${isFemale ? 'text-white' : 'text-navy-400'}`} /></div>}
                        title="أنثى"
                      />
                    </div>
                  </Field>

                  {form.gender && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="space-y-5">
                      <Field label="الاسم المستعار" hint="اختياري — يظهر في ملفك العام. مثال: أبو محمد، المطيري، باحثة عن الستر">
                        <TextInput 
                          value={form.nickname} 
                          onChange={(v) => {
                            set('nickname', v);
                            // Auto translit for username if username is empty or matches previous auto-translit
                            const cleanedNick = v.trim();
                            if (cleanedNick) {
                              const translit = translitArabicToEnglish(cleanedNick);
                              set('username', translit);
                            }
                          }} 
                          placeholder={isMale ? 'مثال: القحطاني، أبو عبدالله' : 'مثال: باحثة عن الستر، أم محمد'} 
                        />
                      </Field>

                      <Field label="اسم المستخدم / اليوزر" required error={errors.username} hint="اسم مستخدم فريد ومميز بالإنجليزية لملفك الشخصي (مثال: abu_abdullah)">
                        <TextInput 
                          value={form.username} 
                          onChange={(v) => {
                            const cleaned = v.toLowerCase().replace(/[^a-z0-9_]/g, '');
                            set('username', cleaned);
                          }} 
                          placeholder="abu_abdullah" 
                        />
                      </Field>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="تاريخ الميلاد" required error={errors.birthDate} hint="اختر السنة ثم الشهر ثم اليوم">
                          <DateSelect value={form.birthDate} onChange={handleBirthDateChange} />
                        </Field>
                        <Field label="العمر (محسوب تلقائيًا)">
                          <div className="px-4 py-3 rounded-xl bg-gold-300/10 border-2 border-gold-300/40 flex items-center gap-2 h-full">
                            <span className="font-cairo font-extrabold text-2xl text-gradient-gold">
                              {form.age > 0 ? form.age : '—'}
                            </span>
                            {form.age > 0 && <span className="text-navy-500 font-tajawal">سنة</span>}
                          </div>
                        </Field>
                      </div>

                      <Field label="الدولة" required error={errors.country} hint="دولة الإقامة الحالية">
                        <SearchableSelect
                          value={form.country}
                          onChange={(v) => { set('country', v); set('city', ''); if (form.nationalityMode === 'same') set('nationality', v); }}
                          options={countryOptions}
                          placeholder="ابحث واختر الدولة"
                          searchPlaceholder="اكتب اسم الدولة..."
                        />
                      </Field>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="المدينة" required error={errors.city}>
                          <SearchableSelect
                            value={form.city}
                            onChange={(v) => set('city', v)}
                            options={cities}
                            placeholder={form.country ? 'ابحث واختر المدينة' : 'اختر الدولة أولًا'}
                            searchPlaceholder="اكتب اسم المدينة..."
                            disabled={!form.country}
                            allowAddNew={!!form.country}
                            onAddNew={handleAddCity(form.country)}
                            addNewLabel="لم تجد مدينتك؟ أضفها هنا"
                            addNewPlaceholder="اكتب اسم مدينتك..."
                          />
                        </Field>
                        <Field label="المنطقة / الولاية" required error={errors.district} hint="الحي أو المنطقة التفصيلية">
                          <TextInput value={form.district} onChange={(v) => set('district', v)} placeholder="حي العليا..." />
                        </Field>
                      </div>

                      <Field label="الجنسية" required error={errors.nationalityMode || errors.nationality} hint="هل جنسيتك نفس دولة الإقامة؟">
                        <div className="space-y-3">
                          <RadioGroup
                            options={[
                              { value: 'same', label: form.country ? `نعم، ${form.country}` : 'نعم، نفس دولة الإقامة' },
                              { value: 'other', label: 'لا، جنسية أخرى' },
                            ]}
                            value={form.nationalityMode}
                            onChange={(v) => {
                              set('nationalityMode', v);
                              if (v === 'same' && form.country) set('nationality', form.country);
                              else set('nationality', '');
                            }}
                            columns={2}
                          />
                          {form.nationalityMode === 'other' && (
                            <SearchableSelect
                              value={form.nationality}
                              onChange={(v) => set('nationality', v)}
                              options={countryOptions}
                              placeholder="ابحث عن الجنسية"
                              searchPlaceholder="اكتب اسم الدولة..."
                            />
                          )}
                        </div>
                      </Field>

                      {/* المذهب — مع خيار "أخرى" */}
                      <Field label="المذهب" required error={errors.sect} hint="المذهب الديني الذي تتبعه">
                        <SelectWithOther
                          value={form.sect}
                          otherValue={form.sectOther}
                          onChange={(v) => set('sect', v)}
                          onOtherChange={(v) => set('sectOther', v)}
                          options={C.SECTS}
                          placeholder="اختر المذهب"
                        />
                        {errors.sectOther && <p className="text-xs text-rose-deep font-tajawal mt-1">{errors.sectOther}</p>}
                      </Field>

                      {/* الحالة الاجتماعية */}
                      <Field label="الحالة الاجتماعية" required error={errors.maritalStatus}>
                        <RadioGroup
                          options={isMale ? C.MARITAL_MALE : C.MARITAL_FEMALE}
                          value={form.maritalStatus}
                          onChange={(v) => set('maritalStatus', v)}
                          columns={isMale ? 4 : 3}
                        />
                      </Field>

                      {/* حقول مطلقة/أرملة/أرمل — الأبناء */}
                      {['divorced', 'widower', 'widow'].includes(form.maritalStatus) && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
                          <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                            <User className="w-4 h-4 text-gold-600" /> معلومات الأبناء
                          </h4>
                          <Field label={isMale ? 'هل لديك أبناء؟' : 'هل لديكِ أبناء؟'}>
                            <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
                          </Field>
                          {form.hasChildren === 'yes' && (
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid sm:grid-cols-2 gap-4">
                              <Field label="عدد الأبناء">
                                <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={C.CHILDREN_COUNT} placeholder="اختر" />
                              </Field>
                              <Field label={isMale ? 'هل الأبناء يعيشون معك؟' : 'هل الأبناء يعيشون معكِ؟'}>
                                <RadioGroup options={C.YES_NO} value={form.childrenLiveWith} onChange={(v) => set('childrenLiveWith', v)} />
                              </Field>
                            </motion.div>
                          )}
                        </motion.div>
                      )}

                      {/* حقول متزوج (للرجال فقط) */}
                      {isMale && form.maritalStatus === 'married' && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
                          <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                            <User className="w-4 h-4 text-gold-600" /> تفاصيل الزواج
                          </h4>
                          <Field label="عدد الزوجات الحالي" required>
                            <RadioGroup options={C.WIFE_COUNT} value={form.wifeCount} onChange={(v) => set('wifeCount', v)} columns={3} />
                          </Field>
                          <Field label="هل لديك أبناء؟">
                            <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
                          </Field>
                          {form.hasChildren === 'yes' && (
                            <Field label="كم عدد الأبناء؟">
                              <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={C.CHILDREN_COUNT} placeholder="اختر" />
                            </Field>
                          )}
                          <Field label="هل تبحث عن زوجة أخرى؟">
                            <RadioGroup options={C.YES_NO} value={form.seekingWife} onChange={(v) => set('seekingWife', v)} />
                          </Field>
                        </motion.div>
                      )}
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* ====== الخطوة 1: المواصفات الشخصية ====== */}
              {step === 1 && (
                <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={FileText} title="المواصفات الشخصية" desc="أخبرنا عن مواصفاتك الشخصية" />

                  {/* الطول والوزن — اختيار قوائم منسدلة */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="الطول" required error={errors.height} hint="طولك بالسنتيمتر">
                      <SelectInput
                        value={form.height ? String(form.height) : ''}
                        onChange={(v) => set('height', Number(v))}
                        options={Array.from({ length: 91 }, (_, i) => {
                          const h = 130 + i;
                          return { value: String(h), label: `${h} سم` };
                        })}
                        placeholder="اختر الطول"
                      />
                    </Field>
                    <Field label="الوزن" required error={errors.weight} hint="وزنك بالكيلوغرام">
                      <SelectInput
                        value={form.weight ? String(form.weight) : ''}
                        onChange={(v) => set('weight', Number(v))}
                        options={Array.from({ length: 161 }, (_, i) => {
                          const w = 35 + i;
                          return { value: String(w), label: `${w} كجم` };
                        })}
                        placeholder="اختر الوزن"
                      />
                    </Field>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="لون البشرة" required error={errors.skinColor} hint="لون بشرتك الطبيعي">
                      <SelectInput value={form.skinColor} onChange={(v) => set('skinColor', v)} options={C.SKIN_COLORS} placeholder="اختر لون البشرة" />
                    </Field>
                    <Field label="العرق" required error={errors.ethnicity} hint="مثال: عربي، خليجي، قبلي، قبيلي، إلخ">
                      <TextInput value={form.ethnicity} onChange={(v) => set('ethnicity', v)} placeholder="اكتب العرق بالتفصيل..." />
                    </Field>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="الحالة الصحية" required error={errors.health} hint="مثال: ممتازة، جيدة، وضع صحي خاص">
                      <TextInput value={form.health} onChange={(v) => set('health', v)} placeholder="اكتب حالتك الصحية بالتفصيل..." />
                    </Field>
                    <Field label={isFemale ? 'هل تدخنين؟' : 'هل تدخن؟'} required error={errors.smoking} hint="عادتك في التدخين">
                      <SelectInput value={form.smoking} onChange={(v) => set('smoking', v)} options={C.SMOKING_OPTIONS} placeholder="اختر" />
                    </Field>
                  </div>

                  <Field label="المؤهل الدراسي" required error={errors.education} hint="أعلى مؤهل علمي حصلت عليه">
                    <SelectInput value={form.education} onChange={(v) => set('education', v)} options={C.EDUCATION_LEVELS} placeholder="اختر المؤهل" />
                  </Field>

                  <Field label="نوع جهة العمل" required error={errors.workType} hint="طبيعة عملك الحالي">
                    <RadioGroup
                      options={[
                        { value: 'حكومي', label: 'حكومي' },
                        { value: 'قطاع خاص', label: 'قطاع خاص' },
                        { value: 'عمل حر', label: 'عمل حر' },
                        { value: 'باحث عن عمل', label: 'باحث عن عمل' },
                        { value: 'طالب', label: 'طالب' },
                        { value: 'بدون عمل', label: 'بدون عمل' },
                      ]}
                      value={form.workType}
                      onChange={(v) => { set('workType', v); set('jobTitle', ''); }}
                      columns={3}
                    />
                  </Field>

                  {/* المسمى الوظيفي — يظهر فقط إذا اختار أي شيء غير "بدون عمل" */}
                  {form.workType && form.workType !== 'بدون عمل' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                      <Field label="المسمى الوظيفي" required error={errors.jobTitle} hint={`اكتب مسمى وظيفتك — مثال: ${form.workType === 'طالب' ? 'طالب جامعي، طالب ثانوي' : 'معلم، طبيب، مهندس، محاسب'}`}>
                        <TextInput value={form.jobTitle} onChange={(v) => set('jobTitle', v)} placeholder={form.workType === 'طالب' ? 'طالب جامعي...' : 'معلم، طبيب، مهندس...'} />
                      </Field>
                    </motion.div>
                  )}

                  <Field label="نوع السكن" required error={errors.housing} hint="وضعك السكني الحالي">
                    <SelectInput value={form.housing} onChange={(v) => set('housing', v)} options={C.HOUSING_TYPES} placeholder="اختر" />
                  </Field>

                  {/* حقول النساء فقط */}
                  {isFemale && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-rose-50 rounded-2xl p-4 border border-rose-200">
                      <h4 className="font-cairo font-bold text-rose-700 text-sm flex items-center gap-2">
                        <Heart className="w-4 h-4" /> خيارات خاصة
                      </h4>
                      <Field label="هل تقبلين التعدد؟">
                        <RadioGroup options={C.POLYGAMY_ACCEPT} value={form.acceptPolygamy} onChange={(v) => set('acceptPolygamy', v)} columns={1} />
                      </Field>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="هل تقبلين زوجًا مطلقًا؟">
                          <RadioGroup options={C.YES_NO} value={form.acceptDivorced} onChange={(v) => set('acceptDivorced', v)} />
                        </Field>
                        <Field label="هل تقبلين زوجًا لديه أبناء؟">
                          <RadioGroup options={C.YES_NO} value={form.acceptWithChildren} onChange={(v) => set('acceptWithChildren', v)} />
                        </Field>
                      </div>
                    </motion.div>
                  )}

                  <Field label="نبذة عني" required error={errors.bio} hint={`${form.bio.length}/500 حرف`}>
                    <TextArea value={form.bio} onChange={(v) => set('bio', v)} placeholder="اكتب نبذة قصيرة عن شخصيتك وأهدافك..." rows={4} />
                  </Field>
                </motion.div>
              )}

              {/* ====== الخطوة 2: مواصفات الشريك ====== */}
              {step === 2 && (
                <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={Heart} title="مواصفات الشريك المطلوب" desc={isMale ? 'صف الشريكة التي تبحث عنها' : 'صفي الشريك الذي تبحثين عنه'} />

                  {/* الترتيب الجديد: الدولة، المدينة، العمر، الجنسية أولًا */}
                  <Field label="الدولة المطلوبة" hint="دولة الشريك الذي تبحث عنه">
                    <SearchableSelect
                      value={form.pCountry}
                      onChange={(v) => { set('pCountry', v); set('pCity', ''); }}
                      options={countryOptions}
                      placeholder="اختر"
                      searchPlaceholder="اكتب اسم الدولة..."
                      includeNoPreference
                      noPreferenceLabel="لا يهم"
                    />
                  </Field>

                  {form.pCountry && form.pCountry !== 'لا يهم' && (
                    <Field label="المدينة المطلوبة" hint="مدينة الشريك المطلوب">
                      <SearchableSelect
                        value={form.pCity}
                        onChange={(v) => set('pCity', v)}
                        options={pCities}
                        placeholder="اختر"
                        searchPlaceholder="اكتب اسم المدينة..."
                        includeNoPreference
                        noPreferenceLabel="لا يهم"
                      />
                    </Field>
                  )}

                  <Field label="الجنسية المطلوبة" hint="جنسية الشريك المطلوب">
                    <SearchableSelect
                      value={form.pNationality}
                      onChange={(v) => set('pNationality', v)}
                      options={countryOptions}
                      placeholder="اختر"
                      searchPlaceholder="اكتب اسم الدولة..."
                      includeNoPreference
                      noPreferenceLabel="لا يهم"
                    />
                  </Field>

                  <Field label="العمر المطلوب" hint="نطاق العمر المناسب لك">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-xs text-navy-500 font-tajawal mb-1 block">من</span>
                        <RangeSlider value={form.pAgeMin} onChange={(v) => set('pAgeMin', Math.min(v, form.pAgeMax))} min={18} max={70} unit=" سنة" />
                      </div>
                      <div>
                        <span className="text-xs text-navy-500 font-tajawal mb-1 block">إلى</span>
                        <RangeSlider value={form.pAgeMax} onChange={(v) => set('pAgeMax', Math.max(v, form.pAgeMin))} min={18} max={70} unit=" سنة" />
                      </div>
                    </div>
                  </Field>

                  <Field label="الحالة الاجتماعية المقبولة" hint="حالة الشريك الاجتماعية">
                    <SelectInput value={form.pMaritalStatus} onChange={(v) => set('pMaritalStatus', v)} options={['لا يهم', 'أعزب/عزباء', 'مطلق/مطلقة', 'أرمل/أرملة']} placeholder="اختر" />
                  </Field>

                  {/* "تقبل الأولاد" يظهر فقط إذا لم يختر أعزب/عزباء */}
                  {form.pMaritalStatus !== 'أعزب/عزباء' && form.pMaritalStatus !== '' && form.pMaritalStatus !== 'لا يهم' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                      <Field label="هل تقبل وجود أطفال؟" hint="في حال كان الشريك لديه أبناء">
                        <RadioGroup options={C.YES_NO} value={form.pAcceptChildren} onChange={(v) => set('pAcceptChildren', v)} />
                      </Field>
                    </motion.div>
                  )}

                  <Field label="المذهب المطلوب" hint="مذهب الشريك المطلوب">
                    <SelectWithOther
                      value={form.pSect}
                      otherValue={form.pSectOther}
                      onChange={(v) => set('pSect', v)}
                      onOtherChange={(v) => set('pSectOther', v)}
                      options={['لا يهم', ...C.SECTS.filter((s) => s !== 'أخرى')]}
                      placeholder="اختر"
                    />
                  </Field>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="مستوى التدين" hint="مستوى الالتزام الديني">
                      <SelectInput value={form.pReligionLevel} onChange={(v) => set('pReligionLevel', v)} options={['لا يهم', ...C.RELIGION_LEVELS]} placeholder="اختر" />
                    </Field>
                    <Field label="لون البشرة المطلوب" hint="لون بشرة الشريك">
                      <SelectInput value={form.pSkinColor} onChange={(v) => set('pSkinColor', v)} options={['لا يهم', ...C.SKIN_COLORS]} placeholder="اختر" />
                    </Field>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="المؤهل الدراسي المطلوب" hint="مستوى التعليم">
                      <SelectInput value={form.pEducation} onChange={(v) => set('pEducation', v)} options={['لا يهم', ...C.EDUCATION_LEVELS]} placeholder="اختر" />
                    </Field>
                    <Field label="نوع الوظيفة المطلوبة" hint="طبيعة عمل الشريك">
                      <SelectInput value={form.pWorkType} onChange={(v) => set('pWorkType', v)} options={['لا يهم', 'حكومي', 'قطاع خاص', 'عمل حر', 'طالب', 'بدون عمل']} placeholder="اختر" />
                    </Field>
                  </div>

                  <Field label="الطول المطلوب" hint="طول الشريك المناسب لك">
                    {form.pHeightNoMatter ? (
                      <div className="px-4 py-3 rounded-xl bg-cream-100 text-navy-500 font-tajawal text-center">لا يهم</div>
                    ) : (
                      <RangeSlider value={form.pHeight} onChange={(v) => set('pHeight', v)} min={140} max={250} unit=" سم" />
                    )}
                    <label className="flex items-center gap-2 mt-2 cursor-pointer">
                      <input type="checkbox" checked={form.pHeightNoMatter} onChange={(e) => set('pHeightNoMatter', e.target.checked)} className="w-4 h-4 rounded accent-gold-500" />
                      <span className="text-sm text-navy-600 font-tajawal">لا يهم</span>
                    </label>
                  </Field>

                  <Field label="نوع السكن المطلوب" hint="وضع الشريك السكني">
                    <SelectInput value={form.pHousing} onChange={(v) => set('pHousing', v)} options={['لا يهم', ...C.HOUSING_TYPES]} placeholder="اختر" />
                  </Field>

                  <Field label="ملاحظات إضافية" hint="أي تفاصيل أخرى عن الشريك المطلوب">
                    <TextArea value={form.pNotes} onChange={(v) => set('pNotes', v)} placeholder="اكتب أي ملاحظات إضافية..." rows={3} />
                  </Field>
                </motion.div>
              )}

              {/* ====== الخطوة 3: بيانات الحساب (للإدارة فقط) ====== */}
              {step === 3 && (
                <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={ShieldCheck} title="بيانات الحساب" desc="بيانات التواصل وكلمة المرور لحسابك" />

                  <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
                    <Lock className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-cairo font-bold text-navy-900 text-sm">بيانات سرية بالكامل</h4>
                      <p className="text-xs text-navy-600 font-tajawal mt-1 leading-relaxed">
                        هذه البيانات محمية ولا تظهر لأي عضو أو زائر. تستخدمها الإدارة للتواصل معك بخصوص طلبات التواصل والزواج فقط.
                      </p>
                    </div>
                  </div>

                  <Field label="الاسم الرباعي الحقيقي" required error={errors.realName} hint="اسمك الكامل — سري ولا يظهر لأحد">
                    <TextInput value={form.realName} onChange={(v) => set('realName', v)} placeholder="الاسم الكامل" />
                  </Field>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="رقم الهاتف" required error={errors.phone} hint="رقمك للتواصل — سري">
                      <TextInput value={form.phone} onChange={(v) => set('phone', v)} placeholder="05xxxxxxxx" type="tel" />
                    </Field>
                    <Field label="رقم الواتساب" hint="اختياري — للتواصل السريع">
                      <TextInput value={form.whatsapp} onChange={(v) => set('whatsapp', v)} placeholder="05xxxxxxxx" type="tel" />
                    </Field>
                  </div>

                  <Field label="البريد الإلكتروني" required error={errors.email} hint="لتسجيل الدخول واستقبال الإشعارات">
                    <TextInput value={form.email} onChange={(v) => set('email', v)} placeholder="example@email.com" type="email" />
                  </Field>

                  {/* كلمة المرور وتأكيدها */}
                  <div className="pt-2 border-t border-cream-200">
                    <h4 className="font-cairo font-bold text-navy-900 text-sm mb-4 flex items-center gap-2">
                      <Lock className="w-4 h-4 text-gold-600" /> كلمة المرور
                    </h4>
                    <div className="space-y-4">
                      <Field label="كلمة المرور" required error={errors.password} hint="6 أحرف على الأقل">
                        <div className="relative">
                          <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                          <input
                            type={showPass ? 'text' : 'password'}
                            value={form.password}
                            onChange={(e) => set('password', e.target.value)}
                            placeholder="••••••••"
                            className="w-full pr-12 pl-12 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors"
                          />
                          <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                            {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </Field>

                      <Field label="تأكيد كلمة المرور" required error={errors.passwordConfirm}>
                        <div className="relative">
                          <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                          <input
                            type={showPassConfirm ? 'text' : 'password'}
                            value={form.passwordConfirm}
                            onChange={(e) => set('passwordConfirm', e.target.value)}
                            placeholder="••••••••"
                            className="w-full pr-12 pl-12 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors"
                          />
                          <button type="button" onClick={() => setShowPassConfirm(!showPassConfirm)} className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                            {showPassConfirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </Field>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* أزرار التنقل */}
            <div className="flex items-center gap-3 mt-7">
              {step > 0 && (
                <button onClick={() => { setStep(step - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="flex items-center gap-1 px-5 py-3 rounded-2xl text-navy-600 font-cairo font-semibold hover:bg-cream-100 transition-colors">
                  <ArrowRight className="w-4 h-4" /> السابق
                </button>
              )}
              {step < STEPS.length - 1 ? (
                <Button onClick={handleNext} fullWidth size="lg">
                  التالي <ArrowLeft className="w-4 h-4" />
                </Button>
              ) : (
                <Button onClick={handleNext} fullWidth size="lg" className="shadow-gold">
                  <Check className="w-5 h-5" /> إكمال التسجيل
                </Button>
              )}
            </div>

            {step === 0 && (
              <p className="text-center text-sm text-navy-500 font-tajawal mt-5">
                لديك حساب؟ <Link to="/login" className="text-gold-700 font-cairo font-bold hover:underline">سجّل الدخول</Link>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ icon: Icon, title, desc }: { icon: typeof User; title: string; desc: string }) {
  return (
    <div className="flex items-center gap-3 pb-4 border-b border-cream-200">
      <div className="w-11 h-11 rounded-xl bg-gold-300/15 flex items-center justify-center flex-shrink-0">
        <Icon className="w-6 h-6 text-gold-600" />
      </div>
      <div>
        <h2 className="font-cairo font-bold text-xl text-navy-900">{title}</h2>
        <p className="text-sm text-navy-500 font-tajawal">{desc}</p>
      </div>
    </div>
  );
}

function translitArabicToEnglish(text: string): string {
  if (!text) return '';
  const arabicToEnglish: Record<string, string> = {
    'أ': 'a', 'إ': 'a', 'آ': 'a', 'ا': 'a',
    'ب': 'b',
    'ت': 't',
    'ث': 'th',
    'ج': 'j',
    'ح': 'h',
    'خ': 'kh',
    'د': 'd',
    'ذ': 'dh',
    'ر': 'r',
    'ز': 'z',
    'س': 's',
    'ش': 'sh',
    'ص': 's',
    'ض': 'd',
    'ط': 't',
    'ظ': 'z',
    'ع': 'a',
    'غ': 'gh',
    'ف': 'f',
    'ق': 'q',
    'ك': 'k',
    'ل': 'l',
    'م': 'm',
    'ن': 'n',
    'ه': 'h',
    'و': 'w',
    'ي': 'y', 'ى': 'a', 'ئ': 'e', 'ؤ': 'o', 'ء': 'a', 'ة': 'h'
  };

  let result = '';
  const lowerText = text.trim().toLowerCase();
  for (let i = 0; i < lowerText.length; i++) {
    const char = lowerText[i];
    if (arabicToEnglish[char] !== undefined) {
      result += arabicToEnglish[char];
    } else if (/[a-z0-9]/.test(char)) {
      result += char;
    } else if (char === ' ' || char === '_' || char === '-') {
      result += '_';
    }
  }
  return result.replace(/_+/g, '_').replace(/^_+|_+$/g, '');
}
