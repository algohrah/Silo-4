import { useState, useEffect, useRef, ReactNode, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MapPin, Briefcase, GraduationCap, Ruler, Heart, Bookmark,
  ShieldCheck, Calendar, Users, Globe, Send, ArrowRight,
  Home, Scale, Cigarette, Weight, Palette, Sparkles, AlertTriangle,
  FileText, User, Copy, MessageCircle, Share2, Clock,
  Crown, Check, ChevronDown, ChevronUp, Star, Zap, Eye, EyeOff,
  TrendingUp, Award, BadgeCheck, Lock, Baby, Building2, Church,
  Dumbbell, Stethoscope, TreePine,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import { getMemberById } from '../lib/data';
import { useApp } from '../lib/AppContext';
import { getAvatar, getGenderColors } from '../lib/types';
import { getCompatBadgeColor, getCompatLabel } from '../lib/compatibility';
import { getCurrentUserId, createInterestRequest, useInterestRequests } from '../lib/useInterestRequests';

const MESSAGE_TEMPLATES = [
  'السلام عليكم ورحمة الله، لفت انتباهي توافق ملفنا وأتمنى التوفيق لنا.',
  'مرحبًا، أرى توافقًا في القيم والأهداف وأرغب بالتوافق الجاد للزواج بإذن الله.',
  'السلام عليكم، ملفك أعجبني وأبحث عن شريك بصفات مشابهة، أتمنى التواصل.',
  'تحية طيبة، لاحظت توافقًا في المواصفات وأرغب في التقدم عبر الإدارة.',
];

// ===== Collapsible Section Component =====
function CollapsibleSection({
  title, icon: Icon, gradient, children, defaultOpen = true, badge,
}: {
  title: string;
  icon: any;
  gradient: string;
  children: ReactNode;
  defaultOpen?: boolean;
  badge?: string;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 overflow-hidden transition-all duration-300">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-4 hover:bg-slate-50/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-sm`}>
            <Icon className="w-4.5 h-4.5 text-white" />
          </div>
          <h3 className="font-cairo font-bold text-navy-900 text-sm">{title}</h3>
          {badge && (
            <span className="text-[10px] font-cairo font-bold bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">{badge}</span>
          )}
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown className="w-5 h-5 text-slate-400" />
        </motion.div>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-slate-100">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ===== Info Grid Item =====
function InfoItem({ icon: Icon, label, value, color = 'slate' }: {
  icon: any; label: string; value: string | number | undefined | null; color?: string;
}) {
  if (!value && value !== 0) return null;
  const colorMap: Record<string, string> = {
    slate: 'from-slate-500 to-slate-600',
    blue: 'from-blue-500 to-indigo-600',
    emerald: 'from-emerald-500 to-teal-600',
    purple: 'from-purple-500 to-violet-600',
    rose: 'from-rose-500 to-pink-600',
    amber: 'from-amber-500 to-orange-600',
    navy: 'from-slate-700 to-slate-800',
  };
  return (
    <div className="group flex items-center gap-2.5 bg-slate-50/80 rounded-xl px-3 py-2.5 border border-slate-100 hover:border-slate-200 hover:shadow-sm transition-all">
      <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${colorMap[color] || colorMap.slate} flex items-center justify-center flex-shrink-0 opacity-80 group-hover:opacity-100 transition-opacity`}>
        <Icon className="w-3.5 h-3.5 text-white" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] text-slate-400 font-tajawal leading-none mb-0.5">{label}</p>
        <p className="font-cairo font-bold text-navy-900 text-xs truncate">{value}</p>
      </div>
    </div>
  );
}

export default function MemberProfile() {
  const { id, username } = useParams();
  const navigate = useNavigate();
  const {
    likedMembers, toggleLike, user, showToast, checkLimit, incrementUsage,
    sendInterestRequest, calculateCompatDetailed, interestPurchaseSettings,
    buyExtraInterests, submitReport, members,
  } = useApp();

  const member = useMemo(() => {
    const key = id || username;
    if (!key) return undefined;
    const found = members.find((m) => m.id === key || m.username?.toLowerCase() === key.toLowerCase());
    if (found) return found;
    const staticFound = getMemberById(key);
    if (staticFound) return staticFound;
    return members.find((m) => m.username?.toLowerCase() === key.toLowerCase());
  }, [id, username, members]);

  const [contactOpen, setContactOpen] = useState(false);
  const [contactMsg, setContactMsg] = useState('');
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const [showAllBasic, setShowAllBasic] = useState(true);
  const [showAllPersonal, setShowAllPersonal] = useState(true);
  const [showAllWork, setShowAllWork] = useState(true);
  const [showAllPartner, setShowAllPartner] = useState(true);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 200);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  if (!member) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mb-4">
          <User className="w-10 h-10 text-slate-300" />
        </div>
        <h2 className="font-cairo font-bold text-2xl text-navy-900 mb-2">العضو غير موجود</h2>
        <p className="text-slate-500 font-tajawal mb-4">قد يكون الحساب محذوفاً أو غير متاح</p>
        <Button onClick={() => navigate('/search')} className="mt-2">العودة للبحث</Button>
      </div>
    );
  }

  const liked = likedMembers.has(member.id);
  const isSelf = member.id === (user?.memberId || getCurrentUserId());
  
  const currentUserId = getCurrentUserId();
  const { requests } = useInterestRequests(currentUserId);

  const latestRequest = useMemo(() => {
    if (!requests || requests.length === 0 || !member?.id) return null;
    const sent = requests.filter(r => r.sender_id === currentUserId && r.receiver_id === member.id);
    if (sent.length === 0) return null;
    return [...sent].sort((a, b) => b.id - a.id)[0];
  }, [requests, currentUserId, member?.id]);

  const avatar = getAvatar(member.gender);
  const isMale = member.gender === 'male';
  const compat = calculateCompatDetailed(member);
  const compatScore = compat.score;
  const badge = getCompatBadgeColor(compatScore, compat.isGenderMatch);
  const compatLabel = getCompatLabel(compatScore, compat.isGenderMatch);
  const whyMatches = compat.reasons;
  const limitCheck = checkLimit('message');
  const remainingRequests = limitCheck.allowed ? limitCheck.max - limitCheck.current : 0;

  const accentGradient = isMale ? 'from-blue-500 to-indigo-600' : 'from-rose-500 to-pink-600';
  const heroGradient = isMale ? 'from-slate-800 via-blue-900 to-indigo-900' : 'from-slate-800 via-rose-900 to-pink-900';

  const handleCopyLink = () => {
    const profileUrl = member.username 
      ? `${window.location.origin}/u/${member.username}` 
      : `${window.location.origin}/member/${member.id}`;
      
    navigator.clipboard.writeText(profileUrl)
      .then(() => showToast('تم نسخ رابط الملف الشخصي ✓', 'success'))
      .catch(() => showToast('تعذّر النسخ', 'error'));
  };

  const handleShareWhatsApp = () => {
    const profileUrl = member.username 
      ? `${window.location.origin}/u/${member.username}` 
      : `${window.location.origin}/member/${member.id}`;
    const text = `مرحبًا، وجدت هذا الملف على منصة توافق: ${profileUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const radius = 28;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (compatScore / 100) * circumference;

  return (
    <div className="bg-gradient-to-b from-slate-50 to-white min-h-screen pb-24">
      {/* ═══════════ HERO HEADER ═══════════ */}
      <div className="relative overflow-hidden bg-[#f0f6fc] border-b border-slate-200/60 rounded-b-3xl">
        {/* Decorative shapes */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-500 rounded-full -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500 rounded-full translate-y-1/2 -translate-x-1/4" />
        </div>

        {/* Top bar */}
        <div className="relative z-10 flex items-center justify-between px-4 sm:px-6 pt-4">
          <button onClick={() => navigate(-1)} className="h-9 w-9 rounded-xl bg-white flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-all border border-slate-200 shadow-sm" title="رجوع">
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <button onClick={handleShareWhatsApp} className="h-9 w-9 rounded-xl bg-white flex items-center justify-center text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 transition-all border border-slate-200 shadow-sm" title="مشاركة واتساب">
              <Share2 className="w-4 h-4" />
            </button>
            <button onClick={handleCopyLink} className="h-9 w-9 rounded-xl bg-white flex items-center justify-center text-slate-600 hover:bg-slate-100 transition-all border border-slate-200 shadow-sm" title="نسخ الرابط">
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Main hero content */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 pt-4 pb-6">
          <div className="flex items-center justify-between gap-4 w-full">
            {/* Right side: Avatar */}
            <div className="relative flex-shrink-0">
              <div className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-0.5 border-2 ${isMale ? 'border-blue-500/60' : 'border-rose-500/60'} shadow-sm`}>
                <div className="w-full h-full rounded-[12px] bg-white flex items-center justify-center overflow-hidden">
                  <img src={avatar} alt="" className="w-full h-full object-contain p-2" />
                </div>
              </div>
              {member.online && (
                <span className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white animate-pulse" />
              )}
              {member.verified && (
                <span className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-emerald-500 ring-2 ring-white flex items-center justify-center shadow-sm">
                  <ShieldCheck className="w-3.5 h-3.5 text-white" />
                </span>
              )}
            </div>

            {/* Center: Name + Info */}
            <div className="flex-1 min-w-0 text-right space-y-1.5">
              <div className="flex items-center gap-2 justify-start mb-1 flex-wrap">
                <h1 className="font-cairo font-extrabold text-lg sm:text-2xl text-slate-900 leading-none">{member.nickname}</h1>
                {(member.plan === 'elite' || (member.premium && member.plan !== 'gold')) && (
                  <span className="inline-flex items-center justify-center gap-1 px-2 py-0.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 shadow-sm font-cairo font-extrabold text-[10px] sm:text-xs" title="الباقة المميزة">
                    <span>⭐ مميز</span>
                  </span>
                )}
                {member.plan === 'gold' && (
                  <span className="inline-flex items-center justify-center gap-1 px-2 py-0.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 shadow-sm font-cairo font-extrabold text-[10px] sm:text-xs" title="الباقة الذهبية">
                    <Crown className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span>ذهبي</span>
                  </span>
                )}
              </div>

              {member.username && (
                <div className="text-xs text-slate-500 font-mono tracking-wide select-all pb-1 flex items-center gap-1 justify-start" dir="ltr">
                  <span className="text-slate-400">@</span>
                  <span className="font-semibold text-slate-600">{member.username}</span>
                </div>
              )}

              {/* Badges */}
              <div className="flex items-center gap-1.5 justify-start flex-wrap">
                <span className="inline-flex items-center px-2 py-0.5 rounded-lg bg-blue-600 text-white text-[11px] font-cairo font-bold">
                  {isMale ? 'رجل' : 'امرأة'}
                </span>
                {member.verified && (
                  <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-lg text-[11px] font-cairo font-bold">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" /> موثّق
                  </span>
                )}
                {member.hasSeriousnessBadge && (
                  <span className="inline-flex items-center gap-1 bg-gradient-to-l from-amber-500 to-orange-500 text-white px-2 py-0.5 rounded-lg text-[11px] font-cairo font-bold shadow-sm">
                    🏅 جاد
                  </span>
                )}
              </div>

              {/* Details */}
              <div className="flex items-center gap-2 sm:gap-3.5 justify-start flex-wrap text-slate-600 text-[11px] sm:text-xs font-tajawal">
                <span className="flex items-center gap-1 text-slate-700"><Calendar className="w-3.5 h-3.5 text-slate-400" />{member.age} سنة</span>
                <span className="flex items-center gap-1 text-slate-700"><MapPin className="w-3.5 h-3.5 text-slate-400" />{member.city}</span>
                <span className="flex items-center gap-1 text-slate-700"><Briefcase className="w-3.5 h-3.5 text-slate-400" />{member.jobTitle}</span>
              </div>

              {/* Status */}
              <div className="flex items-center gap-1 justify-start text-[11px] sm:text-xs text-slate-500 font-tajawal">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{member.online ? 'متصل الآن' : member.lastActive || 'غير متصل'}</span>
              </div>
            </div>


          </div>
        </div>
      </div>

      {/* ═══════════ ACTION BUTTONS BAR ═══════════ */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 -mt-5 relative z-20">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl shadow-md border border-slate-100 p-4 flex flex-col gap-3"
        >
          {!isSelf ? (
            <div className="flex flex-col gap-2 w-full">
              {/* Primary: Request */}
              {latestRequest ? (
                latestRequest.journey_stage === 'declined' || latestRequest.journey_stage === 'cancelled' ? (
                  <button
                    onClick={() => (user.isLoggedIn ? setContactOpen(true) : navigate('/login'))}
                    className="w-full flex items-center justify-center gap-2 py-3.5 px-5 rounded-2xl bg-gradient-to-r from-[#ca9d42] to-[#b3852b] text-white font-cairo font-extrabold text-sm sm:text-base shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all"
                  >
                    <span>أرسل طلب اهتمام جديد</span>
                    <Send className="w-4 h-4 -scale-x-100" />
                  </button>
                ) : (
                  <button
                    onClick={() => navigate(`/journey/${latestRequest.id}`)}
                    className="w-full flex items-center justify-center gap-2 py-3.5 px-5 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-cairo font-extrabold text-sm sm:text-base shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all"
                  >
                    <span>
                      {latestRequest.journey_stage === 'sent' 
                        ? 'طلبك في انتظار الرد (متابعة)' 
                        : 'متابعة الرحلة'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )
              ) : (
                <button
                  onClick={() => (user.isLoggedIn ? setContactOpen(true) : navigate('/login'))}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-5 rounded-2xl bg-gradient-to-r from-[#ca9d42] to-[#b3852b] text-white font-cairo font-extrabold text-sm sm:text-base shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all"
                >
                  <span>أرسل طلب اهتمام</span>
                  <Send className="w-4 h-4 -scale-x-100" />
                </button>
              )}

              {/* Secondary Action Buttons */}
              <div className="grid grid-cols-2 gap-2 w-full">
                {/* Save (First in RTL: shows on right visually) */}
                <button
                  onClick={() => toggleLike(member.id)}
                  className={`flex items-center justify-center h-12 rounded-2xl border transition-all duration-300 gap-1.5 font-cairo font-bold text-xs ${
                    liked
                      ? 'bg-amber-500 border-amber-500 text-white shadow-md shadow-amber-500/30'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Bookmark className={`w-4 h-4 ${liked ? 'fill-white' : ''}`} />
                  <span>{liked ? 'تم حفظ الملف' : 'حفظ الملف'}</span>
                </button>

                {/* Report (Second in RTL: shows on left visually) */}
                <button
                  onClick={() => user.isLoggedIn ? setReportOpen(true) : navigate('/login')}
                  className="flex items-center justify-center h-12 rounded-2xl border border-red-100 bg-red-50/20 text-red-600 hover:bg-red-50 hover:text-red-700 transition-all font-cairo font-bold text-xs gap-1.5"
                >
                  <AlertTriangle className="w-4 h-4" />
                  <span>إبلاغ عن العضو</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex-1 text-center py-2">
              <p className="font-cairo font-bold text-slate-700 text-sm flex items-center justify-center gap-2">
                <User className="w-4 h-4" /> هذا حسابك — يمكنك <button onClick={() => navigate('/profile/edit')} className="text-blue-600 underline">تعديل ملفك</button>
              </p>
            </div>
          )}
        </motion.div>
      </div>

      {/* ═══════════ MAIN CONTENT ═══════════ */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 mt-6 grid lg:grid-cols-3 gap-5">
        {/* LEFT COLUMN */}
        <div className="lg:col-span-2 space-y-4">

          {/* ── Bio Section ── */}
          <CollapsibleSection title="نبذة عني" icon={FileText} gradient="from-blue-500 to-indigo-600" defaultOpen={true}>
            <p className="text-slate-700 font-tajawal leading-[1.9] text-sm pt-3">{member.bio}</p>
          </CollapsibleSection>

          {/* ── Partner Section ── */}
          <CollapsibleSection title="أبحث عن" icon={Heart} gradient="from-rose-500 to-pink-600" defaultOpen={true}>
            <p className="text-slate-700 font-tajawal leading-[1.9] text-sm pt-3">{member.aboutPartner}</p>
          </CollapsibleSection>

          {/* ── Basic Info Grid ── */}
          <CollapsibleSection title="المعلومات الأساسية" icon={User} gradient="from-blue-500 to-indigo-600" defaultOpen={true} badge="7 حقول">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-3">
              <InfoItem icon={Calendar} label="العمر" value={`${member.age} سنة`} color="blue" />
              <InfoItem icon={Heart} label="الحالة الاجتماعية" value={member.maritalLabel} color="rose" />
              <InfoItem icon={MapPin} label="المدينة" value={member.city} color="emerald" />
              <InfoItem icon={MapPin} label="المنطقة" value={member.district} color="emerald" />
              <InfoItem icon={Globe} label="الدولة" value={member.country} color="blue" />
              <InfoItem icon={Globe} label="الجنسية" value={member.nationality} color="navy" />
              <InfoItem icon={Church} label="المذهب" value={member.sect} color="amber" />
            </div>
          </CollapsibleSection>

          {/* ── Personal Traits Grid ── */}
          <CollapsibleSection title="الصفات الشخصية" icon={Ruler} gradient="from-emerald-500 to-teal-600" defaultOpen={true} badge="6 حقول">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-3">
              <InfoItem icon={Ruler} label="الطول" value={`${member.height} سم`} color="emerald" />
              <InfoItem icon={Weight} label="الوزن" value={`${member.weight} كجم`} color="blue" />
              <InfoItem icon={Palette} label="لون البشرة" value={member.skinColor} color="amber" />
              <InfoItem icon={Stethoscope} label="الحالة الصحية" value={member.health} color="emerald" />
              <InfoItem icon={Cigarette} label="التدخين" value={member.smoking} color="slate" />
              {member.hasChildren && (
                <InfoItem icon={Baby} label="الأبناء" value={member.childrenCount} color="rose" />
              )}
              <InfoItem icon={Users} label="لديه أبناء" value={member.hasChildren ? 'نعم' : 'لا'} color="purple" />
              {member.ethnicity && (
                <InfoItem icon={Globe} label="العرق" value={member.ethnicity} color="navy" />
              )}
            </div>
          </CollapsibleSection>

          {/* ── Education & Work Grid ── */}
          <CollapsibleSection title="التعليم والعمل" icon={GraduationCap} gradient="from-purple-500 to-violet-600" defaultOpen={true} badge="4 حقول">
            <div className="grid grid-cols-2 gap-2 pt-3">
              <InfoItem icon={GraduationCap} label="المؤهل العلمي" value={member.education} color="purple" />
              <InfoItem icon={Briefcase} label="نوع العمل" value={member.workType} color="blue" />
              <InfoItem icon={Building2} label="المسمى الوظيفي" value={member.jobTitle} color="navy" />
              <InfoItem icon={Home} label="نوع السكن" value={member.housing} color="emerald" />
            </div>
          </CollapsibleSection>

          {/* ── Why Matches ── */}
          {compat.isGenderMatch && whyMatches.length > 0 && (
            <CollapsibleSection title="لماذا يناسبك؟" icon={Sparkles} gradient="from-emerald-500 to-teal-600" defaultOpen={true} badge={`${whyMatches.length} نقاط`}>
              <div className="grid sm:grid-cols-2 gap-2 pt-3">
                {whyMatches.map((reason, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-100"
                  >
                    <div className="w-6 h-6 rounded-lg bg-emerald-500 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3.5 h-3.5 text-white" />
                    </div>
                    <span className="text-xs font-cairo font-semibold text-emerald-800">{reason}</span>
                  </motion.div>
                ))}
              </div>
            </CollapsibleSection>
          )}

          {/* Mediation notice */}
          <div className="bg-gradient-to-l from-amber-50 to-yellow-50/50 rounded-2xl p-4 border border-amber-200/60 flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-cairo font-bold text-slate-900 text-sm mb-1">وساطة احترافية</h3>
              <p className="text-xs text-slate-600 font-tajawal leading-relaxed">
                التواصل يتم حصريًا عبر فريق الإدارة لضمان الخصوصية والجدية. عند إرسال طلب اهتمام، ستتولى الإدارة التنسيق بين الطرفين.
              </p>
            </div>
          </div>
        </div>

        {/* RIGHT SIDEBAR */}
        <div className="space-y-4">



          {/* Status card */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 overflow-hidden">
            <div className="h-1 bg-gradient-to-l from-slate-700 to-slate-900" />
            <div className="p-4">
              <h3 className="font-cairo font-bold text-slate-900 text-sm mb-3 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" /> حالة العضو
              </h3>
              <div className="space-y-2.5">
                {[
                  { icon: ShieldCheck, iconColor: 'text-emerald-500', label: 'التوثيق', value: member.verified ? 'موثّق ✓' : 'غير موثّق', valueColor: member.verified ? 'text-emerald-600' : 'text-slate-400' },
                  { 
                    icon: Crown, 
                    iconColor: member.plan === 'elite' ? 'text-rose-500' : member.plan === 'gold' ? 'text-amber-500' : 'text-slate-400', 
                    label: 'العضوية', 
                    value: member.plan === 'elite' ? 'باقة مميزة ⭐' : member.plan === 'gold' ? 'باقة ذهبية 👑' : 'باقة مجانية', 
                    valueColor: member.plan === 'elite' ? 'text-rose-600 font-extrabold' : member.plan === 'gold' ? 'text-amber-600 font-extrabold' : 'text-slate-400' 
                  },
                  { icon: Clock, iconColor: 'text-blue-500', label: 'النشاط', value: member.online ? 'متصل الآن' : member.lastActive, valueColor: member.online ? 'text-emerald-600' : 'text-slate-400' },
                  { icon: User, iconColor: 'text-purple-500', label: 'الجنس', value: isMale ? 'رجل' : 'امرأة', valueColor: 'text-slate-700' },
                  { icon: Scale, iconColor: 'text-amber-500', label: 'المذهب', value: member.sect, valueColor: 'text-slate-700' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between py-1.5 border-b border-slate-100 last:border-0">
                    <span className="text-[11px] text-slate-500 font-tajawal flex items-center gap-2">
                      <item.icon className={`w-3.5 h-3.5 ${item.iconColor}`} />
                      {item.label}
                    </span>
                    <span className={`text-[11px] font-cairo font-bold ${item.valueColor}`}>{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Privacy */}
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-4 text-white">
            <div className="flex items-center gap-2 mb-2.5">
              <Lock className="w-5 h-5 text-amber-400" />
              <h3 className="font-cairo font-bold text-sm">خصوصية تامة</h3>
            </div>
            <p className="text-xs font-tajawal leading-relaxed text-slate-300">
              لا تظهر معلومات التواصل للأعضاء. عبر <strong className="text-amber-400">«طلب اهتمام»</strong> تتولى الإدارة التواصل مع الطرف الآخر بسرية كاملة.
            </p>
            <div className="mt-3 pt-3 border-t border-white/10">
              <p className="text-[10px] text-slate-400 font-tajawal flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                لا تشارك معلوماتك المالية مع أي طرف
              </p>
            </div>
          </div>

          {/* Share */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-4">
            <h3 className="font-cairo font-bold text-slate-900 text-sm mb-3 flex items-center gap-2">
              <Share2 className="w-4 h-4 text-amber-500" /> مشاركة الملف
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={handleShareWhatsApp} className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-50 text-emerald-600 font-cairo font-semibold text-xs hover:bg-emerald-100 transition-colors">
                <MessageCircle className="w-4 h-4" /> واتساب
              </button>
              <button onClick={handleCopyLink} className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-100 text-slate-600 font-cairo font-semibold text-xs hover:bg-slate-200 transition-colors">
                <Copy className="w-4 h-4" /> نسخ الرابط
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════ STICKY BOTTOM BAR (on scroll) ═══════════ */}
      <AnimatePresence>
        {scrolled && !isSelf && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed bottom-0 left-0 right-0 z-50"
          >
            <div className="bg-white/95 backdrop-blur-xl border-t border-slate-200 shadow-[0_-4px_30px_rgba(0,0,0,0.08)]">
              <div className="max-w-5xl mx-auto px-4 py-2.5 flex items-center justify-between gap-4 w-full" dir="rtl">
                <div className="flex items-center gap-2 flex-shrink-0 text-right">
                  <div>
                    <p className="font-cairo font-bold text-slate-900 text-sm leading-tight">{member.nickname}</p>
                    <p className="text-[10px] text-slate-400 font-tajawal">{member.age} سنة · {member.city}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {/* 1. طلب اهتمام (Interest) */}
                  {latestRequest ? (
                    latestRequest.journey_stage === 'declined' || latestRequest.journey_stage === 'cancelled' ? (
                      <button
                        onClick={() => (user.isLoggedIn ? setContactOpen(true) : navigate('/login'))}
                        className={`flex items-center justify-center gap-2 py-2 px-4 sm:px-6 rounded-xl text-white font-cairo font-bold text-xs sm:text-sm shadow-sm hover:shadow hover:-translate-y-0.5 transition-all duration-200 ${
                          isMale 
                            ? 'bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600' 
                            : 'bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-500'
                        }`}
                      >
                        <Send className="w-3.5 h-3.5 -scale-x-100" />
                        <span>أرسل اهتمام جديد</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => navigate(`/journey/${latestRequest.id}`)}
                        className="flex items-center justify-center gap-2 py-2 px-4 sm:px-6 rounded-xl text-white font-cairo font-bold text-xs sm:text-sm shadow-sm hover:shadow hover:-translate-y-0.5 transition-all duration-200 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                        <span>
                          {latestRequest.journey_stage === 'sent' 
                            ? 'في انتظار الرد' 
                            : 'متابعة الرحلة'}
                        </span>
                      </button>
                    )
                  ) : (
                    <button
                      onClick={() => (user.isLoggedIn ? setContactOpen(true) : navigate('/login'))}
                      className={`flex items-center justify-center gap-2 py-2 px-4 sm:px-6 rounded-xl text-white font-cairo font-bold text-xs sm:text-sm shadow-sm hover:shadow hover:-translate-y-0.5 transition-all duration-200 ${
                        isMale 
                          ? 'bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600' 
                          : 'bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-500'
                      }`}
                    >
                      <Send className="w-3.5 h-3.5 -scale-x-100" />
                      <span>أرسل اهتمام</span>
                    </button>
                  )}

                  {/* 2. حفظ (Save) */}
                  <button
                    onClick={() => toggleLike(member.id)}
                    className={`h-10 rounded-xl px-4 flex items-center justify-center gap-1.5 transition-all font-cairo font-bold text-xs ${
                      liked ? 'bg-amber-500 text-white shadow-sm hover:bg-amber-600' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                    title={liked ? 'إزالة من المحفوظات' : 'حفظ'}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${liked ? 'fill-white' : ''}`} />
                    <span>حفظ</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════ CONTACT MODAL ═══════════ */}
      <Modal open={contactOpen} onClose={() => setContactOpen(false)} title="إرسال طلب اهتمام">
        <div className="space-y-4">
          {/* Member preview */}
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${accentGradient} p-[2px]`}>
              <div className="w-full h-full rounded-[10px] bg-white flex items-center justify-center">
                <img src={avatar} alt="" className="w-full h-full object-contain p-1.5" />
              </div>
            </div>
            <div className="flex-1">
              <p className="font-cairo font-bold text-slate-900 text-sm">{member.nickname}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[10px] text-slate-500 font-tajawal">{member.age} سنة</span>
                <span className="text-[10px] text-slate-500 font-tajawal">· {member.city}</span>
                <span className="text-[10px] text-slate-500 font-tajawal">· {member.education}</span>
              </div>
            </div>
            {compat.isGenderMatch && (
              <div className="text-center px-3 py-1.5 rounded-xl bg-slate-100">
                <span className={`font-cairo font-extrabold text-lg block ${badge.text}`}>{compatScore}%</span>
                <span className="text-[9px] text-slate-400 font-tajawal">توافق</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2.5 p-3 bg-amber-50 rounded-xl border border-amber-200/60">
            <ShieldCheck className="w-5 h-5 text-amber-600 flex-shrink-0" />
            <p className="text-xs text-slate-600 font-tajawal">طلبك سيصل لفريق الإدارة الذي سيتواصل مع الطرف الآخر بسرية تامة</p>
          </div>

          {/* Templates */}
          <div>
            <label className="block text-xs font-cairo font-bold text-slate-800 mb-2">💬 قوالب جاهزة</label>
            <div className="space-y-1.5">
              {MESSAGE_TEMPLATES.map((tpl, i) => (
                <button
                  key={i}
                  onClick={() => setContactMsg(tpl)}
                  className={`w-full text-right p-2.5 rounded-xl border-2 text-xs font-tajawal leading-relaxed transition-all ${
                    contactMsg === tpl
                      ? 'border-amber-500 bg-amber-50 text-slate-900 shadow-sm'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-amber-300'
                  }`}
                >
                  {tpl}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-cairo font-bold text-slate-800 mb-1.5">✏️ رسالتك (اختياري)</label>
            <textarea
              value={contactMsg}
              onChange={(e) => setContactMsg(e.target.value)}
              rows={2}
              placeholder="اكتب رسالة لطيفة ومحترمة..."
              className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border-2 border-slate-200 focus:border-amber-500 focus:outline-none font-tajawal text-sm resize-none transition-colors"
            />
          </div>

          {limitCheck.allowed && (
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-xs text-slate-600 font-tajawal flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-600" /> الطلبات المتبقية
              </span>
              <span className="text-sm font-cairo font-extrabold text-slate-900">
                {remainingRequests} <span className="text-slate-400 font-normal text-xs">من {limitCheck.max}</span>
              </span>
            </div>
          )}

          {!limitCheck.allowed ? (
            <div className="bg-amber-50 rounded-xl p-4 border border-amber-200 space-y-3 text-center">
              <p className="text-xs font-tajawal text-slate-700">لقد استنفدت حد باقتك اليومي لطلبات الاهتمام المتاحة.</p>
              {(!user.profile.plan || user.profile.plan === 'free') ? (
                <button
                  onClick={() => {
                    setContactOpen(false);
                    navigate('/plans');
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-l from-rose-500 to-pink-600 text-white font-cairo font-extrabold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all"
                >
                  الترقية للباقات المدفوعة للحصول على حد يومي أعلى 🚀
                </button>
              ) : (
                <button onClick={() => buyExtraInterests()} className="w-full py-3 rounded-xl bg-gradient-to-l from-amber-500 to-yellow-500 text-slate-900 font-cairo font-bold shadow-md">
                  شراء اهتمامات إضافية — {interestPurchaseSettings.price} ر.س
                </button>
              )}
            </div>
          ) : (
            <button
              onClick={async () => {
                incrementUsage('message');
                setContactOpen(false);
                const msg = contactMsg;
                setContactMsg('');
                const res = await createInterestRequest(getCurrentUserId(), member.id, msg);
                if (res.ok) {
                  showToast('تم إرسال طلب الاهتمام بنجاح! 💌', 'success');
                  setTimeout(() => navigate('/requests'), 1200);
                } else {
                  showToast(res.error || 'تعذّر إرسال الطلب', 'error');
                }
              }}
              className={`w-full py-3.5 rounded-xl bg-gradient-to-l ${accentGradient} text-white font-cairo font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2`}
            >
              <Send className="w-4.5 h-4.5 -scale-x-100" /> إرسال الطلب
            </button>
          )}
        </div>
      </Modal>

      {/* ═══════════ REPORT MODAL ═══════════ */}
      <Modal open={reportOpen} onClose={() => setReportOpen(false)} title="⚠️ إرسال بلاغ">
        <div className="space-y-4">
          <div className="flex items-center gap-2.5 p-3 bg-red-50 rounded-xl border border-red-200">
            <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
            <p className="text-xs text-red-800 font-cairo font-medium">نأخذ البلاغات على محمل الجد لضمان أمان الأعضاء.</p>
          </div>
          <div className="bg-slate-50 p-3 rounded-xl">
            <span className="text-[10px] text-slate-400 font-cairo">العضو المُبلَغ عنه:</span>
            <span className="block font-cairo font-bold text-slate-900 mt-0.5">{member.nickname}</span>
          </div>
          <textarea
            value={reportReason}
            onChange={(e) => setReportReason(e.target.value)}
            rows={4}
            placeholder="اكتب تفاصيل البلاغ بوضوح..."
            className="w-full p-3 rounded-xl bg-slate-50 border-2 border-slate-200 focus:border-red-400 focus:outline-none font-tajawal text-sm resize-none"
          />
          <button
            onClick={() => {
              if (!reportReason.trim()) { showToast('اكتب محتوى البلاغ', 'error'); return; }
              submitReport(member.id, member.nickname, reportReason);
              setReportOpen(false);
              setReportReason('');
              showToast('تم إرسال البلاغ ✓', 'success');
            }}
            className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-cairo font-bold text-sm transition-colors flex items-center justify-center gap-2"
          >
            <AlertTriangle className="w-4.5 h-4.5" /> إرسال البلاغ
          </button>
        </div>
      </Modal>
    </div>
  );
}
