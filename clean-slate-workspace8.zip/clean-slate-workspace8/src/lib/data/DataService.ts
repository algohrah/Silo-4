import { IDatabaseAdapter } from './interfaces';
import { LocalStorageAdapter } from './LocalStorageAdapter';

// ============================================================================
//  DataService — نقطة الوصول الموحدة لجميع عمليات قواعد البيانات والتحكم بها
//  Single Source Data Architecture — Central Data Access Layer
// ============================================================================
//  طريقة الترقية لقاعدة بيانات حقيقية (Supabase, Firebase, PostgreSQL, SQL, Appwrite... إلخ):
//  1. قم بإنشاء فئة (Class) جديدة تُمثل محوّل قاعدة البيانات الجديدة (مثل RealDatabaseAdapter).
//  2. اجعل الفئة الجديدة تُطبق (implements) الواجهة `IDatabaseAdapter` بالكامل.
//  3. قم باستيراد محوّلك الجديد هنا، ثم قم بتغيير القيمة الافتراضية للـ provider أو استخدم المتغير البيئي.
// ============================================================================

export class DataService {
  private static instance: DataService;

  /** المحوّل النشط حالياً لتنفيذ جميع العمليات */
  public db: IDatabaseAdapter;
  
  /** نوع مزود البيانات النشط (يمكن التحكم به عبر متغير البيئة VITE_DATABASE_PROVIDER) */
  public provider: 'local' | 'real_database';

  private constructor() {
    // يمكنك تعيين المتغير البيئي VITE_DATABASE_PROVIDER=real_database عند تفعيل قاعدة البيانات الحقيقية
    const configProvider = import.meta.env.VITE_DATABASE_PROVIDER;
    
    if (configProvider === 'real_database') {
      this.provider = 'real_database';
      // هنا نقوم بتركيب قاعدة البيانات الحقيقية بمجرد إنشائها:
      // this.db = new RealDatabaseAdapter();
      this.db = new LocalStorageAdapter(); // مؤقتاً نستخدم المحلي حتى تفعيلها
      if (typeof window !== 'undefined') {
        console.info('[DataService] Connected to Real Database via RealDatabaseAdapter.');
      }
    } else {
      this.provider = 'local';
      this.db = new LocalStorageAdapter();
      if (typeof window !== 'undefined') {
        console.info('[DataService] Running in localStorage-only mode. All data is saved locally in the browser.');
      }
    }
  }

  public static getInstance(): DataService {
    if (!DataService.instance) {
      DataService.instance = new DataService();
    }
    return DataService.instance;
  }
}

export const dataService = DataService.getInstance();

