import { useCallback, useEffect, useMemo, useState } from 'react';
import { dataService } from './data/DataService';
import { BLOG_POSTS, FAQS } from './data';

export interface FaqRow { id: number; question: string; answer: string; sort_order: number; }
export interface BlogRow {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  date: string;
  read_time: string;
  image: string;
}

const FAQ_KEY = 'twafok_content_faqs';
const BLOG_KEY = 'twafok_content_blog_posts';

function mapFaqs(): FaqRow[] {
  return FAQS.map((f, i) => ({ id: i + 1, question: f.q, answer: f.a, sort_order: i }));
}

function mapBlogPost(post: typeof BLOG_POSTS[number]): BlogRow {
  return {
    id: post.id,
    title: post.title,
    excerpt: post.excerpt,
    content: post.content,
    category: post.category,
    author: post.author,
    date: post.date,
    read_time: post.readTime,
    image: post.image,
  };
}

function readRows<T>(key: string, fallback: T[]): T[] {
  const stored = dataService.db.settings.get(key);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      dataService.db.settings.remove(key);
    }
  }
  dataService.db.settings.set(key, JSON.stringify(fallback));
  return fallback;
}

export function useFaqs() {
  const fallback = useMemo(() => mapFaqs(), []);
  const [faqs, setFaqs] = useState<FaqRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    try {
      setError(null);
      setFaqs(readRows<FaqRow>(FAQ_KEY, fallback).sort((a, b) => a.sort_order - b.sort_order));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل الأسئلة الشائعة');
    } finally {
      setLoading(false);
    }
  }, [fallback]);

  useEffect(() => { load(); }, [load]);
  return { faqs, loading, error, refresh: load };
}

export function useBlogPosts() {
  const fallback = useMemo(() => BLOG_POSTS.map(mapBlogPost), []);
  const [posts, setPosts] = useState<BlogRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    try {
      setError(null);
      setPosts(readRows<BlogRow>(BLOG_KEY, fallback));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل المقالات');
    } finally {
      setLoading(false);
    }
  }, [fallback]);

  useEffect(() => { load(); }, [load]);
  return { posts, loading, error, refresh: load };
}

export function useBlogPost(id?: string) {
  const fallback = useMemo(() => BLOG_POSTS.map(mapBlogPost), []);
  const [post, setPost] = useState<BlogRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    if (!id) {
      setPost(null);
      setLoading(false);
      return;
    }
    try {
      setError(null);
      const rows = readRows<BlogRow>(BLOG_KEY, fallback);
      setPost(rows.find((item) => item.id === id) || null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل المقال');
      setPost(null);
    } finally {
      setLoading(false);
    }
  }, [fallback, id]);

  useEffect(() => { load(); }, [load]);
  return { post, loading, error, refresh: load };
}
