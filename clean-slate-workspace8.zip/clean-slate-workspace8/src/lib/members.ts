import { dataService } from './data/DataService';
import type { Gender } from './types';

// ====================================================================
//  واجهة العضو — مطابقة لحقول نموذج التسجيل
// ====================================================================
export interface Member {
  id: string;
  nickname: string;        // الاسم المستعار
  username?: string;       // اسم المستخدم / اليوزر
  gender: Gender;          // الجنس
  age: number;             // العمر
  country: string;         // الدولة
  city: string;            // المدينة
  district: string;        // المنطقة / الحي
  nationality: string;     // الجنسية
  sect: string;            // المذهب
  maritalStatus: string;   // الحالة الاجتماعية (قيمة)
  maritalLabel: string;    // الحالة الاجتماعية (نص عربي صحيح حسب الجنس)
  hasChildren: boolean;    // لديه أبناء
  childrenCount: string;   // عدد الأبناء
  // شخصية
  height: number;          // الطول
  weight: number;          // الوزن
  skinColor: string;       // لون البشرة
  health: string;          // الحالة الصحية
  smoking: string;         // التدخين
  ethnicity?: string;      // العرق
  // تعليم وعمل
  education: string;       // المؤهل
  workType: string;        // نوع جهة العمل
  jobTitle: string;        // المسمى الوظيفي
  housing: string;         // نوع السكن
  bio: string;             // نبذة عني
  // مواصفات الشريك
  aboutPartner: string;    // وصف الشريك المطلوب
  // حالة الحساب
  verified: boolean;       // موثق
  premium: boolean;        // عضو ذهبي/نخبة
  online: boolean;         // متصل
  lastActive: string;      // آخر ظهور
  matchScore?: number;     // نسبة التوافق
  hasSeriousnessBadge?: boolean; // وسام الجدية المعتمد
  plan?: 'free' | 'gold' | 'elite'; // باقة العضو الحالية
  pinned?: boolean; // هل العضو مثبت من الإدارة؟
  isManagedByAdmin?: boolean;
  managedByAdminId?: string;
  // ===== حقول الاستيراد =====
  sourceType?: 'registered' | 'imported';  // نوع المصدر
  importBatchId?: string;      // معرف الدفعة
  importOfficeName?: string;   // اسم الخطابة
  importDate?: string;         // تاريخ الاستيراد
  importNotes?: string;        // ملاحظات الاستيراد
  isProfileIncomplete?: boolean; // هل الملف الشخصي غير مكتمل؟
  status?: 'active' | 'suspended' | 'pending' | 'banned';
}

// ===== 8 أعضاء تجريبيين — مطابقين لحقول التسجيل =====
export const MEMBERS: Member[] = [
  {
    id: 'm1',
    nickname: 'أبو عبدالله',
    username: 'abu_abdullah',
    gender: 'male', age: 32,
    country: 'السعودية', city: 'الرياض', district: 'حي العليا',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'أعزب',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 178, weight: 78, skinColor: 'أبيض قمحي',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'ماجستير', workType: 'حكومي', jobTitle: 'مهندس مدني',
    housing: 'أملك منزل',
    bio: 'مهندس طموح أحب الحياة المستقرة، أبحث عن شريكة تكملني وتشاركني رحلة الحياة بإذن الله.',
    aboutPartner: 'أبحث عن شريكة متعلمة، هادئة، تحب العائلة وتطمح لبناء بيت مستقر على القيم الإسلامية.',
    verified: true, premium: true, online: true, lastActive: 'متصل الآن', matchScore: 94, hasSeriousnessBadge: true,
  },
  {
    id: 'm2',
    nickname: 'باحثة عن الستر',
    username: 'sara_qht',
    gender: 'female', age: 27,
    country: 'السعودية', city: 'جدة', district: 'حي الروضة',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'عزباء',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 165, weight: 58, skinColor: 'أبيض',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'عمل حر', jobTitle: 'معلمة',
    housing: 'أسكن مع العائلة',
    bio: 'معلمة أحب العلم والمعرفة، أؤمن أن الزواج شراكة عقول قبل القلوب، أبحث عن سكني ومستقر.',
    aboutPartner: 'أبحث عن رجل مثقف، ناضج، يحترم العائلة ويقدّر طموحي ويخاف الله.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور منذ ساعة', matchScore: 96,
  },
  {
    id: 'm3',
    nickname: 'القحطاني',
    username: 'fahad_dows',
    gender: 'male', age: 35,
    country: 'السعودية', city: 'الدمام', district: 'حي الشاطئ',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'divorced', maritalLabel: 'مطلق',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 180, weight: 85, skinColor: 'حنطي',
    health: 'جيدة', smoking: 'سابقة وتركت',
    education: 'بكالوريوس', workType: 'عمل حر', jobTitle: 'رجل أعمال',
    housing: 'أملك منزل',
    bio: 'رجل أعمال ناجح، خبرة الحياة علّمتني الصبر والحكمة، أبحث عن شريكة تكملني بصدق.',
    aboutPartner: 'أبحث عن امرأة ناضجة، واثقة، تفهم معنى الشراكة وتقدّر الاستقرار العائلي.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور منذ 3 ساعات', matchScore: 88, hasSeriousnessBadge: true,
  },
  {
    id: 'm4',
    nickname: 'أم محمد',
    username: 'noura_otb',
    gender: 'female', age: 30,
    country: 'السعودية', city: 'مكة المكرمة', district: 'حي العزيزية',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'divorced', maritalLabel: 'مطلقة',
    hasChildren: true, childrenCount: '1',
    height: 162, weight: 60, skinColor: 'حنطي مائل للسمار',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'دبلوم', workType: 'عمل حر', jobTitle: 'مصممة أزياء',
    housing: 'أسكن مع العائلة',
    bio: 'أم لطفل واحد، أحب الحياة العائلية، أبحث عن رجل يعرف معنى المسؤولية ويقبل ابني كابن له.',
    aboutPartner: 'أبحث عن رجل متدين، حنون، يقبل أبنائي ويبني معي حياة مستقرة ومستقيمة.',
    verified: true, premium: false, online: true, lastActive: 'متصل الآن', matchScore: 85,
  },
  {
    id: 'm5',
    nickname: 'العتيبي',
    username: 'majed_hrb',
    gender: 'male', age: 29,
    country: 'السعودية', city: 'الخبر', district: 'حي العقربية',
    nationality: 'السعودية', sect: 'سلفي',
    maritalStatus: 'single', maritalLabel: 'أعزب',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 175, weight: 72, skinColor: 'أبيض قمحي',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'حكومي', jobTitle: 'ضابط عسكري',
    housing: 'أملك منزل',
    bio: 'ضابط في القطاع العسكري، أحب الانضباط والاستقرار، أبحث عن شريكة حياة تقف بجانبي.',
    aboutPartner: 'أبحث عن فتاة طموحة، دافئة، تحب الحياة العائلية البسيطة وتخاف الله.',
    verified: true, premium: false, online: true, lastActive: 'متصل الآن', matchScore: 91, hasSeriousnessBadge: true,
  },
  {
    id: 'm6',
    nickname: 'أم عبدالرحمن',
    username: 'reem_shh',
    gender: 'female', age: 25,
    country: 'السعودية', city: 'المدينة المنورة', district: 'حي قباء',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'عزباء',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 168, weight: 56, skinColor: 'أبيض',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'ماجستير', workType: 'حكومي', jobTitle: 'محاضرة جامعية',
    housing: 'أسكن مع العائلة',
    bio: 'محاضرة جامعية شغوفة بالعلم، أؤمن أن خير البيوت من اختارها أهلها على دينها وخلقها.',
    aboutPartner: 'أبحث عن رجل متعلم، ذو خلق ودين، يحترم طموحي ويعينني على الآخرة والدنيا.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور أمس', matchScore: 93,
  },
  {
    id: 'm7',
    nickname: 'أبو فيصل',
    username: 'sultan_qrn',
    gender: 'male', age: 40,
    country: 'السعودية', city: 'أبها', district: 'حي المنهل',
    nationality: 'السعودية', sect: 'سني',
    maritalStatus: 'widower', maritalLabel: 'أرمل',
    hasChildren: true, childrenCount: '2',
    height: 172, weight: 80, skinColor: 'أسمر',
    health: 'جيدة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'عمل حر', jobTitle: 'تاجر',
    housing: 'أملك منزل',
    bio: 'تاجر وأب لطفلين، رزقني الله الصبر بعد فقد زوجتي، أبحث عن أم حنونة لأبنائي وشريكة حياة.',
    aboutPartner: 'أبحث عن امرأة صالحة، حنونة، تقبل أبنائي وتكون لهم أمًا، وتشاركني الحياة بإذن الله.',
    verified: true, premium: true, online: false, lastActive: 'آخر ظهور منذ يومين', matchScore: 82,
  },
  {
    id: 'm8',
    nickname: 'بنت الخليج',
    username: 'latifa_ahmd',
    gender: 'female', age: 24,
    country: 'الإمارات', city: 'دبي', district: 'حي الكرامة',
    nationality: 'الإمارات', sect: 'سني',
    maritalStatus: 'single', maritalLabel: 'عزباء',
    hasChildren: false, childrenCount: 'لا يوجد',
    height: 160, weight: 52, skinColor: 'أبيض جدا',
    health: 'ممتازة', smoking: 'لا أدخن',
    education: 'بكالوريوس', workType: 'باحث عن عمل', jobTitle: 'محاسبة',
    housing: 'أسكن مع العائلة',
    bio: 'محاسبة هادئة الطباع، أحب العائلة والاستقرار، أبحث عن شريك حياة جاد وحسن الخلق.',
    aboutPartner: 'أبحث عن رجل متدين، مستقر ماديًا، يحب العائلة ويقدّر معنى الزواج الحقيقي.',
    verified: false, premium: false, online: true, lastActive: 'متصل الآن', matchScore: 89,
  },
];

// يقرأ تعديلات الإدارة المحفوظة (saved_members_list) أولاً كي تظهر
// أي موافقة أو تعديل أجرته الإدارة لجميع الأطراف، ثم يسقط للقائمة الأصلية.
export function getMemberById(id: string): Member | undefined {
  let member: Member | undefined;
  if (typeof window !== 'undefined') {
    try {
      const saved = dataService.db.settings.get('saved_members_list');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const found = parsed.find((m: Member) => m.id === id);
          if (found) member = found;
        }
      }
    } catch { /* تجاهل */ }
  }
  if (!member) {
    member = MEMBERS.find((m) => m.id === id);
  }
  // التحقق من حالة العضو في adminMeta — إخفاء المحذوفين والمحظورين والمجمّدين
  if (member && typeof window !== 'undefined') {
    try {
      const metaRaw = dataService.db.settings.get('twafok_admin_meta_v1');
      if (metaRaw) {
        const meta = JSON.parse(metaRaw);
        const m = meta[member.id];
        if (m) {
          if (m.deleted) return undefined;
          if (m.status && m.status !== 'active') return undefined;
        }
        if (member.status && member.status !== 'active') return undefined;
      }
    } catch { /* تجاهل */ }
  }
  return member;
}
