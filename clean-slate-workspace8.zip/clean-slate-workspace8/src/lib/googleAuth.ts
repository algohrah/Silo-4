import supabase from './supabase';

// Google OAuth معطّل في وضع localStorage-only لتجنب أي اتصال خارجي داخل AI Studio.
// الزر يفتح جلسة محلية تجريبية بدلًا من الاتصال بالإنترنت.
export async function signInWithGoogle(appName = 'توافق') {
  console.info(`[local-auth] Simulating Google sign-in for ${appName} without network calls.`);
  await supabase.auth.signInWithIdToken({ provider: 'google', token: 'local-google-token' } as any);
  if (typeof window !== 'undefined') window.location.href = '/';
}

export async function handleGoogleRedirect() {
  // لا حاجة لمعالجة redirect في الوضع المحلي.
}
