export type JourneyStage = 'pending' | 'accepted' | 'serious_communication' | 'sharia_meeting' | 'completed' | 'rejected';

export interface UserProfile {
  id: string;
  name: string;
  gender: 'male' | 'female';
  city: string;
  country: string;
  age: number;
  isPrivate: boolean;
  bio: string;
  occupation: string;
  education: string;
  religiousCommitment: string;
}

export interface MatchRequest {
  id: string;
  senderId: string;
  receiverId: string;
  status: JourneyStage;
  createdAt: number;
}

const DEFAULT_PROFILES: UserProfile[] = [
  {
    id: 'p1',
    name: 'أحمد العتيبي',
    gender: 'male',
    city: 'الرياض',
    country: 'المملكة العربية السعودية',
    age: 31,
    isPrivate: false,
    bio: 'أبحث عن شريكة حياة صالحة تعينني على طاعة الله ونبني معاً أسرة مستقرة قائمة على المودة والرحمة والتفاهم.',
    occupation: 'مهندس برمجيات',
    education: 'بكالوريوس هندسة حاسب',
    religiousCommitment: 'محافظ وملتزم بالصلاة والفرائض والسنن والحمد لله'
  },
  {
    id: 'p2',
    name: 'فاطمة الحربي',
    gender: 'female',
    city: 'جدة',
    country: 'المملكة العربية السعودية',
    age: 27,
    isPrivate: true,
    bio: 'أرغب في الارتباط بشخص جاد، يقدر المسؤولية ويخاف الله في بيته وأسرته، ويكون خير شريك وصديق لبناء بيت عامر بالخير.',
    occupation: 'طبيبة أطفال',
    education: 'ماجستير طب بشري',
    religiousCommitment: 'ملتزمة بالفرائض والضوابط الشرعية والوقار والحمد لله'
  },
  {
    id: 'p3',
    name: 'خالد الدوسري',
    gender: 'male',
    city: 'الدمام',
    country: 'المملكة العربية السعودية',
    age: 34,
    isPrivate: false,
    bio: 'إنسان جاد أعمل في قطاع التعليم وأبحث عن شريكة لرحلة الاستقرار والتربية الصالحة والألفة والراحة النفسية.',
    occupation: 'معلم لغة عربية',
    education: 'بكالوريوس تربية',
    religiousCommitment: 'ملتزم ومحب للخير والعمل الصالح والتربية الأسرية المتوازنة'
  },
  {
    id: 'p4',
    name: 'سارة الشمري',
    gender: 'female',
    city: 'الرياض',
    country: 'المملكة العربية السعودية',
    age: 29,
    isPrivate: true,
    bio: 'أبحث عن زوج صالح، متفهم وناضج فكرياً لبناء أسرة دافئة قائمة على التفاهم التام والتعاون على البر والتقوى والنجاح المشترك.',
    occupation: 'أخصائية تسويق',
    education: 'بكالوريوس إدارة أعمال',
    religiousCommitment: 'ملتزمة بالضوابط الشرعية والفرائض والالتزام الأخلاقي والأسري'
  }
];

const DEFAULT_REQUESTS: MatchRequest[] = [
  {
    id: 'req_1',
    senderId: 'p1',
    receiverId: 'p2',
    status: 'pending',
    createdAt: Date.now() - 3 * 24 * 60 * 60 * 1000 // 3 days ago
  },
  {
    id: 'req_2',
    senderId: 'p3',
    receiverId: 'p4',
    status: 'serious_communication',
    createdAt: Date.now() - 10 * 24 * 60 * 60 * 1000 // 10 days ago
  }
];

const STORAGE_KEYS = {
  PROFILES: 'tawafuq_profiles_v1',
  REQUESTS: 'tawafuq_requests_v1',
  CURRENT_USER_ID: 'tawafuq_current_user_id_v1'
};

export class DataService {
  static getProfiles(): UserProfile[] {
    const data = localStorage.getItem(STORAGE_KEYS.PROFILES);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(DEFAULT_PROFILES));
      return DEFAULT_PROFILES;
    }
    return JSON.parse(data);
  }

  static getRequests(): MatchRequest[] {
    const data = localStorage.getItem(STORAGE_KEYS.REQUESTS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(DEFAULT_REQUESTS));
      return DEFAULT_REQUESTS;
    }
    return JSON.parse(data);
  }

  static getRequestsForUser(userId: string): MatchRequest[] {
    const requests = this.getRequests();
    return requests.filter(r => r.senderId === userId || r.receiverId === userId);
  }

  static setCurrentUserId(userId: string): void {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, userId);
  }

  static getCurrentUserId(): string {
    return localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID) || 'p1';
  }

  static saveProfile(updatedProfile: UserProfile): void {
    const profiles = this.getProfiles();
    const index = profiles.findIndex(p => p.id === updatedProfile.id);
    if (index !== -1) {
      profiles[index] = updatedProfile;
      localStorage.setItem(STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
    }
  }

  static sendRequest(senderId: string, receiverId: string): void {
    const requests = this.getRequests();
    // Check if there is already an active request
    const exists = requests.some(r => 
      (r.senderId === senderId && r.receiverId === receiverId) ||
      (r.senderId === receiverId && r.receiverId === senderId)
    );
    if (!exists) {
      const newRequest: MatchRequest = {
        id: 'req_' + Math.random().toString(36).substr(2, 9),
        senderId,
        receiverId,
        status: 'pending',
        createdAt: Date.now()
      };
      requests.push(newRequest);
      localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(requests));
    }
  }

  static updateRequestStatus(requestId: string, newStatus: JourneyStage): void {
    const requests = this.getRequests();
    const index = requests.findIndex(r => r.id === requestId);
    if (index !== -1) {
      requests[index].status = newStatus;
      localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(requests));
    }
  }

  static deleteRequest(requestId: string): void {
    const requests = this.getRequests();
    const filtered = requests.filter(r => r.id !== requestId);
    localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(filtered));
  }

  static resetData(): void {
    localStorage.removeItem(STORAGE_KEYS.PROFILES);
    localStorage.removeItem(STORAGE_KEYS.REQUESTS);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER_ID);
  }
}
