import { mkdir, rm } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);
const url = 'https://github.com/algohrah/Tawasol-silo/raw/386e03ac87fa63788c603e6959bfdea9d1d6b973/marriage-platform12.zip';
const archivePath = 'tmp/marriage-platform12.zip';
const extractDir = 'tmp/marriage-platform12';

async function main() {
  await rm('tmp', { recursive: true, force: true });
  await mkdir('tmp', { recursive: true });

  const response = await fetch(url);
  if (!response.ok || !response.body) {
    throw new Error(`Failed to download archive: ${response.status} ${response.statusText}`);
  }
  await pipeline(response.body, createWriteStream(archivePath));
  await mkdir(extractDir, { recursive: true });
  await execFileAsync('unzip', ['-q', archivePath, '-d', extractDir]);
  const { stdout } = await execFileAsync('find', [extractDir, '-maxdepth', '3', '-type', 'f']);
  console.log(stdout);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
