# هيكل قاعدة البيانات الكامل — منصة توافق لتيسير الزواج

هذا المستند هو **مصدر الحقيقة الوحيد** لهيكل قاعدة بيانات Supabase الخاصة بهذا المشروع.
الغاية منه: عند استيراد هذا المشروع من جديد في بيئة أخرى، يمكن لأي مطوّر أو نموذج ذكاء اصطناعي
إعادة إنشاء القاعدة بالكامل — بنفس الجداول، الأعمدة، الأنواع، سياسات الأمان (RLS)، وحاوية التخزين —
دون أي تخمين أو تجربة وخطأ، وبالتسلسل الصحيح لتفادي أخطاء الاعتماد بين الجداول.

> **تنبيه حاسم:** لا تُنشئ الجداول بأي ترتيب عشوائي. اتبع الترتيب المذكور أدناه لأن بعض الجداول
> (مثل `member_auth_links`) تُستخدم من طبقة API فوراً بعد إنشائها.

> **دليل الاستيراد التنفيذي المفصّل خطوة بخطوة (موصى به للبدء):** [`database/IMPORT_GUIDE.md`](./database/IMPORT_GUIDE.md)
> يحتوي على كل أمر مطلوب بالترتيب الدقيق (الجداول، السياسات، التخزين، استرجاع البيانات، حساب المشرف، والتحقق النهائي).
> **نسخة احتياطية فعلية من بيانات المشروع الحالية:** [`database/backup/`](./database/backup) — ملف JSON جاهز
> للاستيراد المباشر لكل جدول (`supabase_insert`)، بالإضافة إلى `manifest.json` يوضّح ترتيب الاستيراد وعدد الصفوف.

---

## 0. ملخص سريع (Checklist عند الاستيراد)

1. إنشاء الجداول العشرين (20) بالترتيب المذكور في القسم 2 عبر `supabase_create_table`.
2. تفعيل سياسة RLS `deny_all_direct_access` (`ALL` / `using: false`) على **كل** جدول من الجداول العشرين — القسم 3.أ.
3. إضافة سياسات SELECT التكميلية المطلوبة لتشغيل Supabase Realtime فعلياً — القسم 3.ب (هذه الخطوة يسهل نسيانها لكنها ضرورية، وإلا لن تُسلَّم أحداث Realtime إطلاقاً للمتصفح).
4. إنشاء حاوية التخزين العامة `verification-docs` — القسم 4.
5. استرجاع بيانات النسخة الاحتياطية الفعلية من [`database/backup/`](./database/backup) بالترتيب الموضَّح في `manifest.json` (بدلاً من كتابة بيانات بذر جديدة من الصفر) — القسم 5، أو تعبئة بيانات بذر أساسية جديدة إذا كانت بيئة نظيفة تماماً.
6. إنشاء حساب Supabase Auth حقيقي بنفس البريد الموجود في `admin_users` (عبر `supabase_auth_create_user`) — هذا ضروري لتسجيل دخول لوحة الإدارة لأن التحقق يتم بمطابقة البريد بين Supabase Auth و`admin_users`، وليس بمقارنة كلمة سر مخزّنة في الجدول.
7. عدم تخزين كلمات مرور الأعضاء نصياً في `members.password` إطلاقاً — الحقل موجود للتوافق الخلفي فقط ويُترك فارغاً دائماً؛ المصادقة الحقيقية للأعضاء تمر عبر Supabase Auth + جدول `member_auth_links`.

---

## 1. مبدأ الوصول لقاعدة البيانات (مهم جداً لفهم الأمان)

* **كل الجداول محمية بسياسة RLS تمنع أي وصول مباشر** (`deny_all_direct_access`, `USING (false)`, لكل العمليات `ALL`).
* الوصول الفعلي الوحيد يتم من خلال **مسارات Vercel API** الموجودة في مجلد `api/` والتي تستخدم `SUPABASE_SERVICE_ROLE_KEY` (يتجاوز RLS تلقائياً لأنه مفتاح خادم موثوق).
* الواجهة الأمامية (`src/`) **لا تتصل بقاعدة البيانات مباشرة أبداً** — كل قراءة/كتابة تمر عبر `fetch('/api/...')`.
* التحقق من الصلاحيات (عضو عادي / مشرف) يتم داخل كل ملف `api/*.js` عبر `api/_auth.js`:
  * `getAuthUser(req)`: يفكّ رمز Bearer المرسل من الواجهة ويُرجع مستخدم Supabase Auth الحقيقي.
  * `isAdminEmail(email)`: يتحقق من وجود البريد في جدول `admin_users`.
  * `getMemberLink(authUserId)`: يجلب ربط حساب المصادقة بعضو معيّن من `member_auth_links`.
  * `requireAdmin(req, res)`: يرفض الطلب (401/403) إن لم يكن المستخدم مشرفاً حقيقياً.
  * `authorizeMemberAction(req, res, claimedMemberId)`: يسمح فقط للمشرف أو لصاحب الحساب الحقيقي المرتبط بـ`claimedMemberId`.

---

## 2. الجداول العشرون — الأعمدة والأنواع الدقيقة

> الأنواع مطابقة تماماً لما استُخدم فعلياً عبر `supabase_create_table`. أنشئها بهذا الترتيب.

### 2.1 `members` — بيانات الأعضاء الكاملة (الجدول الأساسي)

| العمود | النوع | ملاحظات |
|---|---|---|
| `id` | `text` **PK** | مثل `m1`, `m_1699999999999` |
| `nickname` | `text` | الاسم المستعار المعروض علناً |
| `username` | `text` | معرّف فريد يستخدمه العضو (رابط `/u/username`) |
| `real_name` | `text` | **حسّاس** — لا يُعرض إلا للمشرف أو صاحب الحساب |
| `email` | `text` | **حسّاس** |
| `phone` | `text` | **حسّاس** |
| `whatsapp` | `text` | **حسّاس** |
| `password` | `text` | **يُترك فارغاً دائماً** — المصادقة الحقيقية عبر Supabase Auth، هذا الحقل للتوافق الخلفي فقط |
| `gender` | `text` | `male` \| `female` |
| `birth_date` | `text` | `YYYY-MM-DD` |
| `age` | `integer` default `0` | |
| `country` | `text` | |
| `city` | `text` | |
| `district` | `text` | |
| `nationality` | `text` | |
| `sect` | `text` | |
| `religion_level` | `text` | |
| `marital_status` | `text` default `'single'` | `single`\|`married`\|`divorced`\|`widower`\|`widow` |
| `marital_label` | `text` | التسمية الظاهرة (أعزب/عزباء/مطلق...) |
| `has_children` | `boolean` default `false` | |
| `children_count` | `text` | |
| `housing_type` | `text` | |
| `housing` | `text` | |
| `skin_color` | `text` | |
| `height` | `integer` default `0` | سم |
| `weight` | `integer` default `0` | كجم |
| `health` | `text` | |
| `health_status` | `text` | |
| `smoking` | `text` | |
| `prayer` | `text` | |
| `ethnicity` | `text` | |
| `education` | `text` | |
| `work_type` | `text` | |
| `job_title` | `text` | |
| `income_range` | `text` | |
| `bio` | `text` | نبذة عن النفس |
| `about_partner` | `text` | مواصفات الشريك (نص حر) |
| `p_country` | `text` | بلد إقامة الشريك المطلوب |
| `p_city` | `text` | |
| `p_nationality` | `text` | |
| `p_age_min` | `integer` | |
| `p_age_max` | `integer` | |
| `p_marital_status` | `text` | |
| `p_accept_children` | `text` | `yes`\|`no`\|`conditional` |
| `p_notes` | `text` | |
| `verified` | `boolean` default `false` | توثيق الهوية |
| `premium` | `boolean` default `false` | |
| `online` | `boolean` default `false` | (غير مستخدم في الواجهة حالياً بقرار خصوصية) |
| `last_active` | `timestamptz` | |
| `match_score` | `integer` default `90` | (غير مُستخدم في الواجهة بقرار حذف نسب التوافق) |
| `has_seriousness_badge` | `boolean` default `false` | وسام الجدية |
| `plan` | `text` default `'free'` | `free`\|`gold`\|`elite` |
| `pinned` | `boolean` default `false` | تثبيت إداري في نتائج البحث |
| `status` | `text` default `'active'` | `active`\|`pending`\|`suspended`\|`banned` |
| `status_reason` | `text` | **حسّاس** |
| `status_by` | `text` | **حسّاس** |
| `notes` | `text` | **حسّاس** — ملاحظات إدارية داخلية |
| `flagged` | `boolean` default `false` | |
| `source_type` | `text` default `'registered'` | `registered`\|`imported` |
| `import_batch_id` | `text` | **حسّاس** |
| `import_office_name` | `text` | **حسّاس** |
| `import_date` | `text` | **حسّاس** |
| `import_notes` | `text` | **حسّاس** |
| `is_profile_incomplete` | `boolean` default `false` | |
| `details` | `jsonb` | **حسّاس** — بيانات وصفية إضافية |
| `created_at` | `timestamptz` default `now()` | |
| `updated_at` | `timestamptz` default `now()` | |

**قاعدة الأمان في `api/members.js`:** أي استجابة GET عامة (بدون مصادقة مشرف أو صاحب الحساب) تُزيل تلقائياً الحقول:
`password, email, phone, whatsapp, real_name, notes, status_reason, status_by, import_batch_id, import_office_name, import_date, import_notes, birth_date, details`.

**عمود `details` (jsonb) — تخزين الحقول الموسّعة:** الحقول التي لا عمود مخصّص لها في جدول `members` تُحفظ داخل `details` وتُسترجَع منه تلقائياً في `api/members.js` (عبر `buildDetails()` و`DETAIL_KEYS`). أبرزها: `acceptPolygamy` (قيمة `yes`/`no`/فارغ للنساء — قابلة للتعديل من لوحة الإدارة بعد الاستيراد)، `acceptDivorced`, `acceptWithChildren`, ومواصفات الشريك التفصيلية (`pCountry`, `pCity`, `pAgeMin`, `pAgeMax`, `pNationality`, `pMaritalStatus`, ...). لا حاجة لإضافة أعمدة جديدة لهذه القيم.

**ملاحظات على الاستيراد (بعد الإصلاحات):**
- **لا تخمين تلقائي:** الاستيراد يقبل ملف CSV/Tab/JSON مهيكلاً فقط (كما يُنتجه الذكاء الاصطناعي)؛ أُزيل الاستخراج التخميني من النصوص الحرة.
- **الاسم المستعار (`nickname`):** لا يُخترع من الاسم/القبيلة؛ إن لم يوجد صراحةً يُشتق تصنيف بسيط من الجنس («رجل»/«أنثى»). الاسم الحقيقي والبريد وكلمة السر وتاريخ الميلاد **محذوفة من الاستيراد**.
- **تعطيل اكتشاف التكرار:** يُستورد كل صف كعضو مستقل بمعرّف فريد (بناءً على طلب التشغيل الحالي) — لا يُسقَط أي صف بسبب تشابه الهاتف أو الحقول.
- **طبقة تطبيع القيم:** تُصحّح مخرجات الـ AI تلقائياً لأقرب قيمة معتمدة (مثل «إيجار»→«أستأجر»، «متقاعد»→«بدون عمل»، «شاب»→«أعزب»).

### 2.2 `admin_users` — حسابات المشرفين

| العمود | النوع |
|---|---|
| `id` | `text` **PK** (غالباً نفس البريد الإلكتروني) |
| `username` | `text` |
| `email` | `text` — **المرجع الوحيد للتحقق من صلاحية الإدارة** (مطابقة مع بريد Supabase Auth) |
| `role` | `text` default `'admin'` |
| `created_at` | `timestamptz` default `now()` |

### 2.3 `interest_requests` — رحلة طلب الاهتمام والتوافق الكاملة

| العمود | النوع |
|---|---|
| `id` | `bigint` **PK** |
| `sender_id` / `receiver_id` | `text` |
| `status` | `text` default `'sent'` |
| `journey_stage` | `text` default `'sent'` — المصدر الرسمي لمرحلة الرحلة |
| `mediation_stage` | `text` |
| `message` | `text` |
| `sender_paid` / `receiver_paid` | `boolean` default `false` |
| `sender_paid_at` / `receiver_paid_at` | `timestamptz` |
| `deadline_date` | `timestamptz` |
| `defer_date` | `text` |
| `defer_by` | `text` |
| `decline_reason` / `cancel_reason` | `text` |
| `meeting_date` / `meeting_notes` | `text` |
| `contact_info` / `contact_by` | `text` |
| `guardian_phone` / `guardian_name` / `guardian_relation` | `text` |
| `contact_time` / `contact_note` | `text` |
| `male_phone` / `male_name` / `male_relation` | `text` |
| `male_contact_time` / `male_contact_note` | `text` |
| `male_pledged` / `female_pledged` | `boolean` default `false` |
| `sender_viewing_result` / `sender_viewing_note` | `text` |
| `receiver_viewing_result` / `receiver_viewing_note` | `text` |
| `evaluation_result` / `evaluation_note` | `text` |
| `frozen` | `boolean` default `false` |
| `frozen_reason` | `text` |
| `frozen_at` | `timestamptz` |
| `created_at` / `updated_at` | `timestamptz` default `now()` |

**مراحل `journey_stage` الممكنة:** `sent → accepted → seriousness → coordination → sharia_viewing → engagement → completed`, أو `declined` / `cancelled` في أي وقت.

### 2.4 `notifications`

| العمود | النوع |
|---|---|
| `id` | `bigserial` **PK** |
| `user_id` | `text` (أو `'all'` للإشعارات الجماعية) |
| `request_id` | `bigint` |
| `title` / `text` | `text` |
| `type` | `text` default `'system'` |
| `read` | `boolean` default `false` |
| `created_at` | `timestamptz` default `now()` |

### 2.5 `transactions` — كل المدفوعات (اشتراكات، رسوم جدية، باقات رسائل، رسوم سعي)

| العمود | النوع |
|---|---|
| `id` | `bigserial` **PK** |
| `user_id` | `text` |
| `request_id` | `bigint` |
| `amount` | `numeric` default `0` |
| `type` | `text` default `'payment'` — `subscription`\|`deposit`\|`inquiry`\|`inquiry_package`\|`final`\|`exemption` |
| `description` | `text` |
| `status` | `text` default `'completed'` — `pending`\|`completed`\|`failed`\|`refunded` |
| `metadata` | `jsonb` — يحمل بيانات التفعيل (مثل `desiredPlan` أو `credits`) تستخدمها `api/transactions.js` لتفعيل الامتياز فعلياً عند اعتماد المشرف |
| `created_at` | `timestamptz` default `now()` |

> **مهم:** المدفوعات اليدوية (تحويل بنكي/عملات رقمية) تُنشأ بحالة `pending` ولا تُفعَّل تلقائياً؛ يجب أن يعتمدها المشرف من `AdminTransactions` (PUT إلى `/api/transactions` بـ `status: completed`) لتُفعَّل فعلياً (ترقية باقة، شحن رصيد، توثيق زواج، إلخ) عبر دالة `grantEntitlement()` في `api/transactions.js`.

### 2.6 `coupons`

| العمود | النوع |
|---|---|
| `code` | `text` **PK** |
| `discount` | `numeric` default `0` |
| `is_active` | `boolean` default `true` |
| `uses_count` | `integer` default `0` |
| `expires_at` | `timestamptz` |
| `details` | `jsonb` |
| `created_at` | `timestamptz` default `now()` |

### 2.7 `support_tickets`

| العمود | النوع |
|---|---|
| `id` | `bigserial` **PK** |
| `user_id` | `text` |
| `subject` / `message` / `category` | `text` |
| `priority` | `text` default `'normal'` |
| `status` | `text` default `'open'` |
| `details` | `jsonb` |
| `created_at` / `updated_at` | `timestamptz` default `now()` |

### 2.8 `inquiry_messages` — رسائل غرفة الاستفسار داخل رحلة التوافق

| العمود | النوع |
|---|---|
| `id` | `bigserial` **PK** |
| `request_id` | `bigint` |
| `sender_id` | `text` |
| `text` | `text` |
| `charged_to` | `text` |
| `status` | `text` default `'approved'` |
| `moderated_by` | `text` |
| `created_at` | `timestamptz` default `now()` |

### 2.9 `verification_docs` — وثائق توثيق الهوية

| العمود | النوع |
|---|---|
| `id` | `text` **PK** |
| `member_id` | `text` |
| `doc_type` | `text` default `'identity'` |
| `file_url` | `text` — رابط عام من حاوية `verification-docs` |
| `status` | `text` default `'pending'` |
| `reviewer_name` / `rejection_reason` | `text` |
| `details` | `jsonb` |
| `created_at` / `updated_at` | `timestamptz` default `now()` |

### 2.10 `geo_countries`

| العمود | النوع |
|---|---|
| `name` | `text` **PK** |
| `code` / `flag` | `text` |

### 2.11 `geo_cities`

| العمود | النوع |
|---|---|
| `id` | `bigserial` **PK** |
| `country` / `name` | `text` |

### 2.12 `pending_cities` — مدن مقترحة من المستخدمين بانتظار مراجعة الإدارة

| العمود | النوع |
|---|---|
| `id` | `text` **PK** |
| `name` / `country` | `text` |
| `suggested_by` / `suggested_by_id` | `text` |
| `source` | `text` default `'register'` |
| `status` | `text` default `'pending'` |
| `rejection_reason` | `text` |
| `created_at` | `timestamptz` default `now()` |

### 2.13 `geo_nationalities`

| العمود | النوع |
|---|---|
| `name` | `text` **PK** |
| `country` | `text` |
| `gender` | `text` default `'both'` — `male` \| `female` \| `both` |

> **إدارة الجنسيات (بعد الإصلاحات):** تُدار من `/admin/cities` → تبويب «الجنسيات» بعرض جدولي: لكل دولة صفٌّ يعرض **جنسية الذكر** و**جنسية الأنثى** بتعديل مباشر لكل خانة (مثل السعودية → «سعودي» ذكر / «سعودية» أنثى). المقترحات الجديدة (دول/مدن/جنسيات) تظهر كلٌّ في تبويبه الخاص عبر **زر «المقترحات»** (نافذة منبثقة)، مع توحيد المكرّرات في عنصر واحد وأدوات اعتماد/تعديل/دمج/رفض. القوائم الرسمية موحّدة المصدر بين التسجيل والبحث وتعديل الملف (تُحمّل عبر `ensureGeoLoaded()`).

### 2.14 `geo_suggestions` — مقترحات جغرافية عامة (دولة/مدينة/جنسية) بانتظار المراجعة

| العمود | النوع |
|---|---|
| `id` | `text` **PK** |
| `kind` | `text` — `country`\|`city`\|`nationality` |
| `name` / `country` | `text` |
| `suggested_by` / `suggested_by_id` | `text` |
| `source` | `text` default `'register'` |
| `status` | `text` default `'pending'` — `pending`\|`approved`\|`merged`\|`rejected` |
| `target_name` / `target_country` | `text` |
| `rejection_reason` / `reviewer` | `text` |
| `reviewed_at` | `timestamptz` |
| `created_at` | `timestamptz` default `now()` |

### 2.15 `settings` — إعدادات المنصة + مفاتيح شخصية للأعضاء (جدول key/value عام)

| العمود | النوع |
|---|---|
| `key` | `text` **PK** |
| `value` | `text` |
| `updated_at` | `timestamptz` default `now()` |

**تصنيف المفاتيح في `api/settings.js`:**
* **مفاتيح شخصية** (يكتبها العضو نفسه بعد تسجيل دخول فقط، دون صلاحية إدارية): `user_deposit_quota`, `user_extra_interests_count`, `user_unlimited_interests_until`, `dark_mode`, `profile_boosted`, `twafok_reviewed_reports`, `twafok_reviewed_tickets`, وأي مفتاح يبدأ بـ `inquiry_balance_` أو `profile_hidden_`.
* **كل مفتاح آخر** (باقات، بوابات دفع، شروط، هوية المنصة...) يتطلب صلاحية إدارية للكتابة/الحذف، والقراءة عامة دوماً.

### 2.16 `member_reports` — بلاغات الأعضاء

| العمود | النوع |
|---|---|
| `id` | `text` **PK** |
| `reporter_id` / `reporter_name` | `text` |
| `reported_id` / `reported_name` | `text` |
| `reason` | `text` |
| `status` | `text` default `'pending'` |
| `category` / `severity` | `text` |
| `admin_notes` | `text` |
| `action_log` | `jsonb` |
| `created_at` | `timestamptz` default `now()` |

### 2.17 `exemption_requests` — طلبات إعفاء رسوم الجدية

| العمود | النوع |
|---|---|
| `id` | `text` **PK** |
| `request_id` / `user_id` / `user_nickname` | `text` |
| `reason` | `text` |
| `status` | `text` default `'pending'` |
| `created_at` | `timestamptz` default `now()` |

### 2.18 `member_auth_links` — الربط بين حساب Supabase Auth الحقيقي وعضو `members`

| العمود | النوع |
|---|---|
| `auth_user_id` | `uuid` **PK** — نفس `auth.users.id` |
| `member_id` | `text` — يشير إلى `members.id` |
| `email` | `text` |
| `created_at` | `timestamptz` default `now()` |

> يُنشأ صف هنا تلقائياً في `api/members.js` (POST) عند تسجيل عضو جديد بعد نجاح `supabase.auth.signUp` من الواجهة. يُستخدم في `authorizeMemberAction()` لمنع أي عضو من التصرف بحساب غيره.

### 2.19 `audit_logs` — سجل التدقيق الإداري الحقيقي

| العمود | النوع |
|---|---|
| `id` | `bigserial` **PK** |
| `actor_email` | `text` — بريد المشرف الذي نفّذ الإجراء |
| `action` | `text` — مثل `update_member`, `approve_transaction`, `delete_request`... |
| `target_type` / `target_id` | `text` |
| `details` | `jsonb` |
| `created_at` | `timestamptz` default `now()` |

### 2.20 `rate_limits` — حماية من التكرار المفرط (Rate Limiting)

| العمود | النوع |
|---|---|
| `key` | `text` **PK** — مثل `report:m2` أو `ir_create:m5` |
| `count` | `integer` default `0` |
| `window_start` | `timestamptz` default `now()` |

---

## 3. سياسات الأمان (Row Level Security)

### 3.أ سياسة الحظر الافتراضية (على كل الجداول العشرين بلا استثناء)

**كل جدول من الجداول العشرين أعلاه بلا استثناء** يجب أن يحصل على سياسة واحدة بهذه المواصفات بالضبط:

```
policy_name: deny_all_direct_access
operation: ALL
using_expression: false
```

هذا يمنع أي وصول من العميل مباشرة (anon key / authenticated عبر مكتبة العميل)، ويسمح فقط بالوصول عبر
`SUPABASE_SERVICE_ROLE_KEY` المستخدم داخل `api/db-client.js` على الخادم.

### 3.ب سياسات SELECT التكميلية (مطلوبة لتشغيل Supabase Realtime فعلياً)

سياسة الحظر أعلاه تمنع أيضاً بث أحداث Realtime لأن Supabase يتحقق من RLS بنفس دور الاتصال قبل تسليم
أي `postgres_changes`. لذلك أضِف — **بعد** تطبيق سياسات الحظر على الجداول الخمسة أدناه — سياسة SELECT
إضافية واحدة على كل جدول، بالضبط كما يلي (رتّبها بهذا التسلسل لأن بعضها يستعلم عن جداول أخرى في شرطها):

| الجدول | اسم السياسة | العملية | `using_expression` |
|---|---|---|---|
| `member_auth_links` | `own_link_select` | SELECT | `auth_user_id = auth.uid()` |
| `admin_users` | `own_admin_check_select` | SELECT | `email = auth.email()` |
| `interest_requests` | `party_or_admin_select` | SELECT | `EXISTS (SELECT 1 FROM member_auth_links mal WHERE mal.auth_user_id = auth.uid() AND (mal.member_id = interest_requests.sender_id OR mal.member_id = interest_requests.receiver_id)) OR EXISTS (SELECT 1 FROM admin_users au WHERE au.email = auth.email())` |
| `notifications` | `own_notifications_select` | SELECT | `user_id = 'all' OR EXISTS (SELECT 1 FROM member_auth_links mal WHERE mal.auth_user_id = auth.uid() AND mal.member_id = notifications.user_id) OR EXISTS (SELECT 1 FROM admin_users au WHERE au.email = auth.email())` |
| `inquiry_messages` | `party_or_admin_select` | SELECT | `EXISTS (SELECT 1 FROM interest_requests ir WHERE ir.id = inquiry_messages.request_id) OR EXISTS (SELECT 1 FROM admin_users au WHERE au.email = auth.email())` |

الجداول المستخدمة فعلياً في اشتراكات Realtime بالواجهة (`src/pages/Notifications.tsx`, `src/components/ui/Header.tsx`,
`src/pages/JourneyPage.tsx`) هي بالضبط: `notifications`, `inquiry_messages`, `interest_requests` — بقية الجداول
تبقى محظورة بالكامل من القراءة المباشرة (السياسة 3.أ فقط) لأنها لا تحتاج بثاً لحظياً للعميل.

---

## 4. التخزين (Storage)

| الحاوية | عام؟ | الاستخدام |
|---|---|---|
| `verification-docs` | ✅ عام (public) | صور/ملفات توثيق الهوية التي يرفعها الأعضاء عبر `api/verification-docs.js`، ويُعاد `getPublicUrl()` ويُحفظ في `verification_docs.file_url` |

---

## 5. بيانات البذر الأساسية المطلوبة بعد إنشاء الجداول

**الطريقة الموصى بها (الأسرع والأدق):** استخدم النسخة الاحتياطية الفعلية الجاهزة في
[`database/backup/`](./database/backup) — استورد كل ملف JSON عبر `supabase_insert` بالترتيب الموضَّح في
`backup/manifest.json`. هذه الطريقة تضمن استعادة كل البيانات الحالية (الأعضاء التجريبيون، الدول والمدن
والجنسيات، إعدادات المنصة، سجل التدقيق) بنقرة واحدة لكل جدول دون كتابة أي بيانات يدوياً. راجع
[`database/IMPORT_GUIDE.md`](./database/IMPORT_GUIDE.md) للخطوات التفصيلية الكاملة.

**إذا كانت بيئة نظيفة تماماً بلا نسخة احتياطية متاحة**، يمكن تعبئة بذر أساسي جديد يدوياً بالحد الأدنى التالي:

1. **`admin_users`**: صف واحد على الأقل، مثال:
   ```json
   { "id": "algohrah4u@gmail.com", "username": "algohrah4u@gmail.com", "email": "algohrah4u@gmail.com", "role": "super_admin" }
   ```
   ثم **يجب** إنشاء حساب Supabase Auth حقيقي بنفس البريد (`supabase_auth_create_user`) — بدون هذه الخطوة لن يستطيع أي مشرف الدخول لأن `/api/whoami` يتحقق من مطابقة بريد الجلسة الحقيقية مع هذا الجدول.
2. **`geo_countries` / `geo_cities` / `geo_nationalities`**: قوائم الدول العربية الأساسية (السعودية، الإمارات، مصر، الكويت، قطر، الأردن، المغرب، الجزائر، العراق، البحرين، عمان، اليمن) مع مدنها الكبرى وجنسياتها المقابلة — مطلوبة لعمل نموذج التسجيل والبحث بدون أخطاء.
3. **`settings`**: مفاتيح أساسية: `platform_name`, `privacy_policy`, `seriousness_fee`, `payment_gateway_enabled`, `registration_enabled` (وأي مفتاح آخر تحتاجه صفحات `AdminPlatformSettings` / `AdminPaymentSettings` / `AdminFeatureSettings`).
4. **`members`**: أعضاء تجريبيون (اختياري لكن يُنصح به) لضمان ظهور محتوى فوري في صفحتي البحث والرئيسية.

---

## 6. بيانات دخول لوحة الإدارة (Admin Credentials)

* **البريد الإلكتروني:** `algohrah4u@gmail.com`
* **كلمة السر:** يُحدَّدها عند إنشاء المستخدم عبر `supabase_auth_create_user` (لم تعد مخزّنة أو مقارَنة في كود الواجهة). في بيئة التطوير الحالية: `Tawafoq@Admin2024`.
* **ملاحظة:** المشرف يدخل من `/login` بنفس البريد، ويُحوَّل تلقائياً إلى `/admin` حتى لو لم يكن له ملف عضو في جدول `members`.
* **المسار:** `/admin`
* **آلية الحماية الحالية:** `src/components/admin/AdminLayout.tsx` → `verifyAdminSession()` يستدعي `/api/whoami` بجلسة Supabase Auth حقيقية، ويتحقق من وجود البريد في `admin_users` عبر `requireAdmin()` في كل مسار إداري بـ`api/_auth.js`.

---

## 7. حقول مواصفات الشريك في نموذج التسجيل (مرجع سريع لـ `src/lib/fieldSchema.ts`)

* `pCountry`, `pCity`, `pNationality`: إقامة/جنسية الشريك المطلوب.
* `pAgeMin`, `pAgeMax`: نطاق العمر.
* `pMaritalStatus`: الحالة الاجتماعية المطلوبة.
* `pAcceptChildren`: `yes` \| `no` \| `conditional`.
* `pNotes` / `aboutPartner`: ملاحظات تفصيلية حرة.

---

## 8. قيود واجهة المستخدم المعتمدة (لا تُعاد هذه الميزات عند التطوير المستقبلي دون طلب صريح)

* لا يُعرض `matchScore` (نسبة توافق رقمية) لأي عضو.
* لا تُعرض حالة "متصل الآن" أو "آخر ظهور" حفاظاً على الخصوصية.
* لا يُعرض عدّاد زيارات الملف الشخصي (`profileVisits`).
* لوحة الإدارة محظورة بالكامل خلف مصادقة Supabase Auth + تحقق `admin_users`.

---

## 9. جداول قد تحتاجها ميزات مستقبلية (غير منشأة حالياً — للتوثيق فقط)

لا توجد حالياً؛ الهيكل أعلاه يغطي كل الميزات المفعّلة في الكود الحالي بالكامل. أي جدول جديد يُضاف مستقبلاً
يجب أن يُوثَّق هنا فوراً بنفس الصيغة (الأعمدة + الأنواع + سياسة RLS) قبل استخدامه في أي `api/*.js` جديد.
