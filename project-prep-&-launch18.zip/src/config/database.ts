export type DatabaseProvider = 'api' | 'local' | 'supabase';

export const DATABASE_CONFIG = {
  // الوضع الافتراضي الآن يمر عبر Vercel API Routes المتصلة بقاعدة Supabase الحقيقية.
  // إذا تم تمرير supabase من نسخة قديمة نتعامل معه كـ api حفاظاً على التوافق ومنع الوصول المباشر من الواجهة.
  PROVIDER: ((import.meta.env.VITE_DATABASE_PROVIDER as DatabaseProvider) || 'api') as DatabaseProvider,
};
