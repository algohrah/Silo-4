import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../lib/AppContext';
import {
  Search as SearchIcon, SlidersHorizontal, MapPin, Calendar,
  Briefcase, GraduationCap, Users, ChevronDown, ChevronUp,
  Globe, BookOpen, Heart, ShieldCheck, Baby, Building2,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import {
  ARAB_COUNTRIES, ARAB_CITIES, EDUCATION_LEVELS, JOB_TITLES,
  SECTS, CHILDREN_COUNTS, getMaritalOptions,
} from '../lib/types';
import { CITIES_BY_COUNTRY, NATIONALITIES } from '../lib/constants';
import MemberCard from '../components/MemberCard';
import { MemberGridSkeleton } from '../components/ui/MemberCardSkeleton';
import { dataService } from '../lib/data/DataService';

type GenderFilter = 'male' | 'female' | 'all';

const PAGE_SIZE = 24;

export default function Search() {
  const navigate = useNavigate();
  const { checkLimit, incrementUsage, showToast, members, membersLoading, membersError, retryLoadMembers, calculateCompatDetailed, blockedMembers } = useApp();
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  // ===== الفلاتر الأساسية =====
  const [searchQuery, setSearchQuery] = useState('');
  const [gender, setGender] = useState<GenderFilter>('all');
  const [ageRange, setAgeRange] = useState<[number, number]>([18, 70]);
  const [country, setCountry] = useState('');
  const [city, setCity] = useState('');

  // ===== الفلاتر المتقدمة =====
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [nationality, setNationality] = useState('');
  const [education, setEducation] = useState('');
  const [job, setJob] = useState('');
  const [maritalStatus, setMaritalStatus] = useState('');
  const [sect, setSect] = useState('');
  const [hasChildren, setHasChildren] = useState('');
  const [childrenCount, setChildrenCount] = useState('');

  // نضمن تحميل قوائم الجغرافيا الرسمية من قاعدة البيانات (نفس مصدر التسجيل)
  React.useEffect(() => { dataService.db.ensureGeoLoaded?.().catch(() => undefined); }, []);

  // الدول والمدن والجنسيات من قاعدة البيانات الموحّدة (مع fallback للقوائم الثابتة)
  const countryOptions = React.useMemo(() => {
    const db = dataService.db.getCountryNames?.() || [];
    return db.length ? db : ARAB_COUNTRIES;
  }, []);
  const OTHER_CITY_OPTION = 'أخرى (مدن أخرى)';

  const cityOptions = React.useMemo(() => {
    if (!country) return ARAB_CITIES;
    const db = dataService.db.getCities?.(country) || [];
    const mainCities = db.length ? db : (CITIES_BY_COUNTRY[country] || []);
    // نضمن إدراج خيار "أخرى (مدن أخرى)" في نهاية خيارات المدينة للدولة المحددة
    const uniqueCities = Array.from(new Set(mainCities));
    return [...uniqueCities, OTHER_CITY_OPTION];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [country]);
  const nationalityOptions = React.useMemo(() => {
    const db = dataService.db.getNationalities?.() || [];
    return db.length ? db : NATIONALITIES;
  }, []);

  // خيارات الحالة الاجتماعية حسب الجنس المختار
  const maritalOptions = gender === 'all' ? [] : getMaritalOptions(gender);

  // عند تغيير الجنس: نعيد ضبط الحالة الاجتماعية لأن الخيارات تختلف
  const handleGenderChange = (g: GenderFilter) => {
    setGender(g);
    setMaritalStatus(''); // إعادة ضبط الحالة الاجتماعية
    setHasChildren('');
    setChildrenCount('');
  };

  // عند اختيار "مطلق/مطلقة" نظهر خيارات الأبناء
  const showChildrenOptions = ['divorced', 'widower', 'widow', 'widowed', 'مطلق', 'مطلقة', 'أرمل', 'أرملة'].includes(maritalStatus);

  // Live filtering (replaces separate results page - Red Priority #2)
  const filteredMembers = members.filter(m => {
    if (m.status && m.status !== 'active') return false;
    // إخفاء الأعضاء المحظورين شخصياً من نتائج البحث
    if (blockedMembers.has(m.id)) return false;
    // لا نخفي المستوردين بسبب نقص الجنس/العمر؛ يكفي وجود اسم أو رمز عضو.
    if (!m.nickname && !m.realName && !m.id) return false;

    // البحث بالكلمة المفتاحية / الرمز
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const matchId = (m.id || '').toLowerCase().includes(q);
      const matchNick = (m.nickname || '').toLowerCase().includes(q);
      const matchUser = (m.username || '').toLowerCase().includes(q);
      const matchJob = (m.jobTitle || '').toLowerCase().includes(q);
      const matchBio = (m.bio || '').toLowerCase().includes(q);
      if (!matchId && !matchNick && !matchUser && !matchJob && !matchBio) {
        return false;
      }
    }

    if (gender !== 'all' && m.gender !== gender) return false;
    if (m.age && (m.age < ageRange[0] || m.age > ageRange[1])) return false;
    if (country && m.country !== country) return false;
    if (city) {
      if (city === OTHER_CITY_OPTION || city === 'أخرى' || city.startsWith('أخرى')) {
        // عند اختيار "أخرى (مدن أخرى)"، يُطابق الأعضاء الذين مدينتهم ليست ضمن القائمة الرئيسية لتلك الدولة
        const targetCountry = m.country || country;
        const db = dataService.db.getCities?.(targetCountry) || [];
        const mainCities = db.length ? db : (CITIES_BY_COUNTRY[targetCountry] || []);
        const normMCity = (m.city || '').trim().toLowerCase();
        const isMain = mainCities.some((c) => c.trim().toLowerCase() === normMCity);
        if (isMain) return false;
      } else {
        if (m.city !== city) return false;
      }
    }

    // تصفية الجنسية (مطابقة مرنة تشمل الدولة والمسمى الوظيفي والنسبة)
    if (nationality) {
      const normFilter = nationality.replace('/ة', '').replace('ة', '').replace('ال', '').trim().toLowerCase();
      const normNat = (m.nationality || '').replace('/ة', '').replace('ة', '').replace('ال', '').trim().toLowerCase();
      const normCountry = (m.country || '').replace('ال', '').trim().toLowerCase();

      const isNatMatch = m.nationality === nationality || 
                         normNat === normFilter || 
                         (normNat.length > 2 && normFilter.length > 2 && (normNat.includes(normFilter) || normFilter.includes(normNat))) ||
                         (normCountry.length > 2 && normFilter.length > 2 && (normCountry === normFilter || normCountry.includes(normFilter)));

      if (!isNatMatch) return false;
    }

    if (education && m.education !== education) return false;
    
    if (job) {
      const j = job.trim().toLowerCase();
      const wType = (m.workType || '').toLowerCase();
      const jTitle = (m.jobTitle || '').toLowerCase();
      const matchesWork = wType.includes(j) || (j === 'عمل حر' && (wType.includes('حر') || wType.includes('أعمال حرة'))) || (j === 'أعمال حرة' && (wType.includes('حر') || wType.includes('عمل')));
      const matchesTitle = jTitle.includes(j);
      if (!matchesWork && !matchesTitle) return false;
    }

    if (maritalStatus) {
      const mStatus = m.maritalStatus || '';
      const mLabel = m.maritalLabel || '';
      const isWidowMatch = (maritalStatus === 'widower' || maritalStatus === 'widow') && (mStatus === 'widower' || mStatus === 'widow');
      if (mStatus !== maritalStatus && !isWidowMatch && !mLabel.includes(maritalStatus)) {
        return false;
      }
    }

    // تصفية المذهب (مطابقة مرنة مثل سني / مسلم سني / سلفي)
    if (sect) {
      const normFilter = sect.replace('مسلم ', '').trim();
      const normSect = (m.sect || '').replace('مسلم ', '').trim();

      const isSectMatch = m.sect === sect || 
                         normSect === normFilter || 
                         normSect.includes(normFilter) || 
                         normFilter.includes(normSect);

      if (!isSectMatch) return false;
    }
    if (hasChildren && ((hasChildren === 'true' && !m.hasChildren) || (hasChildren === 'false' && m.hasChildren))) return false;
    if (childrenCount && m.childrenCount !== childrenCount) return false;

    return true;
  }).sort((a, b) => {
    // 0. Priority: Pinned members first
    const pinA = a.pinned ? 1 : 0;
    const pinB = b.pinned ? 1 : 0;
    if (pinA !== pinB) {
      return pinB - pinA; // pinned first
    }

    // Priority: Premium Package (Elite) > Gold Package > Free Package
    const getPlanScore = (member: any) => {
      const plan = member.plan || (member.premium ? 'elite' : 'free');
      if (plan === 'elite') return 100;
      if (plan === 'gold') return 50;
      return 10;
    };

    const scoreA = getPlanScore(a) + (a.hasSeriousnessBadge ? 5 : 0);
    const scoreB = getPlanScore(b) + (b.hasSeriousnessBadge ? 5 : 0);

    if (scoreA !== scoreB) {
      return scoreB - scoreA; // higher score first
    }

    // Secondary: Sort by latest (newest ID first)
    const numA = parseInt(a.id.replace(/\D/g, '')) || 0;
    const numB = parseInt(b.id.replace(/\D/g, '')) || 0;
    if (numA !== numB) {
      return numB - numA;
    }

    // Tertiary: fallback comparison
    return b.id.localeCompare(a.id);
  });

  // إعادة الترقيم للصفحة الأولى عند تغيير أي فلتر لتجنّب صفحة فارغة
  React.useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [searchQuery, gender, ageRange[0], ageRange[1], country, city, nationality, education, job, maritalStatus, sect, hasChildren, childrenCount]);

  const visibleMembers = filteredMembers.slice(0, visibleCount);
  const hasMore = filteredMembers.length > visibleMembers.length;

  const handleSearch = () => {
    // Live results already shown below - no navigation needed
    showToast('تم تحديث النتائج فوراً حسب الفلاتر', 'success');
    incrementUsage('search');
  };

  return (
    <div className="bg-cream-50 min-h-screen pb-12">
      {/* Header banner */}
      <div className="bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="absolute -top-20 -left-20 w-72 h-72 bg-gold-500/20 rounded-full blur-3xl" />
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 py-12 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gold-300/15 mb-4">
              <SlidersHorizontal className="w-7 h-7 text-gold-300" />
            </div>
            <h1 className="font-cairo font-extrabold text-3xl sm:text-4xl text-white">البحث المتقدم</h1>
            <p className="mt-3 text-cream-200/80 font-tajawal">خصّص بحثك بدقة للعثور على شريك الحياة المناسب</p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 -mt-6 relative">
        <div className="bg-white dark:bg-navy-900 rounded-3xl shadow-luxe border border-cream-200/60 dark:border-navy-800 p-5 sm:p-7 space-y-6">

          {/* ===== البحث بالرمز أو الكلمة المفتاحية ===== */}
          <div>
            <label className="flex items-center gap-2 text-sm font-cairo font-bold text-navy-800 dark:text-cream-100 mb-2">
              <SearchIcon className="w-4 h-4 text-gold-600" /> البحث بالسير الذاتية / الرمز الكودي
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث بكود العضو (مثل m1)، أو المسمى الوظيفي، أو الاسم المستعار..."
                className="w-full px-4 py-3 pl-10 rounded-2xl bg-cream-50 dark:bg-navy-950 border-2 border-cream-200 dark:border-navy-800 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900 dark:text-cream-100 placeholder:text-navy-400"
              />
              <SearchIcon className="w-4 h-4 text-navy-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {/* ===== الخطوة 1: الجنس (أول خيار) ===== */}
          <FilterSection icon={Users} title="أبحث عن" step={1}>
            <div className="grid grid-cols-3 gap-3">
              <GenderButton
                active={gender === 'all'} onClick={() => handleGenderChange('all')}
                label="الجميع" color="gold"
              />
              <GenderButton
                active={gender === 'male'} onClick={() => handleGenderChange('male')}
                label="رجال" color="blue"
              />
              <GenderButton
                active={gender === 'female'} onClick={() => handleGenderChange('female')}
                label="نساء" color="rose"
              />
            </div>
            {gender === 'all' && (
              <p className="text-xs text-navy-400 font-tajawal mt-2.5 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                عند اختيار «الجميع» تتوفر خيارات الدولة والمدينة والعمر فقط
              </p>
            )}
          </FilterSection>

          {/* ===== الخطوة 2: العمر ===== */}
          <FilterSection icon={Calendar} title="الفئة العمرية" step={2}>
            <div className="bg-cream-50 rounded-2xl p-4 border border-cream-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-navy-500 font-tajawal">من</span>
                <span className="font-cairo font-bold text-lg text-gold-700 bg-gold-300/15 px-3 py-1 rounded-lg">{ageRange[0]} سنة</span>
              </div>
              <input type="range" min="18" max="70" value={ageRange[0]}
                onChange={(e) => setAgeRange([Math.min(Number(e.target.value), ageRange[1]), ageRange[1]])}
                className="w-full accent-gold-500" />
            </div>
            <div className="bg-cream-50 rounded-2xl p-4 border border-cream-200 mt-3">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-navy-500 font-tajawal">إلى</span>
                <span className="font-cairo font-bold text-lg text-gold-700 bg-gold-300/15 px-3 py-1 rounded-lg">{ageRange[1]} سنة</span>
              </div>
              <input type="range" min="18" max="70" value={ageRange[1]}
                onChange={(e) => setAgeRange([ageRange[0], Math.max(Number(e.target.value), ageRange[0])])}
                className="w-full accent-gold-500" />
            </div>
          </FilterSection>

          {/* ===== الخطوة 3: الدولة والمدينة ===== */}
          <FilterSection icon={MapPin} title="الدولة والمدينة" step={3}>
            <div className="grid sm:grid-cols-2 gap-3">
              <SelectField icon={Globe} label="الدولة" value={country} onChange={(v) => { setCountry(v); setCity(''); }}
                options={countryOptions} placeholder="كل الدول" />
              <SelectField icon={MapPin} label="المدينة" value={city} onChange={setCity}
                options={cityOptions} placeholder="كل المدن" />
            </div>
          </FilterSection>

          {/* ===== زر المزيد من الخيارات ===== */}
          {gender !== 'all' && (
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="w-full flex items-center justify-between p-4 rounded-2xl bg-navy-gradient text-white font-cairo font-bold transition-all hover:shadow-luxe relative overflow-hidden"
            >
              <div className="absolute inset-0 pattern-arabesque opacity-20" />
              <span className="relative flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-gold-300" />
                {showAdvanced ? 'إخفاء الخيارات المتقدمة' : 'مزيد من الخيارات'}
              </span>
              <span className="relative">
                {showAdvanced ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
              </span>
            </button>
          )}

          {/* ===== الخيارات المتقدمة ===== */}
          <AnimatePresence>
            {showAdvanced && gender !== 'all' && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="space-y-5 pt-2 border-t border-cream-200">

                  {/* الحالة الاجتماعية — تتغير حسب الجنس */}
                  <div>
                    <label className="flex items-center gap-2 text-sm font-cairo font-bold text-navy-800 mb-2.5">
                      <Heart className="w-4 h-4 text-gold-600" /> الحالة الاجتماعية
                      <span className="text-[11px] font-normal text-navy-400">
                        ({gender === 'male' ? 'خيارات الرجال' : 'خيارات النساء'})
                      </span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {maritalOptions.map((opt) => (
                        <button
                          key={opt.value}
                          onClick={() => setMaritalStatus(maritalStatus === opt.value ? '' : opt.value)}
                          className={`py-2.5 px-2 rounded-xl font-cairo font-semibold text-sm transition-all no-tap-highlight ${
                            maritalStatus === opt.value
                              ? 'bg-gold-gradient text-navy-900 shadow-soft'
                              : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* عدد الأبناء — يظهر فقط للمطلق/الأرمل */}
                  {showChildrenOptions && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <label className="flex items-center gap-2 text-sm font-cairo font-bold text-navy-800 mb-2.5">
                        <Baby className="w-4 h-4 text-gold-600" /> الأبناء
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        <button
                          onClick={() => { setHasChildren('false'); setChildrenCount(''); }}
                          className={`py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all ${
                            hasChildren === 'false' ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
                          }`}
                        >
                          بدون أبناء
                        </button>
                        <button
                          onClick={() => setHasChildren('true')}
                          className={`py-2.5 rounded-xl font-cairo font-semibold text-sm transition-all ${
                            hasChildren === 'true' ? 'bg-gold-gradient text-navy-900 shadow-soft' : 'bg-cream-100 text-navy-600 hover:bg-cream-200'
                          }`}
                        >
                          لديه أبناء
                        </button>
                      </div>
                      {hasChildren === 'true' && (
                        <div className="mt-2">
                          <SelectField icon={Baby} label="عدد الأبناء" value={childrenCount} onChange={setChildrenCount}
                            options={CHILDREN_COUNTS.filter(c => c !== 'لا يوجد')} placeholder="اختر العدد" />
                        </div>
                      )}
                    </motion.div>
                  )}

                  {/* المذهب */}
                  <SelectField icon={BookOpen} label="المذهب" value={sect} onChange={setSect}
                    options={SECTS} placeholder="كل المذاهب" />

                  {/* الجنسية */}
                  <SelectField icon={Globe} label="الجنسية" value={nationality} onChange={setNationality}
                    options={nationalityOptions} placeholder="كل الجنسيات" />

                  {/* التعليم والوظيفة */}
                  <div className="grid sm:grid-cols-2 gap-3">
                    <SelectField icon={GraduationCap} label="التعليم" value={education} onChange={setEducation}
                      options={EDUCATION_LEVELS} placeholder="الكل" />
                    <SelectField icon={Briefcase} label="نوع العمل" value={job} onChange={setJob}
                      options={['حكومي', 'عمل حر', 'باحث عن عمل', 'طالب', 'بدون وظيفة']} placeholder="الكل" />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* زر البحث */}
          <Button onClick={handleSearch} fullWidth size="lg" className="shadow-gold">
            <SearchIcon className="w-5 h-5" /> ابحث الآن
          </Button>
        </div>
      </div>

      {/* عرض النتائج */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 mt-12 border-t border-cream-200/60">
        <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-cairo font-extrabold text-2xl text-navy-900">
              نتائج البحث ({filteredMembers.length})
            </h2>
            <p className="mt-1 text-sm text-navy-500 font-tajawal">
              {filteredMembers.length > 0
                ? 'مرتبة حسب الجدية والتميز — الأحدث أولاً'
                : 'لا توجد نتائج مطابقة. جرّب تعديل الفلاتر.'}
            </p>
          </div>
          {filteredMembers.length > 0 && (
            <div className="text-xs font-tajawal text-navy-500 bg-cream-100 px-4 py-2 rounded-2xl flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-gold-600" />
              نتائج مفلترة حسب اختيارك
            </div>
          )}
        </div>

        {membersError && members.length === 0 ? (
          <div className="py-20 text-center bg-white rounded-3xl border border-rose-200/70">
            <div className="w-16 h-16 rounded-full bg-rose-soft flex items-center justify-center mx-auto mb-4">
              <SearchIcon className="w-8 h-8 text-rose-deep" />
            </div>
            <p className="font-cairo font-bold text-navy-800 text-lg mb-1">تعذر تحميل الأعضاء</p>
            <p className="text-sm text-navy-500 font-tajawal mb-6">{membersError}</p>
            <Button onClick={retryLoadMembers}>إعادة المحاولة</Button>
          </div>
        ) : membersLoading && members.length === 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-5">
            <MemberGridSkeleton count={8} />
          </div>
        ) : filteredMembers.length > 0 ? (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-5">
              {visibleMembers.map((m) => (
                <MemberCard key={m.id} member={m} />
              ))}
            </div>
            {hasMore && (
              <div className="flex justify-center mt-8">
                <Button onClick={() => setVisibleCount((c) => c + PAGE_SIZE)} variant="outline" size="md">
                  عرض المزيد ({filteredMembers.length - visibleMembers.length} متبقٍ)
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="py-20 text-center">
            <SearchIcon className="w-16 h-16 text-navy-200 mx-auto mb-4" />
            <p className="font-cairo font-bold text-navy-700 text-lg mb-1">لا توجد نتائج مطابقة</p>
            <p className="text-sm text-navy-400 font-tajawal mb-6">جرّب توسيع نطاق البحث أو تعديل الفلاتر</p>
            <Button
              onClick={() => {
                setSearchQuery('');
                setGender('all');
                setAgeRange([18, 70]);
                setCountry('');
                setCity('');
                setNationality('');
                setEducation('');
                setJob('');
                setMaritalStatus('');
                setSect('');
                setHasChildren('');
                setChildrenCount('');
                setShowAdvanced(false);
              }}
              variant="outline"
              size="md"
            >
              إعادة ضبط الفلاتر
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ===== مكوّنات مساعدة ===== */

function FilterSection({ icon: Icon, title, step, children }: { icon: typeof Users; title: string; step: number; children: React.ReactNode }) {
  return (
    <div>
      <label className="flex items-center gap-2.5 mb-3">
        <span className="flex items-center justify-center w-7 h-7 rounded-lg bg-gold-300/20 text-gold-700 font-cairo font-bold text-sm flex-shrink-0">
          {step}
        </span>
        <span className="flex items-center gap-2 text-sm font-cairo font-bold text-navy-800">
          <Icon className="w-4 h-4 text-gold-600" /> {title}
        </span>
      </label>
      {children}
    </div>
  );
}

function GenderButton({ active, onClick, label, color }: { active: boolean; onClick: () => void; label: string; color: 'gold' | 'blue' | 'rose' }) {
  const colors = {
    gold: active ? 'bg-gold-gradient text-navy-900 shadow-soft' : '',
    blue: active ? 'bg-blue-500 text-white shadow-soft' : '',
    rose: active ? 'bg-rose-500 text-white shadow-soft' : '',
  };
  return (
    <button
      onClick={onClick}
      className={`py-3.5 rounded-xl font-cairo font-bold text-sm transition-all no-tap-highlight ${
        active ? colors[color] : 'bg-cream-100 dark:bg-navy-950 text-navy-600 dark:text-cream-200 hover:bg-cream-200 dark:hover:bg-navy-800'
      }`}
    >
      {label}
    </button>
  );
}

function SelectField({ icon: Icon, label, value, onChange, options, placeholder }: {
  icon: typeof Globe; label: string; value: string; onChange: (v: string) => void; options: string[]; placeholder: string;
}) {
  return (
    <div>
      <label className="flex items-center gap-2 text-xs font-cairo font-semibold text-navy-600 dark:text-cream-200 mb-1.5">
        <Icon className="w-3.5 h-3.5 text-gold-600" /> {label}
      </label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full px-4 py-3 rounded-xl bg-cream-50 dark:bg-navy-950 border-2 border-cream-200 dark:border-navy-800 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 dark:text-cream-100 appearance-none cursor-pointer"
        >
          <option value="">{placeholder}</option>
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
        <ChevronDown className="w-4 h-4 text-navy-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
      </div>
    </div>
  );
}
