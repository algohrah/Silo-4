import { dataService } from '../../lib/data/DataService';
import { useState, useEffect } from 'react';
import { FileText, Plus, Edit3, Trash2, Clock, Image as ImageIcon, Eye, HelpCircle, Save, Check, X } from 'lucide-react';
import { BLOG_POSTS, FAQS } from '../../lib/data';
import type { BlogPost } from '../../lib/types';
import Modal from '../../components/ui/Modal';

const BLOG_KEY = 'twafok_admin_blog_v1';
const FAQ_KEY = 'twafok_admin_faq_v1';

function loadBlog(): BlogPost[] {
  if (typeof window === 'undefined') return BLOG_POSTS;
  try {
    const raw = dataService.db.settings.get(BLOG_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  dataService.db.settings.set(BLOG_KEY, JSON.stringify(BLOG_POSTS));
  return BLOG_POSTS;
}

function saveBlog(posts: BlogPost[]) {
  if (typeof window !== 'undefined') {
    try { dataService.db.settings.set(BLOG_KEY, JSON.stringify(posts)); } catch { /* ignore */ }
  }
}

function loadFaqs(): { q: string; a: string }[] {
  if (typeof window === 'undefined') return FAQS;
  try {
    const raw = dataService.db.settings.get(FAQ_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  dataService.db.settings.set(FAQ_KEY, JSON.stringify(FAQS));
  return FAQS;
}

function saveFaqs(faqs: { q: string; a: string }[]) {
  if (typeof window !== 'undefined') {
    try { dataService.db.settings.set(FAQ_KEY, JSON.stringify(faqs)); } catch { /* ignore */ }
  }
}

export default function AdminContent() {
  const [activeTab, setActiveTab] = useState<'blog' | 'faq'>('blog');
  const [posts, setPosts] = useState<BlogPost[]>(BLOG_POSTS);
  const [faqs, setFaqs] = useState<{ q: string; a: string }[]>(FAQS);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [creatingPost, setCreatingPost] = useState(false);
  const [previewing, setPreviewing] = useState<BlogPost | null>(null);
  const [editingFaq, setEditingFaq] = useState<{ q: string; a: string; index: number } | null>(null);
  const [creatingFaq, setCreatingFaq] = useState(false);

  useEffect(() => {
    setPosts(loadBlog());
    setFaqs(loadFaqs());
  }, []);

  const handleDeletePost = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه التدوينة؟')) {
      const next = posts.filter((p) => p.id !== id);
      setPosts(next);
      saveBlog(next);
    }
  };

  const handleDeleteFaq = (index: number) => {
    const next = faqs.filter((_, i) => i !== index);
    setFaqs(next);
    saveFaqs(next);
  };

  const moveFaq = (index: number, dir: 'up' | 'down') => {
    setFaqs((prev) => {
      const next = [...prev];
      const target = dir === 'up' ? index - 1 : index + 1;
      if (target < 0 || target >= next.length) return prev;
      [next[index], next[target]] = [next[target], next[index]];
      saveFaqs(next);
      return next;
    });
  };

  const tabs = [
    { id: 'blog' as const, label: 'المدونة', icon: FileText },
    { id: 'faq' as const, label: 'الأسئلة الشائعة', icon: HelpCircle },
  ];

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900">إدارة المحتوى</h2>
          <p className="text-sm text-slate-500 font-tajawal">المدونة والأسئلة الشائعة — محفوظة فعلياً</p>
        </div>
        <div className="flex gap-2">
          {activeTab === 'blog' && (
            <button onClick={() => setCreatingPost(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors">
              <Plus className="w-4 h-4" /> تدوينة جديدة
            </button>
          )}
          {activeTab === 'faq' && (
            <button onClick={() => setCreatingFaq(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm hover:bg-slate-800 transition-colors">
              <Plus className="w-4 h-4" /> سؤال جديد
            </button>
          )}
        </div>
      </div>

      <div className="flex gap-2 border-b border-slate-200 pb-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-t-lg font-cairo font-bold text-xs transition-colors ${activeTab === tab.id ? 'text-slate-900 border-b-2 border-amber-500 bg-white' : 'text-slate-500 hover:text-slate-700'}`}>
              <Icon className="w-3.5 h-3.5" /> {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'blog' && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {posts.map((post) => (
            <div key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
              <div className="aspect-[16/10] bg-slate-100 relative overflow-hidden">
                {post.image ? (
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-300"><ImageIcon className="w-10 h-10" /></div>
                )}
                <span className="absolute top-2 right-2 px-2 py-1 rounded-md bg-white/90 backdrop-blur text-xs font-cairo font-bold text-slate-700">{post.category}</span>
              </div>
              <div className="p-4">
                <h3 className="font-cairo font-bold text-slate-900 text-sm mb-1 line-clamp-1">{post.title}</h3>
                <p className="text-xs text-slate-500 font-tajawal line-clamp-2 mb-3">{post.excerpt}</p>
                <div className="flex items-center gap-3 text-[10px] text-slate-400 font-tajawal mb-3">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{post.readTime}</span>
                  <span>{post.date}</span>
                  <span className="text-slate-300">·</span>
                  <span>{post.author}</span>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditingPost(post)} className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-amber-50 text-amber-600 text-xs font-cairo font-bold hover:bg-amber-100 transition-colors">
                    <Edit3 className="w-3.5 h-3.5" /> تعديل
                  </button>
                  <button onClick={() => setPreviewing(post)} className="flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-slate-100 text-slate-600 text-xs font-cairo font-bold hover:bg-slate-200 transition-colors">
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => handleDeletePost(post.id)} className="flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-rose-50 text-rose-600 text-xs font-cairo font-bold hover:bg-rose-100 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
          {posts.length === 0 && (
            <div className="col-span-full py-12 text-center">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-400 font-cairo text-sm">لا توجد تدوينات بعد</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'faq' && (
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
                  <HelpCircle className="w-5 h-5 text-slate-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-cairo font-bold text-slate-900 text-sm mb-1">{faq.q}</h3>
                  <p className="text-xs text-slate-600 font-tajawal leading-relaxed">{faq.a}</p>
                </div>
                <div className="flex flex-col gap-1">
                  <button onClick={() => moveFaq(i, 'up')} disabled={i === 0} className="p-1 rounded hover:bg-slate-100 disabled:opacity-30">▲</button>
                  <button onClick={() => moveFaq(i, 'down')} disabled={i === faqs.length - 1} className="p-1 rounded hover:bg-slate-100 disabled:opacity-30">▼</button>
                </div>
              </div>
              <div className="flex gap-2 mt-3 pt-3 border-t border-slate-50">
                <button onClick={() => setEditingFaq({ ...faq, index: i })} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-600 text-xs font-cairo font-bold hover:bg-amber-100 transition-colors">
                  <Edit3 className="w-3.5 h-3.5" /> تعديل
                </button>
                <button onClick={() => handleDeleteFaq(i)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 text-rose-600 text-xs font-cairo font-bold hover:bg-rose-100 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" /> حذف
                </button>
              </div>
            </div>
          ))}
          {faqs.length === 0 && (
            <div className="py-12 text-center">
              <HelpCircle className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-400 font-cairo text-sm">لا توجد أسئلة شائعة بعد</p>
            </div>
          )}
        </div>
      )}

      <Modal open={creatingPost || !!editingPost} onClose={() => { setCreatingPost(false); setEditingPost(null); }} title={editingPost ? 'تعديل التدوينة' : 'تدوينة جديدة'} size="lg">
        <BlogForm post={editingPost} onSave={(post) => {
          if (editingPost) {
            const next = posts.map((p) => (p.id === post.id ? post : p));
            setPosts(next); saveBlog(next);
          } else {
            const next = [{ ...post, id: 'b' + Date.now() }, ...posts];
            setPosts(next); saveBlog(next);
          }
          setCreatingPost(false); setEditingPost(null);
        }} />
      </Modal>

      <Modal open={creatingFaq || !!editingFaq} onClose={() => { setCreatingFaq(false); setEditingFaq(null); }} title={editingFaq ? 'تعديل السؤال' : 'سؤال جديد'}>
        <FAQForm faq={editingFaq} onSave={(faq) => {
          if (editingFaq) {
            const next = faqs.map((f, i) => (i === editingFaq.index ? faq : f));
            setFaqs(next); saveFaqs(next);
          } else {
            const next = [...faqs, faq];
            setFaqs(next); saveFaqs(next);
          }
          setCreatingFaq(false); setEditingFaq(null);
        }} />
      </Modal>

      <Modal open={!!previewing} onClose={() => setPreviewing(null)} title="معاينة التدوينة" size="lg">
        {previewing && (
          <div>
            {previewing.image && (
              <div className="aspect-[16/9] rounded-2xl overflow-hidden mb-4 bg-slate-100">
                <img src={previewing.image} alt={previewing.title} className="w-full h-full object-cover" />
              </div>
            )}
            <span className="inline-block px-2.5 py-1 rounded-full bg-amber-50 text-amber-600 text-xs font-cairo font-bold mb-2">{previewing.category}</span>
            <h3 className="font-cairo font-extrabold text-xl text-slate-900 mb-2">{previewing.title}</h3>
            <p className="text-sm text-slate-500 font-tajawal mb-4">{previewing.excerpt}</p>
            <div className="prose prose-sm max-w-none">
              {previewing.content.split('\n').map((line, i) => {
                if (line.startsWith('## ')) return <h4 key={i} className="font-cairo font-bold text-slate-900 mt-3 mb-1">{line.replace('## ', '')}</h4>;
                if (line.trim()) return <p key={i} className="text-slate-600 font-tajawal leading-relaxed mb-2">{line}</p>;
                return null;
              })}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function FAQForm({ faq, onSave }: { faq: { q: string; a: string } | null; onSave: (f: { q: string; a: string }) => void }) {
  const [q, setQ] = useState(faq?.q || '');
  const [a, setA] = useState(faq?.a || '');
  const inputClass = 'w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm';
  const labelClass = 'block text-xs font-cairo font-bold text-slate-700 mb-1.5';
  return (
    <div className="space-y-4">
      <div>
        <label className={labelClass}>السؤال</label>
        <input value={q} onChange={(e) => setQ(e.target.value)} className={inputClass} placeholder="اكتب السؤال..." />
      </div>
      <div>
        <label className={labelClass}>الجواب</label>
        <textarea value={a} onChange={(e) => setA(e.target.value)} rows={4} className={inputClass + ' resize-none'} placeholder="اكتب الجواب..." />
      </div>
      <button onClick={() => onSave({ q, a })} disabled={!q.trim() || !a.trim()} className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50">حفظ</button>
    </div>
  );
}

function BlogForm({ post, onSave }: { post: BlogPost | null; onSave: (p: BlogPost) => void }) {
  const [form, setForm] = useState<BlogPost>(
    post || { id: '', title: '', excerpt: '', content: '', category: 'نصائح', author: 'فريق توافق', date: 'اليوم', readTime: '5 دقائق', image: '' }
  );
  const inputClass = 'w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900 text-sm';
  const labelClass = 'block text-xs font-cairo font-bold text-slate-700 mb-1.5';
  return (
    <div className="space-y-4">
      <div>
        <label className={labelClass}>رابط صورة الغلاف</label>
        <input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} className={inputClass} placeholder="https://example.com/image.jpg" dir="ltr" />
      </div>
      <div>
        <label className={labelClass}>عنوان التدوينة</label>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className={inputClass} placeholder="عنوان جذاب..." />
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>التصنيف</label>
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={inputClass}>
            <option>نصائح</option><option>علاقات</option><option>عائلة</option><option>إيمان</option><option>قصص نجاح</option>
          </select>
        </div>
        <div>
          <label className={labelClass}>الكاتب</label>
          <input value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} className={inputClass} />
        </div>
      </div>
      <div>
        <label className={labelClass}>المقتطف</label>
        <textarea value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} rows={2} className={inputClass + ' resize-none'} placeholder="ملخص قصير..." />
      </div>
      <div>
        <label className={labelClass}>المحتوى الكامل</label>
        <textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={7} className={inputClass + ' resize-none'} placeholder="اكتب المحتوى... استخدم ## للعناوين الفرعية" />
      </div>
      <button onClick={() => onSave(form)} disabled={!form.title.trim() || !form.excerpt.trim()} className="w-full py-3 rounded-xl bg-slate-900 text-white font-cairo font-bold hover:bg-slate-800 transition-colors disabled:opacity-50">
        {post ? 'حفظ التغييرات' : 'نشر التدوينة'}
      </button>
    </div>
  );
}
