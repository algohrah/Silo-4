import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, Eye, EyeOff, ArrowLeft, ShieldCheck } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { getAvatar } from '../lib/types';
import { useApp } from '../lib/AppContext';
import supabase from '../lib/supabase';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { loginWithSession } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // الصفحة اللي كان يبيها المستخدم قبل ما يُحوّل لتسجيل الدخول
  const from = (location.state as { from?: string })?.from || '/profile';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // مصادقة حقيقية عبر Supabase Auth — لا مقارنة لكلمات المرور في المتصفح إطلاقاً
      const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (signInError) {
        setError('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
        setLoading(false);
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      const res = await fetch('/api/whoami', { headers: token ? { Authorization: `Bearer ${token}` } : {} });
      const who = await res.json();

      // المشرف الحقيقي (مسجّل في admin_users) يدخل مباشرةً للوحة الإدارة ولو لم يكن له ملف عضو
      if (who?.isAdmin) {
        if (who.member) loginWithSession(who.member, who.authUser?.email || email);
        navigate('/admin');
        return;
      }

      if (!who?.member) {
        setError('لم يتم العثور على ملف عضو مرتبط بهذا الحساب. يرجى إنشاء حساب جديد.');
        await supabase.auth.signOut();
        setLoading(false);
        return;
      }

      loginWithSession(who.member, who.authUser?.email || email);
      navigate(from);
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ غير متوقع، حاول مرة أخرى');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] grid lg:grid-cols-2">
      {/* Visual side */}
      <div className="hidden lg:flex relative bg-navy-gradient items-center justify-center p-12 overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="absolute -top-20 -left-20 w-80 h-80 bg-gold-500/20 rounded-full blur-3xl" />
        <div className="relative max-w-md text-center">
          <div className="grid grid-cols-2 gap-3 mb-8">
            <img src={getAvatar('female')} alt="" className="rounded-3xl shadow-2xl w-full aspect-[3/4] object-cover ring-1 ring-gold-500/30 bg-cream-100" />
            <img src={getAvatar('male')} alt="" className="rounded-3xl shadow-2xl w-full aspect-[3/4] object-cover ring-1 ring-gold-500/30 bg-cream-100" />
          </div>
          <h2 className="font-cairo font-extrabold text-3xl text-white leading-tight">مرحبًا بعودتك إلى <span className="text-gradient-gold">توافق</span></h2>
          <p className="mt-4 text-cream-200/80 font-tajawal leading-relaxed">سجّل الدخول لمتابعة رحلتك نحو شريك الحياة المناسب.</p>
          <div className="mt-6 inline-flex items-center gap-2 text-sm text-emerald-300 bg-emerald-500/10 px-4 py-2 rounded-full">
            <ShieldCheck className="w-4 h-4" /> دخول آمن ومحمي
          </div>
        </div>
      </div>

      {/* Form side */}
      <div className="flex items-center justify-center p-6 sm:p-12 bg-cream-50">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <Link to="/" className="inline-flex items-center gap-2 text-navy-600 hover:text-gold-700 font-cairo font-semibold text-sm mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" /> العودة للرئيسية
          </Link>

          <h1 className="font-cairo font-extrabold text-3xl text-navy-900">تسجيل الدخول</h1>
          <p className="mt-2 text-navy-600 font-tajawal">أدخل بياناتك للوصول إلى حسابك</p>

          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-3 text-sm font-tajawal">
                {error}
              </div>
            )}
            <div>
              <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@email.com"
                  className="w-full pr-12 pl-4 py-3.5 rounded-2xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors text-right"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-cairo font-semibold text-navy-800">كلمة المرور</label>
                <Link to="/forgot-password" className="text-xs text-gold-700 font-cairo font-semibold hover:underline">نسيت كلمة المرور؟</Link>
              </div>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type={showPass ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-12 pl-12 py-3.5 rounded-2xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors text-right"
                  dir="ltr"
                />
                <button type="button" onClick={() => setShowPass(!showPass)} aria-label={showPass ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'} className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <Button type="submit" fullWidth size="lg" disabled={loading}>{loading ? 'جارٍ الدخول...' : 'دخول'}</Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-navy-600 font-tajawal">ليس لديك حساب؟</p>
            <Link to="/register" className="inline-block mt-1 font-cairo font-bold text-gold-700 hover:underline">أنشئ حسابًا جديدًا</Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
