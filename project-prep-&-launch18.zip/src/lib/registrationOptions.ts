import * as C from './constants';

export type RegistrationGender = 'male' | 'female' | '';

export const COUNTRY_NATIONALITY_MAP: Record<string, { male: string; female: string; neutral?: string }> = {
  'السعودية': { male: 'سعودي', female: 'سعودية' },
  'الإمارات': { male: 'إماراتي', female: 'إماراتية' },
  'الكويت': { male: 'كويتي', female: 'كويتية' },
  'قطر': { male: 'قطري', female: 'قطرية' },
  'البحرين': { male: 'بحريني', female: 'بحرينية' },
  'عمان': { male: 'عماني', female: 'عمانية' },
  'مصر': { male: 'مصري', female: 'مصرية' },
  'سوريا': { male: 'سوري', female: 'سورية' },
  'الأردن': { male: 'أردني', female: 'أردنية' },
  'اليمن': { male: 'يمني', female: 'يمنية' },
  'العراق': { male: 'عراقي', female: 'عراقية' },
  'لبنان': { male: 'لبناني', female: 'لبنانية' },
  'فلسطين': { male: 'فلسطيني', female: 'فلسطينية' },
  'السودان': { male: 'سوداني', female: 'سودانية' },
  'ليبيا': { male: 'ليبي', female: 'ليبية' },
  'تونس': { male: 'تونسي', female: 'تونسية' },
  'الجزائر': { male: 'جزائري', female: 'جزائرية' },
  'المغرب': { male: 'مغربي', female: 'مغربية' },
  'موريتانيا': { male: 'موريتاني', female: 'موريتانية' },
  'الصومال': { male: 'صومالي', female: 'صومالية' },
  'جيبوتي': { male: 'جيبوتي', female: 'جيبوتية' },
  'جزر القمر': { male: 'قمري', female: 'قمرية' },
  'تركيا': { male: 'تركي', female: 'تركية' },
  'المملكة المتحدة': { male: 'بريطاني', female: 'بريطانية' },
  'أمريكا (الولايات المتحدة)': { male: 'أمريكي', female: 'أمريكية' },
  'كندا': { male: 'كندي', female: 'كندية' },
  'ألمانيا': { male: 'ألماني', female: 'ألمانية' },
  'السويد': { male: 'سويدي', female: 'سويدية' },
  'فرنسا': { male: 'فرنسي', female: 'فرنسية' },
};

export const SELF_MARITAL_MALE = [
  { value: 'single', label: 'أعزب' },
  { value: 'married', label: 'متزوج' },
  { value: 'divorced', label: 'مطلق' },
  { value: 'widower', label: 'أرمل' },
];

export const SELF_MARITAL_FEMALE = [
  { value: 'single', label: 'عزباء' },
  { value: 'married', label: 'متزوجة' },
  { value: 'divorced', label: 'مطلقة' },
  { value: 'widow', label: 'أرملة' },
];

export const PARTNER_MARITAL_FOR_MALE = [
  'لا يهم',
  'عزباء',
  'مطلقة',
  'أرملة',
];

export const PARTNER_MARITAL_FOR_FEMALE = [
  'لا يهم',
  'أعزب',
  'متزوج',
  'مطلق',
  'أرمل',
];

export function getSelfMaritalOptions(gender: RegistrationGender) {
  if (gender === 'female') return SELF_MARITAL_FEMALE;
  return SELF_MARITAL_MALE;
}

export function getPartnerMaritalOptions(userGender: RegistrationGender) {
  return userGender === 'male' ? PARTNER_MARITAL_FOR_MALE : PARTNER_MARITAL_FOR_FEMALE;
}

export function getPartnerTerms(userGender: RegistrationGender) {
  const seekingFemale = userGender === 'male';
  return {
    partnerLabel: seekingFemale ? 'الشريكة' : 'الشريك',
    partnerFullLabel: seekingFemale ? 'شريكة الحياة' : 'شريك الحياة',
    nationalityLabel: seekingFemale ? 'جنسية الشريكة المطلوبة' : 'جنسية الشريك المطلوبة',
    countryLabel: seekingFemale ? 'دولة إقامة الشريكة' : 'دولة إقامة الشريك',
    cityLabel: seekingFemale ? 'مدينة الشريكة' : 'مدينة الشريك',
    maritalLabel: seekingFemale ? 'الحالة الاجتماعية للشريكة' : 'الحالة الاجتماعية للشريك',
    ageLabel: seekingFemale ? 'عمر الشريكة المناسب' : 'عمر الشريك المناسب',
    childrenLabel: seekingFemale ? 'هل تقبل أن تكون لديها أبناء؟' : 'هل تقبلين أن يكون لديه أبناء؟',
    notesPlaceholder: seekingFemale
      ? 'اكتب صفات الشريكة المناسبة لك مثل الخلق، التعليم، المدينة، قبول السكن...'
      : 'اكتبي صفات الشريك المناسب لك مثل الخلق، الاستقرار، التعليم، المدينة...',
  };
}

export function getNationalityForCountry(country: string, gender: RegistrationGender) {
  const item = COUNTRY_NATIONALITY_MAP[country];
  if (!item) return country || '';
  if (gender === 'female') return item.female;
  if (gender === 'male') return item.male;
  return item.neutral || `${item.male}/${item.female}`;
}

export function getNationalityOptions(gender: RegistrationGender, countries: string[] = C.COUNTRIES) {
  const mapped = countries
    .filter((country) => country && country !== 'أخرى')
    .map((country) => getNationalityForCountry(country, gender))
    .filter(Boolean);

  const extra = C.NATIONALITIES
    .filter((item) => item && !countries.includes(item) && !item.includes('/ة') && item !== 'جنسية أخرى' && item !== 'أخرى')
    .map((item) => item.replace('/ة', gender === 'female' ? 'ة' : ''));

  return Array.from(new Set([...mapped, ...extra, 'أخرى']));
}

export function shouldAskChildren(maritalStatus: string) {
  return ['divorced', 'widower', 'widow', 'widowed', 'married', 'مطلق', 'مطلقة', 'أرمل', 'أرملة', 'متزوج', 'متزوجة'].includes(maritalStatus);
}

export function isMarriedMale(gender: RegistrationGender, maritalStatus: string) {
  return gender === 'male' && ['married', 'متزوج'].includes(maritalStatus);
}

export function normalizeMaritalLabel(status: string, gender: RegistrationGender) {
  const options = getSelfMaritalOptions(gender);
  return options.find((option) => option.value === status || option.label === status)?.label || status;
}
