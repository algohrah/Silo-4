import type { ReactNode } from 'react';

// ============================================================
//  رأس صفحة موحّد لكل أقسام لوحة الإدارة — يضمن نفس الحجم واللون
//  والتباعد في كل الصفحات (كان متكرراً يدوياً بأشكال متفاوتة قليلاً).
// ============================================================

interface PageHeaderProps {
  icon?: React.ElementType;
  title: string;
  subtitle?: string;
  /** عنصر إجراء اختياري يظهر على يمين الرأس (زر إضافة/تصدير/حفظ...) */
  action?: ReactNode;
}

export default function PageHeader({ icon: Icon, title, subtitle, action }: PageHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          {Icon && <Icon className="w-5 h-5 text-amber-500 flex-shrink-0" />}
          {title}
        </h2>
        {subtitle && <p className="text-sm text-slate-500 font-tajawal mt-0.5">{subtitle}</p>}
      </div>
      {action && <div className="flex-shrink-0">{action}</div>}
    </div>
  );
}
