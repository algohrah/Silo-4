# دليل الاستيراد السريع — بناء قاعدة البيانات بالكامل بدون أخطاء

هذا الدليل موجَّه بشكل مباشر لأي وكيل ذكاء اصطناعي (أو مطوّر) يستورد هذا المشروع في بيئة جديدة.
اتبع الخطوات **بالترتيب المحدد بالضبط** — الترتيب مهم لتفادي أخطاء الاعتماد بين الجداول
(بعض السياسات تستعلم عن جداول أخرى يجب أن تكون موجودة أولاً).

> **المرجع الكامل للأعمدة والأنواع:** [`../DATABASE_SCHEMA.md`](../DATABASE_SCHEMA.md) — اقرأه أولاً إذا احتجت تفاصيل أي عمود.
> **بيانات النسخة الاحتياطية الفعلية:** مجلد [`backup/`](./backup) — ملف JSON واحد لكل جدول بمحتواه الحالي.

---

## الخطوة 0 — نشر الكود أولاً

1. استورد كل ملفات المشروع كما هي (`src/`, `api/`, `public/`, ملفات الإعداد في الجذر).
2. **لا تنسخ** `vercel.json` أو `.env` الحقيقيين (تم استبعادهما من الأرشيف عمداً). استخدم
   `vercel.json.example` و`.env.example` كقالب، واملأهما بمفاتيح مشروع Supabase **الجديد** الخاص بالبيئة الحالية
   (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, ...).
3. **لا تُعدّل** `api/db-client.js` أو `api/db-wake.js` — هذان الملفان مصمَّمان للعمل تلقائياً مع أي مشروع Supabase جديد بمجرد ضبط متغيرات البيئة.

---

## الخطوة 1 — إنشاء الجداول (بالترتيب بالضبط)

استخدم أداة `supabase_create_table` لكل جدول من الجداول التالية **بهذا الترتيب**، وبنفس الأعمدة والأنواع
الموصوفة بالتفصيل في `DATABASE_SCHEMA.md` (القسم 2). الترتيب هنا لا يفرضه أي قيد FK حقيقي (لا توجد قيود
مرجعية صريحة في هذا التصميم)، لكن اتّباعه يطابق منطق الاعتماد المفهومي بين الجداول:

1. `members`
2. `admin_users`
3. `member_auth_links`
4. `interest_requests`
5. `notifications`
6. `transactions`
7. `coupons`
8. `support_tickets`
9. `inquiry_messages`
10. `verification_docs`
11. `geo_countries`
12. `geo_cities`
13. `pending_cities`
14. `geo_nationalities`
15. `geo_suggestions`
16. `settings`
17. `member_reports`
18. `exemption_requests`
19. `audit_logs`
20. `rate_limits`

**لا تخترع أعمدة أو تُغيّر أنواعها** — أي اختلاف عن `DATABASE_SCHEMA.md` سيكسر توافق مسارات `api/*.js` الحالية
(الملفات تفترض أسماء الأعمدة بالضبط كما وردت هناك، مثل `marital_status` و`about_partner` و`journey_stage`).

---

## الخطوة 2 — تفعيل الأمان (Row Level Security) — بالضبط بهذا الترتيب

### أ. سياسة الحظر الافتراضية على كل الجداول العشرين (نفّذها أولاً على الكل)

لكل جدول من الجداول العشرين المذكورة أعلاه، أنشئ سياسة واحدة بهذه المواصفات الحرفية:

```
policy_name: deny_all_direct_access
operation:   ALL
using:       false
```

هذا يمنع أي وصول مباشر من العميل (anon/authenticated) ويجعل الوصول الوحيد عبر
`SUPABASE_SERVICE_ROLE_KEY` المستخدَم داخل `api/db-client.js` على الخادم.

### ب. سياسات SELECT الإضافية (مطلوبة لتشغيل Supabase Realtime الفعلي)

سياسة `deny_all_direct_access` تمنع أيضاً تسليم أحداث Realtime لأن Supabase يتحقق من RLS قبل البث.
لذلك، **بعد** تنفيذ سياسات الحظر أعلاه، أضف سياسات SELECT الإضافية التالية بالترتيب (كل سياسة قد تعتمد
على وجود جدول آخر في شرطها، فرتبها كما يلي):

| # | الجدول | اسم السياسة | العملية | التعبير (using_expression) |
|---|---|---|---|---|
| 1 | `member_auth_links` | `own_link_select` | SELECT | `auth_user_id = auth.uid()` |
| 2 | `admin_users` | `own_admin_check_select` | SELECT | `email = auth.email()` |
| 3 | `interest_requests` | `party_or_admin_select` | SELECT | `EXISTS (SELECT 1 FROM member_auth_links mal WHERE mal.auth_user_id = auth.uid() AND (mal.member_id = interest_requests.sender_id OR mal.member_id = interest_requests.receiver_id)) OR EXISTS (SELECT 1 FROM admin_users au WHERE au.email = auth.email())` |
| 4 | `notifications` | `own_notifications_select` | SELECT | `user_id = 'all' OR EXISTS (SELECT 1 FROM member_auth_links mal WHERE mal.auth_user_id = auth.uid() AND mal.member_id = notifications.user_id) OR EXISTS (SELECT 1 FROM admin_users au WHERE au.email = auth.email())` |
| 5 | `inquiry_messages` | `party_or_admin_select` | SELECT | `EXISTS (SELECT 1 FROM interest_requests ir WHERE ir.id = inquiry_messages.request_id) OR EXISTS (SELECT 1 FROM admin_users au WHERE au.email = auth.email())` |

> **لماذا هذا الترتيب؟** السياسة رقم 3 تستعلم عن `member_auth_links` و`admin_users`، والسياسة رقم 5
> تستعلم عن `interest_requests` و`admin_users` — لذا يجب أن تُنشأ الجداول المُستعلَم عنها أولاً (وهي منشأة
> بالفعل من الخطوة 1، لكن التزم بترتيب إنشاء *السياسات* كما هو مذكور تجنباً لأي لبس عند التنفيذ اليدوي).

---

## الخطوة 3 — إنشاء حاوية التخزين (Storage)

```
bucket_name: verification-docs
public: true
```

تُستخدم لرفع وثائق توثيق الهوية عبر `api/verification-docs.js`.

---

## الخطوة 4 — استرجاع البيانات من النسخة الاحتياطية (Seed / Restore)

استخدم أداة `supabase_insert` لكل ملف في مجلد [`backup/`](./backup)، **بالترتيب المحدد في `backup/manifest.json`**
(حقل `order`). كل ملف JSON هو مصفوفة صفوف جاهزة للإدراج مباشرة بأسماء الأعمدة الصحيحة (snake_case) كما
في قاعدة البيانات الفعلية — لا حاجة لأي تحويل.

الترتيب الموصى به (مطابق لـ `manifest.json`):

1. `admin_users.json`
2. `members.json`
3. `member_auth_links.json` *(فارغ حالياً — لا شيء لإدراجه)*
4. `geo_countries.json`
5. `geo_cities.json`
6. `pending_cities.json` *(فارغ)*
7. `geo_nationalities.json`
8. `geo_suggestions.json` *(فارغ)*
9. `settings.json`
10. `interest_requests.json` *(فارغ)*
11. `notifications.json` *(فارغ)*
12. `transactions.json` *(فارغ)*
13. `coupons.json` *(فارغ)*
14. `support_tickets.json` *(فارغ)*
15. `inquiry_messages.json` *(فارغ)*
16. `verification_docs.json` *(فارغ)*
17. `member_reports.json` *(فارغ)*
18. `exemption_requests.json` *(فارغ)*
19. `audit_logs.json`
20. `rate_limits.json` *(فارغ)*

**تخطَّ الملفات الفارغة (`[]`) دون استدعاء `supabase_insert` لها** — استدعاء الإدراج بمصفوفة فارغة غير
مطلوب ولا يضيف شيئاً.

> ملاحظة حول `members.json`: كل الصفوف فيها بحقل `password: null` — هذا **متعمَّد** ومطلوب، لأن المصادقة
> الحقيقية لهؤلاء الأعضاء التجريبيين تتم فقط عبر Supabase Auth (وليس عبر حقل password في قاعدة البيانات).
> هؤلاء الأعضاء (m1–m6) **لا يملكون حسابات Supabase Auth فعلية** بعد الاستيراد — إن رغبت بتجربة تسجيل
> الدخول كأحدهم، أنشئ حساب Auth حقيقي بنفس بريده عبر `supabase_auth_create_user` ثم أضف صفاً مطابقاً في
> `member_auth_links` يربط `auth_user_id` الجديد بـ `member_id` الصحيح.

---

## الخطوة 5 — إنشاء حساب المصادقة الإداري (Supabase Auth) — إلزامي

هذه الخطوة **حرجة** ولا يمكن تخطّيها: بدون حساب Auth حقيقي بنفس البريد الموجود في `admin_users`،
لن يستطيع أي مشرف الدخول إلى `/admin` — لأن `api/_auth.js` يتحقق من تطابق بريد جلسة Supabase Auth
الحقيقية مع صف موجود في `admin_users`، وليس من أي كلمة سر مخزَّنة.

```
supabase_auth_create_user(
  email = "algohrah4u@gmail.com"   -- نفس القيمة الموجودة في backup/admin_users.json
  password = "<اختر كلمة سر قوية للبيئة الجديدة>"
)
```

إذا أردت مشرفين إضافيين، أضف صفاً مطابقاً لكل واحد منهم في `admin_users` (نفس البريد بالضبط)، ثم أنشئ
له حساب Auth بالبريد نفسه.

---

## الخطوة 6 — التحقق من متغيرات البيئة (Checklist)

قبل البناء، تأكد من ضبط كل هذه المتغيرات في `.env` وفي إعدادات النشر (Vercel):

- [ ] `NEXT_PUBLIC_SUPABASE_URL`
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- [ ] `SUPABASE_SERVICE_ROLE_KEY`
- [ ] `VITE_SUPABASE_URL`
- [ ] `VITE_SUPABASE_ANON_KEY`
- [ ] `VITE_GOOGLE_CLIENT_ID` (اختياري — فقط إذا رغبت بتفعيل تسجيل الدخول بجوجل)
- [ ] `VITE_GOOGLE_AUTH_PROXY` (اختياري، يبقى كما هو: `https://designarena.ai/auth/google/callback`)
- [ ] `FULLSTACK_PROJECT_REF` (خاص ببيئة Design Arena لاستعادة القاعدة عند التوقف)
- [ ] `FULLSTACK_RESTORE_API_URL` (خاص ببيئة Design Arena، يبقى كما هو)

---

## الخطوة 7 — البناء والتشغيل

```bash
npm install
npm run build   # يجب أن ينتهي بدون أخطاء (vite build)
```

ثم نشر المشروع (`deploy_to_vercel` أو ما يعادلها في بيئتك).

---

## الخطوة 8 — التحقق النهائي (Smoke Test) بعد النشر

تحقق من كل هذه السلوكيات فعلياً بعد النشر لتأكيد أن الاستيراد نجح بالكامل دون نقص:

1. **الصفحة الرئيسية** تعرض أعضاءً حقيقيين (وليس فارغة) — تأكيد أن `members` استُعيدت بنجاح.
2. **صفحة البحث** تعرض نفس الأعضاء مع فلاتر الدول/المدن/الجنسيات تعمل — تأكيد بيانات `geo_*`.
3. **تسجيل الدخول للوحة الإدارة** (`/admin`) بحساب `algohrah4u@gmail.com` وكلمة السر التي حدّدتها في
   الخطوة 5 — تأكيد `admin_users` + Supabase Auth مرتبطان بشكل صحيح.
4. **إنشاء حساب عضو جديد** من `/register` وتسجيل الدخول به من `/login` — تأكيد أن `member_auth_links`
   والمصادقة الحقيقية تعملان معاً.
5. **إرسال طلب اهتمام بين عضوين حقيقيين** (بعد تسجيلهما) ومتابعة رحلة التوافق — تأكيد `interest_requests`
   و`notifications` وسياسات RLS الخاصة بها.
6. **فتح `/admin/settings/platform`** والتأكد من ظهور القيم المستعادة (اسم المنصة، سياسة الخصوصية...) —
   تأكيد استعادة `settings` بنجاح.
7. **فتح `/admin/audit-log`** — يجب أن يظهر السجل التاريخي المستعاد إن أدرجته، وأي إجراء إداري جديد يُسجَّل فوراً.

إذا نجحت كل النقاط أعلاه، فالاستيراد اكتمل بنجاح ودون أي نقص في قاعدة البيانات أو الخيارات.
