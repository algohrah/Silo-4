import { useEffect, useMemo, useState } from 'react';
import type { FormEvent, MouseEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, BadgeCheck, CalendarClock, CheckCircle2, ChevronDown,
  FileCheck, HeartHandshake, Search, Send, ShieldCheck, Users,
  Award, Scale, Heart, Lock, Sparkles, MessageCircle, ExternalLink,
  PlusCircle, Radio, FileText, User, Share2
} from 'lucide-react';
import MemberCard from '../components/MemberCard';
import { MemberGridSkeleton } from '../components/ui/MemberCardSkeleton';
import { useApp } from '../lib/AppContext';
import { getMemberTimestamp } from '../lib/memberUtils';
import { dataService } from '../lib/data/DataService';
import { COUNTRIES, CITIES_BY_COUNTRY } from '../lib/constants';
import { isFeatured } from '../../shared/membership.js';
import heroCourtyard from '../assets/images/qatar_heritage_courtyard_1793817562228.jpg';

const overviewSteps = [
  { icon: Search, title: 'ابحث واختر', description: 'تصفّح المعلومات ومواصفات الشريك قبل إرسال الطلب.' },
  { icon: Send, title: 'أرسل طلب توافق', description: 'ينتظر الطلب الموافقة المبدئية قبل متابعة الخطوات.' },
  { icon: HeartHandshake, title: 'تابع من حسابك', description: 'اعرف الإجراء التالي وتابع التنسيق وحالة طلبك.' },
];

const journeySteps = [
  { icon: Send, title: 'طلب التوافق', description: 'اختر الملف المناسب وأرسل طلبك.' },
  { icon: HeartHandshake, title: 'الموافقة المبدئية', description: 'يمكن للطرف الآخر قبول الطلب أو الاعتذار عنه.' },
  { icon: ShieldCheck, title: 'تأكيد الجدية', description: 'بعد الموافقة المبدئية، يسدّد كل طرف رسوم الجدية المطلوبة لمتابعة التنسيق.' },
  { icon: CalendarClock, title: 'تنسيق التواصل', description: 'تُحدّد الخطوات بحسب نوع الملف، وتُشارك وسائل التواصل بموافقة الأطراف.' },
  { icon: Users, title: 'النظرة وقرار الطرفين', description: 'يحدّد كل طرف رغبته في الاستمرار أو الاعتذار بعد النظرة الشرعية.' },
  { icon: CheckCircle2, title: 'استكمال الرحلة', description: 'عند اتفاق الطرفين، تُتابع الإجراءات والأتعاب المستحقة وفق الشروط.' },
];

const serviceOptions = [
  { number: '01', title: 'الحساب والبحث الأساسي', label: 'مجاني', description: 'أنشئ ملفك، وابحث بحسب الجنس والدولة والمدينة والعمر، وأرسل طلبات ضمن حدود الحساب.' },
  { number: '02', title: 'توافق مميز', label: 'عضوية اختيارية', description: 'فلاتر بحث إضافية، وحد أعلى للطلبات، وتمييز لملفك. لا تشمل العضوية رسوم رحلة التوافق.' },
  { number: '03', title: 'رسوم رحلة التوافق', label: 'بحسب المرحلة', description: 'رسوم جدية وأتعاب لاحقة وفق شروط الرحلة. راجع المبلغ والضريبة وشروط الاسترداد قبل السداد.' },
];

const faqs = [
  { question: 'هل أحتاج إلى اشتراك لأبدأ؟', answer: 'لا. التسجيل والبحث الأساسي متاحان مجانًا، ويمكنك إرسال طلبات توافق ضمن حدود الحساب. توافق مميز عضوية اختيارية لمزايا إضافية، وليس شرطًا لبدء البحث.' },
  { question: 'هل العضوية المميزة تشمل رسوم الرحلة؟', answer: 'لا. العضوية المميزة ورسوم رحلة التوافق خدمتان مستقلتان. راجع تفاصيل كل خدمة والمبلغ المعروض قبل الشراء أو السداد.' },
  { question: 'ما الفرق بين العضو المسجّل وملف الوساطة؟', answer: 'العضو المسجّل لديه حساب يتابع منه طلباته. أما ملف الوساطة فتضيفه الإدارة، وتتولى التنسيق بشأنه مع الخطابة أو الجهة المعنية؛ ولا يعني ظهوره أن صاحبه يستخدم حسابًا نشطًا على المنصة.' },
  { question: 'هل جميع الملفات موثّقة؟', answer: 'لا. شارة التوثيق منفصلة عن العضوية المميزة ووسام الجدية. وجود إحدى هذه الشارات لا يعني وجود الشارات الأخرى، ولا يضمن صحة كل معلومة أو نجاح التوافق.' },
  { question: 'ما المعلومات الظاهرة؟ ومتى تُشارك وسائل التواصل؟', answer: 'تُعرض معلومات الملف ومواصفات الشريك للمتصفحين. وفي رحلة الأعضاء المسجّلين يكتب كل طرف وسائل التواصل التي يختار مشاركتها ويؤكد إرسالها. أما ملفات الوساطة فيتولى الفريق التنسيق بشأنها. لا تضع أرقامًا أو بيانات حساسة في النبذة العامة.' },
  { question: 'هل قبول الطلب أو دفع الرسوم يضمن الزواج؟', answer: 'لا. الموافقة المبدئية ليست اتفاقًا نهائيًا، والرسوم لا تضمن إتمام الزواج. الاستمرار أو الاعتذار قرار للطرفين، وتخضع المدفوعات للشروط المعروضة عند السداد.' },
  { question: 'كيف أبلغ عن ملف أو أطلب مساعدة؟', answer: 'استخدم خيار الإبلاغ من ملف العضو عند وجود مخالفة. وللاستفسارات العامة افتح صفحة «اتصل بنا»، أو تواصل مع الإدارة من حسابك لمتابعة طلب قائم.' },
];

export default function Home() {
  const navigate = useNavigate();
  const { members, membersLoading, user, socialSettings } = useApp();
  const isLoggedIn = !!user?.isLoggedIn;
  const [quickGender, setQuickGender] = useState<'female' | 'male' | 'all'>('female');
  const [quickCountry, setQuickCountry] = useState('قطر');
  const [quickCity, setQuickCity] = useState('');
  const [geoReady, setGeoReady] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    Promise.resolve(dataService.db.ensureGeoLoaded?.())
      .catch(() => undefined)
      .finally(() => { if (active) setGeoReady(true); });
    return () => { active = false; };
  }, []);

  const countryOptions = useMemo(() => {
    const names = dataService.db.getCountryNames?.() || [];
    return names.length ? names : COUNTRIES;
  }, [geoReady]);

  const cityOptions = useMemo(() => {
    if (!quickCountry) return [];
    const cities = dataService.db.getCities?.(quickCountry) || [];
    return cities.length ? cities : (CITIES_BY_COUNTRY[quickCountry] || []);
  }, [quickCountry, geoReady]);

  const featuredMembers = useMemo(() => {
    const seen = new Set<string>();
    const available = members.filter((member) => {
      if (!member || (member.status && member.status !== 'active')) return false;
      if (!(member.nickname || member.realName || member.id) || seen.has(member.id)) return false;
      seen.add(member.id);
      return true;
    }).sort((a, b) => getMemberTimestamp(b) - getMemberTimestamp(a));
    const featured = available.filter((member) => isFeatured(member));
    const list = featured.length >= 2 ? featured : available;
    return list.slice(0, 6);
  }, [members]);

  const handleQuickSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const params = new URLSearchParams();
    if (quickGender !== 'all') params.set('gender', quickGender);
    if (quickCountry) params.set('country', quickCountry);
    if (quickCity) params.set('city', quickCity);
    navigate(`/search?${params.toString()}`);
  };

  const scrollToSection = (event: MouseEvent<HTMLAnchorElement>, sectionId: string) => {
    event.preventDefault();
    const section = document.getElementById(sectionId);
    section?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const whatsappNumber = socialSettings?.whatsappNumber?.replace(/[+\s-]/g, '') || '97403315562';
  const showWhatsapp = true;

  const openWhatsApp = (msg: string = 'السلام عليكم ورحمة الله، أود الاستفسار والتسجيل في منصة خطابة قطر') => {
    window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#FCFBF9] text-[#1C1917] pb-20 font-['Tajawal',sans-serif]" dir="rtl">
      
      {/* Container aligned with the mobile & desktop layout */}
      <div className="max-w-[520px] sm:max-w-xl md:max-w-3xl lg:max-w-5xl mx-auto px-4 pt-3 sm:pt-6">

        {/* 1. TOP BADGE & QATAR FLAG */}
        <div className="flex items-center justify-between mb-3.5">
          <div className="inline-flex items-center gap-1.5 bg-[#FEF8EC] border border-[#F1E0B6] px-3 py-1 rounded-full text-xs font-semibold text-[#A16207]">
            <Award className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>منصة التوفيق الكريمة المعتمدة</span>
          </div>
          <div className="flex items-center gap-1 text-xs font-bold text-[#7B113A]">
            <span>قطر</span>
            <span className="text-sm">🇶🇦</span>
          </div>
        </div>

        {/* 2. MAIN HEADLINE */}
        <div className="text-center mb-4">
          <h1 className="text-2xl sm:text-3xl font-black text-[#1C1917] font-['Cairo'] tracking-tight leading-tight">
            أهلاً بكم في منصة الزواج القطرية
          </h1>
          <p className="text-sm sm:text-base font-bold text-[#57534E] mt-1.5 flex items-center justify-center gap-1.5">
            <span>زواج جاد.. وتواصل باحترام</span>
            <span>🇶🇦</span>
          </p>
        </div>

        {/* 3. HERO IMAGE CARD (COURTYARD & MAROON OVERLAY BANNER) */}
        <div className="relative rounded-2xl overflow-hidden shadow-sm border border-[#EAE3D9] mb-3.5 group">
          <img
            src={heroCourtyard}
            alt="منصة خطابة قطر للتوفيق والزواج"
            className="w-full h-48 sm:h-64 object-cover object-center brightness-[0.98] group-hover:scale-[1.02] transition-transform duration-700"
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#680E30]/95 via-[#7B113A]/85 to-transparent pt-8 pb-3.5 px-4 text-center sm:text-right">
            <p className="text-white text-xs sm:text-[13px] font-medium leading-relaxed drop-shadow-sm">
              المنصة القطرية الأولى الموثوقة لخدمات التوفيق الشرعي والزواج في المجتمع القطري والخليجي في خصوصية وسرية تامة.
            </p>
          </div>
        </div>

        {/* 4. STATS CARD (3 Columns) */}
        <div className="bg-white rounded-2xl border border-[#EAE3D9] shadow-2xs p-3.5 mb-3.5 grid grid-cols-3 divide-x divide-x-reverse divide-[#F0EAE1] text-center items-center">
          <div>
            <div className="text-lg sm:text-xl font-black text-[#1C1917] font-['Cairo'] leading-none">
              +1,200
            </div>
            <div className="text-[11px] text-[#78716C] mt-1 font-medium">توفيق ناجح</div>
          </div>
          <div>
            <div className="text-lg sm:text-xl font-black text-[#1C1917] font-['Cairo'] leading-none">
              100%
            </div>
            <div className="text-[11px] text-[#78716C] mt-1 font-medium">خصوصية مصونة</div>
          </div>
          <div className="flex flex-col items-center justify-center">
            <Scale className="w-4 h-4 text-[#7B113A] mb-1" />
            <div className="text-[11px] text-[#78716C] font-medium leading-none">ضوابط شرعية</div>
          </div>
        </div>

        {/* 5. PRIMARY ACTION BUTTONS */}
        <div className="space-y-2 mb-6">
          <Link
            to="/search"
            className="w-full bg-[#7B113A] hover:bg-[#680E30] text-white py-3 px-5 rounded-xl font-bold font-['Cairo'] text-sm flex items-center justify-center gap-2 shadow-sm shadow-[#7B113A]/20 transition-all active:scale-[0.99]"
          >
            <Search className="w-4 h-4" />
            <span>استعراض طلبات الزواج</span>
          </Link>

          <Link
            to={isLoggedIn ? '/profile' : '/register'}
            className="w-full bg-[#FAF7F2] hover:bg-[#F5EFE4] text-[#7B113A] border border-[#E5DAC6] py-3 px-5 rounded-xl font-bold font-['Cairo'] text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
          >
            <PlusCircle className="w-4 h-4 text-[#A16207]" />
            <span>{isLoggedIn ? 'ملفي الشخصي' : 'تقديم طلب جديد وسري'}</span>
          </Link>
        </div>

        {/* 6. QUICK SEARCH FORM (PRESERVED LOGIC & REFINED DESIGN) */}
        <form onSubmit={handleQuickSearch} className="bg-white rounded-2xl border border-[#EAE3D9] p-4 sm:p-5 shadow-xs mb-8">
          <div className="flex items-center gap-2 pb-3 mb-3 border-b border-[#F5EFE7]">
            <div className="w-8 h-8 rounded-xl bg-[#FEF8EC] text-[#A16207] flex items-center justify-center">
              <Search className="w-4 h-4" />
            </div>
            <div className="text-right">
              <h2 className="font-black text-sm font-['Cairo'] text-[#1C1917]">ابدأ بحثك السريع</h2>
              <p className="text-[11px] text-[#78716C]">اختر الأساسيات، ثم استكشف تفاصيل الملفات والمواصفات.</p>
            </div>
          </div>

          {/* Gender Selector */}
          <div className="mb-3">
            <label className="block text-xs font-bold text-[#57534E] mb-1.5 text-right font-['Cairo']">
              أبحث عن:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {([
                ['female', 'عروس'],
                ['male', 'عريس'],
                ['all', 'الجميع'],
              ] as const).map(([val, label]) => (
                <button
                  type="button"
                  key={val}
                  onClick={() => setQuickGender(val)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    quickGender === val
                      ? 'bg-[#7B113A] text-white border-[#7B113A] shadow-2xs'
                      : 'bg-[#FAF7F2] text-[#57534E] border-[#EAE3D9] hover:bg-[#F5ECE0]'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Location Fields */}
          <div className="grid grid-cols-2 gap-2 mb-3">
            <div>
              <label htmlFor="home-country" className="block text-xs font-bold text-[#57534E] mb-1 text-right">
                الدولة:
              </label>
              <select
                id="home-country"
                value={quickCountry}
                onChange={(e) => { setQuickCountry(e.target.value); setQuickCity(''); }}
                className="w-full bg-[#FAF7F2] border border-[#EAE3D9] rounded-xl px-2.5 py-2 text-xs font-medium focus:outline-[#7B113A]"
              >
                <option value="">جميع الدول</option>
                {countryOptions.map((country) => (
                  <option key={country} value={country}>{country}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="home-city" className="block text-xs font-bold text-[#57534E] mb-1 text-right">
                المدينة:
              </label>
              <select
                id="home-city"
                value={quickCity}
                disabled={!quickCountry}
                onChange={(e) => setQuickCity(e.target.value)}
                className="w-full bg-[#FAF7F2] border border-[#EAE3D9] rounded-xl px-2.5 py-2 text-xs font-medium focus:outline-[#7B113A] disabled:opacity-50"
              >
                <option value="">جميع المدن</option>
                {cityOptions.map((city) => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#7B113A] hover:bg-[#680E30] text-white py-2.5 px-4 rounded-xl text-xs font-bold font-['Cairo'] flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
          >
            <Search className="w-3.5 h-3.5" />
            <span>عرض نتائج البحث</span>
          </button>
        </form>

        {/* 7. SECTION: أقسام التوفيق الرئيسية (2x2 GRID) */}
        <section className="mb-8">
          <div className="text-right mb-3.5">
            <div className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-[#FDF1F4] text-[#7B113A] mb-1">
              <Users className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-black text-[#1C1917] font-['Cairo']">
              أقسام التوفيق الرئيسية
            </h2>
            <p className="text-xs text-[#78716C] mt-0.5">
              تصفح وفق الرغبة الشرعية والاجتماعية
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2.5 mb-3">
            {/* قسم الرجال */}
            <div
              onClick={() => navigate('/search?gender=male')}
              className="bg-white rounded-2xl border border-[#EAE3D9] p-3.5 flex flex-col justify-between hover:border-[#7B113A]/40 transition-all cursor-pointer shadow-2xs group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] bg-[#F5F2EC] text-[#78716C] px-2 py-0.5 rounded-full font-medium">
                    نشط الآن
                  </span>
                  <div className="w-7 h-7 rounded-full bg-[#FDF1F4] text-[#7B113A] flex items-center justify-center">
                    <User className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="font-bold text-sm text-[#1C1917] font-['Cairo'] mb-1">
                  قسم الرجال
                </h3>
                <p className="text-[11px] text-[#78716C] leading-snug line-clamp-2">
                  طلبات الشباب والرجال الباحثين عن الحلال والتأسيس الأسري
                </p>
              </div>
              <div className="flex items-center justify-between pt-3 mt-2 border-t border-[#F5F0E8] text-[11px] text-[#78716C] group-hover:text-[#7B113A]">
                <span>84 ملف موثق</span>
                <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-1" />
              </div>
            </div>

            {/* قسم النساء */}
            <div
              onClick={() => navigate('/search?gender=female')}
              className="bg-white rounded-2xl border border-[#EAE3D9] p-3.5 flex flex-col justify-between hover:border-[#7B113A]/40 transition-all cursor-pointer shadow-2xs group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] bg-[#F5F2EC] text-[#78716C] px-2 py-0.5 rounded-full font-medium">
                    محمي وسري
                  </span>
                  <div className="w-7 h-7 rounded-full bg-[#FEF8EC] text-[#A16207] flex items-center justify-center">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="font-bold text-sm text-[#1C1917] font-['Cairo'] mb-1">
                  قسم النساء
                </h3>
                <p className="text-[11px] text-[#78716C] leading-snug line-clamp-2">
                  ملفات واستشارات التوفيق الموثوقة لفتيات وسيدات المجتمع
                </p>
              </div>
              <div className="flex items-center justify-between pt-3 mt-2 border-t border-[#F5F0E8] text-[11px] text-[#78716C] group-hover:text-[#7B113A]">
                <span>64 ملف مصان</span>
                <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-1" />
              </div>
            </div>

            {/* الزواج المعلن */}
            <div
              onClick={() => navigate('/search?type=معلن')}
              className="bg-white rounded-2xl border border-[#EAE3D9] p-3.5 flex flex-col justify-between hover:border-[#7B113A]/40 transition-all cursor-pointer shadow-2xs group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] bg-[#F5F2EC] text-[#78716C] px-2 py-0.5 rounded-full font-medium">
                    تقليدي
                  </span>
                  <div className="w-7 h-7 rounded-full bg-[#FDF1F4] text-[#7B113A] flex items-center justify-center">
                    <Heart className="w-4 h-4 fill-[#7B113A]/20" />
                  </div>
                </div>
                <h3 className="font-bold text-sm text-[#1C1917] font-['Cairo'] mb-1">
                  الزواج المعلن
                </h3>
                <p className="text-[11px] text-[#78716C] leading-snug line-clamp-2">
                  الزواج الشرعي التقليدي الكامل والمعلن برعاية عائلية
                </p>
              </div>
              <div className="flex items-center justify-between pt-3 mt-2 border-t border-[#F5F0E8] text-[11px] text-[#78716C] group-hover:text-[#7B113A]">
                <span>الأعلى طلباً</span>
                <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-1" />
              </div>
            </div>

            {/* الزواج المسيار */}
            <div
              onClick={() => navigate('/search?type=مسيار')}
              className="bg-white rounded-2xl border border-[#EAE3D9] p-3.5 flex flex-col justify-between hover:border-[#7B113A]/40 transition-all cursor-pointer shadow-2xs group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] bg-[#F5F2EC] text-[#78716C] px-2 py-0.5 rounded-full font-medium">
                    بضوابطه
                  </span>
                  <div className="w-7 h-7 rounded-full bg-[#FEF8EC] text-[#A16207] flex items-center justify-center">
                    <Sparkles className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="font-bold text-sm text-[#1C1917] font-['Cairo'] mb-1">
                  الزواج المسيار
                </h3>
                <p className="text-[11px] text-[#78716C] leading-snug line-clamp-2">
                  وفق الضوابط الفقهية المعتمدة والتراضي الشفاف
                </p>
              </div>
              <div className="flex items-center justify-between pt-3 mt-2 border-t border-[#F5F0E8] text-[11px] text-[#78716C] group-hover:text-[#7B113A]">
                <span>شروط محددة</span>
                <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-1" />
              </div>
            </div>
          </div>

          <button
            onClick={() => navigate('/search')}
            className="w-full bg-[#FAF7F2] hover:bg-[#F3ECE1] border border-[#E5DAC6] rounded-xl p-3 flex items-center justify-between text-xs font-bold font-['Cairo'] text-[#1C1917] transition-all cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#7B113A]" />
              <span>عرض جميع الأقسام والطلبات المتاحة</span>
            </div>
            <span className="bg-[#7B113A] text-white text-[10px] px-2 py-0.5 rounded-full">
              +148 طلب تجريبي
            </span>
          </button>
        </section>

        {/* 8. 3-STEP OVERVIEW SECTION */}
        <section className="mb-8 bg-white rounded-2xl border border-[#EAE3D9] p-4 sm:p-5 shadow-2xs">
          <div className="text-right mb-4">
            <h2 className="text-base font-black text-[#1C1917] font-['Cairo']">الخدمة في ثلاث خطوات</h2>
            <p className="text-xs text-[#78716C]">طريقة ميسرة وموثوقة للبحث والتوفيق</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {overviewSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={step.title} className="p-3 rounded-xl bg-[#FAF7F2] border border-[#EAE3D9] flex items-start gap-2.5 text-right">
                  <div className="w-7 h-7 rounded-lg bg-[#FEF8EC] text-[#A16207] flex items-center justify-center shrink-0 font-bold text-xs">
                    {index + 1}
                  </div>
                  <div>
                    <h3 className="font-bold text-xs font-['Cairo'] text-[#1C1917] mb-0.5">{step.title}</h3>
                    <p className="text-[11px] text-[#78716C] leading-relaxed">{step.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* 9. FEATURED MEMBERS (الأعضاء المميزون) - بطاقتين في الصف الواحد */}
        <section id="featured-members" className="mb-8">
          <div className="flex items-center justify-between mb-3.5 text-right">
            <div>
              <h2 className="text-lg font-black text-[#1C1917] font-['Cairo']">الأعضاء المميزون</h2>
              <p className="text-xs text-[#78716C]">ملفات موثقة تحمل عضوية «توافق مميز» بمواصفات دقيقة.</p>
            </div>
            <Link to="/search" className="text-xs font-bold text-[#7B113A] hover:underline flex items-center gap-1 font-['Cairo']">
              <span>عرض جميع الأعضاء</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* شبكة من عمودين بالضبط (بطاقتين في الصف) مثل صفحة البحث */}
          <div className="grid grid-cols-2 gap-2.5 sm:gap-4">
            {membersLoading && !featuredMembers.length ? (
              <MemberGridSkeleton count={4} />
            ) : (
              featuredMembers.map((member) => (
                <MemberCard key={`featured-${member.id}`} member={member} />
              ))
            )}
          </div>
          {!membersLoading && !featuredMembers.length && (
            <div className="bg-white rounded-2xl border border-[#EAE3D9] p-6 text-center text-xs text-[#78716C]">
              لا توجد ملفات مميزة متاحة حالياً.
            </div>
          )}
        </section>

        {/* 11. JOURNEY STEPS (مراحل التوافق) */}
        <section id="home-journey" className="mb-8 scroll-mt-20">
          <div className="text-right mb-3.5">
            <h2 className="text-lg font-black text-[#1C1917] font-['Cairo']">كيف تسير رحلة التوافق؟</h2>
            <p className="text-xs text-[#78716C]">هذه مراحل رحلة الأعضاء المسجّلين، أما ملفات الوساطة فيتولى الفريق التنسيق بشأنها.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 mb-3">
            {journeySteps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <div key={step.title} className="bg-white rounded-2xl border border-[#EAE3D9] p-3.5 text-right shadow-2xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-mono font-bold text-[#A16207]">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <div className="w-7 h-7 rounded-lg bg-[#FEF8EC] text-[#A16207] flex items-center justify-center">
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="font-bold text-xs font-['Cairo'] text-[#1C1917] mb-1">{step.title}</h3>
                  <p className="text-[11px] text-[#78716C] leading-relaxed">{step.description}</p>
                </div>
              );
            })}
          </div>
          <p className="text-[11px] text-[#78716C] text-center bg-[#FAF7F2] p-2.5 rounded-xl border border-[#EAE3D9]">
            قبول الطلب أو سداد الرسوم لا يضمن إتمام الزواج؛ قرار الاستمرار للطرفين.
          </p>
        </section>

        {/* 12. SERVICES & FEES (اعرف ما هو مجاني وما هو مدفوع) */}
        <section id="home-fees" className="mb-8 scroll-mt-20">
          <div className="text-right mb-3.5">
            <h2 className="text-lg font-black text-[#1C1917] font-['Cairo']">اعرف ما هو مجاني وما هو مدفوع</h2>
            <p className="text-xs text-[#78716C]">خدمات واضحة. الاشتراك في إحداها لا يعني شمول الخدمات الأخرى.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-3">
            {serviceOptions.map((opt) => (
              <div key={opt.title} className="bg-white rounded-2xl border border-[#EAE3D9] p-4 text-right shadow-2xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] bg-[#FEF8EC] text-[#A16207] border border-[#F1E0B6] px-2 py-0.5 rounded-full font-bold">
                    {opt.label}
                  </span>
                  <span className="font-mono text-xs font-bold text-[#7B113A]">{opt.number}</span>
                </div>
                <h3 className="font-bold text-xs font-['Cairo'] text-[#1C1917] mb-1">{opt.title}</h3>
                <p className="text-[11px] text-[#78716C] leading-relaxed">{opt.description}</p>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between text-xs text-[#78716C] pt-1">
            <Link to="/plans" className="text-[#7B113A] font-bold hover:underline font-['Cairo']">
              تفاصيل العضوية والباقات ←
            </Link>
            <Link to="/legal/terms" className="hover:underline font-['Cairo']">
              الشروط والأحكام ←
            </Link>
          </div>
        </section>

        {/* 13. QURANIC VERSE MAROON BANNER */}
        <div className="rounded-2xl bg-gradient-to-r from-[#590C28] via-[#7B113A] to-[#600C2B] p-5 text-center text-white mb-8 shadow-sm border border-[#7B113A]/40 relative overflow-hidden">
          <div className="relative z-10">
            <p className="font-['Cairo'] text-sm sm:text-base font-bold tracking-wide text-[#FFF0D4] drop-shadow-sm leading-relaxed">
              «وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا»
            </p>
          </div>
        </div>

        {/* 14. PRIVACY PRINCIPLES (اعرف ما تشاركه) */}
        <section className="mb-8 bg-white rounded-2xl border border-[#EAE3D9] p-4 sm:p-5 shadow-2xs">
          <div className="text-right mb-4">
            <h2 className="text-lg font-black text-[#1C1917] font-['Cairo']">معلومات واضحة، وقرار التواصل لك</h2>
            <p className="text-xs text-[#78716C]">اطّلع على تفاصيل الملف، وافهم معنى الشارات، وشارك ما تختاره من وسائل التواصل في المرحلة المناسبة.</p>
          </div>

          <div className="space-y-3 text-right">
            <div className="flex items-start gap-3 p-3 rounded-xl bg-[#FAF7F2] border border-[#EAE3D9]">
              <div className="w-8 h-8 rounded-lg bg-[#FDF1F4] text-[#7B113A] flex items-center justify-center shrink-0">
                <FileCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-xs font-['Cairo'] text-[#1C1917]">النبذة العامة ليست مكاناً للبيانات الحساسة</h3>
                <p className="text-[11px] text-[#78716C] mt-0.5">لا تكتب رقم هاتفك أو بيانات هويتك أو معلوماتك المالية في وصف الملف.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-xl bg-[#FAF7F2] border border-[#EAE3D9]">
              <div className="w-8 h-8 rounded-lg bg-[#FEF8EC] text-[#A16207] flex items-center justify-center shrink-0">
                <BadgeCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-xs font-['Cairo'] text-[#1C1917]">لكل شارة معنى مختلف</h3>
                <p className="text-[11px] text-[#78716C] mt-0.5">العضوية المميزة ليست توثيق هوية، والتوثيق أو وسام الجدية ليس ضماناً لنجاح العلاقة.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-xl bg-[#FAF7F2] border border-[#EAE3D9]">
              <div className="w-8 h-8 rounded-lg bg-[#FDF1F4] text-[#7B113A] flex items-center justify-center shrink-0">
                <HeartHandshake className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-xs font-['Cairo'] text-[#1C1917]">مسار مختلف لملفات الوساطة</h3>
                <p className="text-[11px] text-[#78716C] mt-0.5">تتولى الإدارة التنسيق مع الجهة المعنية؛ لا تفترض أن صاحب الملف يتابع الطلب بنفسه.</p>
              </div>
            </div>
          </div>
        </section>

        {/* 15. FAQS ACCORDION */}
        <section id="home-faq" className="mb-8">
          <div className="text-right mb-3.5">
            <h2 className="text-lg font-black text-[#1C1917] font-['Cairo']">الأسئلة الأكثر شيوعاً</h2>
            <p className="text-xs text-[#78716C]">إجابات مختصرة تساعدك على فهم نظام وسرية المنصة.</p>
          </div>

          <div className="space-y-2">
            {faqs.map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={faq.question}
                  className="bg-white rounded-2xl border border-[#EAE3D9] overflow-hidden shadow-2xs"
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                    className="w-full p-4 flex items-center justify-between text-right font-bold text-xs sm:text-sm text-[#1C1917] font-['Cairo'] hover:bg-[#FAF7F2]/60 transition-colors cursor-pointer"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-[#78716C] transition-transform duration-300 shrink-0 mr-2 ${
                        isOpen ? 'rotate-180 text-[#7B113A]' : ''
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-4 pb-4 pt-1 text-xs text-[#57534E] leading-relaxed border-t border-[#F5EFE7] bg-[#FAF8F5]/30">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* 16. OFFICIAL CHANNELS & CONTACT SECTION */}
        <section className="bg-white rounded-2xl border border-[#EAE3D9] p-4 mb-6 shadow-xs text-right">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-base font-black text-[#1C1917] font-['Cairo']">
                  قنوات التواصل والمنصات الرسمية
                </h2>
                <span>🇶🇦</span>
              </div>
              <p className="text-[11px] text-[#78716C] mt-0.5">
                احرص على التواصل عبر القنوات المعتمدة فقط
              </p>
            </div>
          </div>

          {/* Main Maroon WhatsApp Button */}
          <button
            onClick={() => openWhatsApp('السلام عليكم ورحمة الله، أود التواصل مع إدارة منصة خطابة قطر للاستفسار')}
            className="w-full bg-[#7B113A] hover:bg-[#680E30] text-white py-3.5 px-4 rounded-xl flex items-center justify-between shadow-sm transition-all mb-4 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <div className="text-center">
              <div className="font-bold font-['Cairo'] text-sm">محادثة واتساب المباشرة</div>
              <div className="text-[11px] text-white/80 font-mono mt-0.5" dir="ltr">
                +974 0331 5562 (خط الإدارة)
              </div>
            </div>
            <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <div
              onClick={() => openWhatsApp('السلام عليكم، أود الانضمام إلى قناة واتساب الرسمية الأولى للطلبات')}
              className="bg-[#FEF9ED] border border-[#F3E2B8] rounded-xl p-2.5 flex items-center justify-between hover:bg-[#FDF4DF] transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#A16207]" />
              <div className="text-right">
                <div className="text-xs font-bold text-[#1C1917] font-['Cairo']">قناة واتساب الأولى</div>
                <div className="text-[10px] text-[#78716C]">تحديثات الطلبات</div>
              </div>
            </div>

            <div
              onClick={() => openWhatsApp('السلام عليكم، أود الاطلاع على أرشيف الطلبات في القناة الرسمية الثانية')}
              className="bg-[#FAF7F2] border border-[#EAE3D9] rounded-xl p-2.5 flex items-center justify-between hover:bg-[#F3ECE0] transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#78716C]" />
              <div className="text-right">
                <div className="text-xs font-bold text-[#1C1917] font-['Cairo']">قناة واتساب الثانية</div>
                <div className="text-[10px] text-[#78716C]">الأرشيف والخاص</div>
              </div>
            </div>
          </div>
        </section>

        {/* 17. FINAL CALL TO ACTION (خطوتك التالية) */}
        <section className="bg-gradient-to-tr from-[#680E30] to-[#7B113A] rounded-2xl p-5 sm:p-6 text-white text-right shadow-sm mb-8">
          <p className="text-xs font-semibold text-[#FEF8EC] mb-1 font-['Cairo']">خطوتك التالية</p>
          <h2 className="text-lg sm:text-xl font-black font-['Cairo'] mb-2">
            {isLoggedIn ? 'واصل البحث بخطوة واضحة' : 'ابدأ بملف يعبّر عنك بوضوح'}
          </h2>
          <p className="text-xs text-white/80 leading-relaxed mb-4 max-w-lg">
            {isLoggedIn
              ? 'راجع ملفك ومواصفاتك، أو استكشف الملفات وأرسل طلب توافق.'
              : 'أنشئ حسابك، وأضف معلوماتك ومواصفات الشريك الذي تبحث عنه.'}
          </p>
          <div className="flex flex-wrap gap-2.5">
            <Link
              to={isLoggedIn ? '/search' : '/register'}
              className="bg-white text-[#7B113A] font-bold text-xs font-['Cairo'] py-2.5 px-4 rounded-xl flex items-center gap-1.5 shadow-sm hover:bg-[#FAF7F2] transition-colors"
            >
              <span>{isLoggedIn ? 'تصفّح الملفات' : 'إنشاء حساب مجاني'}</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </Link>
            <Link
              to={isLoggedIn ? '/profile' : '/login'}
              className="border border-white/40 text-white font-bold text-xs font-['Cairo'] py-2.5 px-4 rounded-xl hover:bg-white/10 transition-colors"
            >
              {isLoggedIn ? 'مراجعة ملفي' : 'لدي حساب بالفعل'}
            </Link>
          </div>
        </section>

        {/* 18. PRIVACY DISCLAIMER */}
        <div className="bg-[#FAF7F2] rounded-2xl border border-[#EAE3D9] p-3.5 mb-8 text-right">
          <div className="flex items-center gap-1.5 mb-1 justify-end text-[#A16207] font-bold text-xs font-['Cairo']">
            <span>تنويه الخصوصية والأمان</span>
            <ShieldCheck className="w-4 h-4" />
          </div>
          <p className="text-[11px] text-[#78716C] leading-relaxed">
            هذه النسخة تخضع لمعايير الأمان المشددة، لا تظهر هوية أو معلومات أي مشترك للعامة، وحقوق التواصل محصورة بالخطابة المعتمدة حفاظاً على حرمة البيوت.
          </p>
        </div>

        {/* 19. FOOTER LINKS & COPYRIGHT */}
        <footer className="text-center pt-2 pb-6 border-t border-[#EAE3D9]">
          <div className="flex items-center justify-center gap-3 text-xs text-[#78716C] mb-2 font-medium flex-wrap">
            <Link to="/about" className="hover:text-[#7B113A] transition-colors">من نحن</Link>
            <span>•</span>
            <Link to="/plans" className="hover:text-[#7B113A] transition-colors">الباقات</Link>
            <span>•</span>
            <Link to="/contact" className="hover:text-[#7B113A] transition-colors">اتصل بنا</Link>
            <span>•</span>
            <Link to="/legal/terms" className="hover:text-[#7B113A] transition-colors">الشروط والأحكام</Link>
            <span>•</span>
            <Link to="/legal/privacy" className="hover:text-[#7B113A] transition-colors">سياسة الخصوصية</Link>
          </div>

          <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-[#7B113A] mb-1 font-['Cairo']">
            <span>منصة خطابة قطر الرسمية</span>
            <span>🇶🇦</span>
          </div>

          <p className="text-[10px] text-[#A8A29E]">
            جميع الحقوق محفوظة © 2025 | منصة التوفيق الكريمة في قطر والخليج العربي
          </p>
        </footer>

      </div>
    </div>
  );
}
