import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Lock, Eye, EyeOff, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Button } from '../components/ui/Button';
import authClient from '../lib/authClient';

export default function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');
  const [ready, setReady] = useState(false);

  // رابط إعادة تعيين كلمة المرور من البريد ينشئ جلسة مؤقتة تلقائياً عبر قاعدة البيانات المحلية عند تحميل الصفحة
  useEffect(() => {
    authClient.auth.getSession().then(({ data: { session } }) => {
      setReady(!!session);
    });
    const { data: { subscription } } = authClient.auth.onAuthStateChange((_event, session) => {
      if (session) setReady(true);
    });
    return () => subscription.unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (password.length < 6) { setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل'); return; }
    if (password !== confirmPassword) { setError('كلمتا المرور فير متطابقتين'); return; }

    setLoading(true);
    try {
      const { error: updateError } = await authClient.auth.updateUser({ password });
      if (updateError) {
        setError(updateError.message);
      } else {
        setDone(true);
        setTimeout(() => navigate('/login'), 2500);
      }
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ متوقع، حاول مرة أخرى');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] flex items-center justify-center bg-[#FCFBF9] p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-3xl shadow-sm border border-[#EAE3D9] p-6 sm:p-8"
      >
        {done ? (
          <div className="text-center py-4">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 sm:w-9 sm:h-9 text-emerald-600" />
            </div>
            <h1 className="font-cairo font-extrabold text-xl sm:text-2xl text-neutral-900">تم تحديث كلمة المرور!</h1>
            <p className="mt-2 text-neutral-600 font-tajawal text-sm sm:text-base">جارِ تحويلك لصفحة تسجيل الدخول...</p>
          </div>
        ) : !ready ? (
          <div className="text-center py-4">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-rose-50 flex items-center justify-center mx-auto mb-4">
              <ShieldCheck className="w-8 h-8 sm:w-9 sm:h-9 text-rose-500" />
            </div>
            <h1 className="font-cairo font-extrabold text-lg sm:text-xl text-neutral-900">الرابط غير صالح أو منتهي</h1>
            <p className="mt-2 text-neutral-600 font-tajawal text-sm sm:text-base">يرجى طلب رابط إعادة تعيين جديد.</p>
            <Link to="/forgot-password" className="inline-block mt-5 font-cairo font-bold text-[#7B113A] hover:underline">طلب رابط جديد</Link>
          </div>
        ) : (
          <>
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-[#FDF2F4] border border-[#7B113A]/20 flex items-center justify-center mb-5">
              <ShieldCheck className="w-6 h-6 sm:w-7 sm:h-7 text-[#7B113A]" />
            </div>
            <h1 className="font-cairo font-extrabold text-xl sm:text-2xl text-neutral-900">تعيين كلمة مرور جديدة</h1>
            <p className="mt-2 text-neutral-600 font-tajawal text-sm sm:text-base">اختر كلمة مرور قوية وآمنة لحسابك.</p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-5">
              {error && (
                <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-xl p-3 text-sm font-tajawal">
                  {error}
                </div>
              )}
              <div>
                <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">كلمة المرور الجديدة</label>
                <div className="relative">
                  <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                  <input
                    type={showPass ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pr-12 pl-12 py-3.5 rounded-2xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors text-right"
                    dir="ltr"
                  />
                  <button type="button" onClick={() => setShowPass(!showPass)} aria-label={showPass ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'} className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                    {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-cairo font-semibold text-navy-800 mb-2">تأكيد كلمة المرور</label>
                <input
                  type={showPass ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3.5 rounded-2xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 transition-colors text-right"
                  dir="ltr"
                />
              </div>
              <Button type="submit" fullWidth size="lg" disabled={loading}>{loading ? 'جارِ الحفظ...' : 'حفظ كلمة المرور الجديدة'}</Button>
            </form>
          </>
        )}
      </motion.div>
    </div>
  );
}
