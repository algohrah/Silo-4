import { SampleProject } from '../types';

export const SAMPLE_PROJECTS: SampleProject[] = [
  {
    id: 'dashboard',
    title: 'Modern Analytics Dashboard',
    titleAr: 'لوحة تحكم وتحليلات حديثة',
    description: 'HTML/CSS/JS responsive dashboard with real-time charts and status cards',
    descriptionAr: 'لوحة تحكم تفاعلية مع بطاقات إحصائيات ورسوم بيانية',
    icon: 'LayoutDashboard',
    files: [
      {
        id: 'dash-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>مشروع التجربة - لوحة التحكم</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body class="bg-slate-900 text-slate-100 font-sans min-h-screen p-6">
  <div class="max-w-6xl mx-auto space-y-6">
    <header class="flex justify-between items-center bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-xl">
      <div>
        <h1 class="text-2xl font-bold text-emerald-400">🚀 مرحباً بك في منصة تشغيل المشاريع</h1>
        <p class="text-slate-400 text-sm mt-1">تم تشغيل هذا المشروع بنجاح من خلال بيئة المعاينة الفورية</p>
      </div>
      <button id="refreshBtn" class="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold px-4 py-2 rounded-xl transition-all shadow-lg active:scale-95">
        تحديث البيانات 🔄
      </button>
    </header>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div class="bg-slate-800/80 p-6 rounded-2xl border border-slate-700/80 backdrop-blur">
        <span class="text-slate-400 text-sm">إجمالي الزيارات</span>
        <div class="text-3xl font-extrabold text-white mt-2" id="visits">24,580</div>
        <div class="text-emerald-400 text-xs font-semibold mt-2">↑ +14% هذا الأسبوع</div>
      </div>
      <div class="bg-slate-800/80 p-6 rounded-2xl border border-slate-700/80 backdrop-blur">
        <span class="text-slate-400 text-sm">المشاريع النشطة</span>
        <div class="text-3xl font-extrabold text-white mt-2" id="activeProjects">12</div>
        <div class="text-indigo-400 text-xs font-semibold mt-2">جاهزة للعمل ⚡</div>
      </div>
      <div class="bg-slate-800/80 p-6 rounded-2xl border border-slate-700/80 backdrop-blur">
        <span class="text-slate-400 text-sm">سرعة التنفيذ</span>
        <div class="text-3xl font-extrabold text-emerald-400 mt-2">99.8%</div>
        <div class="text-slate-400 text-xs mt-2">استجابة لحظية في المتصفح</div>
      </div>
    </div>

    <div class="bg-slate-800 p-6 rounded-2xl border border-slate-700">
      <h2 class="text-lg font-bold mb-4">سجل العمليات Livelog</h2>
      <ul id="logList" class="space-y-2 text-sm text-slate-300 font-mono">
        <li class="bg-slate-900/60 p-3 rounded-lg border border-slate-700/50">✅ [00:01] تم تحميل كافة الملفات والمستندات بنجاح</li>
        <li class="bg-slate-900/60 p-3 rounded-lg border border-slate-700/50">⚡ [00:02] محرك العرض يعمل بأعلى كفاءة</li>
      </ul>
    </div>
  </div>

  <script src="app.js"></script>
</body>
</html>`
      },
      {
        id: 'dash-css',
        name: 'style.css',
        path: 'style.css',
        language: 'css',
        content: `@keyframes pulseGlow {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.7; }
}

body {
  direction: rtl;
  font-family: system-ui, -apple-system, sans-serif;
}`
      },
      {
        id: 'dash-js',
        name: 'app.js',
        path: 'app.js',
        language: 'javascript',
        content: `console.log("Project runner initialized successfully!");

document.getElementById('refreshBtn').addEventListener('click', () => {
  const visits = document.getElementById('visits');
  const current = parseInt(visits.innerText.replace(/,/g, ''));
  const newVisits = current + Math.floor(Math.random() * 50) + 10;
  visits.innerText = newVisits.toLocaleString();

  const logList = document.getElementById('logList');
  const li = document.createElement('li');
  li.className = "bg-slate-900/60 p-3 rounded-lg border border-slate-700/50 animate-fade-in";
  const now = new Date().toLocaleTimeString();
  li.innerText = "🔄 [" + now + "] تم تحديث إحصائيات المشاهدات تلقائياً";
  logList.prepend(li);
});`
      }
    ]
  },
  {
    id: 'interactive-app',
    title: 'Task & Notes App',
    titleAr: 'تطبيق المهام والملاحظات الذكية',
    description: 'Dynamic web application with state management and local storage preview',
    descriptionAr: 'تطبيق ويب تفاعلي لإدارة المهام والملاحظات اليومية',
    icon: 'CheckSquare',
    files: [
      {
        id: 'todo-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>مدير المهام والملاحظات</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 text-slate-100 min-h-screen p-6">
  <div class="max-w-xl mx-auto bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl backdrop-blur">
    <div class="text-center mb-6">
      <h1 class="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-300">
        📝 قائمة المهام التفاعلية
      </h1>
      <p class="text-slate-400 text-xs mt-1">تطبيق تجريبي جاهز للاختبار السريع</p>
    </div>

    <form id="taskForm" class="flex gap-2 mb-6">
      <input type="text" id="taskInput" placeholder="اكتب مهمة جديدة..." required
        class="flex-1 bg-slate-800 border border-slate-700 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-500 text-white placeholder-slate-500">
      <button type="submit" class="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-3 rounded-2xl transition-all shadow-lg shadow-indigo-600/30">
        إضافة
      </button>
    </form>

    <ul id="taskList" class="space-y-3">
      <!-- Dynamic Tasks -->
    </ul>
  </div>

  <script>
    const tasks = ['مراجعة ملفات المشروع المرفقة', 'اختبار واجهة المستخدم', 'التحقق من كفاءة الأداء'];
    const taskList = document.getElementById('taskList');

    function render() {
      taskList.innerHTML = tasks.map((t, i) => \`
        <li class="flex items-center justify-between bg-slate-800/80 border border-slate-700/60 p-4 rounded-2xl hover:border-indigo-500/50 transition-all">
          <span class="text-sm text-slate-200 font-medium">\${t}</span>
          <button onclick="removeTask(\${i})" class="text-rose-400 hover:text-rose-300 text-xs font-bold bg-rose-500/10 px-3 py-1.5 rounded-xl border border-rose-500/20">
            حذف
          </button>
        </li>
      \`).join('');
    }

    document.getElementById('taskForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('taskInput');
      if (input.value.trim()) {
        tasks.push(input.value.trim());
        input.value = '';
        render();
      }
    });

    function removeTask(index) {
      tasks.splice(index, 1);
      render();
    }

    render();
  </script>
</body>
</html>`
      }
    ]
  }
];
