import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Heart, MessageSquare, Send, CheckCircle2, XCircle, Clock,
  ShieldCheck, UserCheck, CalendarClock, CreditCard, Eye,
  Activity, Filter, RefreshCw, AlertCircle, ArrowLeft,
  ChevronLeft, ClipboardList, Info, HelpCircle
} from 'lucide-react';
import { useApp } from '../../lib/AppContext';
import { dataService } from '../../lib/data/DataService';
import type { InterestRequest } from '../../lib/data';

interface ChatMessage {
  id: number;
  request_id: number;
  sender_id: string;
  text: string;
  charged_to: string | null;
  created_at: string;
}

export default function AdminImportedCoordination() {
  const { interestRequests, adminMembers, members, setInterestRequests, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');
  const [selectedReq, setSelectedReq] = useState<InterestRequest | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  
  // غرف الدردشة
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [newMessageText, setNewMessageText] = useState('');
  const [sendAsType, setSendAsType] = useState<'imported' | 'admin'>('imported');
  
  // حقول تحديث الحالة
  const [adminNotes, setAdminNotes] = useState('');
  const [meetingDate, setMeetingDate] = useState('');
  const [meetingNotes, setMeetingNotes] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  // دمج الأعضاء للحصول على التفاصيل الكاملة
  const allMembers = useMemo(() => {
    const map = new Map<string, any>();
    (members || []).forEach(m => map.set(m.id, m));
    (adminMembers || []).forEach(m => map.set(m.id, { ...map.get(m.id), ...m }));
    return map;
  }, [members, adminMembers]);

  // فلترة الطلبات التي تتضمن عضواً مستورداً واحداً على الأقل
  const importedRequests = useMemo(() => {
    return interestRequests.filter(r => {
      const sender = allMembers.get(r.senderId);
      const receiver = allMembers.get(r.receiverId);
      const hasImported = (sender?.sourceType === 'imported' || receiver?.sourceType === 'imported');
      return hasImported;
    });
  }, [interestRequests, allMembers]);

  // تقسيم الطلبات إلى نشطة ومنتهية
  const filteredRequests = useMemo(() => {
    return importedRequests.filter(r => {
      // البحث بالاسم أو الهوية
      const sender = allMembers.get(r.senderId);
      const receiver = allMembers.get(r.receiverId);
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = 
        r.id.toLowerCase().includes(searchLower) ||
        (sender?.nickname || '').toLowerCase().includes(searchLower) ||
        (receiver?.nickname || '').toLowerCase().includes(searchLower) ||
        (sender?.username || '').toLowerCase().includes(searchLower) ||
        (receiver?.username || '').toLowerCase().includes(searchLower);

      if (!matchesSearch) return false;

      // فلترة حسب المرحلة/الحالة
      if (stageFilter !== 'all') {
        if (r.status !== stageFilter) return false;
      }

      // تقسيم التبويبات
      const isTerminal = ['declined', 'cancelled', 'completed'].includes(r.status);
      if (activeTab === 'active') {
        return !isTerminal;
      } else {
        return isTerminal;
      }
    });
  }, [importedRequests, activeTab, searchQuery, stageFilter, allMembers]);

  // إيجاد العضو المستورد والعضو المسجل في الطلب النشط المحدد
  const parties = useMemo(() => {
    if (!selectedReq) return null;
    const s = allMembers.get(selectedReq.senderId);
    const r = allMembers.get(selectedReq.receiverId);
    
    const imported = s?.sourceType === 'imported' ? s : (r?.sourceType === 'imported' ? r : null);
    const registered = s?.sourceType !== 'imported' ? s : (r?.sourceType !== 'imported' ? r : null);
    
    return {
      sender: s,
      receiver: r,
      imported,
      registered,
      isSenderImported: s?.sourceType === 'imported',
    };
  }, [selectedReq, allMembers]);

  // جلب الرسائل الخاصة بالطلب المحدد
  const loadChat = async (reqId: number) => {
    if (!reqId || isNaN(reqId)) {
      setChatMessages([]);
      return;
    }
    setChatLoading(true);
    try {
      const res = await dataService.db.getInquiry(reqId);
      if (res && Array.isArray(res.messages)) {
        setChatMessages(res.messages);
      } else if (res && Array.isArray(res.data)) {
        setChatMessages(res.data);
      } else if (Array.isArray(res)) {
        setChatMessages(res);
      } else {
        setChatMessages([]);
      }
    } catch (err) {
      console.error('Error loading inquiry chat:', err);
      setChatMessages([]);
    } finally {
      setChatLoading(false);
    }
  };

  useEffect(() => {
    if (selectedReq) {
      const parsedId = Number(String(selectedReq.id).replace(/\D/g, ''));
      loadChat(isNaN(parsedId) ? 0 : parsedId);
      setAdminNotes(selectedReq.adminNotes || '');
      setMeetingDate(selectedReq.meetingDate || '');
      setMeetingNotes(selectedReq.meetingNotes || '');
    } else {
      setChatMessages([]);
    }
  }, [selectedReq]);

  // مزامنة حالة الطلبات في السياق (AppContext)
  const syncLocalRequests = () => {
    if (typeof window !== 'undefined') {
      const raw = localStorage.getItem('twafok_local_db_v4');
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          if (parsed && Array.isArray(parsed.requests)) {
            const mapped = parsed.requests.map((r: any) => {
              let status = 'pending';
              if (r.journey_stage === 'sent') status = 'pending';
              else if (r.journey_stage === 'accepted') status = 'accepted_pending_payment';
              else if (r.journey_stage === 'seriousness') status = 'accepted_pending_payment';
              else if (r.journey_stage === 'coordination') status = 'in_mediation';
              else if (r.journey_stage === 'sharia_viewing') status = 'in_mediation';
              else if (r.journey_stage === 'engagement') status = 'in_mediation';
              else if (r.journey_stage === 'completed') status = 'completed';
              else if (r.journey_stage === 'declined') status = 'declined';
              else if (r.journey_stage === 'cancelled') status = 'cancelled';

              if (r.sender_paid && r.receiver_paid && status === 'accepted_pending_payment') {
                status = 'paid';
              }

              return {
                id: String(r.id),
                senderId: r.sender_id,
                receiverId: r.receiver_id,
                status,
                message: r.message || 'طلب اهتمام مرسل عبر الإدارة',
                time: new Date(r.created_at).toLocaleDateString('ar-SA'),
                createdAt: new Date(r.created_at).getTime(),
                paymentStatus: (r.sender_paid && r.receiver_paid) ? 'paid' : 'waiting_for_payment',
                senderPaid: r.sender_paid,
                receiverPaid: r.receiver_paid,
                meetingDate: r.meeting_date || undefined,
                meetingNotes: r.meeting_notes || undefined,
                declineReason: r.decline_reason || undefined,
                adminNotes: r.admin_notes || undefined,
              };
            });
            setInterestRequests(mapped);
          }
        } catch (e) {
          console.error(e);
        }
      }
    }
  };

  // إرسال رسالة في غرفة التنسيق
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReq || !newMessageText.trim()) return;

    const reqId = Number(selectedReq.id.replace(/\D/g, ''));
    let senderId = 'admin';
    if (sendAsType === 'imported' && parties?.imported) {
      senderId = parties.imported.id;
    }

    try {
      // تهيئة الغرفة أولاً للتأكد من وجودها ومطابقتها للمستخدم
      await dataService.db.initializeInquiry(reqId, senderId === 'admin' ? selectedReq.senderId : senderId);
      
      const res = await dataService.db.sendInquiry(reqId, senderId, newMessageText.trim());
      if (res.ok) {
        setNewMessageText('');
        loadChat(reqId);
        showToast('تم إرسال الرسالة بنجاح ✓', 'success');
      } else {
        showToast(res.error || 'فشل إرسال الرسالة', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'خطأ أثناء إرسال الرسالة', 'error');
    }
  };

  // تحديث حالة معينة للطلب (مثل السداد، الانتقال لمرحلة، الحفظ)
  const handleUpdateStatus = async (action: string, payload: any = {}) => {
    if (!selectedReq) return;
    setIsUpdating(true);
    const reqId = Number(selectedReq.id.replace(/\D/g, ''));
    
    try {
      const res = await dataService.db.runRequestAction(reqId, action, 'admin', payload);
      if (res.ok) {
        // تحديث الحقول الإدارية الإضافية يدوياً في كائن الطلب في قاعدة البيانات المحلية
        const dbRaw = localStorage.getItem('twafok_local_db_v4');
        if (dbRaw) {
          const dbParsed = JSON.parse(dbRaw);
          dbParsed.requests = dbParsed.requests.map((r: any) => {
            if (r.id === reqId) {
              return {
                ...r,
                admin_notes: adminNotes,
                meeting_date: meetingDate || r.meeting_date,
                meeting_notes: meetingNotes || r.meeting_notes,
                ...payload,
              };
            }
            return r;
          });
          localStorage.setItem('twafok_local_db_v4', JSON.stringify(dbParsed));
        }

        syncLocalRequests();
        
        // تحديث العنصر النشط للتفاصيل
        setSelectedReq(prev => prev ? {
          ...prev,
          adminNotes,
          meetingDate: meetingDate || prev.meetingDate,
          meetingNotes: meetingNotes || prev.meetingNotes,
          status: action === 'accept' ? 'accepted_pending_payment' : 
                  action === 'decline' ? 'declined' : 
                  action === 'cancel' ? 'cancelled' : prev.status,
          ...payload
        } as any : null);

        showToast('تم تحديث بيانات الطلب والتنسيق للمستورد بنجاح ✓', 'success');
      } else {
        showToast(res.error || 'فشل التحديث', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'فشل الاتصال وحفظ التعديلات', 'error');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto" dir="rtl">
      {/* رأس الصفحة */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-gray-950 flex items-center gap-2">
            <Heart className="w-6 h-6 text-emerald-600" />
            التنسيق للمستوردين
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            متابعة غرف التوافق والرسائل لطلب الاهتمام الجاري بين الأعضاء المسجلين والأعضاء المستوردين بإشراف الإدارة بالكامل.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              syncLocalRequests();
              showToast('تم تحديث البيانات من النظام ✓', 'info');
            }}
            className="p-2 border.5 border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition"
            title="تحديث القائمة"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* لوحة المعلومات السريعة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-white p-5 rounded-xl border.5 border-gray-100 shadow-sm flex items-center gap-4">
          <div className="p-3 rounded-lg bg-emerald-50 text-emerald-600">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-gray-500 block">إجمالي طلبات المستوردين</span>
            <span className="text-xl font-bold text-gray-950">{importedRequests.length}</span>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border.5 border-gray-100 shadow-sm flex items-center gap-4">
          <div className="p-3 rounded-lg bg-amber-50 text-amber-600">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-gray-500 block">طلبات التنسيق الجارية</span>
            <span className="text-xl font-bold text-gray-950">
              {importedRequests.filter(r => !['declined', 'cancelled', 'completed'].includes(r.status)).length}
            </span>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border.5 border-gray-100 shadow-sm flex items-center gap-4">
          <div className="p-3 rounded-lg bg-emerald-50 text-emerald-600">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-gray-500 block">التوافقات والزيجات المتممة</span>
            <span className="text-xl font-bold text-gray-950">
              {importedRequests.filter(r => r.status === 'completed').length}
            </span>
          </div>
        </div>
      </div>

      {/* واجهة العمل الرئيسية - قسمين */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* قائمة الطلبات على اليمين */}
        <div className="lg:col-span-5 bg-white rounded-xl border.5 border-gray-100 shadow-sm overflow-hidden">
          {/* تبويبات وأدوات بحث */}
          <div className="p-4 border-b border-gray-100 space-y-4">
            <div className="flex border border-gray-100 p-1 rounded-lg bg-gray-50/50">
              <button
                onClick={() => { setActiveTab('active'); setSelectedReq(null); }}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition ${
                  activeTab === 'active' 
                    ? 'bg-white text-emerald-600 shadow-sm border.5 border-gray-100' 
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                تنسيق نشط ({importedRequests.filter(r => !['declined', 'cancelled', 'completed'].includes(r.status)).length})
              </button>
              <button
                onClick={() => { setActiveTab('history'); setSelectedReq(null); }}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition ${
                  activeTab === 'history' 
                    ? 'bg-white text-emerald-600 shadow-sm border.5 border-gray-100' 
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                الأرشيف والسجل ({importedRequests.filter(r => ['declined', 'cancelled', 'completed'].includes(r.status)).length})
              </button>
            </div>

            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="ابحث باسم العضو، المعرّف، اليوزر..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-3 pr-9 py-2 border.5 border-gray-200 rounded-lg text-sm focus:border-emerald-500 focus:outline-none"
                />
                <span className="absolute inset-y-0 right-3 flex items-center text-gray-400 pointer-events-none">
                  <Filter className="w-4 h-4" />
                </span>
              </div>
              <select
                value={stageFilter}
                onChange={(e) => setStageFilter(e.target.value)}
                className="border.5 border-gray-200 rounded-lg px-2 text-xs focus:outline-none focus:border-emerald-500"
              >
                <option value="all">كل المراحل</option>
                <option value="pending">طلب معلق (جديد)</option>
                <option value="accepted_pending_payment">انتظار العربون</option>
                <option value="paid">تم دفع العربون</option>
                <option value="in_mediation">الوساطة والتنسيق</option>
                <option value="completed">مكتمل (زواج)</option>
                <option value="declined">مرفوض</option>
              </select>
            </div>
          </div>

          {/* قائمة الطلبات */}
          <div className="max-h-[600px] overflow-y-auto divide-y divide-gray-100">
            {filteredRequests.length === 0 ? (
              <div className="p-8 text-center text-gray-400">
                <AlertCircle className="w-8 h-8 mx-auto text-gray-300 mb-2" />
                <span className="text-sm block">لا توجد طلبات مطابقة للمعايير المحددة</span>
              </div>
            ) : (
              filteredRequests.map((req, reqIdx) => {
                const s = allMembers.get(req.senderId);
                const r = allMembers.get(req.receiverId);
                const isSelected = selectedReq?.id === req.id;
                
                const imp = s?.sourceType === 'imported' ? s : r;
                const reg = s?.sourceType !== 'imported' ? s : r;

                const reqKey = req.id != null && String(req.id) !== '' && String(req.id) !== 'NaN' 
                  ? `req-${req.id}` 
                  : `req-idx-${reqIdx}`;

                return (
                  <button
                    key={reqKey}
                    onClick={() => setSelectedReq(req)}
                    className={`w-full p-4 text-right flex flex-col gap-2 transition hover:bg-gray-50/50 ${
                      isSelected ? 'bg-emerald-50/40 border-r-4 border-emerald-600' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-xs font-mono text-gray-400">ID: {req.id}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        req.status === 'completed' ? 'bg-emerald-50 text-emerald-700' :
                        req.status === 'in_mediation' ? 'bg-amber-50 text-amber-700' :
                        req.status === 'accepted_pending_payment' ? 'bg-indigo-50 text-indigo-700' :
                        req.status === 'paid' ? 'bg-blue-50 text-blue-700' :
                        req.status === 'declined' ? 'bg-rose-50 text-rose-700' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {req.status === 'completed' ? 'تم الزواج' :
                         req.status === 'in_mediation' ? 'الوساطة والاتصال' :
                         req.status === 'accepted_pending_payment' ? 'بانتظار العربون' :
                         req.status === 'paid' ? 'تم سداد العربون' :
                         req.status === 'declined' ? 'مرفوض/اعتذار' : 'جديد معلق'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      <div className="text-sm font-semibold text-gray-800">
                        {reg?.nickname || 'مجهول'} (مسجل)
                      </div>
                      <span className="text-xs text-gray-400">⇆</span>
                      <div className="text-sm font-bold text-emerald-800 flex items-center gap-1">
                        {imp?.nickname || 'مستورد'} 
                        <span className="bg-emerald-100 text-emerald-800 text-[9px] px-1 rounded">مستورد</span>
                      </div>
                    </div>

                    <div className="text-xs text-gray-500 line-clamp-1 italic">
                      "{req.message}"
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-gray-400 mt-1">
                      <span>تاريخ الطلب: {req.time}</span>
                      {(req.senderPaid || req.receiverPaid) && (
                        <span className="flex items-center gap-0.5 text-emerald-600">
                          <CreditCard className="w-3 h-3" />
                          عربون مدفوع
                        </span>
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* تفاصيل التنسيق ومحاكاة المحادثات على اليسار */}
        <div className="lg:col-span-7 space-y-6">
          {selectedReq ? (
            <div className="space-y-6">
              {/* لوحة رأس تفاصيل الطلب */}
              <div className="bg-white p-5 rounded-xl border.5 border-gray-100 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-gray-900">بيانات التوافق الفوري للطلب #{selectedReq.id}</h2>
                  </div>
                  <button
                    onClick={() => setSelectedReq(null)}
                    className="p-1 rounded-full hover:bg-gray-100 text-gray-500 lg:hidden"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                </div>

                {/* كروت الطرفين في التوافق */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* الطرف المسجل */}
                  <div className="p-4 rounded-lg bg-gray-50 border border-gray-100 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-indigo-700 font-semibold bg-indigo-50 px-2 py-0.5 rounded-full">الطرف المسجل</span>
                      <span className="text-xs text-gray-500">العمر: {parties?.registered?.age} سنة</span>
                    </div>
                    <div className="font-bold text-gray-900 text-base">{parties?.registered?.nickname}</div>
                    <div className="text-xs text-gray-500">{parties?.registered?.country}، {parties?.registered?.city}</div>
                    <div className="text-xs text-gray-500 font-mono">هاتف: {parties?.registered?.phone || 'غير مدرج'}</div>
                    <div className="pt-1 flex items-center justify-between text-xs border-t border-gray-200/50">
                      <span>سداد رسوم الجدية:</span>
                      <span className={`font-semibold ${selectedReq.senderPaid && !parties?.isSenderImported || selectedReq.receiverPaid && parties?.isSenderImported ? 'text-emerald-600' : 'text-amber-600'}`}>
                        {selectedReq.senderPaid && !parties?.isSenderImported || selectedReq.receiverPaid && parties?.isSenderImported ? '✓ تم السداد (مكتمل)' : '⌛ انتظار السداد'}
                      </span>
                    </div>
                  </div>

                  {/* الطرف المستورد */}
                  <div className="p-4 rounded-lg bg-emerald-50/50 border border-emerald-100/60 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-emerald-700 font-semibold bg-emerald-100 px-2 py-0.5 rounded-full">الطرف المستورد</span>
                      <span className="text-xs text-gray-500">العمر: {parties?.imported?.age} سنة</span>
                    </div>
                    <div className="font-bold text-emerald-950 text-base flex items-center gap-1">
                      {parties?.imported?.nickname}
                      {parties?.imported?.hasSeriousnessBadge && (
                        <span className="text-xs bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-normal" title="وسام الجدية">
                          ✓ وسام الجدية
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-emerald-800">{parties?.imported?.country}، {parties?.imported?.city}</div>
                    <div className="text-xs text-emerald-800 font-mono">اليوزر: {parties?.imported?.username || parties?.imported?.nickname}</div>
                    <div className="pt-1 flex items-center justify-between text-xs border-t border-emerald-200/30">
                      <span>عرض السداد للطرف الآخر:</span>
                      <span className="font-semibold text-emerald-700">
                        ✓ يظهر كمُسدّد (مستورد تلقائي)
                      </span>
                    </div>
                  </div>
                </div>

                {/* الرسالة الافتتاحية المصاحبة للطلب */}
                <div className="bg-amber-50/40 border-r-4 border-amber-500 p-3 rounded-lg text-xs text-gray-700">
                  <span className="font-semibold block mb-1">الرسالة التعبيرية للطلب:</span>
                  "{selectedReq.message}"
                </div>
              </div>

              {/* قسم التنسيق الشات والمحادثة */}
              <div className="bg-white rounded-xl border.5 border-gray-100 shadow-sm overflow-hidden flex flex-col h-[500px]">
                {/* رأس المحادثة */}
                <div className="p-4 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-emerald-600" />
                    <div>
                      <h3 className="font-bold text-sm text-gray-900">صندوق المحادثة الشرعية والتوافق</h3>
                      <p className="text-[10px] text-gray-500">متابعة رسائل الطرفين والرد باسم المستورد لإثراء التفاعل.</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">إرسال كـ:</span>
                    <select
                      value={sendAsType}
                      onChange={(e) => setSendAsType(e.target.value as any)}
                      className="border.5 border-gray-200 rounded-md py-1 px-2 text-xs bg-white text-gray-700 focus:outline-none"
                    >
                      <option value="imported">المستورد ({parties?.imported?.nickname})</option>
                      <option value="admin">إدارة المنصة</option>
                    </select>
                  </div>
                </div>

                {/* جسم المحادثة والرسائل */}
                <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-gray-50/30">
                  {chatLoading ? (
                    <div className="flex justify-center items-center h-full">
                      <RefreshCw className="w-6 h-6 animate-spin text-gray-300" />
                    </div>
                  ) : !Array.isArray(chatMessages) || chatMessages.length === 0 ? (
                    <div className="flex flex-col justify-center items-center h-full text-center text-gray-400 p-4">
                      <HelpCircle className="w-10 h-10 text-gray-300 mb-2" />
                      <span className="text-xs block">لم يتم تبادل أي رسائل في غرفة التنسيق حتى الآن.</span>
                      <span className="text-[10px] text-gray-500 mt-1">ابدأ بكتابة رسالة لتشجيع الطرف المسجل وتنسيق التواصل.</span>
                    </div>
                  ) : (
                    (Array.isArray(chatMessages) ? chatMessages : []).map((msg, idx) => {
                      const isMe = msg.sender_id === parties?.imported?.id;
                      const isAdmin = msg.sender_id === 'admin';
                      const senderNick = msg.sender_id === 'admin' 
                        ? 'إدارة المنصة' 
                        : (msg.sender_id === parties?.imported?.id 
                          ? `${parties?.imported?.nickname || 'مستورد'} (مستورد)` 
                          : `${parties?.registered?.nickname || 'مسجل'} (مسجل)`);

                      const msgKey = msg.id != null && String(msg.id) !== 'NaN' ? `msg-${msg.id}` : `msg-idx-${idx}`;

                      return (
                        <div
                          key={msgKey}
                          className={`flex flex-col max-w-[85%] ${
                            isAdmin ? 'mx-auto' : isMe ? 'mr-auto items-end' : 'ml-auto items-start'
                          }`}
                        >
                          <span className={`text-[10px] text-gray-400 mb-0.5 ${isAdmin ? 'text-center block w-full' : ''}`}>
                            {senderNick} • {new Date(msg.created_at).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <div
                            className={`p-3 rounded-xl text-xs leading-relaxed ${
                              isAdmin 
                                ? 'bg-amber-50 text-amber-900 border border-amber-100 text-center rounded-lg shadow-sm font-medium w-full' 
                                : isMe 
                                  ? 'bg-emerald-600 text-white rounded-br-none shadow-sm' 
                                  : 'bg-white text-gray-800 border.5 border-gray-100 rounded-bl-none shadow-sm'
                            }`}
                          >
                            {msg.text}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* حقل إدخال الرسالة */}
                <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-100 bg-white flex gap-2">
                  <input
                    type="text"
                    value={newMessageText}
                    onChange={(e) => setNewMessageText(e.target.value)}
                    placeholder={
                      sendAsType === 'imported'
                        ? `اكتب رداً باسم العضو المستورد: ${parties?.imported?.nickname}...`
                        : 'اكتب رسالة توجيهية وتنسيقية كجهة إدارة المنصة...'
                    }
                    className="flex-1 px-3 py-2 border.5 border-gray-200 rounded-lg text-xs focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="submit"
                    disabled={!newMessageText.trim()}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white rounded-lg transition text-xs flex items-center gap-1.5"
                  >
                    <Send className="w-4 h-4 transform rotate-180" />
                    <span>إرسال</span>
                  </button>
                </form>
              </div>

              {/* لوحة التحكم والإجراءات */}
              <div className="bg-white p-5 rounded-xl border.5 border-gray-100 shadow-sm space-y-4">
                <h3 className="font-bold text-sm text-gray-950 flex items-center gap-2 pb-2 border-b border-gray-50">
                  <ClipboardList className="w-5 h-5 text-emerald-600" />
                  أدوات التحكم وتحديث حالة التوافق
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* الملاحظات الإدارية */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-gray-700 block">ملاحظات الإدارة السرية للطلب:</label>
                    <textarea
                      value={adminNotes}
                      onChange={(e) => setAdminNotes(e.target.value)}
                      placeholder="ملاحظات سرية حول اهتمام الطرفين وجديتهم لا تظهر للأعضاء..."
                      rows={3}
                      className="w-full p-2.5 border.5 border-gray-200 rounded-lg text-xs focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* إعداد موعد التواصل أو اللقاء */}
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-gray-700 block">تاريخ اللقاء أو موعد التنسيق:</label>
                      <input
                        type="datetime-local"
                        value={meetingDate}
                        onChange={(e) => setMeetingDate(e.target.value)}
                        className="w-full p-2 border.5 border-gray-200 rounded-lg text-xs focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-gray-700 block">ملاحظات ومقر اللقاء أو تفاصيل التنسيق:</label>
                      <input
                        type="text"
                        value={meetingNotes}
                        onChange={(e) => setMeetingNotes(e.target.value)}
                        placeholder="رابط الاتصال، رقم المنسق، إرشادات للطرفين..."
                        className="w-full p-2 border.5 border-gray-200 rounded-lg text-xs focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>
                </div>

                {/* أزرار الإجراءات الفورية */}
                <div className="pt-3 border-t border-gray-50 flex flex-wrap gap-2 justify-between">
                  <div className="flex gap-2">
                    {/* تحديث الحقول فقط */}
                    <button
                      onClick={() => handleUpdateStatus('update_notes')}
                      disabled={isUpdating}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-xs transition font-semibold"
                    >
                      حفظ الملاحظات والموعد فقط
                    </button>

                    {/* تغيير مرحلة الوساطة */}
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          handleUpdateStatus('update_mediation', { mediation_stage: e.target.value });
                        }
                      }}
                      className="border.5 border-gray-200 rounded-lg px-2 text-xs focus:outline-none bg-white text-gray-700"
                      defaultValue=""
                    >
                      <option value="" disabled>نقل مرحلة الوساطة الشرعية...</option>
                      <option value="scheduling">تحديد الموعد (مجدولة)</option>
                      <option value="exchanging">تبادل الأرقام والهواتف</option>
                      <option value="evaluating">تقييم نتيجة اللقاء</option>
                    </select>
                  </div>

                  <div className="flex gap-2">
                    {selectedReq.status === 'pending' && (
                      <button
                        onClick={() => handleUpdateStatus('accept')}
                        disabled={isUpdating}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs transition font-semibold flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        قبول الطلب وتنشيطه
                      </button>
                    )}

                    {selectedReq.status !== 'completed' && selectedReq.status !== 'declined' && (
                      <>
                        <button
                          onClick={() => handleUpdateStatus('decline', { reason: 'عدم تطابق الشروط بالتنسيق مع الإدارة' })}
                          disabled={isUpdating}
                          className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-xs transition font-semibold flex items-center gap-1"
                        >
                          <XCircle className="w-4 h-4" />
                          رفض / اعتذار للطلب
                        </button>
                        
                        <button
                          onClick={() => handleUpdateStatus('complete')}
                          disabled={isUpdating}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs transition font-semibold flex items-center gap-1"
                        >
                          <UserCheck className="w-4 h-4" />
                          إتمام الزواج والتوافق مكتمل ✓
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* نص تنبيهي */}
                <div className="bg-blue-50/50 p-3 rounded-lg flex items-start gap-2 text-xs text-blue-900 border border-blue-100/50">
                  <Info className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <p>
                    ملاحظة: عند سداد العربون أو اتخاذ أي إجراء هنا، يتم فورياً ترحيل البيانات لتعديل حالة رحلة التوافق لدى الطرف المسجل في لوحة حساباته لضمان الشفافية، وسيظهر له أن المستورد قد قام بسداد العربون بالكامل.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-12 rounded-xl border.5 border-gray-100 shadow-sm text-center text-gray-400 flex flex-col items-center justify-center min-h-[500px]">
              <div className="p-4 rounded-full bg-emerald-50 text-emerald-600 mb-4 animate-pulse">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-gray-800 mb-1">حدد توافقاً أو طلباً للبدء في التنسيق</h3>
              <p className="text-xs text-gray-500 max-w-sm leading-relaxed">
                اضغط على أي طلب في القائمة الجانبية لعرض الملفات الشخصية بالتفصيل، وإدارة غرف الدردشة بالنيابة عن المستورد، ومتابعة سداد العربون والرسوم.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
