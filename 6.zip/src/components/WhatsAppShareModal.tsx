import { useState, useMemo } from 'react';
import { MessageCircle, Check, Copy, Sparkles, User } from 'lucide-react';
import Modal from './ui/Modal';

interface MemberData {
  id?: string;
  username?: string;
  nickname?: string;
  name?: string;
  realName?: string;
  gender?: string;
  age?: number | string;
  country?: string;
  city?: string;
  nationality?: string;
  maritalLabel?: string;
  maritalStatus?: string;
  marital_status?: string;
  marriageType?: string;
  marriageTypeLabel?: string;
  khataabaPhone?: string;
  khataaba_phone?: string;
  [key: string]: unknown;
}

interface WhatsAppShareModalProps {
  open: boolean;
  onClose: () => void;
  member?: MemberData | null;
  platformWhatsApp?: string;
}

const DEFAULT_TEMPLATES = [
  { id: 'match', label: 'أرغب في توافق مع هذا الملف', text: 'السلام عليكم ورحمة الله، أرغب في توافق مع هذا الملف المبارك.' },
  { id: 'inquire', label: 'الاستفسار عن إتاحة الملف', text: 'السلام عليكم ورحمة الله، هل هذا الملف متاح حالياً للتوافق والتقدم؟' },
  { id: 'details', label: 'طلب تفاصيل إضافية', text: 'تحية طيبة، اطلعت على هذا الملف وأرغب في تزويدي بمزيد من التفاصيل حوله للتوافق.' },
  { id: 'custom', label: 'كتابة رسالة مخصصة', text: '' },
];

export default function WhatsAppShareModal({
  open,
  onClose,
  member,
  platformWhatsApp = '966500000000',
}: WhatsAppShareModalProps) {
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('match');
  const [customMessage, setCustomMessage] = useState<string>('السلام عليكم ورحمة الله، أرغب في توافق مع هذا الملف المبارك.');
  const [includeProfileDetails, setIncludeProfileDetails] = useState<boolean>(true);
  const [targetRecipient, setTargetRecipient] = useState<'share' | 'admin'>('share');
  const [copied, setCopied] = useState<boolean>(false);

  const isMale = member?.gender === 'male';
  const memberName = member?.nickname || member?.name || member?.realName || 'عضو توافق';
  const memberCode = member?.username ? `@${member.username}` : (member?.id ? `#${member.id}` : '');
  
  const profileUrl = typeof window !== 'undefined' && member
    ? (member.username ? `${window.location.origin}/u/${member.username}` : `${window.location.origin}/member/${member.id}`)
    : '';

  const marital = member?.maritalLabel || member?.marital_status || member?.maritalStatus || 'غير محدد';
  const marriageType = member?.marriageTypeLabel || (member?.marriageType === 'misyar' ? 'مسيار' : member?.marriageType === 'both' ? 'معلن أو مسيار' : 'معلن');
  const location = member ? [member.country, member.city].filter(Boolean).join(' - ') || 'السعودية' : '';
  const age = member?.age ? `${member.age} سنة` : '';
  const nationality = member?.nationality || '';

  // تجهيز نص الرسالة الكاملة
  const fullMessage = useMemo(() => {
    if (!member) return '';
    const parts: string[] = [];

    // الرسالة الأساسية
    if (customMessage.trim()) {
      parts.push(customMessage.trim());
    }

    // ملخص بيانات الملف
    if (includeProfileDetails) {
      parts.push('\n━━━━━━━━━━━━━━━━━━━━\n📋 *بيانات الملف للتعريف والتنسيق:*');
      parts.push(`▫️ *الاسم:* ${memberName} ${memberCode ? `(${memberCode})` : ''}`);
      parts.push(`▫️ *الجنس:* ${isMale ? 'ذكر (خاطب)' : 'أنثى (مخطوبة)'}`);
      if (age) parts.push(`▫️ *العمر:* ${age}`);
      if (location) parts.push(`▫️ *الإقامة:* ${location}`);
      if (nationality) parts.push(`▫️ *الجنسية:* ${nationality}`);
      if (marital) parts.push(`▫️ *الحالة الاجتماعية:* ${marital}`);
      if (marriageType) parts.push(`▫️ *نوع الزواج المطلوب:* ${marriageType}`);
      if (profileUrl) {
        parts.push(`\n🔗 *رابط الملف على المنصة:*\n${profileUrl}`);
      }
      parts.push('━━━━━━━━━━━━━━━━━━━━');
    }

    return parts.join('\n');
  }, [member, customMessage, includeProfileDetails, memberName, memberCode, isMale, age, location, nationality, marital, marriageType, profileUrl]);

  const handleTemplateSelect = (template: typeof DEFAULT_TEMPLATES[0]) => {
    setSelectedTemplateId(template.id);
    if (template.id !== 'custom') {
      setCustomMessage(template.text);
    }
  };

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(fullMessage)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      })
      .catch(() => {});
  };

  const handleSendWhatsApp = () => {
    const encoded = encodeURIComponent(fullMessage);
    let waUrl = `https://wa.me/?text=${encoded}`;
    
    // إذا اختار الإرسال لرقم إدارة المنصة أو رقم الخطابة المربوط
    const targetPhone = member?.khataabaPhone || member?.khataaba_phone || platformWhatsApp;
    if (targetRecipient === 'admin' && targetPhone) {
      const cleanPhone = (targetPhone as string).replace(/[^\d]/g, '');
      waUrl = `https://wa.me/${cleanPhone}?text=${encoded}`;
    }

    window.open(waUrl, '_blank', 'noopener,noreferrer');
    onClose();
  };

  if (!member) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="مشاركة الملف عبر واتساب 💬"
      size="md"
    >
      <div className="space-y-4 text-right" dir="rtl">
        {/* بطاقة العضو المصغرة */}
        <div className={`p-3 rounded-2xl border flex items-center gap-3 ${
          isMale 
            ? 'bg-sky-50/70 border-sky-200/80 text-sky-950'
            : 'bg-rose-50/70 border-rose-200/80 text-rose-950'
        }`}>
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center font-cairo font-bold text-white shadow-xs ${
            isMale ? 'bg-sky-600' : 'bg-rose-500'
          }`}>
            <User className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-cairo font-bold text-sm truncate">{memberName}</span>
              {memberCode && <span className="font-mono text-[11px] text-slate-500">{memberCode}</span>}
            </div>
            <div className="text-xs text-slate-600 font-tajawal flex items-center gap-2 mt-0.5">
              <span>{age}</span>
              <span>•</span>
              <span>{location}</span>
              <span>•</span>
              <span className="font-semibold">{marriageType}</span>
            </div>
          </div>
        </div>

        {/* اختيار رسالة جاهزة */}
        <div>
          <label className="block text-xs font-cairo font-bold text-slate-700 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>اختر نص الرسالة أو اكتب رسالتك:</span>
          </label>
          <div className="grid grid-cols-1 gap-1.5">
            {DEFAULT_TEMPLATES.map((tmpl) => (
              <button
                key={tmpl.id}
                type="button"
                onClick={() => handleTemplateSelect(tmpl)}
                className={`w-full text-right p-2.5 rounded-xl border text-xs font-cairo transition-all flex items-center justify-between ${
                  selectedTemplateId === tmpl.id
                    ? 'border-emerald-500 bg-emerald-50/70 text-emerald-900 font-bold shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>{tmpl.label}</span>
                {selectedTemplateId === tmpl.id && (
                  <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* حقل تعديل نص الرسالة */}
        <div>
          <label className="block text-xs font-cairo font-bold text-slate-700 mb-1">
            نص الرسالة:
          </label>
          <textarea
            rows={2}
            value={customMessage}
            onChange={(e) => {
              setCustomMessage(e.target.value);
              setSelectedTemplateId('custom');
            }}
            placeholder="اكتب رسالتك هنا..."
            className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 font-tajawal text-xs focus:outline-none focus:border-emerald-500 text-slate-800"
          />
        </div>

        {/* خيار تضمين ملخص بيانات الملف */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 space-y-2">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={includeProfileDetails}
              onChange={(e) => setIncludeProfileDetails(e.target.checked)}
              className="w-4 h-4 rounded accent-emerald-600 cursor-pointer"
            />
            <span className="text-xs font-cairo font-semibold text-slate-800">
              تضمين ملخص بيانات الملف ورابطه تلقائياً في الرسالة
            </span>
          </label>

          {/* خيار جهة الإرسال */}
          <div className="pt-2 border-t border-slate-200/60 flex items-center gap-4 text-xs font-cairo">
            <span className="text-slate-500 font-bold">طريقة الإرسال:</span>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="targetRecipient"
                value="share"
                checked={targetRecipient === 'share'}
                onChange={() => setTargetRecipient('share')}
                className="accent-emerald-600 cursor-pointer"
              />
              <span className="text-slate-700">مشاركة حرة (اختيار جهة اتصال)</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="radio"
                name="targetRecipient"
                value="admin"
                checked={targetRecipient === 'admin'}
                onChange={() => setTargetRecipient('admin')}
                className="accent-emerald-600 cursor-pointer"
              />
              <span className="text-slate-700">مباشرة لإدارة توافق / المنسق</span>
            </label>
          </div>
        </div>

        {/* معاينة نص الرسالة النهائية */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-cairo font-bold text-slate-500">معاينة الرسالة كما ستصل:</span>
            <button
              type="button"
              onClick={handleCopyMessage}
              className="text-[11px] font-cairo text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ بنجاح ✓' : 'نسخ الرسالة'}</span>
            </button>
          </div>
          <div className="p-3 bg-emerald-900/5 rounded-xl border border-emerald-200/60 max-h-36 overflow-y-auto font-tajawal text-xs text-slate-700 whitespace-pre-line dir-rtl leading-relaxed select-all">
            {fullMessage}
          </div>
        </div>

        {/* الأزرار السفلية */}
        <div className="flex gap-2 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={handleSendWhatsApp}
            className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-cairo font-bold text-sm transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>فتح في تطبيق واتساب 💬</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-cairo font-bold text-xs transition-colors"
          >
            إلغاء
          </button>
        </div>
      </div>
    </Modal>
  );
}
