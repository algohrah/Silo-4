import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCw, Monitor, Smartphone, Tablet, ExternalLink, Terminal, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { ProjectFile, ConsoleLog } from '../types';

interface LivePreviewProps {
  files: ProjectFile[];
  language: 'ar' | 'en';
}

export const LivePreview: React.FC<LivePreviewProps> = ({ files, language }) => {
  const [deviceViewport, setDeviceViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeTab, setActiveTab] = useState<'preview' | 'console'>('preview');
  const [logs, setLogs] = useState<ConsoleLog[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Generate combined HTML for iframe
  const generateIframeContent = () => {
    const entryHtml = files.find(f => f.name.toLowerCase() === 'index.html' || f.name.endsWith('.html')) || files[0];
    
    if (!entryHtml) {
      return `<!DOCTYPE html><html><body style="background:#0f172a;color:#94a3b8;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"><h3>لم يتم العثور على ملف HTML رئيسي للعرض</h3></body></html>`;
    }

    let htmlContent = entryHtml.content;

    // Intercept Console Logs
    const consoleInterceptorScript = `
      <script>
        (function() {
          const sendLog = (type, args) => {
            try {
              window.parent.postMessage({
                type: 'RUNNER_CONSOLE_LOG',
                logType: type,
                message: Array.from(args).map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')
              }, '*');
            } catch (e) {}
          };
          const _log = console.log, _warn = console.warn, _error = console.error, _info = console.info;
          console.log = function(...args) { sendLog('log', args); _log.apply(console, args); };
          console.warn = function(...args) { sendLog('warn', args); _warn.apply(console, args); };
          console.error = function(...args) { sendLog('error', args); _error.apply(console, args); };
          console.info = function(...args) { sendLog('info', args); _info.apply(console, args); };

          window.addEventListener('error', function(e) {
            sendLog('error', [e.message + ' at ' + e.filename + ':' + e.lineno]);
          });
        })();
      </script>
    `;

    // Inject linked CSS files if not already present
    const cssFiles = files.filter(f => f.name.endsWith('.css'));
    let injectedStyles = '';
    cssFiles.forEach(css => {
      injectedStyles += `<style data-filename="${css.name}">\n${css.content}\n</style>\n`;
    });

    // Inject linked JS files
    const jsFiles = files.filter(f => f.name.endsWith('.js') && f.name !== 'index.html');
    let injectedScripts = '';
    jsFiles.forEach(js => {
      injectedScripts += `<script data-filename="${js.name}">\n${js.content}\n</script>\n`;
    });

    // Inject before </head> or </body>
    if (htmlContent.includes('</head>')) {
      htmlContent = htmlContent.replace('</head>', `${consoleInterceptorScript}${injectedStyles}</head>`);
    } else {
      htmlContent = `${consoleInterceptorScript}${injectedStyles}${htmlContent}`;
    }

    if (htmlContent.includes('</body>')) {
      htmlContent = htmlContent.replace('</body>', `${injectedScripts}</body>`);
    } else {
      htmlContent = `${htmlContent}${injectedScripts}`;
    }

    return htmlContent;
  };

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'RUNNER_CONSOLE_LOG') {
        const newLog: ConsoleLog = {
          id: `log-${Date.now()}-${Math.random()}`,
          type: event.data.logType || 'log',
          message: event.data.message || '',
          timestamp: new Date().toLocaleTimeString(),
        };
        setLogs(prev => [newLog, ...prev.slice(0, 49)]);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleRefresh = () => {
    setLogs([]);
    setRefreshKey(prev => prev + 1);
  };

  const handleOpenNewWindow = () => {
    const html = generateIframeContent();
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
    }
  };

  const getViewportWidth = () => {
    switch (deviceViewport) {
      case 'mobile': return 'max-w-[375px]';
      case 'tablet': return 'max-w-[768px]';
      default: return 'w-full';
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl flex flex-col h-full overflow-hidden text-slate-200 shadow-lg">
      
      {/* Top Controls Bar */}
      <div className="p-3 border-b border-slate-800 bg-slate-900 flex flex-wrap items-center justify-between gap-3">
        
        {/* Left Status / Tabs */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'preview'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'العرض المباشر' : 'Live Preview'}</span>
          </button>

          <button
            onClick={() => setActiveTab('console')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'console'
                ? 'bg-slate-800 text-amber-300 border border-amber-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'السجل البرمجي' : 'Console'}</span>
            {logs.length > 0 && (
              <span className="bg-amber-500/20 text-amber-300 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                {logs.length}
              </span>
            )}
          </button>
        </div>

        {/* Viewport & Utility Controls */}
        <div className="flex items-center gap-2">
          {/* Device Toggles */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setDeviceViewport('desktop')}
              className={`p-1.5 rounded-lg transition-colors ${deviceViewport === 'desktop' ? 'bg-slate-800 text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
              title="Desktop"
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDeviceViewport('tablet')}
              className={`p-1.5 rounded-lg transition-colors ${deviceViewport === 'tablet' ? 'bg-slate-800 text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
              title="Tablet"
            >
              <Tablet className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDeviceViewport('mobile')}
              className={`p-1.5 rounded-lg transition-colors ${deviceViewport === 'mobile' ? 'bg-slate-800 text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
              title="Mobile"
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Action Buttons */}
          <button
            onClick={handleRefresh}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
            title={language === 'ar' ? 'تحديث العرض' : 'Refresh Preview'}
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleOpenNewWindow}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
            title={language === 'ar' ? 'فتح في نافذة مستقلة' : 'Open in new tab'}
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>

      {/* Main Sandbox Area */}
      <div className="flex-1 bg-slate-950 p-3 flex justify-center items-center overflow-hidden relative">
        {activeTab === 'preview' ? (
          <div className={`h-full ${getViewportWidth()} transition-all duration-300 w-full bg-white rounded-xl shadow-2xl overflow-hidden relative border border-slate-700/50`}>
            <iframe
              key={refreshKey}
              ref={iframeRef}
              srcDoc={generateIframeContent()}
              title="Project Live Preview"
              sandbox="allow-scripts allow-same-origin allow-modals allow-forms"
              className="w-full h-full border-0 bg-white"
            />
          </div>
        ) : (
          /* Console Output Screen */
          <div className="w-full h-full bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs overflow-y-auto custom-scrollbar space-y-2">
            <div className="flex justify-between items-center pb-2 border-b border-slate-800 text-slate-400">
              <span className="font-bold flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-amber-400" />
                {language === 'ar' ? 'مخرجات المطور (Logs)' : 'Console Output Logs'}
              </span>
              <button
                onClick={() => setLogs([])}
                className="text-slate-500 hover:text-rose-400 text-[11px]"
              >
                {language === 'ar' ? 'مسح السجل' : 'Clear Logs'}
              </button>
            </div>

            {logs.length === 0 ? (
              <div className="text-slate-600 text-center py-12">
                {language === 'ar' ? 'لا توجد رسائل مسجلة حتى الآن' : 'No logs recorded yet'}
              </div>
            ) : (
              logs.map((log) => (
                <div
                  key={log.id}
                  className={`p-2.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                    log.type === 'error'
                      ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                      : log.type === 'warn'
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                      : 'bg-slate-900 border-slate-800 text-slate-300'
                  }`}
                >
                  <span className="text-[10px] text-slate-500 mt-0.5 shrink-0">{log.timestamp}</span>
                  <span className="break-all font-mono whitespace-pre-wrap">{log.message}</span>
                </div>
              ))
            )}
          </div>
        )}
      </div>

    </div>
  );
};
