import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, MapPin, Briefcase, GraduationCap, Ruler, Heart, Bookmark,
  ShieldCheck, Calendar, Users, Copy, Share2, Crown, Check,
  AlertTriangle, Send, Ban, Weight, Palette, Stethoscope, Cigarette,
  Home, ExternalLink, FileText, User, Sparkles, Building2, Church,
  TreePine, Flame, Zap, Shield, Eye, Lock, Globe, Baby, Scale, MessageCircle,
  MoreVertical, ChevronDown, CheckCircle2,
} from 'lucide-react';
import type { Member } from '../lib/members';
import { useApp } from '../lib/AppContext';
import { getAvatar, getGenderColors } from '../lib/types';
import { formatMaritalStatus, getPartnerSummary } from '../lib/memberUtils';
import { getCurrentUserId, useInterestRequests } from '../lib/useInterestRequests';
import { normalizeNationality } from '../lib/data/optionNormalizer';
import WhatsAppShareModal from './WhatsAppShareModal';

interface MemberProfileModalProps {
  member: Member | null;
  open: boolean;
  onClose: () => void;
}

const MESSAGE_TEMPLATES = [
  'السلام عليكم ورحمة الله، لفت انتباهي توافق ملفنا وأتمنى التوفيق لنا.',
  'مرحبًا، أرى توافقًا في القيم والأهداف وأرغب بالتوافق الجاد للزواج بإذن الله.',
  'السلام عليكم، ملفك أعجبني وأبحث عن شريك بصفات مشابهة، أتمنى التواصل.',
  'تحية طيبة، لاحظت توافقًا في المواصفات وأرغب في التقدم عبر الإدارة.',
];

export default function MemberProfileModal({ member, open, onClose }: MemberProfileModalProps) {
  const navigate = useNavigate();
  const {
    user, likedMembers, toggleLike, showToast, checkLimit, incrementUsage,
    sendInterestRequest, submitReport,
    blockedMembers, toggleBlock,
  } = useApp();

  const [contactOpen, setContactOpen] = useState(false);
  const [contactMsg, setContactMsg] = useState('');
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [sending, setSending] = useState(false);
  const [whatsAppModalOpen, setWhatsAppModalOpen] = useState(false);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);

  const currentUserId = user?.isLoggedIn ? (user.memberId || getCurrentUserId()) : '';
  const { requests } = useInterestRequests(currentUserId);

  const latestRequest = useMemo(() => {
    if (!user?.isLoggedIn || !requests || requests.length === 0 || !member?.id || !currentUserId) return null;
    const sent = requests.filter(r => r.sender_id === currentUserId && r.receiver_id === member.id);
    if (sent.length === 0) return null;
    return [...sent].sort((a, b) => b.id - a.id)[0];
  }, [requests, currentUserId, member?.id, user?.isLoggedIn]);

  if (!open || !member) return null;

  const liked = user?.isLoggedIn ? likedMembers.has(member.id) : false;
  const isBlocked = user?.isLoggedIn ? blockedMembers.has(member.id) : false;
  const isSelf = Boolean(user?.isLoggedIn && currentUserId && member.id === currentUserId);

  const safeGender = (member.gender === 'male' || member.gender === 'female' ? member.gender : 'female') as any;
  const avatar = getAvatar(safeGender);
  const c = getGenderColors(safeGender);
  const isMale = member.gender === 'male';

  const maritalFormatted = formatMaritalStatus(member.maritalStatus, member.maritalLabel, member.gender);
  const marriageTypeFormatted = (
    member.marriageType === 'misyar' || (member as any).marriage_type === 'misyar' ? 'مسيار' :
    member.marriageType === 'both' || (member as any).marriage_type === 'both' || member.marriageTypeLabel?.includes('مسيار') && member.marriageTypeLabel?.includes('معلن') ? 'لا مانع / معلن او مسيار' :
    member.marriageType === 'announced' || (member as any).marriage_type === 'announced' ? 'معلن' :
    member.marriageTypeLabel || ''
  );
  const partnerSummary = getPartnerSummary(member);

  const limitCheck = checkLimit('message');

  // نسخ جميع بيانات العضو بطريقة مرتبة وشاملة للحافظة
  const handleCopyMemberData = () => {
    const genderWord = isMale ? 'رجل' : 'امرأة';
    const profileUrl = member.username
      ? `${window.location.origin}/u/${member.username}`
      : `${window.location.origin}/member/${member.id}`;

    const lines = [
      `📌 **بيانات العضو في منصة توافق للزواج الشرعي** 📌`,
      `━━━━━━━━━━━━━━━━━━━━`,
      `👤 الاسم المستعار: ${member.nickname || 'غير محدد'}`,
      member.username ? `🆔 اليوزر: @${member.username}` : null,
      `⚤ الجنس: ${genderWord}`,
      `🎂 العمر: ${member.age ? `${member.age} سنة` : 'غير محدد'}`,
      `📍 الدولة والمدينة: ${[member.city, member.country].filter(Boolean).join('، ') || 'غير محدد'}`,
      member.district ? `🏙️ المنطقة/الحي: ${member.district}` : null,
      member.nationality ? `🌍 الجنسية: ${member.nationality}` : null,
      member.sect ? `🕌 المذهب: ${member.sect}` : null,
      (member as any).tribe ? `🏛️ القبيلة/النسب: ${(member as any).tribe}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      `💍 الحالة الاجتماعية: ${member.maritalLabel || member.maritalStatus || 'غير محدد'}`,
      marriageTypeFormatted ? `📜 نوع الزواج المطلوب: ${marriageTypeFormatted}` : null,
      member.hasChildren ? `👶 الأطفال: نعم (${member.childrenCount || 'يوجد'})` : `👶 الأطفال: لا يوجد`,
      member.housing ? `🏠 السكن: ${member.housing}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      `💼 العمل والوظيفة: ${member.jobTitle || member.workType || 'غير محدد'}`,
      member.education ? `🎓 المؤهل التعليمي: ${member.education}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      member.height ? `📏 الطول: ${member.height} سم` : null,
      member.weight ? `⚖️ الوزن: ${member.weight} كجم` : null,
      member.skinColor ? `🎨 لون البشرة: ${member.skinColor}` : null,
      member.health ? `🏥 الحالة الصحية: ${member.health}` : null,
      member.smoking ? `🚬 التدخين: ${member.smoking}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      member.bio ? `📝 نبذة عني:\n"${member.bio}"` : null,
      member.aboutPartner ? `🎯 مواصفات الشريك المطلوب:\n"${member.aboutPartner}"` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      `✨ الشارات: ${[
        member.verified ? '✓ موثق' : '',
        member.hasSeriousnessBadge ? '🏅 جاد' : '',
        member.plan === 'gold' ? '👑 ذهبي' : member.plan === 'elite' ? '⭐ مميز' : '',
      ].filter(Boolean).join(' | ') || 'عضو عادي'}`,
      `🔗 رابط الملف الشخصي: ${profileUrl}`,
    ].filter(Boolean).join('\n');

    navigator.clipboard.writeText(lines)
      .then(() => {
        showToast('تم نسخ كافة بيانات العضو إلى الحافظة بنجاح! 📋', 'success');
      })
      .catch(() => {
        showToast('تعذّر النسخ إلى الحافظة', 'error');
      });
  };

  const handleCopyLink = () => {
    const profileUrl = member.username
      ? `${window.location.origin}/u/${member.username}`
      : `${window.location.origin}/member/${member.id}`;
    navigator.clipboard.writeText(profileUrl)
      .then(() => showToast('تم نسخ رابط الملف الشخصي ✓', 'success'))
      .catch(() => showToast('تعذّر النسخ', 'error'));
  };

  const handleShareWhatsApp = () => {
    setWhatsAppModalOpen(true);
  };

  const handleViewFullPage = () => {
    onClose();
    navigate(`/member/${member.id}`);
  };

  const handleSendInterest = async () => {
    if (!limitCheck.allowed) {
      showToast('لقد وصلت للحد الأقصى لإرسال طلبات الاهتمام اليوم', 'error');
      return;
    }
    setSending(true);
    try {
      const msg = contactMsg || 'طلب توافق جديد للزواج عبر المنصة';
      const res = await sendInterestRequest(member.id, msg);
      if (res?.ok) {
        incrementUsage('message');
        setContactOpen(false);
        setContactMsg('');
        showToast('تم إرسال طلب التوافق بنجاح! سيتم إشعار الطرف الآخر. 💌', 'success');
      } else {
        showToast(res?.error || 'حدث خطأ أثناء إرسال الطلب', 'error');
      }
    } catch {
      showToast('تعذر إرسال الطلب، يرجى المحاولة لاحقاً', 'error');
    } finally {
      setSending(false);
    }
  };

  const handleReportSubmit = () => {
    if (!reportReason.trim()) {
      showToast('يرجى كتابة سبب البلاغ', 'error');
      return;
    }
    submitReport(member.id, reportReason);
    setReportOpen(false);
    setReportReason('');
    showToast('تم إرسال بلاغك للإدارة بنجاح، وستتم مراجعته بفحص دقيق.', 'success');
  };

  return (
    <>
      <div key={`modal-overlay-${member.id}`} className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-hidden dir-rtl" dir="rtl">
        {/* الخلفية المظلمة الضبابية */}
        <motion.div
          key={`modal-backdrop-${member.id}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-navy-950/75 backdrop-blur-md"
          onClick={onClose}
        />

        {/* جسم النافذة المنبثقة */}
        <motion.div
          key={`modal-card-${member.id}`}
          initial={{ opacity: 0, y: 50, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.97 }}
          transition={{ type: 'spring', damping: 26, stiffness: 300 }}
          className={`relative w-full max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[92vh] flex flex-col overflow-hidden border transition-colors ${
            isMale
              ? 'bg-[#edf5ff] dark:bg-[#0b1728] border-sky-300 dark:border-sky-800/80'
              : 'bg-[#faf0f4] dark:bg-[#230913] border-rose-300 dark:border-rose-900/80'
          }`}
        >
          {/* Header Bar: هيدر مرتب بدون تكرار أزرار */}
          <div className={`sticky top-0 z-20 flex items-center justify-between px-4 sm:px-6 py-3 border-b ${
            isMale
              ? 'bg-[#e0f2fe]/95 dark:bg-[#071322]/95 border-sky-200 dark:border-sky-800/80 backdrop-blur-md'
              : 'bg-[#f4dbe3]/95 dark:bg-[#1a050d]/95 border-rose-200 dark:border-rose-900/80 backdrop-blur-md'
          }`}>
            <div className="flex items-center gap-2 min-w-0">
              <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 animate-pulse ${isMale ? 'bg-sky-500' : 'bg-rose-600'}`} />
              <h3 className="font-cairo font-bold text-sm sm:text-base text-navy-900 dark:text-cream-50 truncate">
                ملف العضو: {member.nickname}
              </h3>
              {member.username && (
                <span className="text-xs font-mono text-navy-400 dark:text-slate-400 hidden xs:inline" dir="ltr">
                  @{member.username}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
              {/* زر عرض الصفحة كاملة (أنيق وموجز في الرأس) */}
              <button
                onClick={handleViewFullPage}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/90 dark:bg-navy-800/90 hover:bg-white dark:hover:bg-navy-800 text-navy-800 dark:text-cream-100 font-cairo font-bold text-xs transition-colors border border-navy-100 dark:border-navy-700 shadow-2xs cursor-pointer"
                title="الانتقال إلى الصفحة الكاملة"
              >
                <ExternalLink className="w-3.5 h-3.5 text-gold-600" />
                <span className="hidden xs:inline">عرض الصفحة كاملة</span>
              </button>

              {/* زر إغلاق النافذة */}
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-white/80 hover:bg-white dark:bg-navy-800 dark:hover:bg-navy-700 flex items-center justify-center text-navy-600 dark:text-cream-200 transition-colors shadow-2xs cursor-pointer"
                title="إغلاق النافذة"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* محتوى البطاقة القابل للتمرير */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 sm:space-y-5">

            {/* 1. بطاقة البطل التلخيصية (Hero Profile Card) */}
            <div className={`relative rounded-2xl p-4 border shadow-sm transition-colors ${
              isMale
                ? 'bg-gradient-to-br from-sky-50 via-blue-50/40 to-white dark:from-sky-950/40 dark:to-navy-800/90 border-sky-200/80 dark:border-sky-800/40'
                : 'bg-gradient-to-br from-[#4a1224]/10 via-rose-50/50 to-white dark:from-[#3a0d1c]/40 dark:to-navy-800/90 border-rose-200/80 dark:border-rose-900/50'
            }`}>
              <div className="flex items-start gap-3.5 sm:gap-4">
                {/* الصورة الرمزية مع الشارة */}
                <div className="relative flex-shrink-0">
                  <div className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white dark:bg-navy-950 p-1 ring-2 ${c.ring} ring-opacity-30 shadow-md flex items-center justify-center overflow-hidden`}>
                    <img src={avatar} alt="" className="w-full h-full object-contain p-1.5" />
                  </div>
                  {member.verified && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 ring-2 ring-white flex items-center justify-center shadow-xs" title="حساب موثّق">
                      <ShieldCheck className="w-3 h-3 text-white" />
                    </span>
                  )}
                </div>

                {/* تفاصيل الاسم والشارات الأساسية */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h2 className="font-cairo font-black text-lg sm:text-xl text-navy-900 dark:text-cream-50 leading-tight">
                      {member.nickname}
                    </h2>
                    {member.username && (
                      <span className="text-xs font-mono text-navy-400 dark:text-slate-400" dir="ltr">@{member.username}</span>
                    )}
                  </div>

                  {/* الشارات المعتمدة */}
                  <div className="flex items-center gap-1.5 flex-wrap mb-2">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg ${c.badgeBg} text-white font-cairo font-bold text-[10px]`}>
                      {isMale ? 'رجل' : 'امرأة'}
                    </span>
                    {member.verified && (
                      <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold">
                        <ShieldCheck className="w-3 h-3 text-emerald-600" /> موثّق
                      </span>
                    )}
                    {member.hasSeriousnessBadge && (
                      <span className="inline-flex items-center gap-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold shadow-xs">
                        🏅 جاد
                      </span>
                    )}
                    {member.plan === 'gold' && (
                      <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold">
                        <Crown className="w-3 h-3 text-amber-500 fill-amber-500" /> ذهبي
                      </span>
                    )}
                    {(member.plan === 'elite' || (member.premium && member.plan !== 'gold')) && (
                      <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-200 px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold">
                        ⭐ مميز
                      </span>
                    )}
                  </div>

                  {/* معلومات أساسية سريعة */}
                  <div className="flex items-center gap-3 flex-wrap text-xs text-navy-700 dark:text-cream-200/80 font-tajawal">
                    <span className="inline-flex items-center gap-1"><Calendar className="w-3.5 h-3.5 text-gold-600" />{member.age ? `${member.age} سنة` : '—'}</span>
                    <span className="inline-flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-gold-600" />{[member.city, member.country].filter(Boolean).join('، ') || 'الموقع غير محدد'}</span>
                    <span className="inline-flex items-center gap-1"><Users className="w-3.5 h-3.5 text-gold-600" />{maritalFormatted}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. شريط الخصوصية والوساطة الشرعية (رسالة طمأنة وتوضيح) */}
            <div className="bg-emerald-50/70 dark:bg-emerald-950/30 rounded-2xl p-3 border border-emerald-200/70 dark:border-emerald-800/50 flex items-start gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs font-tajawal text-emerald-900 dark:text-emerald-200 leading-relaxed">
                <strong className="font-cairo font-bold block mb-0.5">وساطة شرعية وسرية تامة:</strong>
                يتم التواصل والتوافق بخصوصية عالية تحت إشراف الإدارة، ولا تظهر بيانات الاتصال المباشرة إلا بإذن شرعي رسمي من الطرفين.
              </div>
            </div>

            {/* 3. مواصفات الشريك المطلوب (أبحث عن) — لها الأولوية القصوى لمعرفة التوافق */}
            <div className="bg-white dark:bg-navy-800/60 rounded-2xl p-4 border border-rose-200/80 dark:border-rose-900/50 shadow-xs space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-cairo font-bold text-xs sm:text-sm">
                  <Heart className="w-4.5 h-4.5 text-rose-500 fill-rose-100" />
                  <span>مواصفات الشريك المطلوب (أبحث عن):</span>
                </div>
                <span className="text-[10px] font-cairo font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300 px-2 py-0.5 rounded-full border border-rose-200/60">
                  المواصفات المطلوبة
                </span>
              </div>

              {/* الوسوم الشاملة لمواصفات الشريك */}
              {partnerSummary.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {partnerSummary.tags.map((tag, tIdx) => (
                    <span key={`modal-tag-${tag.label}-${tIdx}`} className="bg-rose-50 dark:bg-rose-950/50 text-rose-900 dark:text-rose-200 px-2.5 py-1 rounded-lg text-xs font-cairo font-bold border border-rose-200/80 dark:border-rose-800/60 shadow-2xs">
                      {tag.label}: {tag.value}
                    </span>
                  ))}
                </div>
              )}

              {/* النص التفصيلي والملاحظات */}
              {partnerSummary.text ? (
                <p className="text-xs sm:text-sm font-tajawal text-navy-800 dark:text-cream-100 leading-relaxed bg-rose-50/40 dark:bg-navy-950/40 p-3 rounded-xl border border-rose-100 dark:border-navy-800">
                  {partnerSummary.text}
                </p>
              ) : partnerSummary.tags.length === 0 ? (
                <p className="text-xs font-tajawal text-navy-400 dark:text-slate-400 italic">
                  لم يقم العضو بتحديد مواصفات الشريك بعد.
                </p>
              ) : null}
            </div>

            {/* 4. نبذة عني (عن نفسي) */}
            <div className="bg-white dark:bg-navy-800/60 rounded-2xl p-4 border border-cream-200 dark:border-navy-700/60 shadow-xs space-y-1.5">
              <div className="flex items-center gap-2 text-gold-600 font-cairo font-bold text-xs sm:text-sm">
                <FileText className="w-4.5 h-4.5 text-gold-500" />
                <span>نبذة عن العضو (عن نفسي):</span>
              </div>
              <p className="text-xs sm:text-sm font-tajawal text-navy-800 dark:text-cream-100 leading-relaxed bg-cream-50/60 dark:bg-navy-950/40 p-3 rounded-xl border border-cream-100 dark:border-navy-800">
                {member.bio || 'لم يقم العضو بإضافة نبذة عن نفسه بعد.'}
              </p>
            </div>

            {/* 5. المعلومات الأساسية والشخصية */}
            <div className="space-y-2">
              <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                <User className="w-4 h-4 text-amber-500" />
                <span>المعلومات الأساسية والشخصية:</span>
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2">
                <DetailGridItem icon={User} label="الجنس" value={member.gender === 'female' ? 'أنثى' : 'ذكر'} />
                {member.age ? <DetailGridItem icon={Calendar} label="العمر" value={`${member.age} سنة`} /> : null}
                {member.country && !['—', ''].includes(member.country) ? <DetailGridItem icon={MapPin} label="الدولة" value={normalizeNationality(member.country)} /> : null}
                {member.city && !['—', ''].includes(member.city) ? <DetailGridItem icon={MapPin} label="المدينة" value={member.city} /> : null}
                {member.district && !['—', 'غير ينطبق', ''].includes(member.district) ? <DetailGridItem icon={MapPin} label="الحي / المنطقة" value={member.district} /> : null}
                {member.nationality && !['—', ''].includes(member.nationality) ? <DetailGridItem icon={Globe} label="الجنسية" value={normalizeNationality(member.nationality)} /> : null}
                {member.sect && !['—', 'غير ينطبق', ''].includes(member.sect) ? <DetailGridItem icon={Church} label="المذهب" value={member.sect} /> : null}
                {member.tribe && !['—', 'غير ينطبق', ''].includes(member.tribe) ? (
                  <DetailGridItem icon={TreePine} label="القبيلة / النسب" value={member.tribe} />
                ) : null}
                {member.ethnicity && !['—', 'غير ينطبق', ''].includes(member.ethnicity) ? (
                  <DetailGridItem icon={Globe} label="العرق / الأصل" value={member.ethnicity} />
                ) : null}
              </div>
            </div>

            {/* 6. الحالة الاجتماعية والسكن والأبناء والتعدد */}
            <div className="space-y-2">
              <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-500" />
                <span>الحالة الاجتماعية والسكن والأبناء:</span>
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2">
                <DetailGridItem icon={Users} label="الحالة الاجتماعية" value={maritalFormatted} />
                {marriageTypeFormatted && !['غير ينطبق', '—', ''].includes(marriageTypeFormatted) && (
                  <DetailGridItem icon={Heart} label="نوع الزواج" value={marriageTypeFormatted} />
                )}
                {member.gender === 'male' && member.wifeCount && !['غير ينطبق', 'لا يوجد', 'لا يوجد (أعزب)', '—', '0', ''].includes(member.wifeCount) && ['married', 'متزوج'].includes(member.maritalStatus) && (
                  <DetailGridItem icon={Users} label="عدد الزوجات الحالي" value={member.wifeCount} />
                )}
                {member.gender === 'male' && member.seekingWife && !['غير ينطبق', '—', '', 'غير متعدد', 'زواج أول (غير متعدد)'].includes(member.seekingWife) && (
                  <DetailGridItem icon={Heart} label="التعدد / رغبة الزواج" value={member.seekingWife} />
                )}
                {(() => {
                  const isSingle = ['single', 'أعزب', 'عزباء'].includes(member.maritalStatus) || ['أعزب', 'عزباء'].includes(maritalFormatted);
                  if (member.hasChildren) {
                    return <DetailGridItem icon={Users} label="وجود أبناء" value="نعم" />;
                  }
                  if (!isSingle) {
                    return <DetailGridItem icon={Users} label="وجود أبناء" value="لا يوجد" />;
                  }
                  return null;
                })()}
                {member.hasChildren && member.childrenCount && !['لا يوجد', 'غير ينطبق', '—', '0', ''].includes(member.childrenCount) && (
                  <DetailGridItem icon={Baby} label="عدد الأبناء" value={member.childrenCount} />
                )}
                {member.hasChildren && member.childrenLiveWith && !['لا يوجد', 'غير ينطبق', '—', ''].includes(member.childrenLiveWith) && (
                  <DetailGridItem icon={Home} label="إقامة الأبناء" value={member.childrenLiveWith} />
                )}
                {member.housing && !['—', 'غير ينطبق', ''].includes(member.housing) && (
                  <DetailGridItem icon={Home} label="نوع السكن" value={member.housing} />
                )}
              </div>
            </div>

            {/* 7. التعليم والعمل */}
            {(member.education || member.workType || member.jobTitle) && (
              <div className="space-y-2">
                <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-blue-500" />
                  <span>التعليم والعمل:</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2">
                  {member.education && !['—', ''].includes(member.education) ? <DetailGridItem icon={GraduationCap} label="المؤهل العلمي" value={member.education} /> : null}
                  {member.workType && !['—', ''].includes(member.workType) ? <DetailGridItem icon={Building2} label="جهة العمل" value={member.workType} /> : null}
                  {member.jobTitle && !['—', ''].includes(member.jobTitle) ? <DetailGridItem icon={Briefcase} label="المسمى الوظيفي" value={member.jobTitle} /> : null}
                </div>
              </div>
            )}

            {/* 8. المواصفات الجسدية والصحية */}
            {(member.height || member.weight || member.skinColor || member.health || member.smoking) && (
              <div className="space-y-2">
                <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                  <Ruler className="w-4 h-4 text-purple-500" />
                  <span>المواصفات الجسدية والصحية:</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2">
                  {member.height ? <DetailGridItem icon={Ruler} label="الطول" value={`${member.height} سم`} /> : null}
                  {member.weight ? <DetailGridItem icon={Weight} label="الوزن" value={`${member.weight} كجم`} /> : null}
                  {member.skinColor && !['—', ''].includes(member.skinColor) ? <DetailGridItem icon={Palette} label="لون البشرة" value={member.skinColor} /> : null}
                  {member.health && !['—', ''].includes(member.health) ? <DetailGridItem icon={Stethoscope} label="الحالة الصحية" value={member.health} /> : null}
                  {member.smoking && !['—', ''].includes(member.smoking) ? <DetailGridItem icon={Cigarette} label="التدخين" value={member.smoking} /> : null}
                </div>
              </div>
            )}

            {/* حقل رسالة طلب الاهتمام المنبثقة إن كانت مفتوحة */}
            {contactOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-white dark:bg-navy-900 rounded-2xl p-4 border-2 border-amber-400 dark:border-amber-600 space-y-3 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-xs sm:text-sm text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                    <Send className="w-4 h-4 -scale-x-100 text-amber-600" />
                    <span>إرسال طلب توافق للزواج:</span>
                  </span>
                  <button onClick={() => setContactOpen(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-navy-800">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* القوالب الجاهزة */}
                <div className="space-y-1.5">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 font-cairo">اختر قالباً سريعاً:</span>
                  <div className="grid grid-cols-1 gap-1.5 max-h-32 overflow-y-auto pr-1">
                    {MESSAGE_TEMPLATES.map((tpl, i) => (
                      <button
                        key={`modal-tpl-${i}`}
                        onClick={() => setContactMsg(tpl)}
                        className="text-right text-xs font-tajawal bg-cream-50 dark:bg-navy-800/60 hover:bg-cream-100 p-2 rounded-xl text-navy-800 dark:text-cream-100 border border-cream-200 dark:border-navy-700 transition-colors truncate"
                      >
                        {tpl}
                      </button>
                    ))}
                  </div>
                </div>

                <textarea
                  value={contactMsg}
                  onChange={(e) => setContactMsg(e.target.value)}
                  rows={2}
                  placeholder="اكتب رسالة اهتمام مخصصة أو اختر من القوالب أعلاه..."
                  className="w-full px-3 py-2 rounded-xl bg-cream-50 dark:bg-navy-950 border border-cream-300 dark:border-navy-700 font-tajawal text-xs focus:outline-none focus:border-amber-500 dark:text-cream-50"
                />

                <button
                  onClick={handleSendInterest}
                  disabled={sending}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-cairo font-bold text-xs shadow-soft transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5 -scale-x-100" />
                  <span>{sending ? 'جاري إرسال الطلب...' : 'تأكيد إرسال طلب التوافق 💌'}</span>
                </button>
              </motion.div>
            )}

            {/* نموذج الإبلاغ إن كان مفتوحاً */}
            {reportOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-white dark:bg-navy-900 rounded-2xl p-4 border border-rose-300 dark:border-rose-900/60 space-y-3 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-xs sm:text-sm text-rose-700 dark:text-rose-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-500" />
                    <span>إرسال بلاغ ضد العضو:</span>
                  </span>
                  <button onClick={() => setReportOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <textarea
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                  rows={2}
                  placeholder="وضح سبب البلاغ للإدارة بالتفصيل..."
                  className="w-full px-3 py-2 rounded-xl bg-rose-50/50 dark:bg-navy-950 border border-rose-200 dark:border-navy-700 font-tajawal text-xs focus:outline-none focus:border-rose-500 dark:text-cream-50"
                />

                <button
                  onClick={handleReportSubmit}
                  className="w-full py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs transition-all cursor-pointer"
                >
                  تأكيد إرسال البلاغ للإدارة ⚠️
                </button>
              </motion.div>
            )}

          </div>

          {/* ═══════════ شريط الإجراءات السفلي الذكي والمطور (STICKY ACTION BAR) ═══════════ */}
          <div className={`p-3 sm:p-4 border-t relative z-30 transition-colors ${
            isMale
              ? 'bg-[#e0f2fe] dark:bg-[#071322] border-sky-200 dark:border-sky-800/80'
              : 'bg-[#f4dbe3] dark:bg-[#1a050d] border-rose-200 dark:border-rose-900/80'
          }`}>
            <div className="flex items-center gap-2">
              {/* 1. الزر الأساسي الأكبر: إرسال طلب التوافق أو متابعته */}
              <div className="flex-1 min-w-0">
                {latestRequest ? (
                  latestRequest.journey_stage === 'declined' || latestRequest.journey_stage === 'cancelled' ? (
                    <button
                      onClick={() => {
                        if (!user?.isLoggedIn) {
                          showToast('يرجى تسجيل الدخول أولاً لإرسال طلب توافق', 'info');
                          onClose();
                          navigate('/login');
                          return;
                        }
                        setContactOpen(true);
                      }}
                      className="w-full py-2.5 sm:py-3 px-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-cairo font-black text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Send className="w-4 h-4 -scale-x-100" />
                      <span className="truncate">طلب توافق جديد 💌</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        onClose();
                        navigate('/requests');
                      }}
                      className="w-full py-2.5 sm:py-3 px-3 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-cairo font-black text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span className="truncate">
                        {latestRequest.journey_stage === 'sent' ? 'الطلب قيد الانتظار (متابعة)' : 'متابعة رحلة التوافق'}
                      </span>
                    </button>
                  )
                ) : (
                  <button
                    onClick={() => {
                      if (!user?.isLoggedIn) {
                        showToast('يرجى تسجيل الدخول أو إنشاء حساب أولاً لإرسال طلب توافق', 'info');
                        onClose();
                        navigate('/login');
                        return;
                      }
                      setContactOpen(!contactOpen);
                    }}
                    disabled={isSelf}
                    className="w-full py-2.5 sm:py-3 px-3 rounded-2xl bg-gradient-to-r from-amber-500 via-gold-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-cairo font-black text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-4 h-4 -scale-x-100 text-slate-900" />
                    <span className="truncate">إرسال طلب توافق للزواج 💌</span>
                  </button>
                )}
              </div>

              {/* 2. زر الواتساب للتوافق */}
              <button
                onClick={handleShareWhatsApp}
                className="py-2.5 sm:py-3 px-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs flex-shrink-0"
                title="إرسال طلب توافق أو استفسار عبر واتساب"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span className="hidden xs:inline">واتساب</span>
              </button>

              {/* 3. زر المفضلة التفاعلي */}
              <button
                onClick={() => {
                  if (!user?.isLoggedIn) {
                    showToast('يرجى تسجيل الدخول لحفظ العضو في المفضلة', 'info');
                    onClose();
                    navigate('/login');
                    return;
                  }
                  toggleLike(member.id);
                }}
                className={`py-2.5 sm:py-3 px-3 rounded-2xl font-cairo font-bold text-xs transition-all flex items-center justify-center gap-1.5 border cursor-pointer flex-shrink-0 shadow-xs ${
                  liked
                    ? 'bg-amber-500 text-white border-amber-500'
                    : 'bg-white dark:bg-navy-900 text-navy-700 dark:text-cream-100 border-cream-300 dark:border-navy-700 hover:bg-cream-50'
                }`}
                title={liked ? 'إزالة من المحفوظات' : 'حفظ في المفضلة'}
              >
                <Bookmark className={`w-4 h-4 ${liked ? 'fill-white' : ''}`} />
                <span className="hidden sm:inline">{liked ? 'محفوظ' : 'حفظ'}</span>
              </button>

              {/* 4. قائمة الخيارات الإضافية والأمان المنسدلة (...) */}
              <div className="relative flex-shrink-0">
                <button
                  onClick={() => setMoreMenuOpen(!moreMenuOpen)}
                  className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-white dark:bg-navy-900 hover:bg-cream-100 dark:hover:bg-navy-800 text-navy-700 dark:text-cream-100 border border-cream-300 dark:border-navy-700 transition-colors flex items-center justify-center cursor-pointer shadow-xs"
                  title="خيارات إضافية"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>

                {/* القائمة المنسدلة */}
                <AnimatePresence>
                  {moreMenuOpen && (
                    <motion.div
                      key="modal-more-menu-dropdown"
                      initial={{ opacity: 0, scale: 0.95, y: 10 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: 10 }}
                      className="absolute left-0 bottom-full mb-2 w-52 bg-white dark:bg-navy-900 rounded-2xl shadow-xl border border-cream-200 dark:border-navy-700 p-1.5 z-50 space-y-1 text-right"
                    >
                      {/* نسخ بيانات العضو */}
                      <button
                        onClick={() => {
                          setMoreMenuOpen(false);
                          handleCopyMemberData();
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-cairo font-bold text-navy-800 dark:text-cream-100 hover:bg-cream-50 dark:hover:bg-navy-800 transition-colors cursor-pointer"
                      >
                        <Copy className="w-4 h-4 text-amber-600" />
                        <span>نسخ كافة بيانات العضو</span>
                      </button>

                      {/* نسخ رابط الملف */}
                      <button
                        onClick={() => {
                          setMoreMenuOpen(false);
                          handleCopyLink();
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-cairo font-bold text-navy-800 dark:text-cream-100 hover:bg-cream-50 dark:hover:bg-navy-800 transition-colors cursor-pointer"
                      >
                        <Share2 className="w-4 h-4 text-blue-500" />
                        <span>نسخ رابط الملف</span>
                      </button>

                      {/* حظر العضو */}
                      {user?.isLoggedIn && !isSelf && (
                        <button
                          onClick={() => {
                            setMoreMenuOpen(false);
                            toggleBlock(member.id);
                            showToast(isBlocked ? 'تم إلغاء حظر العضو' : 'تم حظر العضو بنجاح', isBlocked ? 'info' : 'warning');
                          }}
                          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-cairo font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-navy-800 transition-colors cursor-pointer"
                        >
                          <Ban className="w-4 h-4 text-slate-500" />
                          <span>{isBlocked ? 'إلغاء حظر العضو' : 'حظر العضو'}</span>
                        </button>
                      )}

                      {/* إبلاغ الإدارة */}
                      {user?.isLoggedIn && !isSelf && (
                        <button
                          onClick={() => {
                            setMoreMenuOpen(false);
                            setReportOpen(true);
                          }}
                          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-cairo font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer border-t border-cream-100 dark:border-navy-800 pt-2"
                        >
                          <AlertTriangle className="w-4 h-4 text-rose-500" />
                          <span>إبلاغ الإدارة عن العضو</span>
                        </button>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
                {moreMenuOpen && (
                  <div key="modal-more-menu-backdrop" className="fixed inset-0 z-40" onClick={() => setMoreMenuOpen(false)} />
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* نافذة خيارات وإرسال رسالة الواتساب */}
      <WhatsAppShareModal
        open={whatsAppModalOpen}
        onClose={() => setWhatsAppModalOpen(false)}
        member={member}
      />
    </>
  );
}

// عنصر الخلية الصغيرة في قائمة التفاصيل
function DetailGridItem({ icon: Icon, label, value }: { icon: any; label: string; value: string | number }) {
  return (
    <div className="bg-cream-50/80 dark:bg-navy-950/60 rounded-xl p-2 sm:p-2.5 border border-cream-200/70 dark:border-navy-800 flex items-start gap-1.5 sm:gap-2 min-w-0">
      <Icon className="w-3.5 h-3.5 text-gold-600 dark:text-gold-400 mt-0.5 flex-shrink-0" />
      <div className="min-w-0 flex-1">
        <span className="block text-[9px] sm:text-[10px] text-navy-400 dark:text-slate-400 font-tajawal leading-none mb-1 truncate">{label}</span>
        <span className="block text-[11px] sm:text-xs font-cairo font-bold text-navy-900 dark:text-cream-50 truncate" title={String(value)}>{value}</span>
      </div>
    </div>
  );
}

