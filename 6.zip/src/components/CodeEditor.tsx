import React from 'react';
import { Copy, Check, Download, Code2, Save } from 'lucide-react';
import { ProjectFile } from '../types';

interface CodeEditorProps {
  file: ProjectFile | null;
  onCodeChange: (fileId: string, newContent: string) => void;
  language: 'ar' | 'en';
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ file, onCodeChange, language }) => {
  const [copied, setCopied] = React.useState(false);

  if (!file) {
    return (
      <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl h-full flex flex-col items-center justify-center p-8 text-slate-500 text-center">
        <Code2 className="w-12 h-12 mb-3 text-slate-600 stroke-[1.5]" />
        <p className="text-sm font-medium">
          {language === 'ar' ? 'حدد ملفاً من القائمة الجانبية لعرض وتعديل الكود' : 'Select a file to view and edit code'}
        </p>
      </div>
    );
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(file.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.name;
    link.click();
    URL.revokeObjectURL(url);
  };

  const lineCount = file.content.split('\n').length;
  const lineNumbers = Array.from({ length: Math.max(lineCount, 1) }, (_, i) => i + 1);

  return (
    <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl flex flex-col h-full overflow-hidden text-slate-200 shadow-lg">
      
      {/* File Bar Header */}
      <div className="p-3 border-b border-slate-800 bg-slate-900 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold text-slate-200 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700/80">
            {file.path || file.name}
          </span>
          <span className="text-[10px] uppercase font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded-md">
            {file.language}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700/80 px-2.5 py-1 rounded-lg text-xs transition-colors"
            title={language === 'ar' ? 'نسخ الكود' : 'Copy code'}
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? (language === 'ar' ? 'تم النسخ' : 'Copied') : (language === 'ar' ? 'نسخ' : 'Copy')}</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center gap-1 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700/80 px-2.5 py-1 rounded-lg text-xs transition-colors"
            title={language === 'ar' ? 'تنزيل الملف' : 'Download file'}
          >
            <Download className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'تحميل' : 'Download'}</span>
          </button>
        </div>
      </div>

      {/* Editor Container with Line Numbers */}
      <div className="flex-1 flex overflow-hidden font-mono text-xs relative bg-slate-950">
        
        {/* Line Numbers Column */}
        <div className="select-none py-3 px-2 text-right text-slate-600 bg-slate-900/60 border-r border-slate-800/80 shrink-0 w-12 overflow-hidden">
          {lineNumbers.map((num) => (
            <div key={num} className="leading-5">
              {num}
            </div>
          ))}
        </div>

        {/* Textarea Code Input */}
        <textarea
          value={file.content}
          onChange={(e) => onCodeChange(file.id, e.target.value)}
          spellCheck={false}
          className="w-full h-full p-3 bg-transparent text-slate-200 focus:outline-none resize-none leading-5 font-mono selection:bg-indigo-500/30 selection:text-white custom-scrollbar whitespace-pre"
        />
      </div>

      {/* Footer Info */}
      <div className="px-3 py-1.5 border-t border-slate-800/80 bg-slate-900/80 flex items-center justify-between text-[11px] text-slate-500">
        <span>{lineCount} {language === 'ar' ? 'أسطر' : 'lines'}</span>
        <span className="flex items-center gap-1 text-emerald-400 font-medium">
          <Save className="w-3 h-3" />
          {language === 'ar' ? 'التحديث القائم ينعكس فورياً على العرض' : 'Live synced with preview'}
        </span>
      </div>

    </div>
  );
};
