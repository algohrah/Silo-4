import React from 'react';
import { Layers, CheckCircle2, FileCode2, Zap, ArrowUpRight, FolderGit2 } from 'lucide-react';
import { ProjectFile, ProjectAnalysis } from '../types';

interface ProjectSummaryBannerProps {
  files: ProjectFile[];
  projectName?: string;
  onOpenUploadModal: () => void;
  onLoadSample: (sampleId: string) => void;
  language: 'ar' | 'en';
}

export const ProjectSummaryBanner: React.FC<ProjectSummaryBannerProps> = ({
  files,
  projectName,
  onOpenUploadModal,
  onLoadSample,
  language
}) => {
  const analyzeProject = (): ProjectAnalysis => {
    let framework: ProjectAnalysis['framework'] = 'HTML5/JS';
    const filenames = files.map(f => f.name.toLowerCase());
    
    if (filenames.some(f => f.includes('react') || f.endsWith('.jsx') || f.endsWith('.tsx'))) {
      framework = 'React';
    } else if (filenames.includes('vite.config.ts') || filenames.includes('vite.config.js')) {
      framework = 'Vite';
    } else if (filenames.includes('package.json')) {
      framework = 'Node.js';
    }

    const entryPoint = filenames.find(f => f === 'index.html') 
      || filenames.find(f => f.endsWith('.html')) 
      || filenames.find(f => f === 'app.js' || f === 'main.js')
      || files[0]?.name 
      || null;

    const hasCss = files.some(f => f.name.endsWith('.css'));
    const hasJs = files.some(f => f.name.endsWith('.js') || f.name.endsWith('.ts') || f.name.endsWith('.jsx') || f.name.endsWith('.tsx'));

    return {
      framework,
      entryPoint,
      totalFiles: files.length,
      dependencies: [],
      hasCss,
      hasJs,
      recommendations: [
        language === 'ar' ? 'تم تجهيز محرك المعاينة الفورية لربط الكود تلقائياً' : 'Live preview engine synced automatically'
      ]
    };
  };

  const analysis = analyzeProject();

  return (
    <div className="bg-gradient-to-r from-slate-900 via-indigo-950/50 to-slate-900 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl text-slate-100">
      <div className="flex flex-wrap items-center justify-between gap-4">
        
        {/* Left Info Group */}
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 shadow-inner">
            <FolderGit2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white">
                {projectName || (language === 'ar' ? 'مشروعك المرفوع' : 'Uploaded Project')}
              </h1>
              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                {language === 'ar' ? 'جاهز للتشغيل' : 'Ready to Run'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-3">
              <span className="flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-indigo-400" />
                {analysis.framework}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <FileCode2 className="w-3.5 h-3.5 text-emerald-400" />
                {analysis.totalFiles} {language === 'ar' ? 'ملفات' : 'files'}
              </span>
              <span>•</span>
              <span>
                {language === 'ar' ? 'الملف الرئيسي:' : 'Entry:'} <code className="text-amber-300 font-mono">{analysis.entryPoint}</code>
              </span>
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenUploadModal}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2.5 rounded-2xl transition-all shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 active:scale-95"
          >
            <Zap className="w-4 h-4" />
            <span>{language === 'ar' ? 'رفع مشروع آخر (ZIP)' : 'Upload New Project'}</span>
          </button>

          <div className="flex gap-1.5 bg-slate-950/60 p-1 rounded-2xl border border-slate-800">
            <button
              onClick={() => onLoadSample('dashboard')}
              className="text-xs text-slate-300 hover:text-white hover:bg-slate-800 px-3 py-1.5 rounded-xl transition-colors"
            >
              {language === 'ar' ? 'تجربة Dashboard' : 'Sample Dashboard'}
            </button>
            <button
              onClick={() => onLoadSample('interactive-app')}
              className="text-xs text-slate-300 hover:text-white hover:bg-slate-800 px-3 py-1.5 rounded-xl transition-colors"
            >
              {language === 'ar' ? 'تجربة Tasks App' : 'Sample Tasks App'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
