import React, { useState, useRef } from 'react';
import { Upload, FileArchive, FolderPlus, FileCode, CheckCircle2, AlertCircle, X } from 'lucide-react';
import JSZip from 'jszip';
import { ProjectFile } from '../types';

interface DropZoneProps {
  onFilesLoaded: (files: ProjectFile[], projectName?: string) => void;
  isOpen: boolean;
  onClose: () => void;
  language: 'ar' | 'en';
}

export const DropZone: React.FC<DropZoneProps> = ({ onFilesLoaded, isOpen, onClose, language }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pastedCode, setPastedCode] = useState('');
  const [pastedFileName, setPastedFileName] = useState('index.html');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const zipInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const getLanguageFromExt = (filename: string): ProjectFile['language'] => {
    const ext = filename.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'html': case 'htm': return 'html';
      case 'css': return 'css';
      case 'js': case 'jsx': return 'javascript';
      case 'ts': case 'tsx': return 'typescript';
      case 'json': return 'json';
      case 'md': return 'markdown';
      case 'py': return 'python';
      default: return 'text';
    }
  };

  const handleZipFile = async (file: File) => {
    setLoading(true);
    setError(null);
    try {
      const zip = new JSZip();
      const contents = await zip.loadAsync(file);
      const parsedFiles: ProjectFile[] = [];

      let idCounter = 1;
      for (const relativePath of Object.keys(contents.files)) {
        const zipObj = contents.files[relativePath];
        if (!zipObj.dir && !relativePath.startsWith('__MACOSX') && !relativePath.includes('.DS_Store')) {
          const text = await zipObj.async('string');
          const cleanPath = relativePath.replace(/^[^/]+\//, ''); // strip top folder if present
          const filename = cleanPath.split('/').pop() || relativePath;

          parsedFiles.push({
            id: `zip-file-${idCounter++}`,
            name: filename,
            path: cleanPath || relativePath,
            language: getLanguageFromExt(filename),
            content: text,
          });
        }
      }

      if (parsedFiles.length === 0) {
        throw new Error(language === 'ar' ? 'لم يتم العثور على ملفات برمجية صالحة داخل الأرشيف' : 'No valid code files found inside the ZIP archive');
      }

      onFilesLoaded(parsedFiles, file.name.replace(/\.zip$/i, ''));
      onClose();
    } catch (err: any) {
      setError(err.message || (language === 'ar' ? 'فشل فك ضغط الملف' : 'Failed to extract ZIP file'));
    } finally {
      setLoading(false);
    }
  };

  const handleMultipleFiles = async (files: FileList) => {
    setLoading(true);
    setError(null);
    try {
      const parsedFiles: ProjectFile[] = [];
      let idCounter = 1;

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.name.endsWith('.zip')) {
          await handleZipFile(file);
          return;
        }

        const text = await file.text();
        const relPath = (file as any).webkitRelativePath || file.name;

        parsedFiles.push({
          id: `raw-file-${idCounter++}`,
          name: file.name,
          path: relPath,
          language: getLanguageFromExt(file.name),
          content: text,
        });
      }

      if (parsedFiles.length > 0) {
        onFilesLoaded(parsedFiles);
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Error reading uploaded files');
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleMultipleFiles(e.dataTransfer.files);
    }
  };

  const handlePasteSubmit = () => {
    if (!pastedCode.trim()) return;
    const filename = pastedFileName.trim() || 'index.html';
    const newFile: ProjectFile = {
      id: `pasted-${Date.now()}`,
      name: filename,
      path: filename,
      language: getLanguageFromExt(filename),
      content: pastedCode,
    };
    onFilesLoaded([newFile]);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 md:p-8 shadow-2xl relative text-slate-100 animate-in fade-in zoom-in duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
            <Upload className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold">
            {language === 'ar' ? 'رفع وتشغيل ملفات المشروع' : 'Upload & Run Project Files'}
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            {language === 'ar'
              ? 'يمكنك رفع ملف مضغوط (ZIP)، أو اختيار عدة ملفات، أو لصق الكود مباشرة'
              : 'Support ZIP archives, folder selection, multi-file uploads, or raw code pasting'}
          </p>
        </div>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 p-3 rounded-xl text-xs flex items-center gap-2 mb-4">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Drag & Drop Area */}
        <div
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer ${
            isDragging
              ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]'
              : 'border-slate-700/80 hover:border-slate-600 bg-slate-800/40 hover:bg-slate-800/60'
          }`}
        >
          {loading ? (
            <div className="flex flex-col items-center justify-center py-4">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-2"></div>
              <p className="text-xs text-indigo-300">
                {language === 'ar' ? 'جاري معالجة وفك ضغط الملفات...' : 'Processing and extracting project files...'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex justify-center gap-3 text-slate-400">
                <FileArchive className="w-8 h-8 text-amber-400" />
                <FolderPlus className="w-8 h-8 text-indigo-400" />
                <FileCode className="w-8 h-8 text-emerald-400" />
              </div>
              <p className="text-sm font-semibold text-slate-200">
                {language === 'ar' ? 'اسحب وأسقط ملف ZIP أو المستندات هنا' : 'Drag & Drop ZIP or project files here'}
              </p>
              <div className="flex flex-wrap justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => zipInputRef.current?.click()}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-md"
                >
                  {language === 'ar' ? 'اختر ملف ZIP' : 'Select ZIP Archive'}
                </button>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium px-4 py-2.5 rounded-xl transition-all"
                >
                  {language === 'ar' ? 'اختر عدة ملفات' : 'Select Multiple Files'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Hidden Inputs */}
        <input
          type="file"
          ref={zipInputRef}
          accept=".zip"
          onChange={(e) => e.target.files?.[0] && handleZipFile(e.target.files[0])}
          className="hidden"
        />
        <input
          type="file"
          ref={fileInputRef}
          multiple
          onChange={(e) => e.target.files && handleMultipleFiles(e.target.files)}
          className="hidden"
        />

        {/* Quick Raw Code Paste Option */}
        <div className="mt-6 pt-6 border-t border-slate-800 space-y-3">
          <label className="text-xs font-semibold text-slate-300 block">
            {language === 'ar' ? 'أو قم بلصق كود المباشر هنا:' : 'Or paste raw code directly:'}
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={pastedFileName}
              onChange={(e) => setPastedFileName(e.target.value)}
              placeholder="index.html"
              className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white w-36 focus:outline-none focus:border-indigo-500"
            />
            <button
              onClick={handlePasteSubmit}
              disabled={!pastedCode.trim()}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-bold px-4 py-1.5 rounded-xl transition-all ml-auto"
            >
              {language === 'ar' ? 'تشغيل الكود الملصوق' : 'Run Pasted Code'}
            </button>
          </div>
          <textarea
            value={pastedCode}
            onChange={(e) => setPastedCode(e.target.value)}
            placeholder={
              language === 'ar'
                ? '<!DOCTYPE html>\n<html>\n  <body><h1>مرحباً بك!</h1></body>\n</html>'
                : 'Paste your HTML, CSS, JS, or JSON code here...'
            }
            rows={4}
            className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-3 font-mono text-xs text-slate-200 focus:outline-none focus:border-indigo-500/80 resize-none"
          />
        </div>

      </div>
    </div>
  );
};
