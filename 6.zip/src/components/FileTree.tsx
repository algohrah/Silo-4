import React, { useState } from 'react';
import { FileCode, FileText, Plus, Trash2, Search, FileJson, FileType, Code } from 'lucide-react';
import { ProjectFile } from '../types';

interface FileTreeProps {
  files: ProjectFile[];
  activeFileId: string | null;
  onSelectFile: (file: ProjectFile) => void;
  onDeleteFile: (id: string) => void;
  onAddFile: (file: ProjectFile) => void;
  language: 'ar' | 'en';
}

export const FileTree: React.FC<FileTreeProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onDeleteFile,
  onAddFile,
  language
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newFileName, setNewFileName] = useState('');

  const getFileIcon = (lang: ProjectFile['language'], filename: string) => {
    if (filename.endsWith('.html') || filename.endsWith('.htm')) return <Code className="w-4 h-4 text-orange-400" />;
    if (filename.endsWith('.css')) return <FileType className="w-4 h-4 text-sky-400" />;
    if (filename.endsWith('.js') || filename.endsWith('.jsx')) return <FileCode className="w-4 h-4 text-yellow-400" />;
    if (filename.endsWith('.ts') || filename.endsWith('.tsx')) return <FileCode className="w-4 h-4 text-indigo-400" />;
    if (filename.endsWith('.json')) return <FileJson className="w-4 h-4 text-emerald-400" />;
    return <FileText className="w-4 h-4 text-slate-400" />;
  };

  const handleCreateFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;

    const name = newFileName.trim();
    const ext = name.split('.').pop()?.toLowerCase();
    let lang: ProjectFile['language'] = 'text';
    if (ext === 'html' || ext === 'htm') lang = 'html';
    else if (ext === 'css') lang = 'css';
    else if (ext === 'js' || ext === 'jsx') lang = 'javascript';
    else if (ext === 'ts' || ext === 'tsx') lang = 'typescript';
    else if (ext === 'json') lang = 'json';

    const newFile: ProjectFile = {
      id: `custom-${Date.now()}`,
      name,
      path: name,
      language: lang,
      content: lang === 'html' ? '<!DOCTYPE html>\n<html>\n<head>\n  <title>New File</title>\n</head>\n<body>\n  <h1>Hello World</h1>\n</body>\n</html>' : ''
    };

    onAddFile(newFile);
    setNewFileName('');
    setIsAdding(false);
  };

  const filteredFiles = files.filter(f =>
    f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.path.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl flex flex-col h-full overflow-hidden text-slate-200 shadow-lg">
      
      {/* Header & Controls */}
      <div className="p-3 border-b border-slate-800 flex items-center justify-between gap-2 bg-slate-900">
        <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          📁 {language === 'ar' ? 'ملفات المشروع' : 'Project Files'} ({files.length})
        </span>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="text-slate-400 hover:text-indigo-400 p-1 rounded-lg hover:bg-slate-800 transition-colors"
          title={language === 'ar' ? 'إضافة ملف جديد' : 'Add new file'}
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* New File Input */}
      {isAdding && (
        <form onSubmit={handleCreateFile} className="p-2 border-b border-slate-800 bg-slate-950/50">
          <input
            type="text"
            autoFocus
            value={newFileName}
            onChange={(e) => setNewFileName(e.target.value)}
            placeholder="script.js, style.css..."
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
          />
        </form>
      )}

      {/* Search Input */}
      <div className="p-2 border-b border-slate-800/60">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'ar' ? 'بحث عن ملف...' : 'Search files...'}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-slate-700"
          />
        </div>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
        {filteredFiles.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">
            {language === 'ar' ? 'لا توجد ملفات مطابقة' : 'No files found'}
          </div>
        ) : (
          filteredFiles.map((file) => {
            const isActive = file.id === activeFileId;
            return (
              <div
                key={file.id}
                onClick={() => onSelectFile(file)}
                className={`group flex items-center justify-between px-3 py-2 rounded-xl text-xs cursor-pointer transition-all border ${
                  isActive
                    ? 'bg-indigo-600/15 border-indigo-500/40 text-indigo-300 font-medium shadow-sm'
                    : 'border-transparent hover:bg-slate-800/60 text-slate-300 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  {getFileIcon(file.language, file.name)}
                  <span className="truncate">{file.path || file.name}</span>
                </div>

                {files.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteFile(file.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-rose-500/10 transition-all"
                    title={language === 'ar' ? 'حذف الملف' : 'Delete file'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
