export interface ProjectFile {
  id: string;
  name: string;
  path: string;
  content: string;
  language: 'html' | 'css' | 'javascript' | 'typescript' | 'json' | 'markdown' | 'python' | 'text';
  isFolder?: boolean;
  parentId?: string | null;
}

export interface ConsoleLog {
  id: string;
  type: 'log' | 'info' | 'warn' | 'error';
  message: string;
  timestamp: string;
}

export interface ProjectAnalysis {
  framework: 'HTML5/JS' | 'React' | 'Vite' | 'Node.js' | 'Python' | 'Static Site' | 'Unknown';
  entryPoint: string | null;
  totalFiles: number;
  dependencies: string[];
  hasCss: boolean;
  hasJs: boolean;
  recommendations: string[];
}

export interface SampleProject {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  icon: string;
  files: ProjectFile[];
}
