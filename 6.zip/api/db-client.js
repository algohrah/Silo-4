import { createClient } from '@supabase/supabase-js';
import { triggerRestore } from './db-wake.js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY || '';

let supabase;

if (url && key && !url.includes('placeholder')) {
  supabase = createClient(url, key, {
    global: {
      fetch: async (targetUrl, options) => {
        const res = await fetch(targetUrl, options);
        if (!res.ok && res.status >= 500) triggerRestore();
        return res;
      },
    },
  });
} else {
  const createDummyQuery = () => {
    const dummy = {
      select: () => dummy,
      insert: () => dummy,
      update: () => dummy,
      delete: () => dummy,
      eq: () => dummy,
      neq: () => dummy,
      order: () => dummy,
      limit: () => dummy,
      single: async () => ({ data: null, error: null }),
      maybeSingle: async () => ({ data: null, error: null }),
      then: (resolve) => resolve({ data: [], error: null }),
    };
    return dummy;
  };

  supabase = {
    auth: {
      getUser: async () => ({ data: { user: { id: 'admin-1', email: 'admin@tawafok.com' } }, error: null }),
    },
    from: () => createDummyQuery(),
  };
}

export default supabase;

