import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://xqsizkjfqitbnziyyuho.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "sb_publishable_gK6MItlQbKGZB--RjnxWiA_qzPY8QGJ";

// التحقق من وجود مفاتيح ربط Supabase حقيقية لتهيئة العميل الفعلي
export const hasRealSupabase = !!(
  supabaseUrl &&
  supabaseAnonKey &&
  supabaseUrl !== 'placeholder-url' &&
  supabaseAnonKey !== 'placeholder-key'
);

type LocalSession = {
  access_token: string;
  refresh_token: string;
  user: { id: string; email: string };
};

const AUTH_KEY = 'twafok_local_auth_session';

function readSession(): LocalSession | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveSession(session: LocalSession | null) {
  if (typeof window === 'undefined') return;
  if (session) localStorage.setItem(AUTH_KEY, JSON.stringify(session));
  else localStorage.removeItem(AUTH_KEY);
  window.dispatchEvent(new CustomEvent('local-auth-changed', { detail: session }));
}

function makeSession(email: string): LocalSession {
  return {
    access_token: `local-token-${Date.now()}`,
    refresh_token: `local-refresh-${Date.now()}`,
    user: { id: email || 'local-user', email: email || 'demo@tawasul.sa' },
  };
}

const createMockQuery = () => {
  const query: any = {
    select: () => query,
    insert: () => query,
    update: () => query,
    upsert: () => query,
    delete: () => query,
    eq: () => query,
    neq: () => query,
    in: () => query,
    order: () => query,
    limit: () => query,
    range: () => query,
    match: () => query,
    maybeSingle: async () => ({ data: null, error: null }),
    single: async () => ({ data: null, error: null }),
    then: (resolve: (value: any) => any) => Promise.resolve({ data: [], error: null }).then(resolve),
    catch: (reject: (reason: any) => any) => Promise.resolve({ data: [], error: null }).catch(reject),
  };
  return query;
};

// تهيئة العميل السحابي الفعلي أو المحاكي المحلي بنفس واجهة الاستدعاء (API Shape)
let supabaseClient: any;

if (hasRealSupabase) {
  try {
    supabaseClient = createClient(supabaseUrl, supabaseAnonKey);
  } catch (err) {
    console.warn('[Supabase] Failed to initialize real client:', err);
  }
}

if (!supabaseClient) {
  supabaseClient = {
    from: (_tableName: string) => createMockQuery(),
    auth: {
      getSession: async () => ({ data: { session: readSession() }, error: null }),
      onAuthStateChange: (callback: (_event: string, session: LocalSession | null) => void) => {
        const handler = (event: Event) => callback('LOCAL_AUTH_CHANGED', (event as CustomEvent).detail ?? readSession());
        window.addEventListener('local-auth-changed', handler);
        return { data: { subscription: { unsubscribe: () => window.removeEventListener('local-auth-changed', handler) } } };
      },
      signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
        if (!email.includes('@') || password.length < 6) {
          return { data: { user: null, session: null }, error: new Error('بيانات الدخول غير صحيحة') };
        }
        const session = makeSession(email);
        saveSession(session);
        return { data: { user: session.user, session }, error: null };
      },
      signUp: async ({ email, password }: { email: string; password: string }) => {
        if (!email.includes('@') || password.length < 6) {
          return { data: { user: null, session: null }, error: new Error('البريد أو كلمة المرور غير صحيحة') };
        }
        const session = makeSession(email);
        saveSession(session);
        return { data: { user: session.user, session }, error: null };
      },
      signOut: async () => {
        saveSession(null);
        return { error: null };
      },
      setSession: async ({ access_token, refresh_token }: { access_token?: string; refresh_token?: string }) => {
        const session: LocalSession = {
          access_token: access_token || `local-token-${Date.now()}`,
          refresh_token: refresh_token || `local-refresh-${Date.now()}`,
          user: { id: 'google-local-user', email: 'google.local@tawasul.sa' },
        };
        saveSession(session);
        return { data: { user: session.user, session }, error: null };
      },
      signInWithIdToken: async (_args?: any) => {
        const session = makeSession('google.local@tawasul.sa');
        saveSession(session);
        return { data: { user: session.user, session }, error: null };
      },
    },
  };
}

export default supabaseClient;
