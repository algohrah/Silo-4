// ====================================================================
//  ملف تعريف الحقول الموحد — يستخدمه نموذج التسجيل ونظام الاستيراد
//  أي حقل جديد يضاف هنا يظهر تلقائياً في التسجيل والاستيراد
// ====================================================================

// ===== تعريف الحقل =====
export interface FieldDefinition {
  key: string;              // اسم الحقل في النظام
  label: string;            // الاسم العربي للعرض
  labelEn?: string;         // الاسم الإنجليزي (للاستيراد)
  type: 'text' | 'number' | 'select' | 'radio' | 'textarea' | 'date' | 'checkbox' | 'conditional';
  required: boolean;        // هل الحقل مطلوب
  group: 'basic' | 'personal' | 'partner' | 'contact' | 'admin';
  options?: string[];       // الخيارات للقوائم
  optionsWithLabel?: { value: string; label: string }[];  // خيارات مع قيم
  min?: number;             // للحقول الرقمية
  max?: number;             // للحقول الرقمية
  minLength?: number;       // للنصوص
  maxLength?: number;       // للنصوص
  placeholder?: string;     // نص التلميح
  hint?: string;            // وصف إضافي
  conditionalOn?: string;   // يظهر فقط إذا...
  conditionalValue?: string | string[];  // القيمة المطلوبة
  genderSpecific?: 'male' | 'female' | 'both';  // يظهر لجنس محدد
  defaultValue?: any;       // القيمة الافتراضية
  csvColumn?: string;       // اسم العمود في CSV
  sensitive?: boolean;      // بيانات حساسة (للإدارة فقط)
}

// ===== المجموعات =====
export const FIELD_GROUPS = {
  basic: { label: 'البيانات الأساسية', icon: 'User', order: 1 },
  personal: { label: 'المواصفات الشخصية', icon: 'FileText', order: 2 },
  partner: { label: 'مواصفات الشريك', icon: 'Heart', order: 3 },
  contact: { label: 'بيانات الحساب', icon: 'ShieldCheck', order: 4 },
  admin: { label: 'بيانات الإدارة', icon: 'Lock', order: 5 },
} as const;

// ===== الثوابت المستخدمة ===== (يجب أن تكون قبل REGISTRATION_FIELDS)
export const COUNTRIES = [
  'السعودية', 'الإمارات', 'الكويت', 'قطر', 'البحرين', 'عمان',
  'مصر', 'سوريا', 'الأردن', 'اليمن', 'العراق', 'لبنان',
  'فلسطين', 'السودان', 'ليبيا', 'تونس', 'الجزائر', 'المغرب',
  'موريتانيا', 'الصومال', 'جيبوتي', 'جزر القمر', 'أخرى',
];

export const CITIES_BY_COUNTRY: Record<string, string[]> = {
  'السعودية': ['الرياض', 'جدة', 'مكة المكرمة', 'المدينة المنورة', 'الدمام', 'الخبر', 'الطائف', 'بريدة', 'تبوك', 'أبها', 'خميس مشيط', 'الجبيل', 'ينبع', 'حائل', 'نجران', 'الجوف', 'الأحساء', 'القطيف', 'القصيم', 'الباحة'],
  'الإمارات': ['دبي', 'أبو ظبي', 'الشارقة', 'العين', 'عجمان', 'رأس الخيمة', 'الفجيرة', 'أم القيوين'],
  'الكويت': ['الكويت', 'حولي', 'الجهراء', 'السالمية', 'الفروانية', 'الأحمدي'],
  'قطر': ['الدوحة', 'الريان', 'الوكرة', 'الخور', 'الظعين'],
  'البحرين': ['المنامة', 'المحرق', 'الرفاع', 'حمد', 'عيسى'],
  'عمان': ['مسقط', 'صلالة', 'نزوى', 'صحار', 'صور', 'بهلا'],
  'مصر': ['القاهرة', 'الجيزة', 'الإسكندرية', 'المنصورة', 'طنطا', 'أسيوط', 'الزقازيق', 'بني سويف', 'الفيوم', 'أسوان', 'بورسعيد', 'السويس', 'الإسماعيلية'],
  'سوريا': ['دمشق', 'حلب', 'حمص', 'حماة', 'اللاذقية', 'دير الزور', 'الرقة', 'الحسكة', 'درعا', 'السويداء', 'طرطوس', 'إدلب'],
  'الأردن': ['عمّان', 'الزرقاء', 'إربد', 'العقبة', 'السلط', 'مادبا', 'الكرك', 'معان', 'جرش', 'عجلون'],
  'اليمن': ['صنعاء', 'عدن', 'تعز', 'الحديدة', 'المكلا', 'إب', 'ذمار', 'صعدة', 'المخا'],
  'العراق': ['بغداد', 'البصرة', 'الموصل', 'أربيل', 'النجف', 'كربلاء', 'كركوك', 'السليمانية', 'الناصرية', 'الديوانية', 'العمارة', 'الرمادي'],
  'لبنان': ['بيروت', 'طرابلس', 'صيدا', 'صور', 'جونية', 'زحلة', 'بعلبك', 'النبطية'],
  'فلسطين': ['القدس', 'غزة', 'رام الله', 'نابلس', 'الخليل', 'بيت لحم', 'جنين', 'طولكرم', 'قلقيلية', 'رفح', 'خان يونس'],
  'السودان': ['الخرطوم', 'أم درمان', 'بخت الرضا', 'بورتسودان', 'كسلا', 'القضارف', 'مدني', 'الأبيض', 'دنقلا', 'نيالا'],
  'ليبيا': ['طرابلس', 'بنغازي', 'مصراتة', 'الزاوية', 'سبها', 'البيضاء', 'زوارة', 'درنة'],
  'تونس': ['تونس', 'صفاقس', 'سوسة', 'قابس', 'بنزرت', 'القيروان', 'المنستير', 'المهدية', 'قفصة'],
  'الجزائر': ['الجزائر', 'وهران', 'قسنطينة', 'عنابة', 'البليدة', 'باتنة', 'سطيف', 'تبسة', 'تيزي وزو', 'بجاية'],
  'المغرب': ['الدار البيضاء', 'الرباط', 'فاس', 'مراكش', 'طنجة', 'أكادير', 'مكناس', 'وجدة', 'القنيطرة', 'تطوان'],
  'موريتانيا': ['نواكشوط', 'نواذيبو', 'روصو', 'كيهيدي', 'أطار', 'زويرات'],
  'الصومال': ['مقديشو', 'هرجيسا', 'بيدوا', 'كيسمايو', 'بوصاصا', 'جالكعيو'],
  'جيبوتي': ['جيبوتي', 'علي صبيح', 'تاجورة', 'أوبوك', 'دخيل'],
  'جزر القمر': ['موروني', 'موتسامودو', 'فومبوني', 'دوموني'],
  'أخرى': ['مدينة أخرى'],
};

export const SECTS = ['سني', 'سلفي', 'صوفي', 'زيدي', 'جعفري', 'إباضي', 'أخرى'];

export const RELIGION_LEVELS = ['متدين ممتاز', 'متدين', 'متدين بشكل معتدل', 'ألتزم بالأساسيات', 'غير محدد'];

export const SKIN_COLORS = ['أبيض جدا', 'أبيض', 'أبيض قمحي', 'حنطي', 'حنطي مائل للسمار', 'أسمر', 'أسمر داكن'];

export const SMOKING_OPTIONS = ['لا أدخن', 'أدخن أحيانًا', 'أدخن بانتظام', 'أدخن شيشة', 'سابقًا وتركت'];

export const EDUCATION_LEVELS = ['أقل من الثانوية', 'الثانوية العامة', 'دبلوم', 'دبلوم عالي', 'بكالوريوس', 'ماجستير', 'دكتوراه'];

export const WORK_TYPES_OPTIONS = [
  { value: 'حكومي', label: 'حكومي' },
  { value: 'قطاع خاص', label: 'قطاع خاص' },
  { value: 'عمل حر', label: 'عمل حر' },
  { value: 'باحث عن عمل', label: 'باحث عن عمل' },
  { value: 'طالب', label: 'طالب' },
  { value: 'بدون عمل', label: 'بدون عمل' },
];

export const HOUSING_TYPES = ['أملك منزل', 'أسكن مع العائلة', 'أستأجر', 'أخرى'];

export const CHILDREN_COUNT = ['لا يوجد', '1', '2', '3', '4', '5', 'أكثر من 5'];

export const WIFE_COUNT = [
  { value: '1', label: 'زوجة واحدة' },
  { value: '2', label: 'زوجتان' },
  { value: '3', label: 'ثلاث زوجات' },
];

export const YES_NO = [{ value: 'yes', label: 'نعم' }, { value: 'no', label: 'لا' }];

export const MARITAL_MALE = [
  { value: 'single', label: 'أعزب' },
  { value: 'divorced', label: 'مطلق' },
  { value: 'widower', label: 'أرمل' },
  { value: 'married', label: 'متزوج' },
];

export const MARITAL_FEMALE = [
  { value: 'single', label: 'عزباء' },
  { value: 'divorced', label: 'مطلقة' },
  { value: 'widow', label: 'أرملة' },
];

export const POLYGAMY_ACCEPT = [
  { value: 'yes', label: 'نعم، أقبل التعدد' },
  { value: 'first_only', label: 'أقبل أن أكون الزوجة الأولى فقط' },
  { value: 'no', label: 'لا أقبل التعدد' },
];

// ===== جميع الحقول =====
export const REGISTRATION_FIELDS: FieldDefinition[] = [
  // === البيانات الأساسية ===
  {
    key: 'gender',
    label: 'الجنس',
    labelEn: 'Gender',
    type: 'radio',
    required: true,
    group: 'basic',
    optionsWithLabel: [{ value: 'male', label: 'ذكر' }, { value: 'female', label: 'أنثى' }],
    csvColumn: 'gender',
    defaultValue: '',
  },
  {
    key: 'nickname',
    label: 'الاسم المستعار',
    labelEn: 'Nickname',
    type: 'text',
    required: false,
    group: 'basic',
    placeholder: 'مثال: أبو محمد، المطيري',
    hint: 'اختياري — يظهر في ملفك العام',
    maxLength: 50,
    csvColumn: 'nickname',
    defaultValue: '',
  },
  {
    key: 'birthDate',
    label: 'تاريخ الميلاد',
    labelEn: 'Birth Date',
    type: 'date',
    required: true,
    group: 'basic',
    hint: 'اختر السنة ثم الشهر ثم اليوم',
    csvColumn: 'birth_date',
    defaultValue: '',
  },
  {
    key: 'age',
    label: 'العمر',
    labelEn: 'Age',
    type: 'number',
    required: true,
    group: 'basic',
    min: 18,
    max: 100,
    hint: 'محسوب تلقائياً من تاريخ الميلاد',
    csvColumn: 'age',
    defaultValue: 0,
  },
  {
    key: 'country',
    label: 'الدولة',
    labelEn: 'Country',
    type: 'select',
    required: true,
    group: 'basic',
    options: COUNTRIES,
    hint: 'دولة الإقامة الحالية',
    csvColumn: 'country',
    defaultValue: '',
  },
  {
    key: 'city',
    label: 'المدينة',
    labelEn: 'City',
    type: 'select',
    required: true,
    group: 'basic',
    options: [], // يتم تحديثها ديناميكياً حسب الدولة
    hint: 'المدينة حسب الدولة المختارة',
    csvColumn: 'city',
    defaultValue: '',
  },
  {
    key: 'district',
    label: 'المنطقة / الحي',
    labelEn: 'District',
    type: 'text',
    required: true,
    group: 'basic',
    placeholder: 'حي العليا...',
    hint: 'الحي أو المنطقة التفصيلية',
    maxLength: 100,
    csvColumn: 'district',
    defaultValue: '',
  },
  {
    key: 'nationalityMode',
    label: 'الجنسية',
    labelEn: 'Nationality Mode',
    type: 'radio',
    required: true,
    group: 'basic',
    optionsWithLabel: [{ value: 'same', label: 'نفس دولة الإقامة' }, { value: 'other', label: 'جنسية أخرى' }],
    hint: 'هل جنسيتك نفس دولة الإقامة؟',
    csvColumn: 'nationality_mode',
    defaultValue: '',
  },
  {
    key: 'nationality',
    label: 'الجنسية (أخرى)',
    labelEn: 'Nationality',
    type: 'select',
    required: false,
    group: 'basic',
    options: COUNTRIES,
    conditionalOn: 'nationalityMode',
    conditionalValue: 'other',
    csvColumn: 'nationality',
    defaultValue: '',
  },
  {
    key: 'sect',
    label: 'المذهب',
    labelEn: 'Sect',
    type: 'select',
    required: true,
    group: 'basic',
    options: SECTS,
    hint: 'المذهب الديني الذي تتبعه',
    csvColumn: 'sect',
    defaultValue: '',
  },
  {
    key: 'sectOther',
    label: 'المذهب (أخرى)',
    labelEn: 'Sect Other',
    type: 'text',
    required: false,
    group: 'basic',
    conditionalOn: 'sect',
    conditionalValue: 'أخرى',
    maxLength: 50,
    csvColumn: 'sect_other',
    defaultValue: '',
  },
  {
    key: 'maritalStatus',
    label: 'الحالة الاجتماعية',
    labelEn: 'Marital Status',
    type: 'radio',
    required: true,
    group: 'basic',
    optionsWithLabel: MARITAL_MALE, // يتم استخدام MARITAL_FEMALE للنساء
    csvColumn: 'marital_status',
    defaultValue: '',
  },
  {
    key: 'hasChildren',
    label: 'هل لديك أبناء؟',
    labelEn: 'Has Children',
    type: 'radio',
    required: false,
    group: 'basic',
    optionsWithLabel: YES_NO,
    conditionalOn: 'maritalStatus',
    conditionalValue: ['divorced', 'widower', 'widow', 'married'],
    csvColumn: 'has_children',
    defaultValue: '',
  },
  {
    key: 'childrenCount',
    label: 'عدد الأبناء',
    labelEn: 'Children Count',
    type: 'select',
    required: false,
    group: 'basic',
    options: CHILDREN_COUNT,
    conditionalOn: 'hasChildren',
    conditionalValue: 'yes',
    csvColumn: 'children_count',
    defaultValue: '',
  },
  {
    key: 'childrenLiveWith',
    label: 'هل الأبناء يعيشون معك؟',
    labelEn: 'Children Live With',
    type: 'radio',
    required: false,
    group: 'basic',
    optionsWithLabel: YES_NO,
    conditionalOn: 'hasChildren',
    conditionalValue: 'yes',
    csvColumn: 'children_live_with',
    defaultValue: '',
  },
  {
    key: 'wifeCount',
    label: 'عدد الزوجات الحالي',
    labelEn: 'Wife Count',
    type: 'radio',
    required: false,
    group: 'basic',
    optionsWithLabel: WIFE_COUNT,
    conditionalOn: 'maritalStatus',
    conditionalValue: 'married',
    genderSpecific: 'male',
    csvColumn: 'wife_count',
    defaultValue: '',
  },
  {
    key: 'seekingWife',
    label: 'هل تبحث عن زوجة أخرى؟',
    labelEn: 'Seeking Wife',
    type: 'radio',
    required: false,
    group: 'basic',
    optionsWithLabel: YES_NO,
    conditionalOn: 'maritalStatus',
    conditionalValue: 'married',
    genderSpecific: 'male',
    csvColumn: 'seeking_wife',
    defaultValue: '',
  },

  // === المواصفات الشخصية ===
  {
    key: 'height',
    label: 'الطول',
    labelEn: 'Height',
    type: 'number',
    required: true,
    group: 'personal',
    min: 130,
    max: 220,
    hint: 'طولك بالسنتيمتر',
    csvColumn: 'height',
    defaultValue: 0,
  },
  {
    key: 'weight',
    label: 'الوزن',
    labelEn: 'Weight',
    type: 'number',
    required: true,
    group: 'personal',
    min: 35,
    max: 200,
    hint: 'وزنك بالكيلوغرام',
    csvColumn: 'weight',
    defaultValue: 0,
  },
  {
    key: 'skinColor',
    label: 'لون البشرة',
    labelEn: 'Skin Color',
    type: 'select',
    required: true,
    group: 'personal',
    options: SKIN_COLORS,
    hint: 'لون بشرتك الطبيعي',
    csvColumn: 'skin_color',
    defaultValue: '',
  },
  {
    key: 'ethnicity',
    label: 'العرق',
    labelEn: 'Ethnicity',
    type: 'text',
    required: true,
    group: 'personal',
    placeholder: 'مثال: عربي، خليجي، قبلي...',
    hint: 'مثال: عربي، خليجي، قبيلي، إلخ',
    maxLength: 100,
    csvColumn: 'ethnicity',
    defaultValue: '',
  },
  {
    key: 'health',
    label: 'الحالة الصحية',
    labelEn: 'Health',
    type: 'text',
    required: true,
    group: 'personal',
    placeholder: 'مثال: ممتازة، جيدة، وضع صحي خاص...',
    hint: 'مثال: ممتازة، جيدة، وضع صحي خاص',
    maxLength: 200,
    csvColumn: 'health',
    defaultValue: '',
  },
  {
    key: 'smoking',
    label: 'التدخين',
    labelEn: 'Smoking',
    type: 'select',
    required: true,
    group: 'personal',
    options: SMOKING_OPTIONS,
    hint: 'عادتك في التدخين',
    csvColumn: 'smoking',
    defaultValue: '',
  },
  {
    key: 'education',
    label: 'المؤهل الدراسي',
    labelEn: 'Education',
    type: 'select',
    required: true,
    group: 'personal',
    options: EDUCATION_LEVELS,
    hint: 'أعلى مؤهل علمي حصلت عليه',
    csvColumn: 'education',
    defaultValue: '',
  },
  {
    key: 'workType',
    label: 'نوع جهة العمل',
    labelEn: 'Work Type',
    type: 'radio',
    required: true,
    group: 'personal',
    optionsWithLabel: WORK_TYPES_OPTIONS,
    hint: 'طبيعة عملك الحالي',
    csvColumn: 'work_type',
    defaultValue: '',
  },
  {
    key: 'jobTitle',
    label: 'المسمى الوظيفي',
    labelEn: 'Job Title',
    type: 'text',
    required: false,
    group: 'personal',
    placeholder: 'معلم، طبيب، مهندس...',
    hint: 'اكتب مسمى وظيفتك',
    maxLength: 100,
    conditionalOn: 'workType',
    conditionalValue: ['حكومي', 'قطاع خاص', 'عمل حر', 'طالب'],
    csvColumn: 'job_title',
    defaultValue: '',
  },
  {
    key: 'housing',
    label: 'نوع السكن',
    labelEn: 'Housing',
    type: 'select',
    required: true,
    group: 'personal',
    options: HOUSING_TYPES,
    hint: 'وضعك السكني الحالي',
    csvColumn: 'housing',
    defaultValue: '',
  },
  {
    key: 'bio',
    label: 'نبذة عني',
    labelEn: 'Bio',
    type: 'textarea',
    required: true,
    group: 'personal',
    placeholder: 'اكتب نبذة قصيرة عن شخصيتك وأهدافك...',
    minLength: 20,
    maxLength: 500,
    hint: '20-500 حرف',
    csvColumn: 'bio',
    defaultValue: '',
  },
  {
    key: 'acceptPolygamy',
    label: 'هل تقبلين التعدد؟',
    labelEn: 'Accept Polygamy',
    type: 'radio',
    required: false,
    group: 'personal',
    optionsWithLabel: POLYGAMY_ACCEPT,
    genderSpecific: 'female',
    csvColumn: 'accept_polygamy',
    defaultValue: '',
  },
  {
    key: 'acceptDivorced',
    label: 'هل تقبلين زوجًا مطلقًا؟',
    labelEn: 'Accept Divorced',
    type: 'radio',
    required: false,
    group: 'personal',
    optionsWithLabel: YES_NO,
    genderSpecific: 'female',
    csvColumn: 'accept_divorced',
    defaultValue: '',
  },
  {
    key: 'acceptWithChildren',
    label: 'هل تقبلين زوجًا لديه أبناء؟',
    labelEn: 'Accept With Children',
    type: 'radio',
    required: false,
    group: 'personal',
    optionsWithLabel: YES_NO,
    genderSpecific: 'female',
    csvColumn: 'accept_with_children',
    defaultValue: '',
  },

  // === مواصفات الشريك ===
  {
    key: 'pCountry',
    label: 'الدولة المطلوبة',
    labelEn: 'Partner Country',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', ...COUNTRIES],
    hint: 'دولة الشريك الذي تبحث عنه',
    csvColumn: 'partner_country',
    defaultValue: '',
  },
  {
    key: 'pCity',
    label: 'المدينة المطلوبة',
    labelEn: 'Partner City',
    type: 'select',
    required: false,
    group: 'partner',
    options: [], // ديناميكية
    conditionalOn: 'pCountry',
    conditionalValue: COUNTRIES, // أي دولة غير "لا يهم"
    csvColumn: 'partner_city',
    defaultValue: '',
  },
  {
    key: 'pNationality',
    label: 'الجنسية المطلوبة',
    labelEn: 'Partner Nationality',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', ...COUNTRIES],
    hint: 'جنسية الشريك المطلوب',
    csvColumn: 'partner_nationality',
    defaultValue: '',
  },
  {
    key: 'pAgeMin',
    label: 'العمر المطلوب (من)',
    labelEn: 'Partner Age Min',
    type: 'number',
    required: false,
    group: 'partner',
    min: 18,
    max: 70,
    defaultValue: 22,
    csvColumn: 'partner_age_min',
  },
  {
    key: 'pAgeMax',
    label: 'العمر المطلوب (إلى)',
    labelEn: 'Partner Age Max',
    type: 'number',
    required: false,
    group: 'partner',
    min: 18,
    max: 70,
    defaultValue: 35,
    csvColumn: 'partner_age_max',
  },
  {
    key: 'pMaritalStatus',
    label: 'الحالة الاجتماعية المقبولة',
    labelEn: 'Partner Marital Status',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', 'أعزب/عزباء', 'مطلق/مطلقة', 'أرمل/أرملة'],
    hint: 'حالة الشريك الاجتماعية',
    csvColumn: 'partner_marital_status',
    defaultValue: '',
  },
  {
    key: 'pAcceptChildren',
    label: 'هل تقبل وجود أطفال؟',
    labelEn: 'Partner Accept Children',
    type: 'radio',
    required: false,
    group: 'partner',
    optionsWithLabel: YES_NO,
    conditionalOn: 'pMaritalStatus',
    conditionalValue: ['مطلق/مطلقة', 'أرمل/أرملة'],
    csvColumn: 'partner_accept_children',
    defaultValue: '',
  },
  {
    key: 'pSect',
    label: 'المذهب المطلوب',
    labelEn: 'Partner Sect',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', ...SECTS.filter(s => s !== 'أخرى')],
    hint: 'مذهب الشريك المطلوب',
    csvColumn: 'partner_sect',
    defaultValue: '',
  },
  {
    key: 'pSectOther',
    label: 'المذهب المطلوب (أخرى)',
    labelEn: 'Partner Sect Other',
    type: 'text',
    required: false,
    group: 'partner',
    conditionalOn: 'pSect',
    conditionalValue: 'أخرى',
    maxLength: 50,
    csvColumn: 'partner_sect_other',
    defaultValue: '',
  },
  {
    key: 'pReligionLevel',
    label: 'مستوى التدين',
    labelEn: 'Partner Religion Level',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', ...RELIGION_LEVELS],
    hint: 'مستوى الالتزام الديني',
    csvColumn: 'partner_religion_level',
    defaultValue: '',
  },
  {
    key: 'pEducation',
    label: 'المؤهل الدراسي المطلوب',
    labelEn: 'Partner Education',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', ...EDUCATION_LEVELS],
    hint: 'مستوى التعليم',
    csvColumn: 'partner_education',
    defaultValue: '',
  },
  {
    key: 'pWorkType',
    label: 'نوع الوظيفة المطلوبة',
    labelEn: 'Partner Work Type',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', 'حكومي', 'قطاع خاص', 'عمل حر', 'طالب', 'بدون عمل'],
    hint: 'طبيعة عمل الشريك',
    csvColumn: 'partner_work_type',
    defaultValue: '',
  },
  {
    key: 'pSkinColor',
    label: 'لون البشرة المطلوب',
    labelEn: 'Partner Skin Color',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', ...SKIN_COLORS],
    hint: 'لون بشرة الشريك',
    csvColumn: 'partner_skin_color',
    defaultValue: '',
  },
  {
    key: 'pHeight',
    label: 'الطول المطلوب',
    labelEn: 'Partner Height',
    type: 'number',
    required: false,
    group: 'partner',
    min: 140,
    max: 250,
    defaultValue: 170,
    csvColumn: 'partner_height',
  },
  {
    key: 'pHeightNoMatter',
    label: 'الطول لا يهم',
    labelEn: 'Partner Height No Matter',
    type: 'checkbox',
    required: false,
    group: 'partner',
    defaultValue: false,
    csvColumn: 'partner_height_no_matter',
  },
  {
    key: 'pHousing',
    label: 'نوع السكن المطلوب',
    labelEn: 'Partner Housing',
    type: 'select',
    required: false,
    group: 'partner',
    options: ['لا يهم', ...HOUSING_TYPES],
    hint: 'وضع الشريك السكني',
    csvColumn: 'partner_housing',
    defaultValue: '',
  },
  {
    key: 'pNotes',
    label: 'ملاحظات إضافية',
    labelEn: 'Partner Notes',
    type: 'textarea',
    required: false,
    group: 'partner',
    placeholder: 'اكتب أي ملاحظات إضافية...',
    maxLength: 500,
    csvColumn: 'partner_notes',
    defaultValue: '',
  },

  // === بيانات الحساب (للإدارة فقط) ===
  {
    key: 'realName',
    label: 'الاسم الرباعي الحقيقي',
    labelEn: 'Real Name',
    type: 'text',
    required: true,
    group: 'contact',
    placeholder: 'الاسم الكامل',
    hint: 'اسمك الكامل — سري ولا يظهر لأحد',
    maxLength: 100,
    csvColumn: 'real_name',
    sensitive: true,
    defaultValue: '',
  },
  {
    key: 'phone',
    label: 'رقم الهاتف',
    labelEn: 'Phone',
    type: 'text',
    required: true,
    group: 'contact',
    placeholder: '05xxxxxxxx',
    hint: 'رقمك للتواصل — سري',
    maxLength: 20,
    csvColumn: 'phone',
    sensitive: true,
    defaultValue: '',
  },
  {
    key: 'whatsapp',
    label: 'رقم الواتساب',
    labelEn: 'WhatsApp',
    type: 'text',
    required: false,
    group: 'contact',
    placeholder: '05xxxxxxxx',
    hint: 'اختياري — للتواصل السريع',
    maxLength: 20,
    csvColumn: 'whatsapp',
    sensitive: true,
    defaultValue: '',
  },
  {
    key: 'email',
    label: 'البريد الإلكتروني',
    labelEn: 'Email',
    type: 'text',
    required: false,
    group: 'contact',
    placeholder: 'example@email.com',
    hint: 'اختياري — لتسجيل الدخول',
    maxLength: 100,
    sensitive: true,
    defaultValue: '',
  },
  {
    key: 'password',
    label: 'كلمة المرور',
    labelEn: 'Password',
    type: 'text',
    required: false,
    group: 'contact',
    minLength: 6,
    hint: 'اختياري — 6 أحرف على الأقل',
    sensitive: true,
    defaultValue: '',
  },
];

// ===== دوال مساعدة =====

// الحصول على الحقول حسب المجموعة
export function getFieldsByGroup(group: string): FieldDefinition[] {
  return REGISTRATION_FIELDS.filter(f => f.group === group);
}

// الحصول على الحقول حسب الجنس
export function getFieldsByGender(gender: 'male' | 'female'): FieldDefinition[] {
  return REGISTRATION_FIELDS.filter(f => f.genderSpecific === 'both' || f.genderSpecific === gender || !f.genderSpecific);
}

// الحصول على الحقول المطلوبة فقط
export function getRequiredFields(): FieldDefinition[] {
  return REGISTRATION_FIELDS.filter(f => f.required);
}

// الحصول على الحقول للCSV (جميع الحقول غير الحساسة)
export function getCSVFields(): FieldDefinition[] {
  return REGISTRATION_FIELDS.filter(f => f.csvColumn);
}

// الحصول على الحقول الحساسة (للإدارة فقط)
export function getSensitiveFields(): FieldDefinition[] {
  return REGISTRATION_FIELDS.filter(f => f.sensitive);
}

// إنشاء قالب CSV بسيط وسهل
export function generateSimpleCSVTemplate(): string {
  const headers = ['real_name', 'gender', 'birth_date', 'nationality', 'country', 'city', 'district', 'marital_status', 'phone', 'notes'];
  const labels = ['الاسم الكامل', 'الجنس (ذكر/أنثى)', 'تاريخ الميلاد (YYYY-MM-DD)', 'الجنسية', 'الدولة', 'المدينة', 'الحي', 'الحالة الاجتماعية (أعزب/عزباء/مطلق/مطلقة/أرمل/أرملة)', 'رقم الهاتف', 'ملاحظات'];
  const exampleRow1 = ['عبدالله أحمد السالم', 'ذكر', '1992-06-15', 'سعودي', 'السعودية', 'الرياض', 'حي العليا', 'أعزب', '0501234567', 'عضو جديد عن طريق المكتب'];
  const exampleRow2 = ['سارة محمد علي', 'أنثى', '1996-03-20', 'سعودية', 'السعودية', 'جدة', 'حي الشاطئ', 'عزباء', '0559876543', 'تفضل السكن في جدة'];
  
  return `${headers.join(',')}\n${labels.join(',')}\n${exampleRow1.join(',')}\n${exampleRow2.join(',')}`;
}

// إنشاء قالب CSV
export function generateCSVTemplate(): string {
  const fields = getCSVFields();
  const headers = fields.map(f => f.csvColumn!).join(',');
  const labels = fields.map(f => f.label).join(',');
  const exampleRow = fields.map(f => {
    if (f.type === 'number') return '25';
    if (f.type === 'select' && f.options?.length) return f.options[0];
    if (f.type === 'radio' && f.optionsWithLabel?.length) return f.optionsWithLabel[0].value;
    if (f.type === 'checkbox') return 'false';
    if (f.key === 'gender') return 'male';
    if (f.key === 'birth_date' || f.key === 'birthDate') return '1990-01-15';
    if (f.key === 'phone') return '05xxxxxxxx';
    return 'مثال';
  }).join(',');
  return `${headers}\n${labels}\n${exampleRow}`;
}

// ===== إنشاء قالب كامل مع الخيارات للنسخ =====
export function generateFullTemplateWithOptions(): string {
  const lines: string[] = [];
  
  // العناوين
  lines.push('=== قالب واستعراض خيارات استيراد الأعضاء (تعليمات موجهة للذكاء الاصطناعي AI) ===');
  lines.push('');
  lines.push('📋 هذا القالب موجه لإنشاء ملفات استيراد الأعضاء بنجاح في منصة توافق.');
  lines.push('⚡ تم إلغاء حقول البريد الإلكتروني وكلمة السر نهائياً من خيارات الاستيراد.');
  lines.push('💡 الحقول الفارغة يتم قبولها واستيراد العضو بدون أخطاء.');
  lines.push('');
  lines.push('🤖 تعليمات للذكاء الاصطناعي (Prompt for AI):');
  lines.push('قم بإنشاء جدول بيانات أعضاء بصيغة CSV أو Tab بدون أعمدة البريد الإلكتروني أو كلمة السر.');
  lines.push('يمكنك ترك الحقول غير المتوفرة فارغة وسيقوم النظام باستيراد الأعضاء مباشرة دون أخطاء.');
  lines.push('');
  lines.push('---');
  lines.push('');
  
  // تنسيق CSV
  lines.push('📌 تنسيق CSV (نسخ هذا السطر كعناوين الأعمدة):');
  lines.push('');
  const csvHeaders = getCSVFields().map(f => f.csvColumn || f.key).join(',');
  lines.push(csvHeaders);
  lines.push('');
  
  // تنسيق Tab (للنسخ من Excel)
  lines.push('📌 تنسيق Tab (للنسخ واللصق المباشر من Excel / Google Sheets):');
  lines.push('');
  const tabHeaders = getCSVFields().map(f => f.label).join('\t');
  lines.push(tabHeaders);
  lines.push('');
  
  lines.push('---');
  lines.push('');
  
  // جميع الحقول مع الخيارات
  lines.push('📖 جميع الحقول والخيارات المتاحة:');
  lines.push('');
  
  const groups = ['basic', 'personal', 'partner', 'contact'] as const;
  const groupLabels: Record<string, string> = {
    basic: 'البيانات الأساسية',
    personal: 'المواصفات الشخصية',
    partner: 'مواصفات الشريك',
    contact: 'بيانات التواصل والإدارة',
  };
  
  groups.forEach(group => {
    const groupFields = getCSVFields().filter(f => f.group === group);
    if (groupFields.length === 0) return;
    
    lines.push(``);
    lines.push(`【${groupLabels[group]}】`);
    lines.push('');
    
    groupFields.forEach(field => {
      const requiredMark = field.required ? '✓ رئيسي' : '○ اختياري (يمكن تركه فارغاً)';
      const csvName = field.csvColumn || field.key;
      
      lines.push(`• ${field.label} (${csvName})`);
      lines.push(`  الحالة: ${requiredMark}`);
      
      if (field.options && field.options.length > 0) {
        lines.push(`  الخيارات: ${field.options.join(' | ')}`);
      }
      
      if (field.optionsWithLabel && field.optionsWithLabel.length > 0) {
        const opts = field.optionsWithLabel.map(o => `${o.label} (${o.value})`).join(' | ');
        lines.push(`  الخيارات: ${opts}`);
      }
      
      if (field.min || field.max) {
        lines.push(`  النطاق: ${field.min || '?'} - ${field.max || '?'}`);
      }
      
      if (field.hint) {
        lines.push(`  توضيح: ${field.hint}`);
      }
      
      if (field.genderSpecific) {
        lines.push(`  خاص ب: ${field.genderSpecific === 'male' ? 'الرجال فقط' : field.genderSpecific === 'female' ? 'النساء فقط' : 'الجميع'}`);
      }
      
      lines.push('');
    });
  });
  
  lines.push('---');
  lines.push('');
  
  // مثال صف بيانات ذكر
  lines.push('📝 مثال صف بيانات عضو (ذكر) - CSV:');
  lines.push('');
  const exampleMale = getCSVFields().map(f => {
    if (f.key === 'gender') return 'male';
    if (f.key === 'nickname') return 'أبو محمد';
    if (f.key === 'birthDate' || f.key === 'birth_date') return '1990-05-15';
    if (f.key === 'age') return '35';
    if (f.key === 'country') return 'السعودية';
    if (f.key === 'city') return 'الرياض';
    if (f.key === 'district') return 'حي العليا';
    if (f.key === 'nationality') return 'السعودية';
    if (f.key === 'sect') return 'سني';
    if (f.key === 'maritalStatus' || f.key === 'marital_status') return 'single';
    if (f.key === 'height') return '175';
    if (f.key === 'weight') return '75';
    if (f.key === 'skinColor' || f.key === 'skin_color') return 'أبيض قمحي';
    if (f.key === 'ethnicity') return 'عربي';
    if (f.key === 'health') return 'ممتازة';
    if (f.key === 'smoking') return 'لا أدخن';
    if (f.key === 'education') return 'بكالوريوس';
    if (f.key === 'workType' || f.key === 'work_type') return 'حكومي';
    if (f.key === 'jobTitle' || f.key === 'job_title') return 'مهندس';
    if (f.key === 'housing') return 'أملك منزل';
    if (f.key === 'bio') return 'مهندس طموح أبحث عن الاستقرار والسعادة الزوجية';
    if (f.key === 'realName' || f.key === 'real_name') return 'محمد عبدالله السالم';
    if (f.key === 'phone') return '0512345678';
    if (f.key === 'whatsapp') return '0512345678';
    if (f.key === 'pCountry' || f.key === 'partner_country') return 'السعودية';
    if (f.key === 'pAgeMin' || f.key === 'partner_age_min') return '22';
    if (f.key === 'pAgeMax' || f.key === 'partner_age_max') return '30';
    if (f.type === 'number') return '25';
    if (f.type === 'checkbox') return 'false';
    return '';
  }).join(',');
  lines.push(exampleMale);
  lines.push('');

  // مثال صف بيانات أنثى
  lines.push('📝 مثال صف بيانات عضوة (أنثى) - CSV:');
  lines.push('');
  const exampleFemale = getCSVFields().map(f => {
    if (f.key === 'gender') return 'female';
    if (f.key === 'nickname') return 'أم عبدالرحمن';
    if (f.key === 'birthDate' || f.key === 'birth_date') return '1995-08-20';
    if (f.key === 'age') return '30';
    if (f.key === 'country') return 'السعودية';
    if (f.key === 'city') return 'جدة';
    if (f.key === 'district') return 'حي الشاطئ';
    if (f.key === 'nationality') return 'السعودية';
    if (f.key === 'sect') return 'سني';
    if (f.key === 'maritalStatus' || f.key === 'marital_status') return 'single';
    if (f.key === 'height') return '162';
    if (f.key === 'weight') return '58';
    if (f.key === 'skinColor' || f.key === 'skin_color') return 'أبيض';
    if (f.key === 'ethnicity') return 'عربي';
    if (f.key === 'health') return 'ممتازة';
    if (f.key === 'smoking') return 'لا أدخن';
    if (f.key === 'education') return 'بكالوريوس';
    if (f.key === 'workType' || f.key === 'work_type') return 'قطاع خاص';
    if (f.key === 'jobTitle' || f.key === 'job_title') return 'معلمة';
    if (f.key === 'housing') return 'أسكن مع العائلة';
    if (f.key === 'bio') return 'إنسانية خلوقة ترغب في تكوين أسرة متماسكة';
    if (f.key === 'realName' || f.key === 'real_name') return 'سارة أحمد علي';
    if (f.key === 'phone') return '0559876543';
    if (f.key === 'whatsapp') return '0559876543';
    if (f.key === 'pCountry' || f.key === 'partner_country') return 'السعودية';
    if (f.key === 'pAgeMin' || f.key === 'partner_age_min') return '28';
    if (f.key === 'pAgeMax' || f.key === 'partner_age_max') return '38';
    if (f.type === 'number') return '25';
    if (f.type === 'checkbox') return 'false';
    return '';
  }).join(',');
  lines.push(exampleFemale);
  lines.push('');
  
  lines.push('---');
  lines.push('');
  
  // قائمة الدول
  lines.push('🌍 الدول المتاحة:');
  lines.push(COUNTRIES.join(' | '));
  lines.push('');
  
  // قائمة المذاهب
  lines.push('🕌 المذاهب المتاحة:');
  lines.push(SECTS.join(' | '));
  lines.push('');
  
  // قائمة لون البشرة
  lines.push('🎨 ألوان البشرة:');
  lines.push(SKIN_COLORS.join(' | '));
  lines.push('');
  
  // قائمة المؤهلات
  lines.push('🎓 المؤهلات الدراسية:');
  lines.push(EDUCATION_LEVELS.join(' | '));
  lines.push('');
  
  // قائمة التدخين
  lines.push('🚬 خيارات التدخين:');
  lines.push(SMOKING_OPTIONS.join(' | '));
  lines.push('');
  
  // قائمة السكن
  lines.push('🏠 أنواع السكن:');
  lines.push(HOUSING_TYPES.join(' | '));
  lines.push('');
  
  // الحالة الاجتماعية
  lines.push('💑 الحالة الاجتماعية (الرجال):');
  lines.push(MARITAL_MALE.map(m => `${m.label} (${m.value})`).join(' | '));
  lines.push('');
  lines.push('💑 الحالة الاجتماعية (النساء):');
  lines.push(MARITAL_FEMALE.map(m => `${m.label} (${m.value})`).join(' | '));
  lines.push('');
  
  lines.push('---');
  lines.push('');
  lines.push('✅ انتهى القالب الصالح للذكاء الاصطناعي');
  
  return lines.join('\n');
}

// إنشاء كائن فارغ للنموذج
export function createEmptyFormData(): Record<string, any> {
  return REGISTRATION_FIELDS.reduce((acc, f) => {
    acc[f.key] = f.defaultValue;
    return acc;
  }, {} as Record<string, any>);
}

// تحويل قيمة CSV إلى القيمة المناسبة (بدون فرض قيم افتراضية للحقول الفارغة)
export function parseCSVValue(field: FieldDefinition, value: string): any {
  if (value === undefined || value === null || value.trim() === '') {
    return '';
  }
  if (field.type === 'number') {
    const num = Number(value);
    return isNaN(num) ? '' : num;
  }
  if (field.type === 'checkbox') {
    return value === 'true' || value === '1' || value === 'نعم';
  }
  if (field.type === 'select' || field.type === 'radio') {
    // تحويل القيمة العربية إلى الإنجليزية إذا لزم الأمر
    if (field.optionsWithLabel) {
      const match = field.optionsWithLabel.find(o => o.label === value || o.value === value);
      return match?.value || value;
    }
    return value;
  }
  return value.trim();
}

// التحقق من صحة الحقل
export function validateField(field: FieldDefinition, value: any, formData?: Record<string, any>): string | null {
  // التحقق من الشرط
  if (field.conditionalOn && formData) {
    const conditionValue = formData[field.conditionalOn];
    const shouldValidate = Array.isArray(field.conditionalValue)
      ? field.conditionalValue.includes(conditionValue)
      : conditionValue === field.conditionalValue;
    if (!shouldValidate) return null; // الحقل غير مطلوب في هذه الحالة
  }

  // التحقق من الجنس
  if (field.genderSpecific && formData?.gender && field.genderSpecific !== formData.gender && field.genderSpecific !== 'both') {
    return null;
  }

  // الحقل المطلوب
  if (field.required) {
    if (value === undefined || value === null || value === '' || (typeof value === 'number' && value === 0)) {
      return `${field.label} مطلوب`;
    }
  }

  // الحد الأدنى للنص
  if (field.minLength && typeof value === 'string' && value.length < field.minLength) {
    return `${field.label} يجب أن يكون ${field.minLength} حرف على الأقل`; 
  }

  // الحد الأقصى للنص
  if (field.maxLength && typeof value === 'string' && value.length > field.maxLength) {
    return `${field.label} يجب أن يكون ${field.maxLength} حرف على الأكثر`; 
  }

  // الحد الأدنى للرقم
  if (field.min && typeof value === 'number' && value < field.min) {
    return `${field.label} يجب أن يكون ${field.min} على الأقل`; 
  }

  // الحد الأقصى للرقم
  if (field.max && typeof value === 'number' && value > field.max) {
    return `${field.label} يجب أن يكون ${field.max} على الأكثر`; 
  }

  // الخيارات
  if (field.options && value && !field.options.includes(value)) {
    return `${field.label} يجب أن يكون أحد: ${field.options.join(', ')}`; 
  }

  if (field.optionsWithLabel && value) {
    const validValues = field.optionsWithLabel.map(o => o.value);
    const validLabels = field.optionsWithLabel.map(o => o.label);
    if (!validValues.includes(value) && !validLabels.includes(value)) {
      return `${field.label} يجب أن يكون أحد: ${validLabels.join(', ')}`; 
    }
  }

  return null;
}

// التحقق من صحة جميع الحقول
export function validateAllFields(formData: Record<string, any>): Record<string, string> {
  const errors: Record<string, string> = {}; 
  REGISTRATION_FIELDS.forEach(field => {
    const error = validateField(field, formData[field.key], formData);
    if (error) errors[field.key] = error; 
  });
  return errors;
}

// تحويل البيانات من CSV إلى كائن مع مطابقة ذكية للترادفات
export function parseCSVRow(headers: string[], row: string[]): Record<string, any> {
  const data: Record<string, any> = {}; 
  const fields = getCSVFields();
  
  headers.forEach((header, idx) => {
    const rawVal = (row[idx] ?? '').trim();
    const trimmedHeader = (header || '').trim();
    if (!trimmedHeader) return;

    data[trimmedHeader] = rawVal;
    const lowerHeader = trimmedHeader.toLowerCase();

    // البحث المباشر
    let field = fields.find(f => 
      f.csvColumn === trimmedHeader || 
      f.label === trimmedHeader || 
      f.key === trimmedHeader ||
      (f.labelEn && f.labelEn.toLowerCase() === lowerHeader) ||
      (f.csvColumn && f.csvColumn.toLowerCase() === lowerHeader)
    );

    // مطابقة الترادفات الشائعة باللغتين
    if (!field) {
      if (['real_name', 'realname', 'الاسم الحقيقي', 'الاسم الكامل', 'الاسم الرباعي', 'اسم العضو'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'realName');
      } else if (['nickname', 'الاسم المستعار', 'اللقب', 'القبيلة', 'الاسم'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'nickname');
      } else if (['p_notes', 'pnotes', 'partner_notes', 'partnernotes', 'مواصفات الشريك', 'شروط الشريك', 'شروطي'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'pNotes');
      } else if (['birth_date', 'birthdate', 'تاريخ الميلاد', 'تاريخ_الميلاد'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'birthDate');
      } else if (['marital_status', 'maritalstatus', 'الحالة الاجتماعية', 'الحالة_الاجتماعية'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'maritalStatus');
      } else if (['skin_color', 'skincolor', 'لون البشرة', 'البشرة'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'skinColor');
      } else if (['work_type', 'worktype', 'نوع العمل', 'العمل', 'الوظيفة'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'workType');
      } else if (['job_title', 'jobtitle', 'المسمى الوظيفي', 'الوظيفة الحالية'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'jobTitle');
      } else if (['housing', 'السكن', 'نوع السكن'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'housing');
      } else if (['partner_country', 'p_country', 'pcountry', 'دولة الشريك'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'pCountry');
      } else if (['partner_city', 'p_city', 'pcity', 'مدينة الشريك'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'pCity');
      } else if (['accept_polygamy', 'acceptpolygamy', 'قبول التعدد', 'التعدد'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'acceptPolygamy');
      } else if (['accept_divorced', 'acceptdivorced', 'قبول المطلق', 'قبول المطلقة'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'acceptDivorced');
      } else if (['accept_with_children', 'acceptwithchildren', 'قبول أطفال', 'قبول أبناء'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'acceptWithChildren');
      } else if (['phone', 'mobile', 'الهاتف', 'رقم الهاتف', 'الجوال'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'phone');
      } else if (['whatsapp', 'واتساب', 'رقم الواتساب'].includes(lowerHeader)) {
        field = fields.find(f => f.key === 'whatsapp');
      }
    }

    if (field) {
      data[field.key] = parseCSVValue(field, rawVal);
      if (field.csvColumn) {
        data[field.csvColumn] = rawVal;
      }
    }
  });
  
  return data;
}

// تحويل الكائن إلى صف CSV
export function objectToCSVRow(obj: Record<string, any>): string {
  const fields = getCSVFields();
  return fields.map(f => {
    const value = obj[f.key];
    if (value === undefined || value === null) return '';
    if (typeof value === 'boolean') return value ? 'true' : 'false';
    return String(value);
  }).join(',');
}
