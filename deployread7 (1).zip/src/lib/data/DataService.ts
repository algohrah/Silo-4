import { IDatabaseAdapter } from './interfaces';
import { SupabaseAdapter } from './adapters/supabase/SupabaseAdapter';
import { LocalStorageAdapter } from './LocalStorageAdapter';
import { DATABASE_CONFIG, DatabaseProvider } from '../../config/database';

// ============================================================================
//  DataService — نقطة الوصول الموحدة لجميع عمليات قواعد البيانات والتحكم بها
//  Single Source Data Architecture — Central Data Access Layer
// ============================================================================

export class DataService {
  private static instance: DataService;

  /** المحوّل النشط حالياً لتنفيذ جميع العمليات */
  public db: IDatabaseAdapter;
  
  /** نوع مزود البيانات النشط ('local' أو 'supabase') */
  public provider: DatabaseProvider;

  private constructor() {
    this.provider = DATABASE_CONFIG.PROVIDER || 'local';
    
    if (this.provider === 'supabase') {
      this.db = new SupabaseAdapter();
      if (typeof window !== 'undefined') {
        console.info('[DataService] Connected to Supabase Cloud Database.');
      }
    } else {
      this.db = new LocalStorageAdapter();
      if (typeof window !== 'undefined') {
        console.info('[DataService] Connected to Local Database (LocalStorage).');
      }
    }
  }

  public static getInstance(): DataService {
    if (!DataService.instance) {
      DataService.instance = new DataService();
    }
    return DataService.instance;
  }

  /** تبديل مزود قاعدة البيانات ديناميكياً */
  public setProvider(newProvider: DatabaseProvider): void {
    this.provider = newProvider;
    if (newProvider === 'supabase') {
      this.db = new SupabaseAdapter();
    } else {
      this.db = new LocalStorageAdapter();
    }
  }
}

export const dataService = DataService.getInstance();

