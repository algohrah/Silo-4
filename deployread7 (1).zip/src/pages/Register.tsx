import { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Check, User, FileText, Heart, ShieldCheck,
  Venus, Mars, Lock, Eye, EyeOff,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import {
  Field, TextInput, SelectInput, TextArea,
  RadioGroup, ChoiceCard, RangeSlider, ProgressBar, DateSelect,
  SelectWithOther, PhoneInputWithCountryCode,
} from '../components/ui/FormFields';
import SearchableSelect from '../components/ui/SearchableSelect';
import { useApp } from '../lib/AppContext';
import { translitArabicToEnglish } from '../lib/types';
import * as C from '../lib/constants';
import { dataService } from '../lib/data/DataService';
const { getCountries, getCities, addPendingCity, getAllPendingCities } = dataService.db;



// ====================================================================
//  صفحة التسجيل الديناميكي — نموذج متعدد الخطوات
// ====================================================================

interface FormData {
  // أساسي
  gender: string;
  nickname: string;
  username: string;
  birthDate: string;
  age: number;
  country: string;
  city: string;
  district: string;
  sect: string;
  sectOther: string;
  nationalityMode: string; // 'same' | 'other'
  nationality: string;
  nationalityOther: string;
  // الحالة الاجتماعية
  maritalStatus: string;
  childrenCount: string;
  childrenLiveWith: string;
  hasChildren: string;
  wifeCount: string;
  seekingWife: string;
  // شخصية
  height: number;
  weight: number;
  skinColor: string;
  ethnicity: string;
  health: string;
  smoking: string;
  // نساء فقط
  acceptPolygamy: string;
  acceptDivorced: string;
  acceptWithChildren: string;
  // تعليم وعمل
  education: string;
  workType: string;
  jobTitle: string;
  housing: string;
  // نبذة
  bio: string;
  // مواصفات الشريك
  pCountry: string;
  pCity: string;
  pAgeMin: number;
  pAgeMax: number;
  pNationality: string;
  pNationalityOther: string;
  pMaritalStatus: string;
  pAcceptChildren: string;
  pSect: string;
  pSectOther: string;
  pEducation: string;
  pWorkType: string;
  pReligionLevel: string;
  pSkinColor: string;
  pHeightNoMatter: boolean;
  pHeight: number;
  pHousing: string;
  pNotes: string;
  // بيانات الإدارة
  realName: string;
  phone: string;
  whatsapp: string;
  email: string;
  // كلمة المرور
  password: string;
  passwordConfirm: string;
}

const emptyForm: FormData = {
  gender: '', nickname: '', username: '', birthDate: '', age: 0, country: '', city: '',
  district: '', sect: '', sectOther: '', nationalityMode: '', nationality: '', nationalityOther: '',
  maritalStatus: '', childrenCount: '', childrenLiveWith: '',
  hasChildren: '', wifeCount: '', seekingWife: '',
  height: 0, weight: 0, skinColor: '', ethnicity: '', health: '', smoking: '',
  acceptPolygamy: '', acceptDivorced: '', acceptWithChildren: '',
  education: '', workType: '', jobTitle: '', housing: '',
  bio: '',
  pCountry: '', pCity: '', pAgeMin: 22, pAgeMax: 35, pNationality: '', pNationalityOther: '',
  pMaritalStatus: '', pAcceptChildren: '', pSect: '', pSectOther: '',
  pEducation: '', pWorkType: '', pReligionLevel: '', pSkinColor: '', pHeightNoMatter: false, pHeight: 170, pHousing: '', pNotes: '',
  realName: '', phone: '', whatsapp: '', email: '',
  password: '', passwordConfirm: '',
};

const STEPS = [
  { id: 0, title: 'بيانات الحساب والأمان', icon: ShieldCheck },
  { id: 1, title: 'المعلومات الشخصية', icon: User },
  { id: 2, title: 'المظهر والعمل', icon: FileText },
  { id: 3, title: 'مواصفات الشريك', icon: Heart },
];

export default function Register() {
  const navigate = useNavigate();
  const { registerNewMember, members } = useApp();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormData>(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPass, setShowPass] = useState(false);
  const [showPassConfirm, setShowPassConfirm] = useState(false);

  const isMale = form.gender === 'male';
  const isFemale = form.gender === 'female';

  const set = (key: keyof FormData, value: any) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: '' }));
  };

  // حساب قوة كلمة المرور
  const passwordStrength = useMemo(() => {
    const pass = form.password;
    if (!pass) return { score: 0, label: '', color: 'bg-slate-200', percentage: 0 };
    if (pass.length < 6) return { score: 1, label: 'ضعيفة جدًا (اقل من 6 أحرف)', color: 'bg-rose-500', percentage: 25 };
    
    let score = 1;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass) || /[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass) && pass.length >= 8) score++;

    if (score <= 2) return { score: 2, label: 'مقبولة', color: 'bg-amber-500', percentage: 50 };
    if (score === 3) return { score: 3, label: 'جيدة جداً', color: 'bg-blue-500', percentage: 75 };
    return { score: 4, label: 'قوية وآمنة', color: 'bg-emerald-500', percentage: 100 };
  }, [form.password]);

  // حساب العمر تلقائيًا من تاريخ الميلاد
  const handleBirthDateChange = (date: string) => {
    set('birthDate', date);
    const parts = date ? date.split('-') : [];
    if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
      const birth = new Date(date);
      const today = new Date();
      let calculatedAge = today.getFullYear() - birth.getFullYear();
      const monthDiff = today.getMonth() - birth.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        calculatedAge--;
      }
      set('age', calculatedAge);
    } else {
      set('age', 0);
    }
  };

  // المدن حسب الدولة المختارة
  const cities = useMemo(() => {
    if (!form.country) return [];
    let official: string[] = [];
    try {
      official = getCities(form.country);
    } catch (e) {}
    if (!official || official.length === 0) {
      official = C.CITIES_BY_COUNTRY[form.country] || [];
    }
    const pending = (getAllPendingCities() || [])
      .filter((p) => p.country === form.country && p.status === 'pending')
      .map((p) => p.name);
    const combined = Array.from(new Set([...official, ...pending.filter((c) => !official.includes(c))]));
    return combined.length > 0 ? combined : (C.CITIES_BY_COUNTRY[form.country] || []);
  }, [form.country]);

  const pCities = useMemo(() => {
    if (!form.pCountry || form.pCountry === 'لا تفضيل' || form.pCountry === 'لا يهم') return [];
    let list: string[] = [];
    try {
      list = getCities(form.pCountry);
    } catch (e) {}
    if (!list || list.length === 0) {
      list = C.CITIES_BY_COUNTRY[form.pCountry] || [];
    }
    return list;
  }, [form.pCountry]);

  // قائمة الدول الحيّة من قاعدة البيانات
  const countryOptions = useMemo(() => {
    let list: string[] = [];
    try {
      const dbCountries = getCountries();
      if (Array.isArray(dbCountries) && dbCountries.length > 0) {
        list = dbCountries.map((c) => (typeof c === 'string' ? c : c?.name || String(c))).filter(Boolean);
      }
    } catch (err) {}
    if (!list || list.length === 0) {
      list = C.COUNTRIES;
    }
    return Array.from(new Set([...list, ...C.COUNTRIES]));
  }, []);

  // قائمة الجنسيات مربوطة بقاعدة البيانات وتتطابق مع قائمة الدول + خيار "أخرى"
  const nationalityOptions = useMemo(() => {
    const list = Array.from(new Set([...countryOptions, ...C.NATIONALITIES]));
    const filtered = list.filter((item) => item !== 'أخرى' && item !== 'جنسية أخرى');
    return [...filtered, 'أخرى'];
  }, [countryOptions]);

  // قائمة المذاهب الدينيه من قاعدة البيانات
  const sectOptions = useMemo(() => {
    try {
      const dbSects = dataService.db.getSects();
      if (Array.isArray(dbSects) && dbSects.length > 0) {
        const filtered = dbSects.filter((s) => s !== 'أخرى' && s !== 'مذهب آخر');
        return [...filtered, 'أخرى'];
      }
    } catch (err) {}
    return C.SECTS;
  }, []);

  // خيارات المظهر والعمل والتعليم من قاعدة البيانات
  const skinColorOptions = useMemo(() => {
    try {
      const opts = dataService.db.getRegistrationOptions('skinColors');
      if (Array.isArray(opts) && opts.length > 0) return opts;
    } catch (err) {}
    return C.SKIN_COLORS;
  }, []);

  const educationOptions = useMemo(() => {
    try {
      const opts = dataService.db.getRegistrationOptions('educationLevels');
      if (Array.isArray(opts) && opts.length > 0) return opts;
    } catch (err) {}
    return C.EDUCATION_LEVELS;
  }, []);

  const workTypeOptions = useMemo(() => {
    try {
      const opts = dataService.db.getRegistrationOptions('workTypes');
      if (Array.isArray(opts) && opts.length > 0) return opts;
    } catch (err) {}
    return C.WORK_TYPES;
  }, []);

  const housingOptions = useMemo(() => {
    try {
      const opts = dataService.db.getRegistrationOptions('housingTypes');
      if (Array.isArray(opts) && opts.length > 0) return opts;
    } catch (err) {}
    return C.HOUSING_TYPES;
  }, []);

  const childrenCountOptions = useMemo(() => {
    return Array.from({ length: 20 }, (_, i) => {
      const num = i + 1;
      let label = `${num}`;
      if (num === 1) label = '1 (طفل واحد)';
      else if (num === 2) label = '2 (طفلان)';
      else if (num <= 10) label = `${num} أطفال`;
      else label = `${num} طفلًا`;
      return { value: String(num), label };
    });
  }, []);

  const smokingOptions = useMemo(() => {
    try {
      const opts = dataService.db.getRegistrationOptions('smokingOptions');
      if (Array.isArray(opts) && opts.length > 0) return opts;
    } catch (err) {}
    return C.SMOKING_OPTIONS;
  }, []);

  const religionLevelOptions = useMemo(() => {
    try {
      const opts = dataService.db.getRegistrationOptions('religionLevels');
      if (Array.isArray(opts) && opts.length > 0) return opts;
    } catch (err) {}
    return C.RELIGION_LEVELS;
  }, []);

  const maritalMaleOptions = useMemo(() => {
    let opts: any[] = [];
    try {
      opts = dataService.db.getRegistrationOptions('maritalMale');
    } catch (err) {}
    if (!Array.isArray(opts) || opts.length === 0) opts = C.MARITAL_MALE;
    return opts.map((item) => {
      if (typeof item === 'string') {
        let val = item;
        if (item === 'أعزب') val = 'single';
        else if (item === 'مطلق') val = 'divorced';
        else if (item === 'أرمل') val = 'widower';
        else if (item === 'متزوج') val = 'married';
        return { value: val, label: item };
      }
      return item;
    });
  }, []);

  const maritalFemaleOptions = useMemo(() => {
    let opts: any[] = [];
    try {
      opts = dataService.db.getRegistrationOptions('maritalFemale');
    } catch (err) {}
    if (!Array.isArray(opts) || opts.length === 0) opts = C.MARITAL_FEMALE;
    return opts.map((item) => {
      if (typeof item === 'string') {
        let val = item;
        if (item === 'عزباء') val = 'single';
        else if (item === 'مطلقة') val = 'divorced';
        else if (item === 'أرملة') val = 'widow';
        return { value: val, label: item };
      }
      return item;
    });
  }, []);

  // إضافة مدينة مقترحة
  const handleAddCity = (country: string) => (name: string) => {
    return addPendingCity(name, country, form.nickname || form.realName || 'عضو جديد', 'register');
  };

  // التحقق من صحة كل خطوة
  const validateStep = (s: number): boolean => {
    const e: Record<string, string> = {};

    // ====== الخطوة 0: بيانات الحساب والأمان ======
    if (s === 0) {
      if (!form.realName.trim()) e.realName = 'الرجاء إدخال الاسم الكامل (الرباعي)';
      if (!form.gender) e.gender = 'الرجاء تحديد الجنس (ذكر / أنثى)';
      
      // تحقق من اسم المستخدم / اليوزر
      if (!form.username.trim()) {
        e.username = 'الرجاء إدخال اسم المستخدم (اليوزر)';
      } else if (!/^[a-z0-9_]{3,20}$/.test(form.username)) {
        e.username = 'يجب أن يتكون اسم المستخدم من 3 إلى 20 حرفًا إنجليزيًا أو أرقام أو شرطة سفلية (_) فقط';
      } else {
        const usernameExists = members.some((m) => m.username?.toLowerCase() === form.username.toLowerCase());
        if (usernameExists) {
          e.username = 'اسم المستخدم هذا محجوز بالفعل، يرجى اختيار اسم مستخدم آخر';
        }
      }

      if (!form.whatsapp || !form.whatsapp.trim()) {
        e.whatsapp = 'الرجاء إدخال رقم الواتساب الخاص بك للتواصل مع الإدارة';
      } else {
        const digitsOnly = form.whatsapp.replace(/\D/g, '');
        if (digitsOnly.length < 7) {
          e.whatsapp = 'رقم الواتساب غير مكتمل، يرجى التأكد من اختيار رمز الدولة وكتابة الرقم بشكل صحيح';
        }
      }

      if (!form.email.trim()) e.email = 'الرجاء إدخال البريد الإلكتروني';
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'صيغة البريد الإلكتروني غير صحيحة';
      else {
        const emailExists = members.some((m) => m.email?.toLowerCase() === form.email.toLowerCase());
        if (emailExists) {
          e.email = 'البريد الإلكتروني هذا مستخدم بالفعل بحساب آخر';
        }
      }

      if (!form.password) e.password = 'الرجاء إدخال كلمة المرور';
      else if (form.password.length < 6) e.password = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';

      if (!form.passwordConfirm) e.passwordConfirm = 'الرجاء تأكيد كلمة المرور';
      else if (form.password !== form.passwordConfirm) e.passwordConfirm = 'كلمتا المرور غير متطابقتين';
    }

    // ====== الخطوة 1: المعلومات الشخصية والجغرافية ======
    if (s === 1) {
      const dateParts = form.birthDate ? form.birthDate.split('-') : [];
      const dateComplete = dateParts.length === 3 && dateParts[0] && dateParts[1] && dateParts[2];
      if (!dateComplete) e.birthDate = 'الرجاء اختيار السنة والشهر واليوم';
      else if (form.age < 18) e.birthDate = 'يجب أن يكون عمرك 18 سنة على الأقل لإنشاء حساب';

      if (!form.country) e.country = 'الرجاء اختيار دولة الإقامة';
      if (!form.city) e.city = 'الرجاء اختيار المدينة';
      if (!form.district.trim()) e.district = 'الرجاء إدخال المنطقة / الحي';

      if (!form.nationalityMode) e.nationalityMode = 'الرجاء تحديد الجنسية';
      if (form.nationalityMode === 'other') {
        if (!form.nationality.trim()) e.nationality = 'الرجاء اختيار الجنسية';
        if ((form.nationality === 'أخرى' || form.nationality === 'جنسية أخرى') && !form.nationalityOther.trim()) {
          e.nationalityOther = 'الرجاء كتابة اسم الجنسية';
        }
      }

      if (!form.sect) e.sect = 'الرجاء اختيار المذهب الديني';
      if ((form.sect === 'أخرى' || form.sect === 'مذهب آخر') && !form.sectOther.trim()) e.sectOther = 'الرجاء كتابة المذهب';

      if (!form.maritalStatus) e.maritalStatus = 'الرجاء اختيار الحالة الاجتماعية';
    }

    // ====== الخطوة 2: المظهر والعمل ======
    if (s === 2) {
      if (!form.height || Number(form.height) < 80 || Number(form.height) > 300) {
        e.height = 'الرجاء كتابة الطول الصحيح (بين 80 و 300 سم)';
      }
      if (!form.weight || Number(form.weight) < 20 || Number(form.weight) > 300) {
        e.weight = 'الرجاء كتابة الوزن الصحيح (بين 20 و 300 كجم)';
      }
      if (!form.skinColor) e.skinColor = 'الرجاء اختيار لون البشرة';
      if (!form.ethnicity?.trim()) e.ethnicity = 'الرجاء كتابة العرق / الأصل';
      if (!form.health?.trim()) e.health = 'الرجاء كتابة الحالة الصحية';
      if (!form.smoking) e.smoking = 'الرجاء اختيار حالة التدخين';
      if (!form.education) e.education = 'الرجاء اختيار المؤهل الدراسي';
      if (!form.workType) e.workType = 'الرجاء اختيار نوع جهة العمل';
      if (form.workType && form.workType !== 'بدون عمل' && !form.jobTitle.trim()) e.jobTitle = 'الرجاء كتابة المسمى الوظيفي';
      if (!form.housing) e.housing = 'الرجاء اختيار نوع السكن';
      if (form.bio.trim().length < 20) e.bio = 'النبذة قصيرة جدًا (20 حرفًا على الأقل)';
    }

    // ====== الخطوة 3: مواصفات الشريك ======
    if (s === 3) {
      // لا توجد قيود إجبارية معطلة لحرية اختيار الشريك
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNext = () => {
    if (!validateStep(step)) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    if (step < STEPS.length - 1) setStep(step + 1);
    else handleSubmit();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStepClick = (targetStep: number) => {
    if (targetStep < step) {
      setStep(targetStep);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (targetStep === step + 1) {
      handleNext();
    }
  };

  const handleSubmit = () => {
    registerNewMember(form);
    navigate('/profile');
  };

  const progress = ((step + 1) / STEPS.length) * 100;

  return (
    <div className="min-h-[calc(100vh-5rem)] bg-cream-50 py-6 px-4">
      <div className="max-w-2xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-navy-600 hover:text-gold-700 font-cairo font-semibold text-sm mb-5 transition-colors">
          <ArrowLeft className="w-4 h-4" /> العودة للرئيسية
        </Link>

        <div className="bg-white rounded-3xl shadow-luxe border border-cream-200/60 overflow-hidden">
          {/* Header مع شريط التقدم النقر الذكي */}
          <div className="bg-navy-gradient p-5 sm:p-6">
            <div className="flex items-center justify-between mb-3">
              <h1 className="font-cairo font-bold text-white text-lg">إنشاء حساب جديد</h1>
              <span className="text-gold-300 font-cairo font-bold text-sm">
                الخطوة {step + 1} من {STEPS.length}
              </span>
            </div>
            <ProgressBar value={progress} />
            <div className="flex justify-between mt-3">
              {STEPS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => handleStepClick(i)}
                  disabled={i > step + 1}
                  className={`flex flex-col items-center gap-1 flex-1 transition-all ${
                    i <= step ? 'cursor-pointer hover:opacity-90' : 'cursor-not-allowed opacity-60'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    i < step ? 'bg-emerald-500 text-white shadow-sm' :
                    i === step ? 'bg-gold-gradient text-navy-900 shadow-md ring-2 ring-gold-300/50' :
                    'bg-white/10 text-cream-200/50'
                  }`}>
                    {i < step ? <Check className="w-4 h-4" /> : i + 1}
                  </div>
                  <span className={`text-[10px] font-cairo font-semibold hidden sm:block ${i <= step ? 'text-gold-300' : 'text-cream-200/40'}`}>
                    {s.title}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* محتوى الخطوة */}
          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              {/* ====== الخطوة 0: بيانات الحساب والأمان ====== */}
              {step === 0 && (
                <motion.div key="s0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={ShieldCheck} title="بيانات الحساب والأمان" desc="إنشاء بيئة حسابك وأمان التواصل" />

                  {/* الاسم الكامل واللقب/الاسم المستعار */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="الاسم الكامل الرباعي" required error={errors.realName} hint="سري بالكامل — للإدارة فقط للتحقق من هوية الحساب">
                      <TextInput
                        value={form.realName}
                        onChange={(v) => {
                          set('realName', v);
                          if (!form.nickname) {
                            const first = v.trim().split(' ')[0];
                            if (first) {
                              set('nickname', first);
                              set('username', translitArabicToEnglish(first));
                            }
                          }
                        }}
                        placeholder="أدخل اسمك الرباعي الحقيقي"
                      />
                    </Field>

                    <Field label="الاسم المستعار (الظاهر للجميع)" hint="اختياري — يظهر في ملفك العام للأعضاء. مثال: أبو محمد، باحث عن الستر">
                      <TextInput
                        value={form.nickname}
                        onChange={(v) => {
                          set('nickname', v);
                          const cleanedNick = v.trim();
                          if (cleanedNick) {
                            set('username', translitArabicToEnglish(cleanedNick));
                          }
                        }}
                        placeholder={isMale ? 'مثال: أبو عبدالله، القحطاني' : 'مثال: باحثة عن الستر، أم محمد'}
                      />
                    </Field>
                  </div>

                  {/* تحديد الجنس فوراً */}
                  <Field label="الجنس" required error={errors.gender} hint="لتخصيص الخيارات ونظام المطابقة المناسب">
                    <div className="grid grid-cols-2 gap-3">
                      <ChoiceCard
                        active={isMale}
                        onClick={() => { set('gender', 'male'); set('maritalStatus', ''); }}
                        icon={<div className={`w-12 h-12 rounded-full flex items-center justify-center ${isMale ? 'bg-blue-500' : 'bg-cream-100'}`}><Mars className={`w-6 h-6 ${isMale ? 'text-white' : 'text-navy-400'}`} /></div>}
                        title="ذكر"
                      />
                      <ChoiceCard
                        active={isFemale}
                        onClick={() => { set('gender', 'female'); set('maritalStatus', ''); }}
                        icon={<div className={`w-12 h-12 rounded-full flex items-center justify-center ${isFemale ? 'bg-rose-500' : 'bg-cream-100'}`}><Venus className={`w-6 h-6 ${isFemale ? 'text-white' : 'text-navy-400'}`} /></div>}
                        title="أنثى"
                      />
                    </div>
                  </Field>

                  {/* اسم المستخدم الفريد (اليوزر) */}
                  <Field label="اسم المستخدم / اليوزر الفريد" required error={errors.username} hint="رمز حركي إنجليزي لملفك (3-20 حرف/رقم بدون مسافات)">
                    <div className="relative">
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 font-mono text-sm text-slate-400">@</span>
                      <TextInput
                        value={form.username}
                        onChange={(v) => {
                          const cleaned = v.toLowerCase().replace(/[^a-z0-9_]/g, '');
                          set('username', cleaned);
                        }}
                        placeholder="abu_abdullah"
                        className="pr-9 font-mono"
                      />
                    </div>
                  </Field>

                  {/* البريد الإلكتروني ورقم الواتساب */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="البريد الإلكتروني" required error={errors.email} hint="لتسجيل الدخول واستعادة الحساب">
                      <TextInput value={form.email} onChange={(v) => set('email', v)} placeholder="name@example.com" type="email" />
                    </Field>

                    <Field
                      label="رقم الواتساب للتواصل والإدارة"
                      required
                      error={errors.whatsapp}
                      hint="لتواصل الإدارة المباشر معك عند وجود اهتمام أو شريك مناسب"
                    >
                      <PhoneInputWithCountryCode
                        value={form.whatsapp || ''}
                        onChange={(v) => {
                          set('whatsapp', v);
                          set('phone', v);
                        }}
                        placeholder="501234567"
                      />
                    </Field>
                  </div>

                  {/* كلمة المرور وتأكيدها ومقياس القوة */}
                  <div className="pt-3 border-t border-cream-200 space-y-4">
                    <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                      <Lock className="w-4 h-4 text-gold-600" /> تعيين كلمة المرور
                    </h4>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <Field label="كلمة المرور" required error={errors.password}>
                        <div className="relative">
                          <input
                            type={showPass ? 'text' : 'password'}
                            value={form.password}
                            onChange={(e) => set('password', e.target.value)}
                            placeholder="••••••••"
                            className="w-full pr-4 pl-12 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 text-sm transition-colors"
                          />
                          <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                            {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </Field>

                      <Field label="تأكيد كلمة المرور" required error={errors.passwordConfirm}>
                        <div className="relative">
                          <input
                            type={showPassConfirm ? 'text' : 'password'}
                            value={form.passwordConfirm}
                            onChange={(e) => set('passwordConfirm', e.target.value)}
                            placeholder="••••••••"
                            className="w-full pr-4 pl-12 py-3 rounded-xl bg-cream-50 border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-navy-900 text-sm transition-colors"
                          />
                          <button type="button" onClick={() => setShowPassConfirm(!showPassConfirm)} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700">
                            {showPassConfirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </Field>
                    </div>

                    {/* مؤشر قوة كلمة المرور */}
                    {form.password && (
                      <div className="bg-cream-50 p-3 rounded-xl border border-cream-200 space-y-1.5">
                        <div className="flex justify-between items-center text-xs font-cairo">
                          <span className="text-slate-600">قوة كلمة المرور:</span>
                          <span className="font-bold text-slate-800">{passwordStrength.label}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div className={`h-full ${passwordStrength.color} transition-all duration-300`} style={{ width: `${passwordStrength.percentage}%` }} />
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* ====== الخطوة 1: المعلومات الشخصية والجغرافية ====== */}
              {step === 1 && (
                <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={User} title="المعلومات الشخصية والجغرافية" desc="معلومات الإقامة والعمر والحالة الاجتماعية" />

                  {/* تاريخ الميلاد والعمر */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="تاريخ الميلاد" required error={errors.birthDate} hint="اختر السنة ثم الشهر ثم اليوم">
                      <DateSelect value={form.birthDate} onChange={handleBirthDateChange} />
                    </Field>
                    <Field label="العمر (محسوب تلقائيًا)">
                      <div className="px-4 py-3 rounded-xl bg-gold-300/10 border-2 border-gold-300/40 flex items-center justify-between h-full">
                        <span className="text-xs text-navy-600 font-cairo">العمر الحالي:</span>
                        <div className="flex items-baseline gap-1">
                          <span className="font-cairo font-extrabold text-2xl text-gradient-gold">
                            {form.age > 0 ? form.age : '—'}
                          </span>
                          {form.age > 0 && <span className="text-navy-500 font-tajawal text-xs">سنة</span>}
                        </div>
                      </div>
                    </Field>
                  </div>

                  {/* الدولة والمدينة والمنطقة */}
                  <Field label="دولة الإقامة الحالية" required error={errors.country} hint="الدولة التي تقيم فيها الآن">
                    <SearchableSelect
                      value={form.country}
                      onChange={(v) => { set('country', v); set('city', ''); if (form.nationalityMode === 'same') set('nationality', v); }}
                      options={countryOptions}
                      placeholder="ابحث واختر الدولة"
                      searchPlaceholder="اكتب اسم الدولة..."
                    />
                  </Field>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="المدينة" required error={errors.city}>
                      <SearchableSelect
                        value={form.city}
                        onChange={(v) => set('city', v)}
                        options={cities}
                        placeholder={form.country ? 'ابحث واختر المدينة' : 'اختر الدولة أولًا'}
                        searchPlaceholder="اكتب اسم المدينة..."
                        disabled={!form.country}
                        allowAddNew={!!form.country}
                        onAddNew={handleAddCity(form.country)}
                        addNewLabel="لم تجد مدينتك؟ أضفها هنا"
                        addNewPlaceholder="اكتب اسم مدينتك..."
                      />
                    </Field>
                    <Field label="المنطقة / الحي" required error={errors.district} hint="الحي أو المنطقة التفصيلية">
                      <TextInput value={form.district} onChange={(v) => set('district', v)} placeholder="مثال: حي العليا، الملقا..." />
                    </Field>
                  </div>

                  {/* الجنسية والمذهب */}
                  <Field label="الجنسية" required error={errors.nationalityMode || errors.nationality}>
                    <div className="space-y-3">
                      <RadioGroup
                        options={[
                          { value: 'same', label: form.country ? `نعم، نفس دولة الإقامة (${form.country})` : 'نعم، نفس دولة الإقامة' },
                          { value: 'other', label: 'لا، جنسية أخرى' },
                        ]}
                        value={form.nationalityMode}
                        onChange={(v) => {
                          set('nationalityMode', v);
                          if (v === 'same' && form.country) set('nationality', form.country);
                          else set('nationality', '');
                        }}
                        columns={2}
                      />
                      {form.nationalityMode === 'other' && (
                        <div className="space-y-2">
                          <SearchableSelect
                            value={form.nationality}
                            onChange={(v) => set('nationality', v)}
                            options={nationalityOptions}
                            placeholder="اختر الجنسية"
                            searchPlaceholder="اكتب اسم الجنسية أو الدولة..."
                          />
                          {(form.nationality === 'أخرى' || form.nationality === 'جنسية أخرى') && (
                            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                              <TextInput
                                value={form.nationalityOther}
                                onChange={(v) => set('nationalityOther', v)}
                                placeholder="اكتب اسم الجنسية بالتفصيل..."
                              />
                              {errors.nationalityOther && <p className="text-xs text-rose-deep font-tajawal mt-1">{errors.nationalityOther}</p>}
                            </motion.div>
                          )}
                        </div>
                      )}
                    </div>
                  </Field>

                  <Field label="المذهب" required error={errors.sect} hint="المذهب الديني المتبع">
                    <RadioGroup
                      options={sectOptions.map((s) => ({ value: s, label: s }))}
                      value={form.sect}
                      onChange={(v) => set('sect', v)}
                      columns={3}
                    />
                    {(form.sect === 'أخرى' || form.sect === 'مذهب آخر') && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-2">
                        <TextInput
                          value={form.sectOther}
                          onChange={(v) => set('sectOther', v)}
                          placeholder="اكتب المذهب بالتفصيل..."
                        />
                        {errors.sectOther && <p className="text-xs text-rose-deep font-tajawal mt-1">{errors.sectOther}</p>}
                      </motion.div>
                    )}
                  </Field>

                  {/* الحالة الاجتماعية */}
                  <Field label="الحالة الاجتماعية" required error={errors.maritalStatus}>
                    <RadioGroup
                      options={isMale ? maritalMaleOptions : maritalFemaleOptions}
                      value={form.maritalStatus}
                      onChange={(v) => set('maritalStatus', v)}
                      columns={isMale ? 4 : 3}
                    />
                  </Field>

                  {/* حقول مطلقة/أرملة/أرمل — الأبناء */}
                  {['divorced', 'widower', 'widow', 'widowed', 'مطلق', 'مطلقة', 'أرمل', 'أرملة'].includes(form.maritalStatus) && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
                      <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                        <User className="w-4 h-4 text-gold-600" /> معلومات الأبناء
                      </h4>
                      <Field label={isMale ? 'هل لديك أبناء؟' : 'هل لديكِ أبناء؟'}>
                        <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
                      </Field>
                      {form.hasChildren === 'yes' && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid sm:grid-cols-2 gap-4">
                          <Field label="عدد الأبناء (اختر من 1 إلى 20)">
                            <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={childrenCountOptions} placeholder="اختر عدد الأبناء" />
                          </Field>
                          <Field label={isMale ? 'هل الأبناء يعيشون معك؟' : 'هل الأبناء يعيشون معكِ؟'}>
                            <RadioGroup options={C.YES_NO} value={form.childrenLiveWith} onChange={(v) => set('childrenLiveWith', v)} />
                          </Field>
                        </motion.div>
                      )}
                    </motion.div>
                  )}

                  {/* حقول متزوج (للرجال) */}
                  {isMale && ['married', 'متزوج'].includes(form.maritalStatus) && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
                      <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                        <User className="w-4 h-4 text-gold-600" /> تفاصيل الزواج الحالي
                      </h4>
                      <Field label="عدد الزوجات الحالي" required>
                        <RadioGroup options={C.WIFE_COUNT} value={form.wifeCount} onChange={(v) => set('wifeCount', v)} columns={3} />
                      </Field>
                      <Field label="هل لديك أبناء؟">
                        <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
                      </Field>
                      {form.hasChildren === 'yes' && (
                        <Field label="كم عدد الأبناء؟ (من 1 إلى 20)">
                          <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={childrenCountOptions} placeholder="اختر عدد الأبناء" />
                        </Field>
                      )}
                      <Field label="هل تبحث عن زوجة أخرى؟">
                        <RadioGroup options={C.YES_NO} value={form.seekingWife} onChange={(v) => set('seekingWife', v)} />
                      </Field>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {/* ====== الخطوة 2: المظهر والعمل ====== */}
              {step === 2 && (
                <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={FileText} title="المظهر والعمل والتعليم" desc="المواصفات الجسدية والوظيفية والنبذة التعريفية" />

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="الطول (كتابة)" required error={errors.height} hint="أدخل طولك بالسنتيمتر (من 80 إلى 300 سم)">
                      <div className="relative">
                        <TextInput
                          type="number"
                          min={80}
                          max={300}
                          value={form.height ? String(form.height) : ''}
                          onChange={(v) => set('height', v ? Number(v) : '')}
                          placeholder="اكتب الطول (80 - 300)"
                          className="pl-12"
                        />
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-navy-400 font-tajawal pointer-events-none">سم</span>
                      </div>
                    </Field>
                    <Field label="الوزن (كتابة)" required error={errors.weight} hint="أدخل وزنك بالكيلوغرام (من 20 إلى 300 كجم)">
                      <div className="relative">
                        <TextInput
                          type="number"
                          min={20}
                          max={300}
                          value={form.weight ? String(form.weight) : ''}
                          onChange={(v) => set('weight', v ? Number(v) : '')}
                          placeholder="اكتب الوزن (20 - 300)"
                          className="pl-12"
                        />
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-navy-400 font-tajawal pointer-events-none">كجم</span>
                      </div>
                    </Field>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="لون البشرة" required error={errors.skinColor}>
                      <SelectInput value={form.skinColor} onChange={(v) => set('skinColor', v)} options={skinColorOptions} placeholder="اختر لون البشرة" />
                    </Field>
                    <Field label="العرق / الأصل" required error={errors.ethnicity} hint="مثال: عربي، خليجي، قبلي، قبيلي...">
                      <TextInput value={form.ethnicity} onChange={(v) => set('ethnicity', v)} placeholder="اكتب الأصل/العرق..." />
                    </Field>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="الحالة الصحية" required error={errors.health}>
                      <TextInput value={form.health} onChange={(v) => set('health', v)} placeholder="ممتازة، سليم الحمد لله..." />
                    </Field>
                    <Field label={isFemale ? 'هل تدخنين؟' : 'هل تدخن؟'} required error={errors.smoking}>
                      <SelectInput value={form.smoking} onChange={(v) => set('smoking', v)} options={smokingOptions} placeholder="اختر" />
                    </Field>
                  </div>

                  <Field label="المؤهل الدراسي" required error={errors.education}>
                    <SelectInput value={form.education} onChange={(v) => set('education', v)} options={educationOptions} placeholder="اختر المؤهل" />
                  </Field>

                  <Field label="نوع جهة العمل" required error={errors.workType}>
                    <RadioGroup
                      options={workTypeOptions.map((w: any) => (typeof w === 'string' ? { value: w, label: w } : w))}
                      value={form.workType}
                      onChange={(v) => { set('workType', v); set('jobTitle', ''); }}
                      columns={3}
                    />
                  </Field>

                  {form.workType && form.workType !== 'بدون عمل' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                      <Field label="المسمى الوظيفي" required error={errors.jobTitle}>
                        <TextInput value={form.jobTitle} onChange={(v) => set('jobTitle', v)} placeholder="مثال: معلم، مهندس، موظف إداري..." />
                      </Field>
                    </motion.div>
                  )}

                  <Field label="نوع السكن" required error={errors.housing}>
                    <RadioGroup
                      options={housingOptions.map((h: any) => typeof h === 'string' ? { value: h, label: h } : h)}
                      value={form.housing}
                      onChange={(v) => set('housing', v)}
                      columns={2}
                    />
                  </Field>

                  {isFemale && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-rose-50 rounded-2xl p-4 border border-rose-200">
                      <h4 className="font-cairo font-bold text-rose-700 text-sm flex items-center gap-2">
                        <Heart className="w-4 h-4" /> خيارات خاصة
                      </h4>
                      <Field label="هل تقبلين التعدد؟">
                        <RadioGroup options={C.POLYGAMY_ACCEPT} value={form.acceptPolygamy} onChange={(v) => set('acceptPolygamy', v)} columns={1} />
                      </Field>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <Field label="هل تقبلين زوجًا مطلقًا؟">
                          <RadioGroup options={C.YES_NO} value={form.acceptDivorced} onChange={(v) => set('acceptDivorced', v)} />
                        </Field>
                        <Field label="هل تقبلين زوجًا لديه أبناء؟">
                          <RadioGroup options={C.YES_NO} value={form.acceptWithChildren} onChange={(v) => set('acceptWithChildren', v)} />
                        </Field>
                      </div>
                    </motion.div>
                  )}

                  <Field label="نبذة تعريفية عن نفسك" required error={errors.bio} hint={`${form.bio.length}/500 حرف (20 حرفًا على الأقل)`}>
                    <TextArea value={form.bio} onChange={(v) => set('bio', v)} placeholder="اكتب نبذة مختصرة عن شخصيتك، قيمك، وأهدافك المستقبليّة..." rows={4} />
                  </Field>
                </motion.div>
              )}

              {/* ====== الخطوة 3: مواصفات الشريك ====== */}
              {step === 3 && (
                <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <SectionTitle icon={Heart} title="مواصفات الشريك المطلوب" desc={isMale ? 'صف الشريكة المناسبة لك' : 'صفي الشريك المناسب لكِ'} />

                  <Field label="الدولة المطلوبة">
                    <SearchableSelect
                      value={form.pCountry}
                      onChange={(v) => { set('pCountry', v); set('pCity', ''); }}
                      options={countryOptions}
                      placeholder="اختر"
                      searchPlaceholder="اكتب اسم الدولة..."
                      includeNoPreference
                      noPreferenceLabel="لا يهم"
                    />
                  </Field>

                  {form.pCountry && form.pCountry !== 'لا يهم' && (
                    <Field label="المدينة المطلوبة">
                      <SearchableSelect
                        value={form.pCity}
                        onChange={(v) => set('pCity', v)}
                        options={pCities}
                        placeholder="اختر"
                        searchPlaceholder="اكتب اسم المدينة..."
                        includeNoPreference
                        noPreferenceLabel="لا يهم"
                      />
                    </Field>
                  )}

                  <Field label="الجنسية المطلوبة">
                    <SearchableSelect
                      value={form.pNationality}
                      onChange={(v) => set('pNationality', v)}
                      options={nationalityOptions}
                      placeholder="اختر"
                      searchPlaceholder="اكتب اسم الجنسية أو الدولة..."
                      includeNoPreference
                      noPreferenceLabel="لا يهم"
                    />
                    {(form.pNationality === 'أخرى' || form.pNationality === 'جنسية أخرى') && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-2">
                        <TextInput
                          value={form.pNationalityOther}
                          onChange={(v) => set('pNationalityOther', v)}
                          placeholder="اكتب الجنسية المطلوبة هنا..."
                        />
                      </motion.div>
                    )}
                  </Field>

                  <Field label="العمر المطلوب">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-xs text-navy-500 font-tajawal mb-1 block">من</span>
                        <RangeSlider value={form.pAgeMin} onChange={(v) => set('pAgeMin', Math.min(v, form.pAgeMax))} min={18} max={70} unit=" سنة" />
                      </div>
                      <div>
                        <span className="text-xs text-navy-500 font-tajawal mb-1 block">إلى</span>
                        <RangeSlider value={form.pAgeMax} onChange={(v) => set('pAgeMax', Math.max(v, form.pAgeMin))} min={18} max={70} unit=" سنة" />
                      </div>
                    </div>
                  </Field>

                  <Field label="الحالة الاجتماعية المقبولة">
                    <SelectInput
                      value={form.pMaritalStatus}
                      onChange={(v) => set('pMaritalStatus', v)}
                      options={isMale ? ['لا يهم', 'عزباء', 'مطلقة', 'أرملة'] : ['لا يهم', 'أعزب', 'مطلق', 'أرمل', 'متزوج']}
                      placeholder="اختر"
                    />
                  </Field>

                  {form.pMaritalStatus !== 'أعزب/عزباء' && form.pMaritalStatus !== 'أعزب' && form.pMaritalStatus !== 'عزباء' && form.pMaritalStatus !== '' && form.pMaritalStatus !== 'لا يهم' && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                      <Field label="هل تقبل وجود أطفال؟">
                        <RadioGroup options={C.YES_NO} value={form.pAcceptChildren} onChange={(v) => set('pAcceptChildren', v)} />
                      </Field>
                    </motion.div>
                  )}

                  <Field label="المذهب المطلوب">
                    <RadioGroup
                      options={['لا يهم', ...sectOptions].map((s) => ({ value: s, label: s }))}
                      value={form.pSect}
                      onChange={(v) => set('pSect', v)}
                      columns={3}
                    />
                    {(form.pSect === 'أخرى' || form.pSect === 'مذهب آخر') && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-2">
                        <TextInput
                          value={form.pSectOther}
                          onChange={(v) => set('pSectOther', v)}
                          placeholder="اكتب المذهب المطلوب..."
                        />
                      </motion.div>
                    )}
                  </Field>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="مستوى التدين">
                      <SelectInput value={form.pReligionLevel} onChange={(v) => set('pReligionLevel', v)} options={['لا يهم', ...religionLevelOptions]} placeholder="اختر" />
                    </Field>
                    <Field label="لون البشرة المطلوب">
                      <SelectInput value={form.pSkinColor} onChange={(v) => set('pSkinColor', v)} options={['لا يهم', ...skinColorOptions]} placeholder="اختر" />
                    </Field>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="المؤهل الدراسي المطلوب">
                      <SelectInput value={form.pEducation} onChange={(v) => set('pEducation', v)} options={['لا يهم', ...educationOptions]} placeholder="اختر" />
                    </Field>
                    <Field label="نوع الوظيفة المطلوبة">
                      <SelectInput value={form.pWorkType} onChange={(v) => set('pWorkType', v)} options={['لا يهم', ...workTypeOptions.map((w: any) => typeof w === 'string' ? w : w.label)]} placeholder="اختر" />
                    </Field>
                  </div>

                  <Field label="الطول المطلوب">
                    {form.pHeightNoMatter ? (
                      <div className="px-4 py-3 rounded-xl bg-cream-100 text-navy-500 font-tajawal text-center">لا يهم</div>
                    ) : (
                      <RangeSlider value={form.pHeight} onChange={(v) => set('pHeight', v)} min={140} max={250} unit=" سم" />
                    )}
                    <label className="flex items-center gap-2 mt-2 cursor-pointer">
                      <input type="checkbox" checked={form.pHeightNoMatter} onChange={(e) => set('pHeightNoMatter', e.target.checked)} className="w-4 h-4 rounded accent-gold-500" />
                      <span className="text-sm text-navy-600 font-tajawal">لا يهم</span>
                    </label>
                  </Field>

                  <Field label="نوع السكن المطلوب">
                    <SelectInput value={form.pHousing} onChange={(v) => set('pHousing', v)} options={['لا يهم', ...housingOptions]} placeholder="اختر" />
                  </Field>

                  <Field label="ملاحظات وشروط إضافية">
                    <TextArea value={form.pNotes} onChange={(v) => set('pNotes', v)} placeholder="اكتب أي ملاحظات أو شروط خاصة برغبتك..." rows={3} />
                  </Field>
                </motion.div>
              )}
            </AnimatePresence>

            {/* أزرار التنقل */}
            <div className="flex items-center gap-3 mt-7">
              {step > 0 && (
                <button onClick={() => { setStep(step - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="flex items-center gap-1 px-5 py-3 rounded-2xl text-navy-600 font-cairo font-semibold hover:bg-cream-100 transition-colors">
                  <ArrowRight className="w-4 h-4" /> السابق
                </button>
              )}
              {step < STEPS.length - 1 ? (
                <Button onClick={handleNext} fullWidth size="lg">
                  التالي <ArrowLeft className="w-4 h-4" />
                </Button>
              ) : (
                <Button onClick={handleNext} fullWidth size="lg" className="shadow-gold">
                  <Check className="w-5 h-5" /> إكمال التسجيل وإنشاء الحساب
                </Button>
              )}
            </div>

            {step === 0 && (
              <p className="text-center text-sm text-navy-500 font-tajawal mt-5">
                لديك حساب بالفعل؟ <Link to="/login" className="text-gold-700 font-cairo font-bold hover:underline">سجّل الدخول</Link>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ icon: Icon, title, desc }: { icon: typeof User; title: string; desc: string }) {
  return (
    <div className="flex items-center gap-3 pb-4 border-b border-cream-200">
      <div className="w-11 h-11 rounded-xl bg-gold-300/15 flex items-center justify-center flex-shrink-0">
        <Icon className="w-6 h-6 text-gold-600" />
      </div>
      <div>
        <h2 className="font-cairo font-bold text-xl text-navy-900">{title}</h2>
        <p className="text-sm text-navy-500 font-tajawal">{desc}</p>
      </div>
    </div>
  );
}
