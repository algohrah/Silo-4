export type DatabaseProvider = 'local' | 'supabase';

export const DATABASE_CONFIG = {
  // وضع القاعدة الحالي: 'local' للتطوير والتجربة المحلية، أو 'supabase' للربط السحابي المباشر
  PROVIDER: (import.meta.env.VITE_DATABASE_PROVIDER as DatabaseProvider) || 'local',
};

