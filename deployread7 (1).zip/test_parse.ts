import { parseCSV, parsePastedData } from './src/lib/importBatches.ts';

const text = `real_name,nickname,gender,age,country,city,district,nationality,sect,marital_status,height,weight,skin_color,ethnicity,education,work_type,housing,phone,whatsapp,bio,p_notes
,,ذكر,45,سلطنة عمان,ابراء,,عماني,,متزوج,169,65,حنطي,أخرى,ثانوية,متقاعد,,95856205,95856205,القبيلة: الصلطي. معي بيت ملك في مسقط,اريد زوجه تقبل بازوجه الثانيه وتكون طيبه وخلوقه ويفضل تكون موظفه`;

console.log(JSON.stringify(parsePastedData(text), null, 2));
