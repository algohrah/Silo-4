-- ============================================================================
-- Supabase Full Database Schema for Tawasol Marriage Platform
-- مشروع منصة تواصل للزواج والتعارف الجاد
-- قم بنسخ وتطبيق هذا الملف في SQL Editor داخل لوحة تحكم Supabase
-- ============================================================================

-- 1. جدول الإعدادات العامة (Settings)
CREATE TABLE IF NOT EXISTS public.settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. جدول الأعضاء (Members)
CREATE TABLE IF NOT EXISTS public.members (
    id TEXT PRIMARY KEY,
    nickname TEXT NOT NULL,
    username TEXT,
    gender TEXT,
    age INT,
    country TEXT,
    city TEXT,
    district TEXT,
    nationality TEXT,
    sect TEXT,
    marital_status TEXT,
    marital_label TEXT,
    has_children BOOLEAN DEFAULT FALSE,
    children_count TEXT,
    height INT,
    weight INT,
    skin_color TEXT,
    health TEXT,
    smoking TEXT,
    ethnicity TEXT,
    education TEXT,
    work_type TEXT,
    job_title TEXT,
    housing TEXT,
    bio TEXT,
    about_partner TEXT,
    verified BOOLEAN DEFAULT FALSE,
    premium BOOLEAN DEFAULT FALSE,
    online BOOLEAN DEFAULT FALSE,
    last_active TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    match_score INT,
    has_seriousness_badge BOOLEAN DEFAULT FALSE,
    plan TEXT DEFAULT 'free',
    pinned BOOLEAN DEFAULT FALSE,
    status TEXT DEFAULT 'active',
    status_reason TEXT,
    status_by TEXT,
    notes TEXT,
    flagged BOOLEAN DEFAULT FALSE,
    source_type TEXT DEFAULT 'registered',
    import_batch_id TEXT,
    import_office_name TEXT,
    import_date TEXT,
    import_notes TEXT,
    real_name TEXT,
    email TEXT,
    phone TEXT,
    whatsapp TEXT,
    password TEXT,
    birth_date TEXT,
    is_profile_incomplete BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    details JSONB
);

-- 3. جدول طلبات التوافق والرحلات (Interest Requests / Journeys)
CREATE TABLE IF NOT EXISTS public.interest_requests (
    id BIGINT PRIMARY KEY,
    sender_id TEXT NOT NULL,
    receiver_id TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    mediation_stage TEXT DEFAULT 'none',
    message TEXT,
    sender_paid BOOLEAN DEFAULT FALSE,
    sender_paid_at TIMESTAMP WITH TIME ZONE,
    receiver_paid BOOLEAN DEFAULT FALSE,
    receiver_paid_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. جدول الإشعارات (Notifications)
CREATE TABLE IF NOT EXISTS public.notifications (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT,
    text TEXT NOT NULL,
    type TEXT DEFAULT 'system',
    read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. جدول المعاملات المالية والكوبونات (Transactions & Coupons)
CREATE TABLE IF NOT EXISTS public.transactions (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    amount NUMERIC NOT NULL,
    type TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'completed',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.coupons (
    code TEXT PRIMARY KEY,
    discount NUMERIC NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. جدول تذاكر الدعم والشكاوى (Support Tickets)
CREATE TABLE IF NOT EXISTS public.support_tickets (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'open',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. جدول مديري اللوحة (Admin Users)
CREATE TABLE IF NOT EXISTS public.admin_users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    role TEXT DEFAULT 'admin',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. جدول رسائل غرفة الاستفسار (Inquiry Messages)
CREATE TABLE IF NOT EXISTS public.inquiry_messages (
    id BIGSERIAL PRIMARY KEY,
    request_id BIGINT NOT NULL,
    sender_id TEXT NOT NULL,
    text TEXT NOT NULL,
    status TEXT DEFAULT 'approved',
    moderated_by TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. جدول مستندات التوثيق (Verification Docs)
CREATE TABLE IF NOT EXISTS public.verification_docs (
    id TEXT PRIMARY KEY,
    member_id TEXT NOT NULL,
    doc_type TEXT NOT NULL,
    file_url TEXT,
    status TEXT DEFAULT 'pending',
    reviewer_name TEXT,
    rejection_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 10. جداول المدن والدول (Geo Store)
CREATE TABLE IF NOT EXISTS public.geo_countries (
    name TEXT PRIMARY KEY,
    code TEXT,
    flag TEXT
);

CREATE TABLE IF NOT EXISTS public.geo_cities (
    id BIGSERIAL PRIMARY KEY,
    country TEXT NOT NULL,
    name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.pending_cities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    country TEXT NOT NULL,
    suggested_by TEXT,
    suggested_by_id TEXT,
    source TEXT DEFAULT 'register',
    status TEXT DEFAULT 'pending',
    rejection_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- تعطيل Row Level Security (RLS) للوصول المباشر السلس
ALTER TABLE public.settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.members DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.interest_requests DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupons DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.inquiry_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.verification_docs DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.geo_countries DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.geo_cities DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.pending_cities DISABLE ROW LEVEL SECURITY;
