import { useState, useMemo, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Save, User, MapPin, Heart, FileText, Check, ShieldCheck,
  Lock, Ruler, Weight, GraduationCap, Briefcase, Calendar,
} from 'lucide-react';
import { useApp, type ProfileData } from '../lib/AppContext';
import { Button } from '../components/ui/Button';
import {
  Field, TextInput, SelectInput, TextArea, RadioGroup,
  RangeSlider, DateSelect, SelectWithOther,
} from '../components/ui/FormFields';
import SearchableSelect from '../components/ui/SearchableSelect';
import * as C from '../lib/constants';
import { getNationalityOptions, getPartnerMaritalOptions, getPartnerTerms } from '../lib/registrationOptions';
import { dataService } from '../lib/data/DataService';
const { getCountries, getCities, getAllPendingCities } = dataService.db;



export default function EditProfile() {
  const navigate = useNavigate();
  const { profileData, updateProfileData, showToast, user } = useApp();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // نسخة محلية من البيانات للتعديل
  const [form, setForm] = useState<ProfileData>({ ...profileData });

  useEffect(() => {
    setForm({ ...profileData });
  }, [profileData]);

  // نضمن تحميل قوائم المدن/الجنسيات الرسمية من قاعدة البيانات (نفس مصدر البحث والتسجيل)
  useEffect(() => { dataService.db.ensureGeoLoaded?.().catch(() => undefined); }, []);

  const isMale = form.gender === 'male';
  const isFemale = form.gender === 'female';
  const partnerTerms = useMemo(() => getPartnerTerms(form.gender as any), [form.gender]);

  const set = (key: keyof ProfileData, value: any) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  };

  // المدن حسب الدولة (تشمل الرسمية + المقترحات المعلّقة)
  const cities = useMemo(() => {
    if (!form.country) return [];
    const official = getCities(form.country);
    const pending = getAllPendingCities()
      .filter((p) => p.country === form.country && p.status === 'pending')
      .map((p) => p.name);
    return [...official, ...pending.filter((c) => !official.includes(c))];
  }, [form.country]);

  const pCities = useMemo(() => {
    return form.pCountry && form.pCountry !== 'لا يهم' ? getCities(form.pCountry) : [];
  }, [form.pCountry]);

  // قائمة الدول الحيّة
  const countryOptions = useMemo(() => getCountries().map((c) => c.name), []);
  const nationalityOptions = useMemo(() => Array.from(new Set([...(dataService.db.getNationalities?.() || []), ...getNationalityOptions(form.gender as any, countryOptions)])), [form.gender, countryOptions]);
  const partnerNationalityOptions = useMemo(() => Array.from(new Set([...(dataService.db.getNationalities?.() || []), ...getNationalityOptions(isMale ? 'female' : 'male', countryOptions)])), [isMale, countryOptions]);

  // إضافة مدينة مقترحة
  const handleAddCity = (country: string) => (name: string) => {
    return dataService.db.addPendingGeo('city', name, country, form.nickname || profileData.nickname || 'عضو', 'register');
  };

  const handleAddCountry = (name: string) => {
    return dataService.db.addPendingGeo('country', name, '', form.nickname || profileData.nickname || 'عضو', 'profile');
  };

  const handleAddNationality = (name: string) => {
    return dataService.db.addPendingGeo('nationality', name, form.country || '', form.nickname || profileData.nickname || 'عضو', 'profile');
  };

  // حساب العمر من تاريخ الميلاد
  const handleBirthDateChange = (date: string) => {
    set('birthDate', date);
    const parts = date ? date.split('-') : [];
    if (parts.length === 3 && parts[0] && parts[1] && parts[2]) {
      const birth = new Date(date);
      const today = new Date();
      let age = today.getFullYear() - birth.getFullYear();
      const monthDiff = today.getMonth() - birth.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) age--;
      set('age', age);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // ننتظر اكتمال حفظ التعديلات في قاعدة البيانات قبل المتابعة
      const success = await updateProfileData(form);
      if (success === false) {
        showToast('تعذّر حفظ التغييرات في قاعدة البيانات، حاول مجدداً', 'error');
        setSaving(false);
        return;
      }
      // إعادة جلب الملف من قاعدة البيانات للتأكد من نجاح الحفظ
      const activeId = user?.memberId || (typeof window !== 'undefined' ? dataService.db.getCurrentUserId() : null);
      if (activeId) {
        try {
          const fresh = await dataService.db.members.getById(activeId);
          if (fresh) {
            // تحديث profileData بالبيانات الفعلية من قاعدة البيانات
            setForm({ ...form, ...(fresh as any) });
          }
        } catch { /* ignore refresh error */ }
      }
      setSaving(false);
      setSaved(true);
      showToast('تم حفظ التغييرات بنجاح ✓', 'success');
      setTimeout(() => navigate('/profile'), 600);
    } catch (err) {
      console.error('[EditProfile] Error saving profile:', err);
      setSaving(false);
      showToast('حدث خطأ أثناء الحفظ، يرجى المحاولة مرة أخرى', 'error');
    }
  };

  const sections = [
    {
      title: 'المعلومات الأساسية',
      icon: User,
      fields: (
        <>
          <Field label="الجنس" required>
            <RadioGroup
              options={[{ value: 'male', label: 'ذكر' }, { value: 'female', label: 'أنثى' }]}
              value={form.gender}
              onChange={(v) => set('gender', v)}
              columns={2}
            />
          </Field>
          <Field label="الاسم المستعار" hint="يظهر في ملفك العام">
            <TextInput value={form.nickname} onChange={(v) => set('nickname', v)} placeholder="مثال: أبو عبدالله، باحثة عن الستر" />
          </Field>
          <Field label="تاريخ الميلاد" hint="اختر السنة ثم الشهر ثم اليوم">
            <DateSelect value={form.birthDate} onChange={handleBirthDateChange} />
          </Field>
          <Field label="العمر (محسوب تلقائيًا)">
            <div className="px-4 py-3 rounded-xl bg-gold-300/10 border-2 border-gold-300/40 flex items-center gap-2">
              <span className="font-cairo font-extrabold text-2xl text-gradient-gold">
                {form.age > 0 ? form.age : '—'}
              </span>
              {form.age > 0 && <span className="text-navy-500 font-tajawal">سنة</span>}
            </div>
          </Field>
          <Field label="الدولة" required>
            <SearchableSelect
              value={form.country}
              onChange={(v) => { set('country', v); set('city', ''); }}
              options={countryOptions}
              placeholder="ابحث واختر الدولة"
              searchPlaceholder="اكتب اسم الدولة..."
              allowAddNew
              onAddNew={handleAddCountry}
              addNewLabel="لم تجد دولتك؟ اكتب دولتك هنا"
              addNewPlaceholder="اكتب اسم الدولة..."
            />
          </Field>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="المدينة" required>
              <SearchableSelect
                value={form.city}
                onChange={(v) => set('city', v)}
                options={cities}
                placeholder={form.country ? 'ابحث واختر المدينة' : 'اختر الدولة أولًا'}
                searchPlaceholder="اكتب اسم المدينة..."
                disabled={!form.country}
                allowAddNew={!!form.country}
                onAddNew={handleAddCity(form.country)}
                addNewLabel="لم تجد مدينتك؟ أضفها هنا"
                addNewPlaceholder="اكتب اسم مدينتك..."
              />
            </Field>
            <Field label="المنطقة / الحي" hint="الحي أو المنطقة التفصيلية">
              <TextInput value={form.district} onChange={(v) => set('district', v)} placeholder="حي العليا..." />
            </Field>
          </div>
          <Field label="الجنسية" hint="جنسيتك">
            <SearchableSelect
              value={form.nationality}
              onChange={(v) => set('nationality', v)}
              options={nationalityOptions}
              placeholder="ابحث عن الجنسية"
              searchPlaceholder="اكتب اسم الجنسية..."
              allowAddNew
              onAddNew={handleAddNationality}
              addNewLabel="لم تجد جنسيتك؟ اكتب جنسيتك هنا"
              addNewPlaceholder="اكتب اسم الجنسية..."
            />
          </Field>
          <Field label="المذهب" hint="المذهب الديني الذي تتبعه">
            <SelectWithOther
              value={form.sect}
              otherValue={form.sectOther}
              onChange={(v) => set('sect', v)}
              onOtherChange={(v) => set('sectOther', v)}
              options={C.SECTS}
              placeholder="اختر المذهب"
            />
          </Field>
        </>
      ),
    },
    {
      title: 'الحالة الاجتماعية',
      icon: Heart,
      fields: (
        <>
          <Field label="الحالة الاجتماعية" required>
            <RadioGroup
              options={isMale ? C.MARITAL_MALE : C.MARITAL_FEMALE}
              value={form.maritalStatus}
              onChange={(v) => set('maritalStatus', v)}
              columns={isMale ? 4 : 3}
            />
          </Field>
          {['divorced', 'widower', 'widow', 'widowed', 'مطلق', 'مطلقة', 'أرمل', 'أرملة'].includes(form.maritalStatus) && (
            <div className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
              <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                <User className="w-4 h-4 text-gold-600" /> معلومات الأبناء
              </h4>
              <Field label={isMale ? 'هل لديك أبناء؟' : 'هل لديكِ أبناء؟'}>
                <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
              </Field>
              {form.hasChildren === 'yes' && (
                <div className="grid sm:grid-cols-2 gap-4">
                  <Field label="عدد الأبناء">
                    <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={C.CHILDREN_COUNT} placeholder="اختر" />
                  </Field>
                  <Field label={isMale ? 'هل الأبناء يعيشون معك؟' : 'هل الأبناء يعيشون معكِ؟'}>
                    <RadioGroup options={C.YES_NO} value={form.childrenLiveWith} onChange={(v) => set('childrenLiveWith', v)} />
                  </Field>
                </div>
              )}
            </div>
          )}
          {isMale && ['married', 'متزوج'].includes(form.maritalStatus) && (
            <div className="space-y-4 bg-cream-50 rounded-2xl p-4 border border-cream-200">
              <h4 className="font-cairo font-bold text-navy-900 text-sm flex items-center gap-2">
                <User className="w-4 h-4 text-gold-600" /> تفاصيل الزواج
              </h4>
              <Field label="عدد الزوجات الحالي">
                <RadioGroup options={C.WIFE_COUNT} value={form.wifeCount} onChange={(v) => set('wifeCount', v)} columns={3} />
              </Field>
              <Field label="هل لديك أبناء؟">
                <RadioGroup options={C.YES_NO} value={form.hasChildren} onChange={(v) => set('hasChildren', v)} />
              </Field>
              {form.hasChildren === 'yes' && (
                <Field label="كم عدد الأبناء؟">
                  <SelectInput value={form.childrenCount} onChange={(v) => set('childrenCount', v)} options={C.CHILDREN_COUNT} placeholder="اختر" />
                </Field>
              )}
              <Field label="هل تبحث عن زوجة أخرى؟">
                <RadioGroup options={C.YES_NO} value={form.seekingWife} onChange={(v) => set('seekingWife', v)} />
              </Field>
            </div>
          )}
        </>
      ),
    },
    {
      title: 'المواصفات الشخصية',
      icon: Ruler,
      fields: (
        <>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="الطول (كتابة)" hint="طولك بالسنتيمتر (80 - 300 سم)">
              <div className="relative">
                <TextInput
                  type="number"
                  min={80}
                  max={300}
                  value={form.height ? String(form.height) : ''}
                  onChange={(v) => set('height', v ? Number(v) : '')}
                  placeholder="80 - 300 سم"
                  className="pl-12"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-navy-400 font-tajawal pointer-events-none">سم</span>
              </div>
            </Field>
            <Field label="الوزن (كتابة)" hint="وزنك بالكيلوغرام (20 - 300 كجم)">
              <div className="relative">
                <TextInput
                  type="number"
                  min={20}
                  max={300}
                  value={form.weight ? String(form.weight) : ''}
                  onChange={(v) => set('weight', v ? Number(v) : '')}
                  placeholder="20 - 300 كجم"
                  className="pl-12"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-navy-400 font-tajawal pointer-events-none">كجم</span>
              </div>
            </Field>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="لون البشرة" hint="لون بشرتك الطبيعي">
              <SelectInput value={form.skinColor} onChange={(v) => set('skinColor', v)} options={C.SKIN_COLORS} placeholder="اختر لون البشرة" />
            </Field>
            <Field label="العرق" hint="مثال: عربي، خليجي، قبلي">
              <TextInput value={form.ethnicity} onChange={(v) => set('ethnicity', v)} placeholder="اكتب العرق..." />
            </Field>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="الحالة الصحية" hint="مثال: ممتازة، جيدة، وضع صحي خاص">
              <TextInput value={form.health} onChange={(v) => set('health', v)} placeholder="اكتب حالتك الصحية..." />
            </Field>
            <Field label={isFemale ? 'هل تدخنين؟' : 'هل تدخن؟'} hint="عادتك في التدخين">
              <SelectInput value={form.smoking} onChange={(v) => set('smoking', v)} options={C.SMOKING_OPTIONS} placeholder="اختر" />
            </Field>
          </div>
          {isFemale && (
            <div className="space-y-4 bg-rose-50 rounded-2xl p-4 border border-rose-200">
              <h4 className="font-cairo font-bold text-rose-700 text-sm flex items-center gap-2">
                <Heart className="w-4 h-4" /> خيارات خاصة
              </h4>
              <Field label="هل تقبلين التعدد؟">
                <RadioGroup options={C.POLYGAMY_ACCEPT} value={form.acceptPolygamy} onChange={(v) => set('acceptPolygamy', v)} columns={1} />
              </Field>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="هل تقبلين زوجًا مطلقًا؟">
                  <RadioGroup options={C.YES_NO} value={form.acceptDivorced} onChange={(v) => set('acceptDivorced', v)} />
                </Field>
                <Field label="هل تقبلين زوجًا لديه أبناء؟">
                  <RadioGroup options={C.YES_NO} value={form.acceptWithChildren} onChange={(v) => set('acceptWithChildren', v)} />
                </Field>
              </div>
            </div>
          )}
        </>
      ),
    },
    {
      title: 'التعليم والعمل',
      icon: GraduationCap,
      fields: (
        <>
          <Field label="المؤهل الدراسي" hint="أعلى مؤهل علمي حصلت عليه">
            <SelectInput value={form.education} onChange={(v) => set('education', v)} options={C.EDUCATION_LEVELS} placeholder="اختر المؤهل" />
          </Field>
          <Field label="نوع جهة العمل" hint="طبيعة عملك الحالي">
            <RadioGroup
              options={[
                { value: 'حكومي', label: 'حكومي' },
                { value: 'قطاع خاص', label: 'قطاع خاص' },
                { value: 'عمل حر', label: 'عمل حر' },
                { value: 'باحث عن عمل', label: 'باحث عن عمل' },
                { value: 'طالب', label: 'طالب' },
                { value: 'بدون عمل', label: 'بدون عمل' },
              ]}
              value={form.workType}
              onChange={(v) => { set('workType', v); set('jobTitle', ''); }}
              columns={3}
            />
          </Field>
          {form.workType && form.workType !== 'بدون عمل' && (
            <Field label="المسمى الوظيفي" hint={`مثال: ${form.workType === 'طالب' ? 'طالب جامعي' : 'معلم، طبيب، مهندس'}`}>
              <TextInput value={form.jobTitle} onChange={(v) => set('jobTitle', v)} placeholder={form.workType === 'طالب' ? 'طالب جامعي...' : 'معلم، طبيب...'} />
            </Field>
          )}
          <Field label="نوع السكن" hint="وضعك السكني الحالي">
            <SelectInput value={form.housing} onChange={(v) => set('housing', v)} options={C.HOUSING_TYPES} placeholder="اختر" />
          </Field>
        </>
      ),
    },
    {
      title: 'نبذة عني',
      icon: FileText,
      fields: (
        <Field label="اكتب نبذة قصيرة عنك" hint={`${form.bio.length}/500 حرف`}>
          <TextArea value={form.bio} onChange={(v) => set('bio', v)} placeholder="اكتب نبذة عن شخصيتك وأهدافك..." rows={4} />
        </Field>
      ),
    },
    {
      title: `مواصفات ${partnerTerms.partnerLabel} المطلوبة`,
      icon: Heart,
      fields: (
        <div className="space-y-5">
          {/* 1. الدولة والمدينة */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
            <label className="block text-xs font-cairo font-bold text-slate-800">
              1. {partnerTerms.countryLabel} والمدينة
            </label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  set('pCountry', form.country || 'السعودية');
                  set('pCity', form.city || 'الرياض');
                }}
                className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                  form.pCountry === form.country && form.pCity === form.city
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                ✓ نفس دولتي ومدينتي ({form.country || 'السعودية'} - {form.city || 'الرياض'})
              </button>
              <button
                type="button"
                onClick={() => {
                  set('pCountry', 'لا يهم');
                  set('pCity', 'لا يهم');
                }}
                className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                  form.pCountry === 'لا يهم'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                أي دولة / لا يهم
              </button>
              <button
                type="button"
                onClick={() => {
                  if (form.pCountry === 'لا يهم' || (form.pCountry === form.country && form.pCity === form.city)) {
                    set('pCountry', '');
                    set('pCity', '');
                  }
                }}
                className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                  form.pCountry !== 'لا يهم' && (form.pCountry !== form.country || form.pCity !== form.city)
                    ? 'bg-amber-500 text-white border-amber-500 shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                تحديد دولة / مدينة معينة
              </button>
            </div>

            {form.pCountry !== 'لا يهم' && (form.pCountry !== form.country || form.pCity !== form.city) && (
              <div className="grid sm:grid-cols-2 gap-3 pt-2">
                <Field label="الدولة المطلوبة">
                  <SearchableSelect
                    value={form.pCountry}
                    onChange={(v) => { set('pCountry', v); set('pCity', ''); }}
                    options={countryOptions}
                    placeholder="اختر الدولة"
                    searchPlaceholder="ابحث عن الدولة..."
                    includeNoPreference
                    noPreferenceLabel="لا يهم"
                  />
                </Field>
                {form.pCountry && form.pCountry !== 'لا يهم' && (
                  <Field label="المدينة المطلوبة">
                    <SearchableSelect
                      value={form.pCity}
                      onChange={(v) => set('pCity', v)}
                      options={pCities}
                      placeholder="اختر المدينة"
                      searchPlaceholder="ابحث عن المدينة..."
                      includeNoPreference
                      noPreferenceLabel="لا يهم"
                    />
                  </Field>
                )}
              </div>
            )}
          </div>

          {/* 2. الجنسية */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
            <label className="block text-xs font-cairo font-bold text-slate-800">
              2. {partnerTerms.nationalityLabel}
            </label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => set('pNationality', 'نفس جنسيتي')}
                className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                  form.pNationality === 'نفس جنسيتي'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                ✓ نفس جنسيتي
              </button>
              <button
                type="button"
                onClick={() => set('pNationality', 'لا يهم')}
                className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                  form.pNationality === 'لا يهم'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                أية جنسية / لا يهم
              </button>
              <button
                type="button"
                onClick={() => {
                  if (form.pNationality === 'نفس جنسيتي' || form.pNationality === 'لا يهم') {
                    set('pNationality', '');
                  }
                }}
                className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold transition-all border ${
                  form.pNationality !== 'نفس جنسيتي' && form.pNationality !== 'لا يهم'
                    ? 'bg-amber-500 text-white border-amber-500 shadow-2xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                تحديد جنسية معينة
              </button>
            </div>

            {form.pNationality !== 'نفس جنسيتي' && form.pNationality !== 'لا يهم' && (
              <div className="pt-2">
                <SearchableSelect
                  value={form.pNationality}
                  onChange={(v) => set('pNationality', v)}
                  options={partnerNationalityOptions}
                  placeholder="اختر الجنسية"
                  searchPlaceholder="اكتب اسم الجنسية..."
                  includeNoPreference
                  noPreferenceLabel="لا يهم"
                />
              </div>
            )}
          </div>

          {/* 3. العمر */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-cairo font-bold text-slate-800">
                3. {partnerTerms.ageLabel}
              </label>
              <span className="text-xs font-cairo font-extrabold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                من {form.pAgeMin || 20} إلى {form.pAgeMax || 45} سنة
              </span>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-1">
              <div>
                <span className="text-[11px] text-slate-500 font-tajawal mb-1 block">الحد الأدنى</span>
                <RangeSlider value={form.pAgeMin || 20} onChange={(v) => set('pAgeMin', Math.min(v, form.pAgeMax || 70))} min={18} max={70} unit=" سنة" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 font-tajawal mb-1 block">الحد الأقصى</span>
                <RangeSlider value={form.pAgeMax || 45} onChange={(v) => set('pAgeMax', Math.max(v, form.pAgeMin || 18))} min={18} max={70} unit=" سنة" />
              </div>
            </div>
          </div>

          {/* 4. الحالة الاجتماعية */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
            <label className="block text-xs font-cairo font-bold text-slate-800">
              4. {partnerTerms.maritalLabel}
            </label>
            <SelectInput
              value={form.pMaritalStatus}
              onChange={(v) => set('pMaritalStatus', v)}
              options={['لا يهم', ...getPartnerMaritalOptions(form.gender as any)]}
              placeholder="اختر الحالة الاجتماعية المطلوبة"
            />
          </div>

          {/* 5. قبول الأطفال */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3">
            <label className="block text-xs font-cairo font-bold text-slate-800">
              5. {partnerTerms.childrenLabel}
            </label>
            <RadioGroup
              options={[
                { value: 'نعم', label: 'نعم (أقبل)' },
                { value: 'لا', label: 'لا (أفضل بدون أطفال)' },
                { value: 'لا يهم', label: 'لا يهم' },
                { value: 'بشرط ألا يعيشوا معنا', label: 'بشرط ألا يعيشوا معنا' },
              ]}
              value={form.pAcceptChildren || 'لا يهم'}
              onChange={(v) => set('pAcceptChildren', v)}
              columns={2}
            />
          </div>

          {/* 6. ملاحظات وصفات إضافية */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-2">
            <label className="block text-xs font-cairo font-bold text-slate-800">
              6. ملاحظات وصفات إضافية مرغوبة
            </label>
            <TextArea
              value={form.pNotes}
              onChange={(v) => set('pNotes', v)}
              placeholder={partnerTerms.notesPlaceholder || "اكتب أي مواصفات أو تفاصيل إضافية ترغب بها في شريك حياتك..."}
              rows={3}
            />
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="bg-cream-50 min-h-screen pb-28 lg:pb-8">
      {/* Header */}
      <div className="bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-arabesque opacity-30" />
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link to="/profile" className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors no-tap-highlight">
                <ArrowRight className="w-5 h-5" />
              </Link>
              <div>
                <h1 className="font-cairo font-extrabold text-2xl text-white">تعديل الملف الشخصي</h1>
                <p className="text-cream-200/70 font-tajawal text-sm">حدّث جميع معلوماتك الشخصية</p>
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 text-cream-200/80 text-xs font-tajawal">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> بياناتك محمية
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-4">
        {/* ملاحظة الخصوصية */}
        <div className="bg-gold-300/10 border border-gold-500/20 rounded-2xl p-4 flex items-start gap-3">
          <Lock className="w-5 h-5 text-gold-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-cairo font-semibold text-navy-900 text-sm">خصوصية معلوماتك</p>
            <p className="text-xs text-navy-600 font-tajawal mt-0.5">لا يتم عرض معلوماتك الحساسة (مثل الحي، رقم الهاتف) للأعضاء الآخرين. تظهر فقط معلوماتك الأساسية.</p>
          </div>
        </div>

        {/* الأقسام */}
        {sections.map((section) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl shadow-soft border border-cream-200/60 p-5 sm:p-6"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-gold-300/15 flex items-center justify-center">
                <section.icon className="w-5 h-5 text-gold-600" />
              </div>
              <h2 className="font-cairo font-bold text-lg text-navy-900">{section.title}</h2>
            </div>
            <div className="space-y-4">{section.fields}</div>
          </motion.div>
        ))}

        {/* أزرار الحفظ */}
        <div className="flex gap-3 sticky bottom-20 lg:bottom-4 z-20">
          <Button onClick={handleSave} size="lg" fullWidth className="shadow-gold">
            {saving ? (
              <span className="flex items-center gap-2">
                <span className="w-5 h-5 border-2 border-navy-900/30 border-t-navy-900 rounded-full animate-spin" />
                جارِ الحفظ...
              </span>
            ) : saved ? (
              <span className="flex items-center gap-2"><Check className="w-5 h-5" /> تم الحفظ</span>
            ) : (
              <span className="flex items-center gap-2"><Save className="w-5 h-5" /> حفظ التغييرات</span>
            )}
          </Button>
          <Link to="/profile" className="flex items-center justify-center px-6 py-4 rounded-2xl bg-white border-2 border-cream-200 text-navy-600 font-cairo font-bold hover:bg-cream-100 transition-colors no-tap-highlight">
            إلغاء
          </Link>
        </div>
      </div>
    </div>
  );
}
