import { useState, useMemo } from 'react';
import { GitMerge, Check, X, Edit3, MapPin, Globe, FileText, Trash2, Bell, CheckSquare, Square } from 'lucide-react';
import { dataService } from '../../lib/data/DataService';
import Modal from '../../components/ui/Modal';

type Kind = 'country' | 'city' | 'nationality';

const KIND_META: Record<Kind, { label: string; icon: typeof Globe }> = {
  country: { label: 'دولة', icon: Globe },
  city: { label: 'مدينة', icon: MapPin },
  nationality: { label: 'جنسية', icon: FileText },
};

const SOURCE_LABEL: Record<string, { text: string; color: string }> = {
  register: { text: 'من تسجيل عضو', color: 'bg-blue-50 text-blue-600' },
  import: { text: 'من استيراد', color: 'bg-purple-50 text-purple-600' },
  admin: { text: 'من الإدارة', color: 'bg-amber-50 text-amber-600' },
};

function norm(s: string): string {
  return (s || '').toString().trim().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/\s+/g, ' ').toLowerCase();
}

interface GeoGroup {
  key: string;
  name: string;
  country: string;
  ids: string[];
  count: number;
  sources: Set<string>;
}

export default function GeoSuggestionsPanel({
  kind,
  onAction,
  showToast,
  extraGender,
}: {
  kind: Kind;
  onAction: () => void;
  showToast: (m: string, t?: 'success' | 'error' | 'info') => void;
  extraGender?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editedName, setEditedName] = useState('');
  const [mergeForKey, setMergeForKey] = useState<string | null>(null);
  const [mergeTargetCountry, setMergeTargetCountry] = useState('');
  const [mergeTargetName, setMergeTargetName] = useState('');
  const [genderChoice, setGenderChoice] = useState<Record<string, 'male' | 'female' | 'both'>>({});

  // التحديد الجماعي
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [isBulkMerging, setIsBulkMerging] = useState(false);
  const [bulkTargetCountry, setBulkTargetCountry] = useState('');
  const [bulkTargetName, setBulkTargetName] = useState('');

  const meta = KIND_META[kind];

  const groups = useMemo<GeoGroup[]>(() => {
    const all = dataService.db.getPendingGeoSuggestions() as Array<{ id: string; kind: string; name: string; country?: string; status: string; source?: string }>;
    const pending = all.filter((s) => s.kind === kind && s.status === 'pending');
    const map = new Map<string, GeoGroup>();
    for (const s of pending) {
      const country = s.country || '';
      const key = kind === 'country' ? norm(s.name) : `${norm(s.name)}|${norm(country)}`;
      if (!map.has(key)) {
        map.set(key, { key, name: s.name, country, ids: [], count: 0, sources: new Set() });
      }
      const g = map.get(key)!;
      g.ids.push(s.id);
      g.count++;
      if (s.source) g.sources.add(s.source);
    }
    return Array.from(map.values());
  }, [kind]);

  const countryNames = useMemo(() => {
    return dataService.db.getCountryNames().map((x: unknown) => (typeof x === 'string' ? x : (x as { name?: string })?.name || '')).filter(Boolean);
  }, [onAction]);

  const mergeOptions = useMemo(() => {
    const cleanList = (arr: unknown[]) => arr.map((x) => (typeof x === 'string' ? x : (x as { name?: string })?.name || '')).filter(Boolean);
    if (kind === 'country') return cleanList(dataService.db.getCountryNames());
    if (kind === 'nationality') {
      const nats = cleanList(dataService.db.getNationalities());
      const countries = cleanList(dataService.db.getCountryNames());
      return Array.from(new Set([...nats, ...countries])).sort((a, b) => a.localeCompare(b, 'ar'));
    }
    if (kind === 'city') return mergeTargetCountry ? cleanList(dataService.db.getCities(mergeTargetCountry)) : [];
    return [];
  }, [kind, mergeTargetCountry, onAction]);

  const bulkMergeOptions = useMemo(() => {
    const cleanList = (arr: unknown[]) => arr.map((x) => (typeof x === 'string' ? x : (x as { name?: string })?.name || '')).filter(Boolean);
    if (kind === 'country') return cleanList(dataService.db.getCountryNames());
    if (kind === 'nationality') {
      const nats = cleanList(dataService.db.getNationalities());
      const countries = cleanList(dataService.db.getCountryNames());
      return Array.from(new Set([...nats, ...countries])).sort((a, b) => a.localeCompare(b, 'ar'));
    }
    if (kind === 'city') return bulkTargetCountry ? cleanList(dataService.db.getCities(bulkTargetCountry)) : [];
    return [];
  }, [kind, bulkTargetCountry, onAction]);

  const approve = (g: GeoGroup) => {
    const finalName = (editingKey === g.key ? editedName.trim() : '') || g.name;
    if (kind === 'nationality' && extraGender) {
      const genderVal = genderChoice[g.key] || 'both';
      dataService.db.addNationality(finalName, g.country || '', genderVal);
    } else if (kind === 'country') {
      dataService.db.addCountry(finalName);
    } else if (kind === 'city') {
      dataService.db.addCityToCountry(g.country || '', finalName);
    } else if (kind === 'nationality') {
      dataService.db.addNationality(finalName, g.country || '');
    }

    if (g.ids.length > 0) {
      dataService.db.approvePendingGeo(g.ids[0], finalName);
      for (let i = 1; i < g.ids.length; i++) {
        dataService.db.approvePendingGeo(g.ids[i], finalName);
      }
    }
    showToast(`تم اعتماد ${meta.label} «${finalName}» وإضافتها للقائمة الرسمية${g.count > 1 ? ` (ودمج ${g.count} مقترحاً مكرراً)` : ''}`, 'success');
    setEditingKey(null); setEditedName('');
    onAction();
  };

  const doMerge = (g: GeoGroup) => {
    if (!mergeTargetName) { showToast('اختر القيمة الرسمية المستهدفة للدمج', 'error'); return; }
    const targetCountry = kind === 'city' ? mergeTargetCountry : (g.country || '');
    g.ids.forEach((id) => dataService.db.mergePendingGeo(id, mergeTargetName, targetCountry));
    showToast(`تم دمج «${g.name}» في «${mergeTargetName}» وتحديث بيانات الأعضاء`, 'success');
    setMergeForKey(null); setMergeTargetName(''); setMergeTargetCountry('');
    onAction();
  };

  const reject = (g: GeoGroup) => {
    g.ids.forEach((id) => dataService.db.rejectPendingGeo(id, 'رُفض الاقتراح؛ تبقى القيمة في حساب العضو فقط.'));
    showToast('تم رفض الاقتراح', 'info');
    onAction();
  };

  const del = (g: GeoGroup) => {
    g.ids.forEach((id) => dataService.db.deletePendingGeo(id));
    showToast('تم حذف الاقتراح نهائياً', 'info');
    onAction();
  };

  // عمليات الجماعية
  const toggleSelect = (key: string) => {
    setSelectedKeys((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const toggleSelectAll = () => {
    if (selectedKeys.length === groups.length) {
      setSelectedKeys([]);
    } else {
      setSelectedKeys(groups.map((g) => g.key));
    }
  };

  const bulkApprove = () => {
    const selectedGroups = groups.filter((g) => selectedKeys.includes(g.key));
    selectedGroups.forEach((g) => approve(g));
    setSelectedKeys([]);
  };

  const bulkReject = () => {
    const selectedGroups = groups.filter((g) => selectedKeys.includes(g.key));
    selectedGroups.forEach((g) => reject(g));
    setSelectedKeys([]);
  };

  const bulkMergeExecute = () => {
    if (!bulkTargetName) {
      showToast('اختر القيمة الرسمية المستهدفة للدمج الجماعي', 'error');
      return;
    }
    const selectedGroups = groups.filter((g) => selectedKeys.includes(g.key));
    selectedGroups.forEach((g) => {
      const targetCountry = kind === 'city' ? bulkTargetCountry : (g.country || '');
      g.ids.forEach((id) => dataService.db.mergePendingGeo(id, bulkTargetName, targetCountry));
    });
    setSelectedKeys([]);
    setIsBulkMerging(false);
    setBulkTargetName('');
    setBulkTargetCountry('');
    showToast(`تم دمج ${selectedGroups.length} عناصر بنجاح في «${bulkTargetName}» وتحديث كافة الأعضاء`, 'success');
    onAction();
  };

  const Icon = meta.icon;
  const totalDupes = groups.reduce((sum, g) => sum + g.count, 0);
  const kindPlural = meta.label === 'دولة' ? 'الدول' : meta.label === 'مدينة' ? 'المدن' : 'الجنسيات';

  const trigger = (
    <button
      type="button"
      onClick={() => groups.length > 0 && setOpen(true)}
      disabled={groups.length === 0}
      className={`relative flex items-center gap-2 px-4 py-2.5 rounded-xl font-cairo font-bold text-xs transition-all shadow-sm ${
        groups.length > 0
          ? 'bg-amber-500 hover:bg-amber-600 text-white animate-pulse'
          : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-default'
      }`}
    >
      <Bell className={`w-4 h-4 ${groups.length > 0 ? 'text-white' : 'text-slate-400'}`} />
      <span>مقترحات {kindPlural} الجديدة المعلقة</span>
      {groups.length > 0 && (
        <span className="bg-white text-amber-600 text-[11px] font-extrabold min-w-5 h-5 px-1.5 rounded-full flex items-center justify-center shadow-xs">
          {groups.length}
        </span>
      )}
    </button>
  );

  const body = (
    <div className="space-y-3">
      <p className="text-[11px] text-amber-700 font-tajawal leading-relaxed bg-amber-50 border border-amber-200 rounded-xl p-2.5">
        هذه القيم اكتُشفت من التسجيل أو الاستيراد وليست في القائمة الرسمية بعد. القيم المكرّرة مُوحّدة في عنصر واحد، وأي إجراء يُطبّق على كل مكرّراتها معاً.
        {totalDupes > groups.length && <span className="font-bold"> (تم توحيد {totalDupes} مقترحاً مكرراً في {groups.length}).</span>}
      </p>

      {/* شريط التحديد الجماعي */}
      {groups.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 border border-slate-200 p-3 rounded-xl">
          <button
            onClick={toggleSelectAll}
            className="flex items-center gap-2 text-xs font-cairo font-bold text-slate-700 hover:text-amber-600"
          >
            {selectedKeys.length === groups.length ? (
              <CheckSquare className="w-4 h-4 text-amber-600" />
            ) : (
              <Square className="w-4 h-4 text-slate-400" />
            )}
            تحديد الكل ({groups.length})
          </button>

          {selectedKeys.length > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-cairo font-extrabold text-amber-600 bg-amber-100 px-2.5 py-1 rounded-lg">
                تم تحديد ({selectedKeys.length})
              </span>

              <button
                onClick={bulkApprove}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-xs flex items-center gap-1 shadow-xs"
              >
                <Check className="w-3.5 h-3.5" /> اعتماد الجماعي
              </button>

              <button
                onClick={() => setIsBulkMerging(true)}
                className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-cairo font-bold text-xs flex items-center gap-1 shadow-xs"
              >
                <GitMerge className="w-3.5 h-3.5" /> دمج الجماعي
              </button>

              <button
                onClick={bulkReject}
                className="px-3 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 font-cairo font-bold text-xs flex items-center gap-1"
              >
                <X className="w-3.5 h-3.5" /> رفض الجماعي
              </button>
            </div>
          )}
        </div>
      )}

      {/* واجهة الدمج الجماعي */}
      {isBulkMerging && (
        <div className="bg-sky-50 rounded-xl p-3.5 space-y-3 border border-sky-200">
          <h4 className="font-cairo font-bold text-xs text-sky-900">
            دمج جماعي لـ ({selectedKeys.length}) مقترحات
          </h4>
          {kind === 'city' && (
            <div>
              <label className="block text-[11px] font-cairo font-bold text-slate-600 mb-1">الدولة المستهدفة للدمج</label>
              <select
                value={bulkTargetCountry}
                onChange={(e) => { setBulkTargetCountry(e.target.value); setBulkTargetName(''); }}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-xs bg-white"
              >
                <option value="">— اختر الدولة —</option>
                {countryNames.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="block text-[11px] font-cairo font-bold text-slate-600 mb-1">
              اختر القيمة الرسمية المستهدفة للدمج الجماعي
            </label>
            <select
              value={bulkTargetName}
              onChange={(e) => setBulkTargetName(e.target.value)}
              disabled={kind === 'city' && !bulkTargetCountry}
              className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-xs bg-white disabled:opacity-50"
            >
              <option value="">— اختر القيمة الرسمية —</option>
              {bulkMergeOptions.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setIsBulkMerging(false)} className="px-3 py-1.5 rounded-lg text-slate-500 hover:bg-slate-100 font-cairo font-bold text-xs">إلغاء</button>
            <button onClick={bulkMergeExecute} disabled={!bulkTargetName} className="px-3.5 py-1.5 rounded-lg bg-sky-600 text-white hover:bg-sky-700 disabled:opacity-50 font-cairo font-bold text-xs flex items-center gap-1.5 shadow-xs">
              <GitMerge className="w-3.5 h-3.5" /> تنفيذ الدمج الجماعي
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {groups.map((g) => {
          const isSelected = selectedKeys.includes(g.key);
          const isEditing = editingKey === g.key;
          const isMerging = mergeForKey === g.key;
          const srcList = Array.from(g.sources);
          return (
            <div key={g.key} className={`bg-white rounded-xl border p-3 space-y-2 transition-all ${isSelected ? 'border-amber-400 bg-amber-50/30 shadow-xs' : 'border-slate-200'}`}>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => toggleSelect(g.key)}
                  className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-amber-600"
                >
                  {isSelected ? (
                    <CheckSquare className="w-4 h-4 text-amber-600" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-300" />
                  )}
                </button>
                <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-4 h-4 text-amber-600" />
                </div>
                {isEditing ? (
                  <input
                    value={editedName}
                    onChange={(e) => setEditedName(e.target.value)}
                    autoFocus
                    className="px-2 py-1 rounded-lg border border-amber-400 focus:outline-none font-cairo font-bold text-sm w-40"
                  />
                ) : (
                  <span className="font-cairo font-extrabold text-slate-900 text-sm">{g.name}</span>
                )}
                {kind !== 'country' && g.country && (
                  <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-500 text-[11px] font-cairo font-bold">{g.country}</span>
                )}
                {g.count > 1 && (
                  <span className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-700 text-[10px] font-cairo font-bold">×{g.count} مكرر</span>
                )}
                {srcList.map((src) => {
                  const meta2 = SOURCE_LABEL[src] || SOURCE_LABEL.register;
                  return <span key={src} className={`px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold ${meta2.color}`}>{meta2.text}</span>;
                })}
              </div>

              {/* اعتماد الجنسية بجنس محدد */}
              {kind === 'nationality' && extraGender && !isMerging && (
                <div className="flex items-center gap-1.5 pr-7">
                  <span className="text-[11px] text-slate-500 font-tajawal">تُعتمد كـ:</span>
                  {(['male', 'female', 'both'] as const).map((gv) => (
                    <button
                      key={gv}
                      onClick={() => setGenderChoice((prev) => ({ ...prev, [g.key]: gv }))}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-cairo font-bold transition-all ${
                        (genderChoice[g.key] || 'both') === gv ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {gv === 'male' ? 'ذكر' : gv === 'female' ? 'أنثى' : 'عام'}
                    </button>
                  ))}
                </div>
              )}

              {/* واجهة التحكم بالإجراءات الأربعة */}
              {isMerging ? (
                <div className="bg-slate-50 rounded-xl p-3 space-y-2.5 border border-slate-200">
                  {kind === 'city' && (
                    <div>
                      <label className="block text-[11px] font-cairo font-bold text-slate-600 mb-1">الدولة المستهدفة للدمج</label>
                      <select
                        value={mergeTargetCountry}
                        onChange={(e) => { setMergeTargetCountry(e.target.value); setMergeTargetName(''); }}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-xs bg-white"
                      >
                        <option value="">— اختر الدولة —</option>
                        {countryNames.map((c) => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  )}
                  <div>
                    <label className="block text-[11px] font-cairo font-bold text-slate-600 mb-1">
                      {kind === 'city' ? 'اختر المدينة الرسمية المستهدفة' : kind === 'country' ? 'اختر الدولة الرسمية المستهدفة' : 'اختر الجنسية الرسمية المستهدفة'}
                    </label>
                    <select
                      value={mergeTargetName}
                      onChange={(e) => setMergeTargetName(e.target.value)}
                      disabled={kind === 'city' && !mergeTargetCountry}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-xs bg-white disabled:opacity-50"
                    >
                      <option value="">— اختر القيمة الرسمية الموجودة —</option>
                      {mergeOptions.map((o) => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => { setMergeForKey(null); setMergeTargetName(''); setMergeTargetCountry(''); }} className="px-3 py-1.5 rounded-lg text-slate-500 hover:bg-slate-100 font-cairo font-bold text-xs">إلغاء</button>
                    <button onClick={() => doMerge(g)} disabled={!mergeTargetName} className="px-3.5 py-1.5 rounded-lg bg-sky-600 text-white hover:bg-sky-700 disabled:opacity-50 font-cairo font-bold text-xs flex items-center gap-1.5 shadow-xs">
                      <GitMerge className="w-3.5 h-3.5" /> تأكيد الدمج مع الموجود
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2 flex-wrap pt-1 pr-7">
                  <button onClick={() => approve(g)} className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-[11px] flex items-center gap-1.5 shadow-xs transition-colors">
                    <Check className="w-3.5 h-3.5" /> إضافة للقائمة الرسمية
                  </button>

                  {isEditing ? (
                    <div className="flex items-center gap-1">
                      <button onClick={() => approve(g)} className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-cairo font-bold text-[11px] flex items-center gap-1 shadow-xs">
                        حفظ الاسم والاعتماد
                      </button>
                      <button onClick={() => { setEditingKey(null); setEditedName(''); }} className="px-2 py-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 font-cairo font-bold text-[11px]">
                        إلغاء
                      </button>
                    </div>
                  ) : (
                    <button onClick={() => { setEditingKey(g.key); setEditedName(g.name); }} className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-cairo font-bold text-[11px] flex items-center gap-1.5 shadow-xs transition-colors">
                      <Edit3 className="w-3.5 h-3.5" /> تعديل الاسم وإضافة
                    </button>
                  )}

                  <button onClick={() => { setMergeForKey(g.key); setMergeTargetCountry(kind === 'city' ? (g.country || '') : ''); setMergeTargetName(''); }} className="px-3 py-1.5 rounded-lg bg-sky-100 text-sky-800 hover:bg-sky-200 font-cairo font-bold text-[11px] flex items-center gap-1.5 transition-colors">
                    <GitMerge className="w-3.5 h-3.5 text-sky-600" /> دمج لموجودة حالياً
                  </button>

                  <button onClick={() => reject(g)} className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 font-cairo font-bold text-[11px] flex items-center gap-1.5 transition-colors" title="عدم إضافتها للقائمة الرسمية مع إبقائها ضمن خيار (أخرى) بحساب الأعضاء">
                    <X className="w-3.5 h-3.5 text-slate-500" /> إضافة/إبقاء في قائمة (أخرى)
                  </button>

                  <button onClick={() => del(g)} className="p-1.5 rounded-lg text-slate-300 hover:bg-rose-50 hover:text-rose-600 transition-colors mr-auto" title="حذف نهائي للمقترح">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <>
      {trigger}
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={`مقترحات ${kindPlural} الجديدة (${groups.length})`}
        size="lg"
      >
        {body}
      </Modal>
    </>
  );
}
