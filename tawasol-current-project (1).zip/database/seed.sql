-- =====================================================================
-- تواصل / توافق — DDL + Seed لإعادة إنشاء قاعدة Supabase بالكامل
-- نفّذ في: Supabase Dashboard → SQL Editor
-- الإصدار: 2026-08-08
-- =====================================================================

-- ---------- 1) الجداول ----------

CREATE TABLE IF NOT EXISTS admin_users (
  id text PRIMARY KEY,
  username text,
  role text,
  email text,
  password text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_sessions (
  id text PRIMARY KEY,
  admin_id text,
  token text,
  email text,
  role text,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id serial PRIMARY KEY,
  actor_id text,
  actor_email text,
  actor_role text,
  action text,
  entity_type text,
  entity_id text,
  details jsonb,
  ip text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS members (
  id text PRIMARY KEY,
  nickname text,
  username text,
  gender text,
  age integer,
  country text,
  city text,
  district text,
  nationality text,
  sect text,
  marital_status text,
  marital_label text,
  has_children boolean,
  children_count text,
  height integer,
  weight integer,
  skin_color text,
  health text,
  smoking text,
  ethnicity text,
  education text,
  work_type text,
  job_title text,
  housing text,
  bio text,
  about_partner text,
  verified boolean,
  premium boolean,
  online boolean,
  last_active text,
  match_score integer,
  has_seriousness_badge boolean,
  plan text,
  pinned boolean,
  status text,
  status_reason text,
  status_by text,
  notes text,
  flagged boolean,
  source_type text,
  import_batch_id text,
  import_office_name text,
  import_date text,
  import_notes text,
  real_name text,
  email text,
  phone text,
  whatsapp text,
  password text,
  birth_date text,
  is_profile_incomplete boolean,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS interest_requests (
  id bigint PRIMARY KEY,
  sender_id text,
  receiver_id text,
  journey_stage text,
  status text,
  mediation_stage text,
  message text,
  sender_paid boolean,
  receiver_paid boolean,
  sender_paid_at timestamptz,
  receiver_paid_at timestamptz,
  deadline_date timestamptz,
  decline_reason text,
  cancel_reason text,
  defer_date text,
  defer_by text,
  meeting_date text,
  meeting_notes text,
  contact_info text,
  contact_by text,
  guardian_phone text,
  guardian_name text,
  guardian_relation text,
  contact_time text,
  contact_note text,
  male_phone text,
  male_name text,
  male_relation text,
  male_contact_time text,
  male_contact_note text,
  male_pledged boolean,
  female_pledged boolean,
  sender_viewing_result text,
  receiver_viewing_result text,
  sender_viewing_note text,
  receiver_viewing_note text,
  evaluation_result text,
  evaluation_note text,
  frozen boolean,
  frozen_reason text,
  frozen_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS request_assignments (
  id text PRIMARY KEY,
  request_id bigint,
  mediator_id text,
  mediator_name text,
  sla_hours integer,
  due_at timestamptz,
  status text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notifications (
  id serial PRIMARY KEY,
  user_id text,
  request_id bigint,
  title text,
  text text,
  type text,
  read boolean,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS inquiry_messages (
  id serial PRIMARY KEY,
  request_id bigint,
  sender_id text,
  text text,
  charged_to text,
  status text,
  moderated_by text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS transactions (
  id serial PRIMARY KEY,
  user_id text,
  request_id bigint,
  amount numeric,
  type text,
  description text,
  status text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS coupons (
  code text PRIMARY KEY,
  discount numeric,
  is_active boolean,
  uses_count integer,
  expires_at text,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id serial PRIMARY KEY,
  user_id text,
  subject text,
  message text,
  category text,
  priority text,
  status text,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS verification_docs (
  id text PRIMARY KEY,
  member_id text,
  doc_type text,
  file_url text,
  status text,
  reviewer_name text,
  rejection_reason text,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS member_reports (
  id text PRIMARY KEY,
  reporter_id text,
  reporter_name text,
  reported_id text,
  reported_name text,
  reason text,
  status text,
  category text,
  severity text,
  admin_notes text,
  action_log jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS exemption_requests (
  id text PRIMARY KEY,
  request_id text,
  user_id text,
  user_nickname text,
  reason text,
  status text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS geo_countries (
  name text PRIMARY KEY,
  code text,
  flag text
);

CREATE TABLE IF NOT EXISTS geo_cities (
  id serial PRIMARY KEY,
  country text,
  name text
);

CREATE TABLE IF NOT EXISTS pending_cities (
  id text PRIMARY KEY,
  name text,
  country text,
  suggested_by text,
  suggested_by_id text,
  source text,
  status text,
  rejection_reason text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS geo_nationalities (
  name text PRIMARY KEY,
  country text,
  gender text
);

CREATE TABLE IF NOT EXISTS geo_suggestions (
  id text PRIMARY KEY,
  kind text,
  name text,
  country text,
  suggested_by text,
  suggested_by_id text,
  source text,
  status text,
  target_name text,
  target_country text,
  rejection_reason text,
  reviewer text,
  reviewed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settings (
  key text PRIMARY KEY,
  value text,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS faq_items (
  id text PRIMARY KEY,
  question text,
  answer text,
  category text,
  sort_order integer,
  is_published boolean,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS blog_posts (
  id text PRIMARY KEY,
  title text,
  excerpt text,
  content text,
  category text,
  author text,
  image text,
  read_time text,
  is_published boolean,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS registration_drafts (
  id text PRIMARY KEY,
  email text,
  phone text,
  payload jsonb DEFAULT '{}'::jsonb,
  step integer,
  updated_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- ---------- 2) فهارس ----------
CREATE INDEX IF NOT EXISTS idx_members_status ON members(status);
CREATE INDEX IF NOT EXISTS idx_members_gender ON members(gender);
CREATE INDEX IF NOT EXISTS idx_members_country_city ON members(country, city);
CREATE INDEX IF NOT EXISTS idx_members_plan ON members(plan);
CREATE INDEX IF NOT EXISTS idx_members_created ON members(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_members_email ON members(email);
CREATE INDEX IF NOT EXISTS idx_requests_sender ON interest_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_requests_receiver ON interest_requests(receiver_id);
CREATE INDEX IF NOT EXISTS idx_requests_stage ON interest_requests(journey_stage);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tx_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_token ON admin_sessions(token);
CREATE INDEX IF NOT EXISTS idx_assignments_request ON request_assignments(request_id);
CREATE INDEX IF NOT EXISTS idx_assignments_due ON request_assignments(due_at);

-- ---------- 3) بذور أساسية ----------
-- كلمة المرور 12345678 / password123 مشفّرة بـ sha256('tawasul_v1:' || plain)
-- hash(12345678) = 4156153a95f51aa0a95c51693196c169e6f5ff15ea073b3e7c0ea49d16dfcc49

INSERT INTO admin_users (id, username, role, email, password)
VALUES (
  'admin_main',
  'algohrah4u',
  'super_admin',
  'algohrah4u@gmail.com',
  '4156153a95f51aa0a95c51693196c169e6f5ff15ea073b3e7c0ea49d16dfcc49'
)
ON CONFLICT (id) DO UPDATE SET
  role = EXCLUDED.role,
  email = EXCLUDED.email,
  password = EXCLUDED.password;

INSERT INTO settings (key, value) VALUES
  ('site_name', 'تواصل للزواج'),
  ('whatsapp_number', '966500000000'),
  ('support_email', 'support@tawasul.sa'),
  ('deposit_amount', '299'),
  ('gold_plan_price', '199'),
  ('elite_plan_price', '399'),
  ('features_json', '{"verification":true,"payments":true,"mediation":true,"inquiries":true}'),
  ('terms', 'باستخدام المنصة فإنك توافق على الالتزام بالقيم الإسلامية واحترام خصوصية الأعضاء.'),
  ('privacy', 'نحمي بياناتك ولا نشاركها مع أطراف خارجية إلا بموافقتك أو وفق الأنظمة.'),
  ('payment_gateway', '{"provider":"manual","enabled":true}')
ON CONFLICT (key) DO NOTHING;

INSERT INTO coupons (code, discount, is_active, uses_count, expires_at, details) VALUES
  ('WELCOME20', 20, true, 0, '2026-12-31', '{"description":"خصم ترحيبي 20%"}'),
  ('GOLD50', 50, true, 0, '2026-12-31', '{"description":"خصم 50 ريال"}')
ON CONFLICT (code) DO NOTHING;

INSERT INTO geo_countries (name, code, flag) VALUES
  ('السعودية','SA','🇸🇦'),
  ('الإمارات','AE','🇦🇪'),
  ('الكويت','KW','🇰🇼'),
  ('قطر','QA','🇶🇦'),
  ('البحرين','BH','🇧🇭'),
  ('عُمان','OM','🇴🇲'),
  ('مصر','EG','🇪🇬'),
  ('الأردن','JO','🇯🇴'),
  ('المغرب','MA','🇲🇦'),
  ('اليمن','YE','🇾🇪')
ON CONFLICT (name) DO NOTHING;

INSERT INTO geo_cities (country, name)
SELECT v.country, v.name FROM (VALUES
  ('السعودية','الرياض'),('السعودية','جدة'),('السعودية','مكة المكرمة'),
  ('السعودية','المدينة المنورة'),('السعودية','الدمام'),('السعودية','الخبر'),
  ('الإمارات','دبي'),('الإمارات','أبوظبي'),('الكويت','مدينة الكويت'),
  ('قطر','الدوحة'),('مصر','القاهرة'),('الأردن','عمّان')
) AS v(country, name)
WHERE NOT EXISTS (
  SELECT 1 FROM geo_cities g WHERE g.country = v.country AND g.name = v.name
);

INSERT INTO geo_nationalities (name, country, gender) VALUES
  ('سعودي','السعودية','male'),
  ('سعودية','السعودية','female'),
  ('إماراتي','الإمارات','male'),
  ('إماراتية','الإمارات','female'),
  ('مصري','مصر','male'),
  ('مصرية','مصر','female')
ON CONFLICT (name) DO NOTHING;

INSERT INTO faq_items (id, question, answer, category, sort_order, is_published) VALUES
  ('faq1','هل المنصة تعتمد على الدردشة المباشرة؟','لا. تواصل منصة وساطة شرعية بإشراف الإدارة دون دردشة مباشرة.','عام',1,true),
  ('faq2','ما هي رسوم إثبات الجدية؟','بعد القبول قد يُطلب سداد رسوم جدية قبل تبادل التواصل.','مدفوعات',2,true),
  ('faq3','هل بياناتي ظاهرة للجميع؟','لا. البيانات الحساسة للإدارة فقط.','خصوصية',3,true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO blog_posts (id, title, excerpt, content, category, author, read_time, is_published, image) VALUES
  ('blog1','كيف تختار شريك حياتك بوعي؟','خطوات عملية للوضوح في المواصفات.','الوضوح في النية والمواصفات يوفر وقت الجميع.','نصائح','فريق تواصل','4 دقائق',true,''),
  ('blog2','لماذا الوساطة أفضل من التعارف العشوائي؟','الوساطة تحفظ الخصوصية وتضع إطاراً للجدية.','التعارف العشوائي قد يضيّع الوقت. الوساطة تضع مراحل واضحة.','توعية','فريق تواصل','5 دقائق',true,'')
ON CONFLICT (id) DO NOTHING;

-- أعضاء تجريبيون (password123 hash)
-- hash password123:
-- python: hashlib.sha256(b'tawasul_v1:password123').hexdigest()
-- نستخدم قيمة محسوبة أدناه

INSERT INTO members (
  id, nickname, username, gender, age, country, city, district, nationality, sect,
  marital_status, marital_label, has_children, children_count, height, weight, skin_color,
  health, smoking, ethnicity, education, work_type, job_title, housing, bio, about_partner,
  verified, premium, online, plan, pinned, status, source_type, real_name, email, phone,
  whatsapp, password, birth_date, is_profile_incomplete, details
) VALUES
(
  'm1','فارس نجد','fares_najd','male',32,'السعودية','الرياض','الملقا','سعودي','سني',
  'single','أعزب',false,'0',178,78,'قمحي','سليم','لا','عربي','بكالوريوس','موظف حكومي','محلل نظم','منزل ملك',
  'شاب ملتزم أبحث عن شريكة حياة صالحة.','أبحث عن فتاة ملتزمة بين 24-30.',
  true,true,false,'gold',true,'active','registered','فارس العتيبي','fares@example.com','0501112233',
  '0501112233','c3eba2f0c3e6d53537270efd2d72a05109f952dd2a979118fba62cc2e6812f91','1994-03-15',false,
  '{"pCountry":"السعودية","pCity":"الرياض","pNationality":"سعودية","pAgeMin":24,"pAgeMax":30,"pMaritalStatus":"single","pAcceptChildren":"no","pNotes":"أبحث عن فتاة ملتزمة"}'::jsonb
),
(
  'm2','نورة الياسمين','noura_y','female',27,'السعودية','الرياض','النرجس','سعودية','سني',
  'single','عزباء',false,'0',162,55,'أبيض','سليمة','لا','عربية','ماجستير','موظفة قطاع خاص','أخصائية موارد بشرية','مع الأهل',
  'فتاة محافظة أبحث عن شريك جاد.','يفضل ملتزم ومتعلم ويسكن الرياض.',
  true,false,false,'free',false,'active','registered','نورة الشمري','noura@example.com','0502223344',
  '0502223344','c3eba2f0c3e6d53537270efd2d72a05109f952dd2a979118fba62cc2e6812f91','1999-07-21',false,
  '{"pCountry":"السعودية","pCity":"الرياض","pNationality":"سعودي","pAgeMin":28,"pAgeMax":38,"pMaritalStatus":"single","pAcceptChildren":"no"}'::jsonb
)
ON CONFLICT (id) DO NOTHING;

-- استبدل c3eba2f0c3e6d53537270efd2d72a05109f952dd2a979118fba62cc2e6812f91 بعد حسابه (يُحدَّث تلقائياً في نهاية الملف)

-- ---------- 4) Storage (نفّذ من لوحة Storage أو API) ----------
-- أنشئ bucket باسم: verification-docs  (public = true)

-- ---------- 5) ملاحظات ----------
-- - بعد الاستيراد حدّث .env بمفاتيح المشروع الجديد
-- - لا تستبدل api/db-client.js الخاص بالبيئة إن وُجدت آلية إيقاظ
-- - راجع DATABASE_SCHEMA.md و database/schema.json

SELECT 'schema_ok' AS status;
