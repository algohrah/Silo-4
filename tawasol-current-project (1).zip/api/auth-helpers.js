import crypto from 'crypto';
import supabase from './db-client.js';

export function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Admin-Token, X-Member-Id');
}

export function hashPassword(password) {
  return crypto.createHash('sha256').update(`tawasul_v1:${String(password || '')}`).digest('hex');
}

export function newToken() {
  return crypto.randomBytes(32).toString('hex');
}

export function getBearer(req) {
  const h = req.headers.authorization || req.headers.Authorization || '';
  if (typeof h === 'string' && h.toLowerCase().startsWith('bearer ')) return h.slice(7).trim();
  const adminHeader = req.headers['x-admin-token'] || req.headers['X-Admin-Token'];
  if (adminHeader) return String(adminHeader).trim();
  return '';
}

export async function getAdminSession(req) {
  const token = getBearer(req);
  if (!token) return null;
  const { data, error } = await supabase
    .from('admin_sessions')
    .select('*')
    .eq('token', token)
    .maybeSingle();
  if (error || !data) return null;
  if (data.expires_at && new Date(data.expires_at).getTime() < Date.now()) {
    await supabase.from('admin_sessions').delete().eq('token', token);
    return null;
  }
  return data;
}

export async function requireAdmin(req, res, roles = null) {
  const session = await getAdminSession(req);
  if (!session) {
    res.status(401).json({ error: 'يتطلب صلاحية إدارة — سجّل الدخول للوحة التحكم' });
    return null;
  }
  if (Array.isArray(roles) && roles.length) {
    const role = String(session.role || 'admin');
    const allowed = roles.includes(role) || role === 'super_admin' || role === 'superadmin';
    if (!allowed) {
      res.status(403).json({ error: 'ليس لديك صلاحية لهذا الإجراء' });
      return null;
    }
  }
  return session;
}

/** Protect mutating methods; leave GET public unless forceAll */
export async function guardAdminMutations(req, res, { forceAll = false, roles = null } = {}) {
  if (req.method === 'OPTIONS') return { ok: true, session: null };
  if (!forceAll && req.method === 'GET') return { ok: true, session: await getAdminSession(req) };
  const session = await requireAdmin(req, res, roles);
  if (!session) return { ok: false, session: null };
  return { ok: true, session };
}

export async function writeAuditLog({ actorId, actorEmail, actorRole, action, entityType, entityId, details, ip }) {
  try {
    await supabase.from('audit_logs').insert({
      actor_id: actorId || 'system',
      actor_email: actorEmail || '',
      actor_role: actorRole || 'system',
      action: action || 'unknown',
      entity_type: entityType || '',
      entity_id: entityId ? String(entityId) : '',
      details: details || {},
      ip: ip || '',
    });
  } catch (e) {
    console.warn('audit log failed', e?.message || e);
  }
}

export function clientIp(req) {
  const xf = req.headers['x-forwarded-for'];
  if (typeof xf === 'string' && xf.length) return xf.split(',')[0].trim();
  return req.socket?.remoteAddress || '';
}

export function stripSensitiveMember(m, { includePassword = false } = {}) {
  if (!m) return m;
  const out = { ...m };
  if (!includePassword) {
    delete out.password;
  } else {
    out.password = out.password ? '••••••••' : '';
    out.hasPassword = !!(m.password && String(m.password).length > 0);
  }
  return out;
}

export function passwordsMatch(input, stored) {
  if (!stored) return false;
  const plain = String(input || '');
  const s = String(stored);
  if (s === plain) return true;
  if (s === hashPassword(plain)) return true;
  const legacy = crypto.createHash('sha256').update(plain).digest('hex');
  return s === legacy;
}
