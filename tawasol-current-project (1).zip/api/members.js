import supabase from './db-client.js';
import { getAdminSession, hashPassword, passwordsMatch, stripSensitiveMember, writeAuditLog, clientIp } from './auth-helpers.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

/** حقول إضافية تُحفظ داخل عمود details (jsonb) — مطابقة للتسجيل/تعديل الملف */
const DETAIL_KEYS = [
  'sectOther',
  'nationalityMode',
  'nationalityOther',
  'childrenLiveWith',
  'wifeCount',
  'seekingWife',
  'acceptPolygamy',
  'acceptDivorced',
  'acceptWithChildren',
  'religionLevel',
  'pCountry',
  'pCity',
  'pNationality',
  'pNationalityOther',
  'pAgeMin',
  'pAgeMax',
  'pMaritalStatus',
  'pAcceptChildren',
  'pSect',
  'pSectOther',
  'pReligionLevel',
  'pEducation',
  'pWorkType',
  'pSkinColor',
  'pHeight',
  'pHeightNoMatter',
  'pHousing',
  'pNotes',
];

function asObject(value) {
  if (!value) return {};
  if (typeof value === 'object' && !Array.isArray(value)) return { ...value };
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }
  return {};
}

function truthyChildren(value) {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value > 0;
  const s = String(value ?? '').trim().toLowerCase();
  return s === 'yes' || s === 'true' || s === '1' || s === 'نعم';
}

function extractDetails(source = {}, existingDetails = {}) {
  const details = asObject(existingDetails);
  const incoming = asObject(source.details);

  for (const [key, value] of Object.entries(incoming)) {
    if (value !== undefined) details[key] = value;
  }

  for (const key of DETAIL_KEYS) {
    if (source[key] !== undefined) details[key] = source[key];
  }

  // مزامنة ملاحظات الشريك مع aboutPartner
  if (source.pNotes !== undefined) details.pNotes = source.pNotes;
  else if (source.aboutPartner !== undefined && details.pNotes === undefined) details.pNotes = source.aboutPartner;
  else if (source.about_partner !== undefined && details.pNotes === undefined) details.pNotes = source.about_partner;

  return details;
}

function toDb(m = {}, existingDetails = {}) {
  const details = extractDetails(m, existingDetails);
  const aboutPartner =
    m.aboutPartner ||
    m.about_partner ||
    m.pNotes ||
    m.p_notes ||
    m.partner_notes ||
    details.pNotes ||
    '';

  if (aboutPartner && !details.pNotes) details.pNotes = aboutPartner;

  return {
    id: m.id ? String(m.id) : `m${Date.now()}`,
    nickname: m.nickname || m.realName || m.real_name || m.name || 'عضو جديد',
    username: m.username || '',
    gender: m.gender || '',
    age: Number(m.age) || 0,
    country: m.country || '',
    city: m.city || '',
    district: m.district || '',
    nationality: m.nationality || '',
    sect: m.sect || '',
    marital_status: m.maritalStatus || m.marital_status || 'single',
    marital_label: m.maritalLabel || m.marital_label || '',
    has_children: truthyChildren(m.hasChildren ?? m.has_children),
    children_count: m.childrenCount || m.children_count || '',
    height: Number(m.height) || 0,
    weight: Number(m.weight) || 0,
    skin_color: m.skinColor || m.skin_color || '',
    health: m.health || '',
    smoking: m.smoking || '',
    ethnicity: m.ethnicity || '',
    education: m.education || '',
    work_type: m.workType || m.work_type || '',
    job_title: m.jobTitle || m.job_title || '',
    housing: m.housing || '',
    bio: m.bio || '',
    about_partner: aboutPartner,
    verified: !!m.verified,
    premium: !!m.premium,
    online: !!m.online,
    last_active: m.lastActive || m.last_active || new Date().toISOString(),
    match_score: Number(m.matchScore ?? m.match_score) || 90,
    has_seriousness_badge: !!(m.hasSeriousnessBadge ?? m.has_seriousness_badge),
    plan: m.plan || 'free',
    pinned: !!m.pinned,
    status: m.status || 'active',
    status_reason: m.statusReason || m.status_reason || '',
    status_by: m.statusBy || m.status_by || '',
    notes: m.adminNote || m.notes || '',
    flagged: !!m.flagged,
    source_type: m.sourceType || m.source_type || 'registered',
    import_batch_id: m.importBatchId || m.import_batch_id || '',
    import_office_name: m.importOfficeName || m.import_office_name || '',
    import_date: m.importDate || m.import_date || '',
    import_notes: m.importNotes || m.import_notes || '',
    real_name: m.realName || m.real_name || m.nickname || '',
    email: m.email || '',
    phone: m.phone || '',
    whatsapp: m.whatsapp || '',
    password: m.password ? (String(m.password).startsWith('$') || String(m.password).length === 64 ? m.password : hashPassword(m.password)) : '',
    birth_date: m.birthDate || m.birth_date || '',
    is_profile_incomplete: !!(m.isProfileIncomplete ?? m.is_profile_incomplete),
    details,
    updated_at: new Date().toISOString(),
  };
}

function toDbPartial(fields = {}, existingDetails = {}) {
  const mapping = {
    nickname: 'nickname',
    realName: 'real_name',
    real_name: 'real_name',
    username: 'username',
    gender: 'gender',
    age: 'age',
    country: 'country',
    city: 'city',
    district: 'district',
    nationality: 'nationality',
    sect: 'sect',
    maritalStatus: 'marital_status',
    marital_status: 'marital_status',
    maritalLabel: 'marital_label',
    marital_label: 'marital_label',
    hasChildren: 'has_children',
    has_children: 'has_children',
    childrenCount: 'children_count',
    children_count: 'children_count',
    height: 'height',
    weight: 'weight',
    skinColor: 'skin_color',
    skin_color: 'skin_color',
    health: 'health',
    smoking: 'smoking',
    ethnicity: 'ethnicity',
    education: 'education',
    workType: 'work_type',
    work_type: 'work_type',
    jobTitle: 'job_title',
    job_title: 'job_title',
    housing: 'housing',
    bio: 'bio',
    aboutPartner: 'about_partner',
    about_partner: 'about_partner',
    pNotes: 'about_partner',
    p_notes: 'about_partner',
    partner_notes: 'about_partner',
    verified: 'verified',
    premium: 'premium',
    online: 'online',
    lastActive: 'last_active',
    last_active: 'last_active',
    matchScore: 'match_score',
    match_score: 'match_score',
    hasSeriousnessBadge: 'has_seriousness_badge',
    has_seriousness_badge: 'has_seriousness_badge',
    plan: 'plan',
    pinned: 'pinned',
    status: 'status',
    statusReason: 'status_reason',
    status_reason: 'status_reason',
    statusBy: 'status_by',
    status_by: 'status_by',
    adminNote: 'notes',
    notes: 'notes',
    flagged: 'flagged',
    sourceType: 'source_type',
    source_type: 'source_type',
    importBatchId: 'import_batch_id',
    import_batch_id: 'import_batch_id',
    importOfficeName: 'import_office_name',
    import_office_name: 'import_office_name',
    importDate: 'import_date',
    import_date: 'import_date',
    importNotes: 'import_notes',
    import_notes: 'import_notes',
    email: 'email',
    phone: 'phone',
    whatsapp: 'whatsapp',
    password: 'password',
    birthDate: 'birth_date',
    birth_date: 'birth_date',
    isProfileIncomplete: 'is_profile_incomplete',
    is_profile_incomplete: 'is_profile_incomplete',
  };

  const out = {};
  const detailTouched =
    fields.details !== undefined ||
    DETAIL_KEYS.some((key) => fields[key] !== undefined) ||
    fields.pNotes !== undefined ||
    fields.aboutPartner !== undefined ||
    fields.about_partner !== undefined;

  for (const [key, value] of Object.entries(fields || {})) {
    if (key === 'id' || value === undefined) continue;
    if (key === 'details' || DETAIL_KEYS.includes(key)) continue;

    const dbKey = mapping[key];
    if (!dbKey) continue; // تجاهل أي مفاتيح غير معروفة بدل محاولة كتابتها كأعمدة

    if (['age', 'height', 'weight', 'match_score'].includes(dbKey)) out[dbKey] = Number(value) || 0;
    else if (dbKey === 'has_children') out[dbKey] = truthyChildren(value);
    else if (
      [
        'verified',
        'premium',
        'online',
        'has_seriousness_badge',
        'pinned',
        'flagged',
        'is_profile_incomplete',
      ].includes(dbKey)
    ) {
      out[dbKey] = !!value;
    } else out[dbKey] = value;
  }

  if (out.password) {
    const pw = String(out.password);
    // لا تعيد تشفير القيم المشفّرة مسبقاً (sha256 hex = 64)
    if (pw.length !== 64) out.password = hashPassword(pw);
  }

  if (detailTouched) {
    const details = extractDetails(fields, existingDetails);
    out.details = details;
    if (fields.pNotes !== undefined && out.about_partner === undefined) {
      out.about_partner = fields.pNotes;
    } else if (details.pNotes && out.about_partner === undefined && fields.aboutPartner === undefined) {
      // keep existing about_partner unless explicitly updated
    }
  }

  out.updated_at = new Date().toISOString();
  return out;
}

function compact(obj) {
  return Object.fromEntries(Object.entries(obj).filter(([, value]) => value !== undefined));
}

function fromDb(r) {
  if (!r) return r;
  const details = asObject(r.details);

  return {
    ...details,
    ...r,
    id: String(r.id),
    nickname: r.nickname || r.real_name || r.id,
    username: r.username || '',
    gender: r.gender || '',
    age: Number(r.age) || 0,
    birthDate: r.birth_date || '',
    country: r.country || '',
    city: r.city || '',
    district: r.district || '',
    nationality: r.nationality || '',
    sect: r.sect || '',
    maritalStatus: r.marital_status || 'single',
    maritalLabel: r.marital_label || '',
    hasChildren: !!r.has_children,
    childrenCount: r.children_count || '',
    height: Number(r.height) || 0,
    weight: Number(r.weight) || 0,
    skinColor: r.skin_color || '',
    health: r.health || '',
    smoking: r.smoking || '',
    ethnicity: r.ethnicity || '',
    education: r.education || '',
    workType: r.work_type || '',
    jobTitle: r.job_title || '',
    housing: r.housing || '',
    bio: r.bio || '',
    aboutPartner: r.about_partner || details.pNotes || '',
    verified: !!r.verified,
    premium: !!r.premium,
    online: !!r.online,
    lastActive: r.last_active || '',
    matchScore: Number(r.match_score) || 90,
    hasSeriousnessBadge: !!r.has_seriousness_badge,
    plan: r.plan || 'free',
    pinned: !!r.pinned,
    status: r.status || 'active',
    statusReason: r.status_reason || '',
    statusBy: r.status_by || '',
    adminNote: r.notes || '',
    flagged: !!r.flagged,
    sourceType: r.source_type || 'registered',
    importBatchId: r.import_batch_id || '',
    importOfficeName: r.import_office_name || '',
    importDate: r.import_date || '',
    importNotes: r.import_notes || '',
    realName: r.real_name || '',
    email: r.email || '',
    phone: r.phone || '',
    whatsapp: r.whatsapp || '',
    password: r.password || '',
    isProfileIncomplete: !!r.is_profile_incomplete,
    details,
    // مواصفات الشريك والحقول الإضافية
    sectOther: details.sectOther || '',
    nationalityMode: details.nationalityMode || '',
    nationalityOther: details.nationalityOther || '',
    childrenLiveWith: details.childrenLiveWith || '',
    wifeCount: details.wifeCount || '',
    seekingWife: details.seekingWife || '',
    acceptPolygamy: details.acceptPolygamy || '',
    acceptDivorced: details.acceptDivorced || '',
    acceptWithChildren: details.acceptWithChildren || '',
    religionLevel: details.religionLevel || '',
    pCountry: details.pCountry || '',
    pCity: details.pCity || '',
    pNationality: details.pNationality || '',
    pNationalityOther: details.pNationalityOther || '',
    pAgeMin: details.pAgeMin !== undefined && details.pAgeMin !== null && details.pAgeMin !== '' ? Number(details.pAgeMin) : '',
    pAgeMax: details.pAgeMax !== undefined && details.pAgeMax !== null && details.pAgeMax !== '' ? Number(details.pAgeMax) : '',
    pMaritalStatus: details.pMaritalStatus || '',
    pAcceptChildren: details.pAcceptChildren || '',
    pSect: details.pSect || '',
    pSectOther: details.pSectOther || '',
    pReligionLevel: details.pReligionLevel || '',
    pEducation: details.pEducation || '',
    pWorkType: details.pWorkType || '',
    pSkinColor: details.pSkinColor || '',
    pHeight: details.pHeight !== undefined && details.pHeight !== null && details.pHeight !== '' ? details.pHeight : '',
    pHeightNoMatter: !!details.pHeightNoMatter,
    pHousing: details.pHousing || '',
    pNotes: details.pNotes || r.about_partner || '',
  };
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const {
        id, admin, limit, page, pageSize, gender, country, city,
        q, status, minAge, maxAge, paginated,
      } = req.query;
      const adminSession = admin ? await getAdminSession(req) : null;
      const isAdmin = !!adminSession;
      if (admin && !isAdmin) {
        return res.status(401).json({ error: 'يتطلب صلاحية إدارة' });
      }

      const mapOne = (row) => {
        const m = fromDb(row);
        if (!m) return m;
        if (isAdmin) {
          const hasPassword = !!(row?.password && String(row.password).length > 0);
          const safe = stripSensitiveMember(m, { includePassword: false });
          safe.hasPassword = hasPassword;
          return safe;
        }
        const safe = stripSensitiveMember(m, { includePassword: false });
        delete safe.email;
        delete safe.phone;
        delete safe.whatsapp;
        delete safe.realName;
        delete safe.real_name;
        delete safe.notes;
        delete safe.adminNote;
        return safe;
      };

      if (id) {
        const { data, error } = await supabase.from('members').select('*').eq('id', String(id)).maybeSingle();
        if (error) throw error;
        return res.status(200).json(mapOne(data));
      }

      const usePagination = paginated === '1' || paginated === 'true' || page || pageSize;
      const size = Math.min(Math.max(Number(pageSize || limit || 24), 1), 100);
      const pageNum = Math.max(Number(page || 1), 1);
      const from = (pageNum - 1) * size;
      const to = from + size - 1;

      let query = supabase.from('members').select('*', usePagination ? { count: 'exact' } : undefined);
      if (!isAdmin) {
        query = query.in('status', status ? [String(status)] : ['active']);
      } else if (status) {
        query = query.eq('status', String(status));
      }
      if (gender && gender !== 'all') query = query.eq('gender', String(gender));
      if (country) query = query.eq('country', String(country));
      if (city) query = query.eq('city', String(city));
      if (minAge) query = query.gte('age', Number(minAge));
      if (maxAge) query = query.lte('age', Number(maxAge));
      if (q) {
        const term = String(q).trim();
        query = query.or(`nickname.ilike.%${term}%,username.ilike.%${term}%,id.ilike.%${term}%,job_title.ilike.%${term}%`);
      }
      query = query.order('pinned', { ascending: false }).order('created_at', { ascending: false });

      if (usePagination) query = query.range(from, to);
      else if (limit) query = query.limit(Number(limit));

      const { data, error, count } = await query;
      if (error) throw error;
      const items = (data || []).map(mapOne);
      if (usePagination) {
        return res.status(200).json({
          items,
          page: pageNum,
          pageSize: size,
          total: count || items.length,
          totalPages: Math.max(1, Math.ceil((count || items.length) / size)),
        });
      }
      return res.status(200).json(items);
    }

    if (req.method === 'POST') {
      const body = req.body || {};

      if (Array.isArray(body.bulk)) {
        const rows = body.bulk.map((m) => compact(toDb(m)));
        if (rows.length === 0) return res.status(400).json({ error: 'bulk array is empty' });
        const { data, error } = await supabase.from('members').upsert(rows).select();
        if (error) {
          let saved = 0;
          const failed = [];
          for (const row of rows) {
            const { error: rowError } = await supabase.from('members').upsert(row);
            if (rowError) failed.push({ id: row.id, error: rowError.message });
            else saved++;
          }
          return res.status(207).json({ saved, failedCount: failed.length, failed });
        }
        return res.status(201).json({
          saved: (data || []).length,
          failedCount: 0,
          failed: [],
          members: (data || []).map(fromDb),
        });
      }

      const payload = compact(toDb(body));
      const { data, error } = await supabase.from('members').upsert(payload).select().single();
      if (error) throw error;
      return res.status(201).json(fromDb(data));
    }

    if (req.method === 'PUT') {
      const { id, ...fields } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });

      // دمج details الحالية حتى لا تُحذف الحقول غير المُرسلة
      const { data: current, error: currentError } = await supabase
        .from('members')
        .select('details, about_partner')
        .eq('id', String(id))
        .maybeSingle();
      if (currentError) throw currentError;

      const payload = compact(toDbPartial(fields, current?.details || {}));
      const { data, error } = await supabase
        .from('members')
        .update(payload)
        .eq('id', String(id))
        .select()
        .single();
      if (error) throw error;
      const adminSession = await getAdminSession(req);
      if (adminSession) {
        await writeAuditLog({
          actorId: adminSession.admin_id,
          actorEmail: adminSession.email,
          actorRole: adminSession.role,
          action: 'admin_update_member',
          entityType: 'member',
          entityId: id,
          details: { fields: Object.keys(fields || {}) },
          ip: clientIp(req),
        });
      }
      const result = fromDb(data);
      return res.status(200).json(stripSensitiveMember(result, { includePassword: false }));
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('members').delete().eq('id', String(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Members API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
