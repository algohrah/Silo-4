import supabase from './db-client.js';
import { setCors, requireAdmin } from './auth-helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const admin = await requireAdmin(req, res);
    if (!admin) return;

    if (req.method === 'GET') {
      const limit = Math.min(Number(req.query.limit || 100), 300);
      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit);
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const b = req.body || {};
      const row = {
        actor_id: admin.admin_id,
        actor_email: admin.email,
        actor_role: admin.role,
        action: b.action || 'custom',
        entity_type: b.entityType || b.entity_type || '',
        entity_id: b.entityId || b.entity_id || '',
        details: b.details || {},
      };
      const { data, error } = await supabase.from('audit_logs').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('audit-logs error', err);
    return res.status(500).json({ error: err.message });
  }
}
