import supabase from './db-client.js';
import { setCors, requireAdmin, writeAuditLog, clientIp } from './auth-helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { requestId, mediatorId } = req.query;
      let q = supabase.from('request_assignments').select('*').order('updated_at', { ascending: false });
      if (requestId) q = q.eq('request_id', Number(requestId));
      if (mediatorId) q = q.eq('mediator_id', String(mediatorId));
      // public read for involved parties is ok for status; list all requires admin
      if (!requestId && !mediatorId) {
        const admin = await requireAdmin(req, res);
        if (!admin) return;
      }
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    const admin = await requireAdmin(req, res);
    if (!admin) return;

    if (req.method === 'POST' || req.method === 'PUT') {
      const b = req.body || {};
      const requestId = Number(b.requestId || b.request_id);
      if (!requestId) return res.status(400).json({ error: 'requestId required' });
      const row = {
        id: b.id || `asg_${requestId}`,
        request_id: requestId,
        mediator_id: b.mediatorId || b.mediator_id || admin.admin_id,
        mediator_name: b.mediatorName || b.mediator_name || admin.email || 'وسيطة',
        sla_hours: Number(b.slaHours || b.sla_hours || 48),
        due_at: b.dueAt || b.due_at || new Date(Date.now() + Number(b.slaHours || 48) * 3600 * 1000).toISOString(),
        status: b.status || 'active',
        notes: b.notes || '',
        updated_at: new Date().toISOString(),
      };
      const { data, error } = await supabase.from('request_assignments').upsert(row).select().single();
      if (error) throw error;
      await writeAuditLog({
        actorId: admin.admin_id,
        actorEmail: admin.email,
        actorRole: admin.role,
        action: 'assign_mediator',
        entityType: 'interest_request',
        entityId: String(requestId),
        details: { mediator: row.mediator_name, sla_hours: row.sla_hours },
        ip: clientIp(req),
      });
      // notify both parties lightly
      try {
        const { data: reqRow } = await supabase.from('interest_requests').select('sender_id,receiver_id').eq('id', requestId).maybeSingle();
        if (reqRow) {
          const text = `تم تعيين وسيطة (${row.mediator_name}) لمتابعة رحلتكم. زمن الاستجابة المستهدف: ${row.sla_hours} ساعة.`;
          await supabase.from('notifications').insert([
            { user_id: reqRow.sender_id, request_id: requestId, title: 'تعيين وسيطة', text, type: 'admin', read: false },
            { user_id: reqRow.receiver_id, request_id: requestId, title: 'تعيين وسيطة', text, type: 'admin', read: false },
          ]);
        }
      } catch {}
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const id = req.body?.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('request_assignments').delete().eq('id', String(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('assignments error', err);
    return res.status(500).json({ error: err.message });
  }
}
