import supabase from './db-client.js';
import { setCors, requireAdmin } from './auth-helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
    const admin = await requireAdmin(req, res);
    if (!admin) return;

    const [members, requests, tickets, reports, pendingCities, verifications, exemptions, suggestions, pendingTx, assignments] = await Promise.all([
      supabase.from('members').select('id,status,created_at').eq('status', 'pending'),
      supabase.from('interest_requests').select('id,status,journey_stage,updated_at'),
      supabase.from('support_tickets').select('id,status,subject,created_at').in('status', ['open', 'pending']),
      supabase.from('member_reports').select('id,status,created_at').eq('status', 'pending'),
      supabase.from('pending_cities').select('id,status').eq('status', 'pending'),
      supabase.from('verification_docs').select('id,status,created_at').eq('status', 'pending'),
      supabase.from('exemption_requests').select('id,status').eq('status', 'pending'),
      supabase.from('geo_suggestions').select('id,status').eq('status', 'pending'),
      supabase.from('transactions').select('id,description,amount,created_at,status').eq('status', 'pending').order('created_at', { ascending: false }).limit(20),
      supabase.from('request_assignments').select('*').eq('status', 'active'),
    ]);

    const reqs = requests.data || [];
    const pendingRequests = reqs.filter((r) => ['sent', 'pending'].includes(r.journey_stage || r.status));
    const activeJourneys = reqs.filter((r) => !['declined', 'cancelled', 'completed'].includes(r.journey_stage || r.status));
    const needsAction = reqs.filter((r) => ['accepted', 'seriousness', 'coordination', 'sharia_viewing'].includes(r.journey_stage || r.status));

    const overdueAssignments = (assignments.data || []).filter((a) => a.due_at && new Date(a.due_at).getTime() < Date.now());
    const items = [
      ...(pendingTx.data || []).slice(0, 8).map((tx) => ({
        id: `ptx-${tx.id}`,
        type: 'transaction',
        title: `معاملة معلّقة #${tx.id}`,
        subtitle: `${tx.description || 'دفعة'} · ${Number(tx.amount || 0)} ر.س`,
        to: '/admin/transactions',
        priority: 1,
        createdAt: tx.created_at,
      })),
      ...overdueAssignments.slice(0, 5).map((a) => ({
        id: `asg-${a.id}`,
        type: 'assignment',
        title: `SLA متأخر · ${a.mediator_name || 'وسيطة'}`,
        subtitle: `طلب #${a.request_id}`,
        to: '/admin/requests',
        priority: 1,
        createdAt: a.due_at,
      })),
      ...pendingRequests.slice(0, 8).map((r) => ({
        id: `req-${r.id}`,
        type: 'request',
        title: `طلب اهتمام #${r.id}`,
        subtitle: `المرحلة: ${r.journey_stage || r.status}`,
        to: '/admin/requests',
        priority: 1,
        createdAt: r.updated_at,
      })),
      ...(tickets.data || []).slice(0, 6).map((t) => ({
        id: `ticket-${t.id}`,
        type: 'ticket',
        title: t.subject || 'تذكرة دعم',
        subtitle: 'تذكرة مفتوحة',
        to: '/admin/messages',
        priority: 2,
        createdAt: t.created_at,
      })),
      ...(reports.data || []).slice(0, 6).map((r) => ({
        id: `rep-${r.id}`,
        type: 'report',
        title: 'بلاغ بانتظار المراجعة',
        subtitle: r.id,
        to: '/admin/reports',
        priority: 1,
        createdAt: r.created_at,
      })),
      ...(verifications.data || []).slice(0, 6).map((v) => ({
        id: `ver-${v.id}`,
        type: 'verification',
        title: 'طلب توثيق معلّق',
        subtitle: v.id,
        to: '/admin/verifications',
        priority: 2,
        createdAt: v.created_at,
      })),
      ...(members.data || []).slice(0, 5).map((m) => ({
        id: `mem-${m.id}`,
        type: 'member',
        title: 'عضو بانتظار المراجعة',
        subtitle: m.id,
        to: '/admin/members',
        priority: 3,
        createdAt: m.created_at,
      })),
    ].sort((a, b) => a.priority - b.priority || String(b.createdAt || '').localeCompare(String(a.createdAt || '')));

    return res.status(200).json({
      counts: {
        pendingMembers: (members.data || []).length,
        pendingRequests: pendingRequests.length,
        activeJourneys: activeJourneys.length,
        needsAction: needsAction.length,
        openTickets: (tickets.data || []).length,
        pendingReports: (reports.data || []).length,
        pendingCities: (pendingCities.data || []).length,
        pendingVerifications: (verifications.data || []).length,
        pendingExemptions: (exemptions.data || []).length,
        pendingGeoSuggestions: (suggestions.data || []).length,
        pendingTransactions: (pendingTx.data || []).length,
        overdueAssignments: overdueAssignments.length,
      },
      items: items.slice(0, 25),
    });
  } catch (err) {
    console.error('inbox error', err);
    return res.status(500).json({ error: err.message });
  }
}
