import supabase from './db-client.js';
import { setCors, requireAdmin } from './auth-helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const type = String(req.query.type || req.body?.type || 'faq');

    if (req.method === 'GET') {
      if (type === 'blog') {
        const admin = req.query.admin === 'true' ? await requireAdmin(req, res).catch(() => null) : null;
        // if admin=true and failed auth, still allow published only
        let q = supabase.from('blog_posts').select('*').order('created_at', { ascending: false });
        if (!(admin && req.query.admin === 'true')) q = q.eq('is_published', true);
        // simpler: always return published for public; admin can pass all=1 with token
        if (req.query.all === '1') {
          const a = await requireAdmin(req, res);
          if (!a) return;
          const { data, error } = await supabase.from('blog_posts').select('*').order('created_at', { ascending: false });
          if (error) throw error;
          return res.status(200).json(data || []);
        }
        const { data, error } = await supabase.from('blog_posts').select('*').eq('is_published', true).order('created_at', { ascending: false });
        if (error) throw error;
        return res.status(200).json(data || []);
      }

      // faq
      if (req.query.all === '1') {
        const a = await requireAdmin(req, res);
        if (!a) return;
        const { data, error } = await supabase.from('faq_items').select('*').order('sort_order', { ascending: true });
        if (error) throw error;
        return res.status(200).json(data || []);
      }
      const { data, error } = await supabase.from('faq_items').select('*').eq('is_published', true).order('sort_order', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    const admin = await requireAdmin(req, res);
    if (!admin) return;

    if (req.method === 'POST' || req.method === 'PUT') {
      const b = req.body || {};
      if ((b.type || type) === 'blog') {
        const row = {
          id: b.id || `blog_${Date.now()}`,
          title: b.title || '',
          excerpt: b.excerpt || '',
          content: b.content || '',
          category: b.category || 'نصائح',
          author: b.author || 'فريق تواصل',
          image: b.image || '',
          read_time: b.readTime || b.read_time || '5 دقائق',
          is_published: b.is_published ?? b.isPublished ?? true,
        };
        const { data, error } = await supabase.from('blog_posts').upsert(row).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const row = {
        id: b.id || `faq_${Date.now()}`,
        question: b.question || '',
        answer: b.answer || '',
        category: b.category || 'عام',
        sort_order: Number(b.sort_order ?? b.sortOrder ?? 0),
        is_published: b.is_published ?? b.isPublished ?? true,
      };
      const { data, error } = await supabase.from('faq_items').upsert(row).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const b = req.body || {};
      if ((b.type || type) === 'blog') {
        const { error } = await supabase.from('blog_posts').delete().eq('id', b.id);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      const { error } = await supabase.from('faq_items').delete().eq('id', b.id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('content error', err);
    return res.status(500).json({ error: err.message });
  }
}
