import supabase from './db-client.js';
import { setCors as setCorsAuth, requireAdmin } from './auth-helpers.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Admin-Token, X-Member-Id');
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
    // الإحصائيات للإدارة
    const admin = await requireAdmin(req, res);
    if (!admin) return;

    const [
      membersAll,
      membersActive,
      membersPending,
      membersMale,
      membersFemale,
      membersVerified,
      membersPremium,
      membersBadge,
      requestsAll,
      txAll,
      txCompleted,
      pendingTx,
    ] = await Promise.all([
      supabase.from('members').select('id', { count: 'exact', head: true }),
      supabase.from('members').select('id', { count: 'exact', head: true }).eq('status', 'active'),
      supabase.from('members').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('members').select('id', { count: 'exact', head: true }).eq('gender', 'male'),
      supabase.from('members').select('id', { count: 'exact', head: true }).eq('gender', 'female'),
      supabase.from('members').select('id', { count: 'exact', head: true }).eq('verified', true),
      supabase.from('members').select('id', { count: 'exact', head: true }).in('plan', ['gold', 'elite']),
      supabase.from('members').select('id', { count: 'exact', head: true }).eq('has_seriousness_badge', true),
      supabase.from('interest_requests').select('id,status,journey_stage,sender_paid,receiver_paid'),
      supabase.from('transactions').select('id,amount,status,type,description,created_at').order('created_at', { ascending: false }).limit(200),
      supabase.from('transactions').select('amount,status'),
      supabase.from('transactions').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    ]);

    const requests = requestsAll.data || [];
    const stageOf = (r) => {
      const raw = r.journey_stage || r.status || 'sent';
      return raw === 'pending' ? 'sent' : raw;
    };
    const stageBreakdown = requests.reduce((acc, r) => {
      const s = stageOf(r);
      acc[s] = (acc[s] || 0) + 1;
      return acc;
    }, {});
    const revenue = (txCompleted.data || [])
      .filter((t) => t.status === 'completed')
      .reduce((sum, t) => sum + Number(t.amount || 0), 0);

    return res.status(200).json({
      totalMembers: membersAll.count || 0,
      activeMembers: membersActive.count || 0,
      pendingMembers: membersPending.count || 0,
      suspendedMembers: 0,
      bannedMembers: 0,
      totalRequests: requests.length,
      pendingRequests: requests.filter((r) => ['pending', 'sent'].includes(stageOf(r))).length,
      activeRequests: requests.filter((r) => !['declined', 'cancelled', 'completed'].includes(stageOf(r))).length,
      activeJourneys: requests.filter((r) => !['declined', 'cancelled', 'completed'].includes(stageOf(r))).length,
      completedRequests: requests.filter((r) => stageOf(r) === 'completed').length,
      declinedRequests: requests.filter((r) => stageOf(r) === 'declined').length,
      cancelledRequests: requests.filter((r) => stageOf(r) === 'cancelled').length,
      seriousRequests: requests.filter((r) => ['seriousness', 'coordination', 'sharia_viewing', 'engagement'].includes(stageOf(r))).length,
      maleCount: membersMale.count || 0,
      femaleCount: membersFemale.count || 0,
      males: membersMale.count || 0,
      females: membersFemale.count || 0,
      completed: requests.filter((r) => stageOf(r) === 'completed').length,
      verified: membersVerified.count || 0,
      premium: membersPremium.count || 0,
      revenue,
      totalRevenue: revenue,
      totalTransactions: (txCompleted.data || []).length,
      pendingTransactions: pendingTx.count || 0,
      depositsPaid: requests.filter((r) => r.sender_paid || r.receiver_paid).length,
      seriousnessBadges: membersBadge.count || 0,
      stageBreakdown,
      recentEvents: (txAll.data || []).slice(0, 8).map((tx) => ({
        id: `tx-${tx.id}`,
        note: tx.description || `معاملة ${tx.type || 'مالية'} بقيمة ${Number(tx.amount || 0).toLocaleString('ar-SA')} ر.س`,
        type: tx.type || 'transaction',
        created_at: tx.created_at,
        status: tx.status,
      })),
    });
  } catch (err) {
    console.error('Stats API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
