import supabase from './db-client.js';
import { requireAdmin, writeAuditLog, clientIp } from './auth-helpers.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Admin-Token, X-Member-Id');
}

function isSchemaCacheError(error) {
  return !!error && (
    error.code === 'PGRST204' ||
    String(error.message || '').toLowerCase().includes('schema cache') ||
    String(error.details || '').toLowerCase().includes('schema cache')
  );
}

async function applyCompletedSideEffects(tx, admin) {
  const meta = tx.metadata && typeof tx.metadata === 'object' ? tx.metadata : {};
  const userId = tx.user_id;
  const type = tx.type || meta.type || '';

  if (userId && (type === 'subscription' || meta.planId)) {
    const plan = meta.planId === 'elite' || meta.plan === 'elite' ? 'elite' : 'gold';
    await supabase.from('members').update({
      plan,
      premium: true,
      updated_at: new Date().toISOString(),
    }).eq('id', String(userId));
  }

  if (userId && type === 'deposit' && meta.requestId) {
    const rid = Number(meta.requestId);
    const side = meta.side || meta.actorSide;
    const { data: req } = await supabase.from('interest_requests').select('*').eq('id', rid).maybeSingle();
    if (req) {
      const patch = { updated_at: new Date().toISOString() };
      if (side === 'receiver' || userId === req.receiver_id) {
        patch.receiver_paid = true;
        patch.receiver_paid_at = new Date().toISOString();
      } else {
        patch.sender_paid = true;
        patch.sender_paid_at = new Date().toISOString();
      }
      const senderPaid = patch.sender_paid ?? req.sender_paid;
      const receiverPaid = patch.receiver_paid ?? req.receiver_paid;
      if (senderPaid && receiverPaid) {
        patch.journey_stage = 'coordination';
        patch.status = 'coordination';
        patch.mediation_stage = 'coordination';
      } else {
        patch.journey_stage = 'seriousness';
        patch.status = 'seriousness';
        patch.mediation_stage = 'seriousness';
      }
      await supabase.from('interest_requests').update(patch).eq('id', rid);
      await supabase.from('members').update({ has_seriousness_badge: true }).eq('id', String(userId));
    }
  }

  await writeAuditLog({
    actorId: admin?.admin_id,
    actorEmail: admin?.email,
    actorRole: admin?.role,
    action: 'transaction_approved',
    entityType: 'transaction',
    entityId: String(tx.id),
    details: { userId, type, amount: tx.amount },
    ip: '',
  });
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (['PUT', 'DELETE'].includes(req.method)) {
    const admin = await requireAdmin(req, res);
    if (!admin) return;
  }

  try {
    if (req.method === 'GET') {
      const { id, userId, requestId, status, admin } = req.query;
      // قائمة كاملة للإدارة فقط
      if (admin === 'true' || (!userId && !id && !requestId)) {
        const a = await requireAdmin(req, res);
        if (!a) return;
      }
      let query = supabase.from('transactions').select('*');
      if (id) query = query.eq('id', Number(id)).maybeSingle();
      else {
        if (userId) query = query.eq('user_id', String(userId));
        if (requestId) query = query.eq('request_id', Number(requestId));
        if (status) query = query.eq('status', String(status));
        query = query.order('created_at', { ascending: false });
      }
      const { data, error } = await query;
      if (isSchemaCacheError(error) && requestId) return res.status(200).json([]);
      if (error) throw error;
      return res.status(200).json(data || (id ? null : []));
    }

    if (req.method === 'POST') {
      const body = req.body || {};

      // موافقة/رفض إداري
      if (body.action === 'approve' || body.action === 'reject') {
        const admin = await requireAdmin(req, res);
        if (!admin) return;
        const id = Number(body.id);
        if (!id) return res.status(400).json({ error: 'id is required' });
        const { data: current, error: findErr } = await supabase.from('transactions').select('*').eq('id', id).single();
        if (findErr) throw findErr;
        if (current.status !== 'pending') return res.status(400).json({ error: 'المعاملة ليست معلّقة' });

        if (body.action === 'reject') {
          const meta = { ...(current.metadata || {}), rejectReason: body.reason || 'مرفوض من الإدارة', reviewedBy: admin.email };
          const { data, error } = await supabase.from('transactions').update({ status: 'failed', metadata: meta }).eq('id', id).select().single();
          if (error) throw error;
          await writeAuditLog({ actorId: admin.admin_id, actorEmail: admin.email, actorRole: admin.role, action: 'transaction_rejected', entityType: 'transaction', entityId: String(id), details: { reason: body.reason || '' }, ip: clientIp(req) });
          return res.status(200).json(data);
        }

        const meta = { ...(current.metadata || {}), reviewedBy: admin.email, approvedAt: new Date().toISOString() };
        const { data, error } = await supabase.from('transactions').update({ status: 'completed', metadata: meta }).eq('id', id).select().single();
        if (error) throw error;
        await applyCompletedSideEffects(data, admin);
        return res.status(200).json(data);
      }

      const row = {
        user_id: body.user_id || body.userId || 'system',
        request_id: body.request_id || body.requestId || null,
        amount: Number(body.amount || body.price || 0),
        type: body.type || 'payment',
        description: body.description || '',
        status: body.status || 'completed',
        metadata: body.metadata || body.details || {},
      };
      let { data, error } = await supabase.from('transactions').insert(row).select().single();
      if (isSchemaCacheError(error)) {
        const { request_id, metadata, ...minimalRow } = row;
        const fallback = await supabase.from('transactions').insert(minimalRow).select().single();
        data = fallback.data;
        error = fallback.error;
      }
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...fields } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase.from('transactions').update(fields).eq('id', Number(id)).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('transactions').delete().eq('id', Number(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Transactions API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
