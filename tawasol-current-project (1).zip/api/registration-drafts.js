import supabase from './db-client.js';
import { setCors } from './auth-helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const id = req.query.id;
      const email = req.query.email;
      if (id) {
        const { data, error } = await supabase.from('registration_drafts').select('*').eq('id', String(id)).maybeSingle();
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (email) {
        const { data, error } = await supabase.from('registration_drafts').select('*').ilike('email', String(email)).order('updated_at', { ascending: false }).limit(1).maybeSingle();
        if (error) throw error;
        return res.status(200).json(data);
      }
      return res.status(400).json({ error: 'id or email required' });
    }

    if (req.method === 'POST' || req.method === 'PUT') {
      const b = req.body || {};
      const id = b.id || `draft_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const row = {
        id,
        email: b.email || '',
        phone: b.phone || '',
        payload: b.payload || b.form || {},
        step: Number(b.step || 0),
        updated_at: new Date().toISOString(),
      };
      const { data, error } = await supabase.from('registration_drafts').upsert(row).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('registration_drafts').delete().eq('id', String(id));
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('registration-drafts error', err);
    return res.status(500).json({ error: err.message });
  }
}
