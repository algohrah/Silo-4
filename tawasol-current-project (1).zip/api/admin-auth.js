import supabase from './db-client.js';
import { setCors, hashPassword, newToken, getAdminSession, writeAuditLog, clientIp, passwordsMatch } from './auth-helpers.js';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const session = await getAdminSession(req);
      if (!session) return res.status(401).json({ authenticated: false });
      return res.status(200).json({
        authenticated: true,
        admin: {
          id: session.admin_id,
          email: session.email,
          role: session.role || 'admin',
        },
      });
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const action = body.action || 'login';

      if (action === 'logout') {
        const session = await getAdminSession(req);
        if (session?.token) await supabase.from('admin_sessions').delete().eq('token', session.token);
        return res.status(200).json({ ok: true });
      }

      if (action === 'login') {
        const email = String(body.email || '').trim().toLowerCase();
        const password = String(body.password || '');
        if (!email || !password) return res.status(400).json({ error: 'البريد وكلمة المرور مطلوبان' });

        // Ensure default superadmin exists
        const { data: existing } = await supabase.from('admin_users').select('*').eq('email', email).maybeSingle();
        let admin = existing;
        if (!admin && email === 'algohrah4u@gmail.com' && password === '12345678') {
          const row = {
            id: 'admin_main',
            username: 'algohrah4u',
            role: 'super_admin',
            email,
            password: hashPassword(password),
          };
          const { data: created } = await supabase.from('admin_users').upsert(row).select().single();
          admin = created || row;
        }

        if (!admin) {
          // try username match
          const { data: byUser } = await supabase.from('admin_users').select('*').eq('username', email).maybeSingle();
          admin = byUser;
        }

        if (!admin || !passwordsMatch(password, admin.password)) {
          await writeAuditLog({
            actorEmail: email,
            actorRole: 'anonymous',
            action: 'admin_login_failed',
            entityType: 'admin',
            details: { email },
            ip: clientIp(req),
          });
          return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
        }

        // upgrade plain password to hash
        if (admin.password && admin.password === password) {
          await supabase.from('admin_users').update({ password: hashPassword(password) }).eq('id', admin.id);
        }

        const token = newToken();
        const expires = new Date(Date.now() + 1000 * 60 * 60 * 12).toISOString();
        await supabase.from('admin_sessions').insert({
          id: `as_${Date.now()}`,
          admin_id: admin.id,
          token,
          email: admin.email || email,
          role: admin.role || 'admin',
          expires_at: expires,
        });

        await writeAuditLog({
          actorId: admin.id,
          actorEmail: admin.email || email,
          actorRole: admin.role || 'admin',
          action: 'admin_login',
          entityType: 'admin',
          entityId: admin.id,
          ip: clientIp(req),
        });

        return res.status(200).json({
          token,
          expiresAt: expires,
          admin: {
            id: admin.id,
            email: admin.email || email,
            username: admin.username,
            role: admin.role || 'admin',
          },
        });
      }

      return res.status(400).json({ error: 'Unsupported action' });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('admin-auth error', err);
    return res.status(500).json({ error: err.message });
  }
}
