import supabase from './db-client.js';
import { setCors as setCorsAuth, guardAdminMutations, requireAdmin, getAdminSession, writeAuditLog, clientIp } from './auth-helpers.js';

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Admin-Token, X-Member-Id');
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { code } = req.query;
      let query = supabase.from('coupons').select('*');
      if (code) query = query.eq('code', String(code)).maybeSingle();
      else {
        // قائمة كل الكوبونات للإدارة فقط
        const admin = await requireAdmin(req, res);
        if (!admin) return;
        query = query.order('created_at', { ascending: false });
      }
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data || (code ? null : []));
    }

    // استخدام كوبون من العضو (زيادة العداد فقط)
    if (req.method === 'POST' && (req.body?.action === 'use' || req.body?.action === 'apply')) {
      const code = String(req.body.code || '').toUpperCase();
      if (!code) return res.status(400).json({ error: 'code is required' });
      const { data: row, error: findErr } = await supabase.from('coupons').select('*').eq('code', code).maybeSingle();
      if (findErr) throw findErr;
      if (!row || row.is_active === false) return res.status(400).json({ error: 'كوبون غير صالح' });
      const { data, error } = await supabase
        .from('coupons')
        .update({ uses_count: Number(row.uses_count || 0) + 1 })
        .eq('code', code)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    // إنشاء/تعديل/حذف: إدارة فقط
    const gate = await guardAdminMutations(req, res, { forceAll: true });
    if (!gate.ok) return;

    if (req.method === 'POST' || req.method === 'PUT') {
      const body = req.body || {};
      if (!body.code) return res.status(400).json({ error: 'code is required' });
      const row = {
        code: String(body.code).toUpperCase(),
        discount: Number(body.discount || body.value || 0),
        is_active: body.is_active ?? body.isActive ?? true,
        uses_count: Number(body.uses_count || body.usesCount || 0),
        expires_at: body.expires_at || body.expiresAt || null,
        details: body.details || {},
      };
      const { data, error } = await supabase.from('coupons').upsert(row).select().single();
      if (error) throw error;
      return res.status(req.method === 'POST' ? 201 : 200).json(data);
    }

    if (req.method === 'DELETE') {
      const { code } = req.body || {};
      if (!code) return res.status(400).json({ error: 'code is required' });
      const { error } = await supabase.from('coupons').delete().eq('code', String(code).toUpperCase());
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Coupons API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
