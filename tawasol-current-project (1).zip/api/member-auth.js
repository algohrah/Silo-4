import supabase from './db-client.js';
import { setCors, hashPassword, passwordsMatch, writeAuditLog, clientIp, stripSensitiveMember } from './auth-helpers.js';

function fromDb(r) {
  if (!r) return null;
  const details = r.details && typeof r.details === 'object' ? r.details : {};
  return stripSensitiveMember({
    ...details,
    ...r,
    id: String(r.id),
    birthDate: r.birth_date || '',
    maritalStatus: r.marital_status || 'single',
    hasChildren: !!r.has_children,
    childrenCount: r.children_count || '',
    skinColor: r.skin_color || '',
    workType: r.work_type || '',
    jobTitle: r.job_title || '',
    aboutPartner: r.about_partner || '',
    realName: r.real_name || '',
    isProfileIncomplete: !!r.is_profile_incomplete,
    pNotes: details.pNotes || r.about_partner || '',
    pCountry: details.pCountry || '',
    pCity: details.pCity || '',
  }, { includePassword: false });
}

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    const body = req.body || {};
    const action = body.action || 'login';

    if (action === 'login') {
      const identifier = String(body.email || body.username || '').trim().toLowerCase();
      const password = String(body.password || '');
      if (!identifier || !password) return res.status(400).json({ error: 'بيانات الدخول مطلوبة' });

      const { data: byEmail } = await supabase.from('members').select('*').ilike('email', identifier).maybeSingle();
      let member = byEmail;
      if (!member) {
        const { data: byUser } = await supabase.from('members').select('*').ilike('username', identifier).maybeSingle();
        member = byUser;
      }
      if (!member) return res.status(401).json({ error: 'الحساب غير مسجل' });
      if (!passwordsMatch(password, member.password)) return res.status(401).json({ error: 'كلمة المرور غير صحيحة' });
      if (member.status === 'banned') return res.status(403).json({ error: 'هذا الحساب محظور' });
      if (member.status === 'suspended') return res.status(403).json({ error: 'هذا الحساب معلّق مؤقتاً' });

      // migrate plain -> hash
      if (member.password === password) {
        await supabase.from('members').update({ password: hashPassword(password) }).eq('id', member.id);
      }

      await writeAuditLog({
        actorId: member.id,
        actorEmail: member.email || '',
        actorRole: 'member',
        action: 'member_login',
        entityType: 'member',
        entityId: member.id,
        ip: clientIp(req),
      });

      return res.status(200).json({ ok: true, member: fromDb(member) });
    }

    if (action === 'change_password') {
      const id = String(body.id || body.memberId || '');
      const currentPassword = String(body.currentPassword || '');
      const newPassword = String(body.newPassword || '');
      if (!id || !currentPassword || !newPassword) return res.status(400).json({ error: 'بيانات ناقصة' });
      if (newPassword.length < 6) return res.status(400).json({ error: 'كلمة المرور الجديدة قصيرة' });
      const { data: member } = await supabase.from('members').select('*').eq('id', id).maybeSingle();
      if (!member) return res.status(404).json({ error: 'العضو غير موجود' });
      if (!passwordsMatch(currentPassword, member.password)) return res.status(401).json({ error: 'كلمة المرور الحالية غير صحيحة' });
      await supabase.from('members').update({ password: hashPassword(newPassword), updated_at: new Date().toISOString() }).eq('id', id);
      await writeAuditLog({ actorId: id, action: 'member_password_change', entityType: 'member', entityId: id, ip: clientIp(req) });
      return res.status(200).json({ ok: true });
    }

    if (action === 'admin_reset_password') {
      // requires admin token checked by caller header via separate validation
      const { getAdminSession } = await import('./auth-helpers.js');
      const session = await getAdminSession(req);
      if (!session) return res.status(401).json({ error: 'Unauthorized' });
      const id = String(body.id || body.memberId || '');
      const newPassword = String(body.newPassword || 'Pass@' + Math.random().toString(36).slice(2, 8));
      if (!id) return res.status(400).json({ error: 'id required' });
      await supabase.from('members').update({ password: hashPassword(newPassword), updated_at: new Date().toISOString() }).eq('id', id);
      await writeAuditLog({
        actorId: session.admin_id,
        actorEmail: session.email,
        actorRole: session.role,
        action: 'admin_reset_password',
        entityType: 'member',
        entityId: id,
        ip: clientIp(req),
      });
      return res.status(200).json({ ok: true, temporaryPassword: newPassword });
    }

    return res.status(400).json({ error: 'Unsupported action' });
  } catch (err) {
    console.error('member-auth error', err);
    return res.status(500).json({ error: err.message });
  }
}
