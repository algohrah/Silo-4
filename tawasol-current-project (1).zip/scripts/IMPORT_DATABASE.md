# استيراد قاعدة البيانات عند نقل المشروع

## الطريقة أ — Supabase SQL Editor (موصى بها يدوياً)
1. افتح مشروع Supabase الجديد
2. SQL Editor → الصق محتوى `database/seed.sql` → Run
3. Storage → New bucket → الاسم: `verification-docs` → Public
4. انسخ URL + anon + service_role إلى `.env` و `vercel.json`

## الطريقة ب — أدوات Design Arena Agent
1. اقرأ `database/schema.json`
2. لكل جدول في `tables[]` استدعِ `supabase_create_table` بالأعمدة
3. أنشئ bucket `verification-docs` عبر `supabase_create_bucket`
4. ابذر البيانات عبر `supabase_insert` (أو نفّذ seed.sql)
5. **لا تستبدل** `api/db-client.js` / `api/db-wake.js` / `.env` / `vercel.json`

## ترتيب الإنشاء
انظر القسم 8 في `DATABASE_SCHEMA.md`

## تشفير كلمة المرور (Node)
```js
import crypto from 'crypto';
crypto.createHash('sha256').update('tawasul_v1:' + password).digest('hex');
```
