import { Check, Minus, X } from 'lucide-react';
import { evaluatePartnerFit, summarizePartnerFit, type PartnerFitItem } from '../lib/compatibility';
import type { Member } from '../lib/members';

function StatusIcon({ status }: { status: PartnerFitItem['status'] }) {
  if (status === 'yes') return <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center"><Check className="w-3.5 h-3.5" /></span>;
  if (status === 'no') return <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center"><X className="w-3.5 h-3.5" /></span>;
  if (status === 'partial') return <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center"><Minus className="w-3.5 h-3.5" /></span>;
  return <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center text-[10px] font-bold">—</span>;
}

export default function PartnerFitChecklist({ target, prefs }: { target: Member | any; prefs: any }) {
  if (!prefs || !target) return null;
  const items = evaluatePartnerFit(target, prefs);
  const summary = summarizePartnerFit(items);
  if (summary.total === 0) return null;

  return (
    <div className="rounded-3xl border border-cream-200 bg-white p-4 shadow-soft" dir="rtl">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div>
          <h3 className="font-cairo font-extrabold text-navy-900 text-sm">مطابقة مواصفاتك</h3>
          <p className="text-[11px] text-navy-500 font-tajawal">بدون نسب مئوية — نعم / جزئي / لا</p>
        </div>
        <div className="text-[11px] font-cairo font-bold text-navy-600 bg-cream-100 px-2.5 py-1 rounded-lg">
          {summary.yes} مناسب · {summary.partial} جزئي · {summary.no} غير مطابق
        </div>
      </div>
      <div className="space-y-2">
        {items.filter((i) => i.status !== 'na').map((item) => (
          <div key={item.key} className="flex items-center gap-2.5 rounded-2xl bg-cream-50 border border-cream-100 px-3 py-2">
            <StatusIcon status={item.status} />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-cairo font-bold text-navy-800">{item.label}</p>
              <p className="text-[11px] text-navy-500 font-tajawal truncate">{item.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
