import { LocalStorageAdapter } from '../../LocalStorageAdapter';
import { IRepository, ISettingsRepository } from '../../interfaces';
import type { Member } from '../../../members';
import { MEMBERS } from '../../../members';
import { ADMIN_MEMBERS } from '../../../admin-data';
import { INTEREST_REQUESTS } from '../../../data';
import {
  COUNTRIES as SEED_COUNTRIES,
  CITIES_BY_COUNTRY as SEED_CITIES,
} from '../../../constants';

type JsonMap = Record<string, any>;

const CURRENT_USER_KEY = 'active_member_id';
const MEMBER_CACHE_KEY = 'twafok_api_members_cache';
const REQUEST_CACHE_KEY = 'twafok_api_requests_cache';
const NOTIFICATION_CACHE_KEY = 'twafok_api_notifications_cache';
const COUPON_CACHE_KEY = 'twafok_api_coupons_cache';
const TX_CACHE_KEY = 'twafok_api_transactions_cache';
const DOC_CACHE_KEY = 'twafok_api_verification_docs_cache';
const SETTINGS_CACHE_KEY = 'twafok_api_settings_cache';
const COUNTRIES_CACHE_KEY = 'twafok_api_countries_cache';
const CITIES_CACHE_KEY = 'twafok_api_cities_cache';
const PENDING_CITIES_CACHE_KEY = 'twafok_api_pending_cities_cache';
const NATIONALITIES_CACHE_KEY = 'twafok_api_nationalities_cache';
const GEO_SUGGESTIONS_CACHE_KEY = 'twafok_api_geo_suggestions_cache';

function isBrowser() {
  return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
}

function readCache<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeCache(key: string, value: any) {
  if (!isBrowser()) return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // تجاهل امتلاء التخزين المحلي — المصدر الحقيقي هو Supabase عبر API.
  }
}

async function apiFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers || {});
  if (!headers.has('Content-Type') && init.body) headers.set('Content-Type', 'application/json');
  // إرفاق توكن الإدارة تلقائياً إن وُجد (للمسارات المحمية)
  if (typeof window !== 'undefined' && !headers.has('Authorization') && !headers.has('X-Admin-Token')) {
    const token = localStorage.getItem('twafok_admin_token') || sessionStorage.getItem('twafok_admin_token') || '';
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
      headers.set('X-Admin-Token', token);
    }
  }

  const res = await fetch(path, { ...init, headers });
  const text = await res.text();
  let payload: any = null;
  if (text) {
    try { payload = JSON.parse(text); } catch { payload = text; }
  }
  if (!res.ok) {
    const message = payload?.error || payload?.message || `تعذر الاتصال بالخادم (${res.status})`;
    throw new Error(message);
  }
  if (typeof payload === 'string' && (payload.trim().startsWith('<!') || payload.trim().startsWith('<html'))) {
    throw new Error('استجابة غير صالحة من الخادم (تم إرجاع صفحة HTML بدلاً من بيانات JSON)');
  }
  return payload as T;
}

function asDetailsObject(value: any): Record<string, any> {
  if (!value) return {};
  if (typeof value === 'object' && !Array.isArray(value)) return { ...value };
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }
  return {};
}

function normalizeMember(row: any): any {
  if (!row) return row;
  const details = asDetailsObject(row.details);
  const aboutPartner = row.about_partner || row.aboutPartner || details.pNotes || '';

  return {
    ...details,
    ...row,
    id: String(row.id),
    nickname: row.nickname || row.real_name || row.realName || row.id,
    username: row.username || '',
    gender: row.gender || '',
    age: Number(row.age) || 0,
    birthDate: row.birth_date || row.birthDate || '',
    country: row.country || '',
    city: row.city || '',
    district: row.district || '',
    nationality: row.nationality || '',
    sect: row.sect || '',
    maritalStatus: row.marital_status || row.maritalStatus || 'single',
    maritalLabel: row.marital_label || row.maritalLabel || '',
    hasChildren: !!(row.has_children ?? row.hasChildren),
    childrenCount: row.children_count || row.childrenCount || '',
    height: Number(row.height) || 0,
    weight: Number(row.weight) || 0,
    skinColor: row.skin_color || row.skinColor || '',
    health: row.health || '',
    smoking: row.smoking || '',
    ethnicity: row.ethnicity || '',
    education: row.education || '',
    workType: row.work_type || row.workType || '',
    jobTitle: row.job_title || row.jobTitle || '',
    housing: row.housing || '',
    bio: row.bio || '',
    aboutPartner,
    verified: !!row.verified,
    premium: !!row.premium,
    online: !!row.online,
    lastActive: row.last_active || row.lastActive || new Date().toISOString(),
    matchScore: Number(row.match_score ?? row.matchScore) || 90,
    hasSeriousnessBadge: !!(row.has_seriousness_badge ?? row.hasSeriousnessBadge),
    plan: row.plan || 'free',
    pinned: !!row.pinned,
    status: row.status || 'active',
    statusReason: row.status_reason || row.statusReason || '',
    statusBy: row.status_by || row.statusBy || '',
    adminNote: row.notes || row.adminNote || '',
    notes: row.notes || row.adminNote || '',
    flagged: !!row.flagged,
    sourceType: row.source_type || row.sourceType || 'registered',
    importBatchId: row.import_batch_id || row.importBatchId || '',
    importOfficeName: row.import_office_name || row.importOfficeName || '',
    importDate: row.import_date || row.importDate || '',
    importNotes: row.import_notes || row.importNotes || '',
    isProfileIncomplete: !!(row.is_profile_incomplete ?? row.isProfileIncomplete),
    realName: row.real_name || row.realName || row.nickname || row.id,
    email: row.email || '',
    phone: row.phone || '',
    whatsapp: row.whatsapp || '',
    password: row.password || '',
    details,
    // حقول إضافية + مواصفات الشريك (من details أو من الجذر إن وُجدت)
    sectOther: row.sectOther ?? details.sectOther ?? '',
    nationalityMode: row.nationalityMode ?? details.nationalityMode ?? '',
    nationalityOther: row.nationalityOther ?? details.nationalityOther ?? '',
    childrenLiveWith: row.childrenLiveWith ?? details.childrenLiveWith ?? '',
    wifeCount: row.wifeCount ?? details.wifeCount ?? '',
    seekingWife: row.seekingWife ?? details.seekingWife ?? '',
    acceptPolygamy: row.acceptPolygamy ?? details.acceptPolygamy ?? '',
    acceptDivorced: row.acceptDivorced ?? details.acceptDivorced ?? '',
    acceptWithChildren: row.acceptWithChildren ?? details.acceptWithChildren ?? '',
    religionLevel: row.religionLevel ?? details.religionLevel ?? '',
    pCountry: row.pCountry ?? details.pCountry ?? '',
    pCity: row.pCity ?? details.pCity ?? '',
    pNationality: row.pNationality ?? details.pNationality ?? '',
    pNationalityOther: row.pNationalityOther ?? details.pNationalityOther ?? '',
    pAgeMin: row.pAgeMin ?? details.pAgeMin ?? '',
    pAgeMax: row.pAgeMax ?? details.pAgeMax ?? '',
    pMaritalStatus: row.pMaritalStatus ?? details.pMaritalStatus ?? '',
    pAcceptChildren: row.pAcceptChildren ?? details.pAcceptChildren ?? '',
    pSect: row.pSect ?? details.pSect ?? '',
    pSectOther: row.pSectOther ?? details.pSectOther ?? '',
    pReligionLevel: row.pReligionLevel ?? details.pReligionLevel ?? '',
    pEducation: row.pEducation ?? details.pEducation ?? '',
    pWorkType: row.pWorkType ?? details.pWorkType ?? '',
    pSkinColor: row.pSkinColor ?? details.pSkinColor ?? '',
    pHeight: row.pHeight ?? details.pHeight ?? '',
    pHeightNoMatter: !!(row.pHeightNoMatter ?? details.pHeightNoMatter),
    pHousing: row.pHousing ?? details.pHousing ?? '',
    pNotes: row.pNotes ?? details.pNotes ?? aboutPartner ?? '',
  };
}

function normalizeRequest(row: any): any {
  if (!row) return row;
  const stage = row.journey_stage || row.status || row.mediation_stage || 'pending';
  return {
    ...row,
    id: Number(row.id),
    sender_id: row.sender_id || row.senderId,
    receiver_id: row.receiver_id || row.receiverId,
    senderId: row.sender_id || row.senderId,
    receiverId: row.receiver_id || row.receiverId,
    journey_stage: stage,
    status: stage,
    mediationStage: row.mediation_stage || row.mediationStage || stage,
    message: row.message || '',
    sender_paid: !!(row.sender_paid ?? row.senderPaid),
    receiver_paid: !!(row.receiver_paid ?? row.receiverPaid),
    senderPaid: !!(row.sender_paid ?? row.senderPaid),
    receiverPaid: !!(row.receiver_paid ?? row.receiverPaid),
    sender_paid_at: row.sender_paid_at || row.senderPaidAt || null,
    receiver_paid_at: row.receiver_paid_at || row.receiverPaidAt || null,
    created_at: row.created_at || row.createdAt || new Date().toISOString(),
    updated_at: row.updated_at || row.updatedAt || new Date().toISOString(),
  };
}

/**
 * مفاتيح خاصة بالمتصفح فقط (جلسة/تفضيلات شخصية) — لا تُرفع أبداً للخادم
 * ولا تُقرأ من إعدادات السحابة المشتركة، لأن جدول settings مشترك بين جميع المستخدمين.
 * هذا يمنع مشكلة «آخر مستخدم سجّل دخوله يكتب فوق جلسة الجميع».
 */
const LOCAL_ONLY_KEY_PREFIXES = [
  'auth_user',
  'active_member_id',
  'impersonating',
  'user_profile_data',
  'liked_members_',
  'user_usage_counters',
];

function isLocalOnlyKey(key: string): boolean {
  return LOCAL_ONLY_KEY_PREFIXES.some((p) => key === p || key.startsWith(p));
}

/**
 * لقطات JSON قديمة ضخمة (25KB+) كانت تُرفع للخادم مع كل تغيير.
 * الجداول الحقيقية (members / interest_requests / support_tickets ...) هي
 * المصدر الوحيد للحقيقة الآن، لذا تُحفظ هذه اللقطات محلياً فقط كاحتياط قراءة
 * ولا تُرفع للخادم إطلاقاً.
 */
const LEGACY_SNAPSHOT_KEYS = [
  'saved_members_list',
  'saved_admin_members_list',
  'saved_interest_requests',
  'saved_support_tickets_list',
  'saved_admin_notifications',
  'saved_member_reports_list',
  'saved_exempt_requests',
  'twafok_members',
];

function isLegacySnapshotKey(key: string): boolean {
  return LEGACY_SNAPSHOT_KEYS.includes(key);
}

class ApiSettingsRepository implements ISettingsRepository {
  private cache: Map<string, string>;
  /** مفاتيح متغيّرة بانتظار الرفع للخادم (مزامنة مجمّعة) */
  private pendingSync = new Map<string, string>();
  private syncTimer: ReturnType<typeof setTimeout> | null = null;
  /** آخر قيمة أُرسلت فعلياً للخادم لكل مفتاح — لتخطي القيم غير المتغيرة */
  private lastSynced = new Map<string, string>();

  constructor() {
    this.cache = new Map(Object.entries(readCache<Record<string, string>>(SETTINGS_CACHE_KEY, {})));
    this.refresh();
    // رفع أي تغييرات معلّقة قبل مغادرة الصفحة
    if (isBrowser()) {
      window.addEventListener('beforeunload', () => this.flushSync(true));
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') this.flushSync(true);
      });
    }
  }

  private persist() {
    writeCache(SETTINGS_CACHE_KEY, Object.fromEntries(this.cache.entries()));
  }

  /** جدولة مزامنة مجمّعة بفاصل 3 ثوانٍ بدلاً من طلب لكل تغيير */
  private scheduleSync(key: string, value: string) {
    // تخطي إن لم تتغير القيمة عمّا أُرسل سابقاً
    if (this.lastSynced.get(key) === value) return;
    this.pendingSync.set(key, value);
    if (this.syncTimer) return;
    this.syncTimer = setTimeout(() => this.flushSync(), 3000);
  }

  private flushSync(useBeacon = false) {
    if (this.syncTimer) { clearTimeout(this.syncTimer); this.syncTimer = null; }
    if (this.pendingSync.size === 0) return;
    const entries = Array.from(this.pendingSync.entries());
    this.pendingSync.clear();
    for (const [key, value] of entries) {
      this.lastSynced.set(key, value);
      const body = JSON.stringify({ key, value });
      if (useBeacon && isBrowser() && navigator.sendBeacon) {
        try {
          navigator.sendBeacon('/api/settings', new Blob([body], { type: 'application/json' }));
          continue;
        } catch { /* fallback to fetch */ }
      }
      apiFetch('/api/settings', { method: 'POST', body }).catch(() => undefined);
    }
  }

  async refresh() {
    try {
      const rows = await apiFetch<Array<{ key: string; value: string }>>('/api/settings');
      rows.forEach((row) => {
        this.cache.set(row.key, row.value);
        this.lastSynced.set(row.key, row.value);
      });
      this.persist();
    } catch {
      // يعمل التطبيق بآخر نسخة مخزنة لحين عودة الاتصال.
    }
  }

  get(key: string): string | null {
    if (isBrowser()) {
      const local = localStorage.getItem(key);
      if (local !== null) return local;
    }
    // المفاتيح الشخصية لا تُقرأ أبداً من الإعدادات السحابية المشتركة
    if (isLocalOnlyKey(key)) return null;
    return this.cache.get(key) ?? null;
  }

  set(key: string, value: string): void {
    // الحفظ المحلي فوري دائماً — التطبيق لا ينتظر الشبكة
    if (isBrowser()) {
      try { localStorage.setItem(key, value); } catch {}
    }
    // المفاتيح الشخصية (جلسة، تفضيلات) تبقى في هذا المتصفح فقط
    if (isLocalOnlyKey(key)) return;
    this.cache.set(key, value);
    this.persist();
    // اللقطات القديمة الضخمة لا تُرفع للخادم — الجداول الحقيقية هي المصدر
    if (isLegacySnapshotKey(key)) return;
    // المزامنة مع الخادم مجمّعة (debounced) لمنع عاصفة الطلبات
    this.scheduleSync(key, value);
  }

  remove(key: string): void {
    this.cache.delete(key);
    this.pendingSync.delete(key);
    this.lastSynced.delete(key);
    this.persist();
    if (isBrowser()) localStorage.removeItem(key);
    apiFetch('/api/settings', {
      method: 'DELETE',
      body: JSON.stringify({ key }),
    }).catch(() => undefined);
  }
}

class ApiMembersRepository implements IRepository<any> {
  constructor(private adapter: ApiAdapter) {}

  getAll(): Promise<any[]> { return this.adapter.getMembers(); }

  async getById(id: string | number): Promise<any | null> {
    const found = this.adapter.getLiveMemberById(String(id));
    if (found) return found;
    try {
      return normalizeMember(await apiFetch(`/api/members?id=${encodeURIComponent(String(id))}`));
    } catch {
      return null;
    }
  }

  async create(item: any): Promise<any> {
    const member = normalizeMember(await apiFetch('/api/members', {
      method: 'POST',
      body: JSON.stringify(item),
    }));
    this.adapter.upsertMemberCache(member);
    return member;
  }

  async update(id: string | number, payload: Partial<any>): Promise<any> {
    const member = normalizeMember(await apiFetch('/api/members', {
      method: 'PUT',
      body: JSON.stringify({ id, ...payload }),
    }));
    this.adapter.upsertMemberCache(member);
    return member;
  }

  async delete(id: string | number): Promise<boolean> {
    await apiFetch('/api/members', {
      method: 'DELETE',
      body: JSON.stringify({ id }),
    });
    this.adapter.removeMemberCache(String(id));
    return true;
  }
}

class ApiGenericRepository<T extends { id: string | number }> implements IRepository<T> {
  constructor(private route: string) {}

  async getAll(): Promise<T[]> { return apiFetch<T[]>(this.route); }

  async getById(id: string | number): Promise<T | null> {
    try { return await apiFetch<T>(`${this.route}?id=${encodeURIComponent(String(id))}`); }
    catch { return null; }
  }

  async create(item: T): Promise<T> {
    return apiFetch<T>(this.route, { method: 'POST', body: JSON.stringify(item) });
  }

  async update(id: string | number, payload: Partial<T>): Promise<T> {
    return apiFetch<T>(this.route, { method: 'PUT', body: JSON.stringify({ id, ...payload }) });
  }

  async delete(id: string | number): Promise<boolean> {
    await apiFetch(this.route, { method: 'DELETE', body: JSON.stringify({ id }) });
    return true;
  }
}

export class ApiAdapter extends LocalStorageAdapter {
  public members: IRepository<any>;
  public requests: IRepository<any>;
  public transactions: IRepository<any>;
  public tickets: IRepository<any>;
  public adminUsers: IRepository<any>;
  public settings: ISettingsRepository;

  private memberCache: any[] = (() => {
    const cached = readCache<any[]>(MEMBER_CACHE_KEY, readCache<any[]>('saved_members_list', readCache<any[]>('saved_admin_members_list', [])));
    if (Array.isArray(cached) && cached.length > 0) return cached.map(normalizeMember);
    return (ADMIN_MEMBERS && ADMIN_MEMBERS.length > 0 ? ADMIN_MEMBERS : MEMBERS).map(normalizeMember);
  })();
  private requestCache: any[] = (() => {
    const cached = readCache<any[]>(REQUEST_CACHE_KEY, readCache<any[]>('saved_interest_requests', []));
    if (Array.isArray(cached) && cached.length > 0) return cached;
    return INTEREST_REQUESTS || [];
  })();
  private notificationCache: any[] = readCache<any[]>(NOTIFICATION_CACHE_KEY, []);
  private couponCache: any[] = readCache<any[]>(COUPON_CACHE_KEY, []);
  private txCache: any[] = readCache<any[]>(TX_CACHE_KEY, []);
  private docCache: any[] = readCache<any[]>(DOC_CACHE_KEY, []);
  private countriesCache: any[] = readCache<any[]>(COUNTRIES_CACHE_KEY, SEED_COUNTRIES.map((name: string) => ({ name })));
  private citiesCache: Record<string, string[]> = readCache<Record<string, string[]>>(CITIES_CACHE_KEY, SEED_CITIES as Record<string, string[]>);
  private pendingCitiesCache: any[] = readCache<any[]>(PENDING_CITIES_CACHE_KEY, []);
  private nationalitiesCache: string[] = readCache<string[]>(NATIONALITIES_CACHE_KEY, []);
  private geoSuggestionsCache: any[] = readCache<any[]>(GEO_SUGGESTIONS_CACHE_KEY, []);

  constructor() {
    super();
    this.members = new ApiMembersRepository(this);
    this.requests = new ApiGenericRepository<any>('/api/interest-requests');
    this.transactions = new ApiGenericRepository<any>('/api/transactions');
    this.tickets = new ApiGenericRepository<any>('/api/support-tickets');
    this.adminUsers = new ApiGenericRepository<any>('/api/admin-users');
    this.settings = new ApiSettingsRepository();
    this.hydrateCaches();
  }

  private hydrateCaches() {
    // تحميل كسول: عند الإقلاع نجلب الطلبات فقط.
    // الأعضاء يُجلبون مرة واحدة عبر AppContext (adminGetMembers) — لا داعي للتكرار هنا.
    // الكوبونات/المعاملات/التوثيق/الجغرافيا/الإشعارات تُجلب تلقائياً عند أول استخدام
    // لأن دوال getCoupons/getTransactions/getCountries... تستدعي refresh الخاص بها.
    this.getRequests().catch(() => undefined);
  }

  private cacheMembers(list: any[]) {
    this.memberCache = list.map(normalizeMember);
    writeCache(MEMBER_CACHE_KEY, this.memberCache);
    writeCache('saved_members_list', this.memberCache);
    writeCache('saved_admin_members_list', this.memberCache);
  }

  upsertMemberCache(member: any) {
    const normalized = normalizeMember(member);
    const idx = this.memberCache.findIndex((m) => String(m.id) === String(normalized.id));
    if (idx >= 0) this.memberCache[idx] = normalized;
    else this.memberCache.unshift(normalized);
    this.cacheMembers(this.memberCache);
  }

  removeMemberCache(id: string) {
    this.cacheMembers(this.memberCache.filter((m) => String(m.id) !== String(id)));
  }

  private cacheRequests(list: any[]) {
    this.requestCache = list.map(normalizeRequest);
    writeCache(REQUEST_CACHE_KEY, this.requestCache);
    writeCache('saved_interest_requests', this.requestCache);
  }

  private upsertRequestCache(req: any) {
    const normalized = normalizeRequest(req);
    const idx = this.requestCache.findIndex((r) => Number(r.id) === Number(normalized.id));
    if (idx >= 0) this.requestCache[idx] = normalized;
    else this.requestCache.unshift(normalized);
    this.cacheRequests(this.requestCache);
  }

  // ===== الأعضاء =====
  getMembers = async (): Promise<any[]> => {
    try {
      const rows = await apiFetch<any[]>('/api/members');
      if (!Array.isArray(rows)) {
        console.warn('getMembers received non-array response:', rows);
        return this.getLiveMembers(false);
      }
      const list = rows.map(normalizeMember);
      this.cacheMembers(list);
      return list;
    } catch (err) {
      console.warn('getMembers fetch error, using local fallback:', err);
      return this.getLiveMembers(false);
    }
  };

  getLiveMembers = (includeInactiveAndDeleted: boolean = false): any[] => {
    let list = this.memberCache.length ? this.memberCache : readCache<any[]>(MEMBER_CACHE_KEY, readCache<any[]>('saved_members_list', readCache<any[]>('saved_admin_members_list', [])));
    if (!list || !Array.isArray(list) || list.length === 0) {
      list = (ADMIN_MEMBERS && ADMIN_MEMBERS.length > 0 ? ADMIN_MEMBERS : MEMBERS);
      this.memberCache = list.map(normalizeMember);
    } else {
      list = list.map(normalizeMember);
    }
    if (!includeInactiveAndDeleted) {
      list = list.filter((m) => !m.deleted && (!m.status || m.status === 'active' || m.status === 'pending'));
    }
    return [...list].sort((a, b) => {
      const pin = Number(!!b.pinned) - Number(!!a.pinned);
      if (pin) return pin;
      return String(b.id).localeCompare(String(a.id));
    });
  };

  getLiveMemberById = (id: string): any | undefined => this.getLiveMembers(true).find((m) => String(m.id) === String(id));

  getCurrentUserId = (): string => {
    if (!isBrowser()) return 'm2';
    return localStorage.getItem(CURRENT_USER_KEY) || 'm2';
  };

  setCurrentUserId = (id: string): void => {
    if (!isBrowser()) return;
    localStorage.setItem(CURRENT_USER_KEY, id);
  };

  hasUserPaidDepositAnywhere = (userId: string): boolean => {
    return this.requestCache.some((r) => (r.sender_id === userId || r.receiver_id === userId) && (r.sender_paid || r.receiver_paid));
  };

  // ===== الطلبات والرحلات =====
  getRequests = async (userId?: string): Promise<any[]> => {
    try {
      const query = userId ? `?userId=${encodeURIComponent(userId)}` : '';
      const rows = await apiFetch<any[]>(`/api/interest-requests${query}`);
      if (!Array.isArray(rows)) return this.requestCache;
      const list = rows.map(normalizeRequest);
      this.cacheRequests(userId ? [...list, ...this.requestCache.filter((r) => r.sender_id !== userId && r.receiver_id !== userId)] : list);
      return list;
    } catch {
      return this.requestCache;
    }
  };

  getRequest = async (id: number): Promise<any | null> => {
    try {
      const row = await apiFetch<any>(`/api/interest-requests?id=${encodeURIComponent(String(id))}`);
      const req = normalizeRequest(row);
      this.upsertRequestCache(req);
      return req;
    } catch {
      return this.requestCache.find((r) => Number(r.id) === Number(id)) || null;
    }
  };

  createRequest = async (senderId: string, receiverId: string, message: string): Promise<any> => {
    try {
      const row = await apiFetch<any>('/api/interest-requests', {
        method: 'POST',
        body: JSON.stringify({ senderId, receiverId, message }),
      });
      this.upsertRequestCache(row);
      return { ok: true, data: normalizeRequest(row) };
    } catch (err: any) {
      return { ok: false, error: err.message || 'تعذر إنشاء طلب الاهتمام' };
    }
  };

  runRequestAction = async (requestId: number, action: string, actorId: string, payload: JsonMap = {}): Promise<any> => {
    try {
      const row = await apiFetch<any>('/api/interest-requests', {
        method: 'PUT',
        body: JSON.stringify({ id: requestId, action, actorId, payload }),
      });
      this.upsertRequestCache(row);
      return { ok: true, data: normalizeRequest(row) };
    } catch (err: any) {
      return { ok: false, error: err.message || 'تعذر تحديث رحلة الطلب' };
    }
  };

  getEvents = async (requestId: number): Promise<any[]> => {
    try {
      const rows = await apiFetch<any[]>(`/api/notifications?requestId=${encodeURIComponent(String(requestId))}`);
      return rows.map((n) => ({
        id: Number(n.id),
        request_id: Number(n.request_id || requestId),
        actor_id: n.user_id || 'system',
        type: n.type || 'system',
        note: n.text || n.title || 'تحديث على الطلب',
        created_at: n.created_at || new Date().toISOString(),
      }));
    } catch { return []; }
  };

  isRequestUnseen = (requestId: number, updatedAt?: string | null): boolean => {
    if (!isBrowser()) return false;
    const key = `twafok_seen_request_${requestId}`;
    const seen = localStorage.getItem(key);
    return !!updatedAt && seen !== updatedAt;
  };

  markRequestSeen = (requestId: number): void => {
    if (!isBrowser()) return;
    const req = this.requestCache.find((r) => Number(r.id) === Number(requestId));
    localStorage.setItem(`twafok_seen_request_${requestId}`, req?.updated_at || new Date().toISOString());
  };

  markRequestNotificationsRead = (requestId: number, userId?: string): void => {
    apiFetch('/api/notifications', { method: 'PUT', body: JSON.stringify({ requestId, userId, read: true }) }).catch(() => undefined);
  };

  // ===== غرفة الاستفسار =====
  getUserInquiryBalance = (userId: string): number => Number(this.settings.get(`inquiry_balance_${userId}`) || 0);

  consumeUserInquiryMessage = (userId: string): boolean => {
    const current = this.getUserInquiryBalance(userId);
    if (current <= 0) return false;
    this.settings.set(`inquiry_balance_${userId}`, String(current - 1));
    return true;
  };

  getInquiry = async (requestId: number): Promise<any> => {
    try {
      const messages = await apiFetch<any[]>(`/api/inquiry-messages?requestId=${encodeURIComponent(String(requestId))}`);
      return { messages };
    } catch { return { messages: [] }; }
  };

  initializeInquiry = async (requestId: number, userId: string): Promise<any> => ({ ok: true, state: await this.getInquiry(requestId), ownerId: userId });

  buyInquiry = async (requestId: number, ownerId: string): Promise<any> => this.buyMessagePackageCustom(ownerId, 4, 29, requestId);

  buyMessagePackageCustom = async (userId: string, credits: number, price: number, requestId?: number): Promise<any> => {
    try {
      await apiFetch('/api/transactions', {
        method: 'POST',
        body: JSON.stringify({ user_id: userId, userId, credits, amount: price, type: 'inquiry_package', description: `شراء ${credits} رسائل استفسار`, request_id: requestId }),
      });
      this.settings.set(`inquiry_balance_${userId}`, String(this.getUserInquiryBalance(userId) + credits));
      await this.refreshTransactions();
      return { ok: true };
    } catch (err: any) { return { ok: false, error: err.message }; }
  };

  sendInquiry = async (requestId: number, senderId: string, text: string): Promise<any> => {
    try {
      const row = await apiFetch('/api/inquiry-messages', {
        method: 'POST',
        body: JSON.stringify({ requestId, senderId, text }),
      });
      return { ok: true, data: row };
    } catch (err: any) { return { ok: false, error: err.message || 'تعذر إرسال الرسالة' }; }
  };

  simulateReply = async (requestId: number, replierId: string, text: string): Promise<any> => this.sendInquiry(requestId, replierId, text);

  getAllInquiryMessages = (): any[] => readCache<any[]>('twafok_api_inquiry_messages_cache', []);

  moderateInquiryMessage = (messageId: number, action: 'approve' | 'reject', moderatorName: string): boolean => {
    apiFetch('/api/inquiry-messages', { method: 'PUT', body: JSON.stringify({ id: messageId, action, moderatorName }) }).catch(() => undefined);
    return true;
  };

  deleteInquiryMessage = (messageId: number): boolean => {
    apiFetch('/api/inquiry-messages', { method: 'DELETE', body: JSON.stringify({ id: messageId }) }).catch(() => undefined);
    return true;
  };

  // ===== الإشعارات =====
  private async refreshNotifications(userId?: string) {
    try {
      const query = userId ? `?userId=${encodeURIComponent(userId)}` : '';
      const rows = await apiFetch<any[]>(`/api/notifications${query}`);
      if (Array.isArray(rows)) {
        this.notificationCache = rows;
        writeCache(NOTIFICATION_CACHE_KEY, rows);
        return rows;
      }
    } catch { /* fallback */ }
    return this.notificationCache;
  }

  getJourneyNotifications = async (userId: string): Promise<any[]> => {
    try { return await this.refreshNotifications(userId); }
    catch { return this.notificationCache.filter((n) => n.user_id === userId || n.userId === userId || n.user_id === 'all'); }
  };

  markNotificationRead = (id: number): void => {
    this.notificationCache = this.notificationCache.map((n) => Number(n.id) === Number(id) ? { ...n, read: true } : n);
    writeCache(NOTIFICATION_CACHE_KEY, this.notificationCache);
    apiFetch('/api/notifications', { method: 'PUT', body: JSON.stringify({ id, read: true }) }).catch(() => undefined);
  };

  markAllNotificationsRead = (userId: string): void => {
    this.notificationCache = this.notificationCache.map((n) => (n.user_id === userId || n.user_id === 'all') ? { ...n, read: true } : n);
    writeCache(NOTIFICATION_CACHE_KEY, this.notificationCache);
    apiFetch('/api/notifications', { method: 'PUT', body: JSON.stringify({ userId, read: true }) }).catch(() => undefined);
  };

  getUnreadNotificationsCount = async (userId: string): Promise<number> => (await this.getJourneyNotifications(userId)).filter((n) => !n.read).length;

  getActionableRequestsCount = async (userId: string): Promise<number> => (await this.getRequests(userId)).filter((r) => r.receiver_id === userId && ['pending', 'sent', 'accepted'].includes(r.journey_stage)).length;

  deleteNotification = (id: number): void => {
    this.notificationCache = this.notificationCache.filter((n) => Number(n.id) !== Number(id));
    writeCache(NOTIFICATION_CACHE_KEY, this.notificationCache);
    apiFetch('/api/notifications', { method: 'DELETE', body: JSON.stringify({ id }) }).catch(() => undefined);
  };

  // ===== لوحة الإدارة =====
  adminGetMembers = async (): Promise<any[]> => {
    try {
      const token = (typeof window !== 'undefined')
        ? (localStorage.getItem('twafok_admin_token') || sessionStorage.getItem('twafok_admin_token') || '')
        : '';
      const rows = await apiFetch<any[]>('/api/members?admin=true', {
        headers: token ? { Authorization: `Bearer ${token}`, 'X-Admin-Token': token } : {},
      });
      if (!Array.isArray(rows)) {
        console.warn('adminGetMembers received non-array response:', rows);
        return this.getLiveMembers(true);
      }
      const list = rows.map(normalizeMember);
      this.cacheMembers(list);
      return list;
    } catch (err) {
      console.warn('adminGetMembers fetch error, using local fallback:', err);
      return this.getLiveMembers(true);
    }
  };

  adminUpdateMember = async (id: string, fields: any): Promise<boolean> => {
    try {
      const token = (typeof window !== 'undefined')
        ? (localStorage.getItem('twafok_admin_token') || sessionStorage.getItem('twafok_admin_token') || '')
        : '';
      // لا ترسل كلمة مرور فارغة/قناع
      const payload = { ...fields };
      if (payload.password === '' || payload.password === '••••••••') delete payload.password;
      await apiFetch('/api/members', {
        method: 'PUT',
        headers: token ? { Authorization: `Bearer ${token}`, 'X-Admin-Token': token } : {},
        body: JSON.stringify({ id, ...payload }),
      });
      return true;
    } catch { return false; }
  };

  adminBulkDeleteMembers = async (ids: string[]): Promise<boolean> => {
    await Promise.all(ids.map((id) => this.adminDeleteMember(id)));
    return true;
  };

  adminBulkUpdateStatus = async (ids: string[], status: any, reason = '', by = 'الإدارة'): Promise<boolean> => {
    await Promise.all(ids.map((id) => this.adminUpdateMember(id, { status, statusReason: reason, status_by: by, statusBy: by })));
    return true;
  };

  adminBulkSetVerified = async (ids: string[], value: boolean): Promise<boolean> => {
    await Promise.all(ids.map((id) => this.adminUpdateMember(id, { verified: value })));
    return true;
  };

  adminBulkSetPinned = async (ids: string[], value: boolean): Promise<boolean> => {
    await Promise.all(ids.map((id) => this.adminUpdateMember(id, { pinned: value })));
    return true;
  };

  adminBulkSetPlan = async (ids: string[], plan: 'free' | 'gold' | 'elite'): Promise<boolean> => {
    await Promise.all(ids.map((id) => this.adminUpdateMember(id, { plan, premium: plan !== 'free' })));
    return true;
  };

  adminBulkSetSeriousnessBadge = async (ids: string[], value: boolean): Promise<boolean> => {
    await Promise.all(ids.map((id) => this.adminUpdateMember(id, { hasSeriousnessBadge: value })));
    return true;
  };

  adminDeleteMember = async (id: string): Promise<boolean> => this.members.delete(id);
  adminHardDeleteMember = async (id: string): Promise<boolean> => this.members.delete(id);

  adminResetPassword = async (id: string): Promise<string> => {
    const token = (typeof window !== 'undefined')
      ? (localStorage.getItem('twafok_admin_token') || sessionStorage.getItem('twafok_admin_token') || '')
      : '';
    const data = await apiFetch<any>('/api/member-auth', {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}`, 'X-Admin-Token': token } : {},
      body: JSON.stringify({ action: 'admin_reset_password', id }),
    });
    return data.temporaryPassword || '';
  };

  adminToggleVerified = (id: string, value: boolean): Promise<boolean> => this.adminUpdateMember(id, { verified: value });
  adminSetPremium = (id: string, value: boolean): Promise<boolean> => this.adminUpdateMember(id, { premium: value, plan: value ? 'gold' : 'free' });
  adminSetNote = (id: string, note: string): Promise<boolean> => this.adminUpdateMember(id, { adminNote: note, notes: note });
  adminToggleFlag = (id: string, value: boolean): Promise<boolean> => this.adminUpdateMember(id, { flagged: value });

  adminSendNotification = async (id: string, text: string, title?: string): Promise<boolean> => {
    try {
      await apiFetch('/api/notifications', { method: 'POST', body: JSON.stringify({ user_id: id, userId: id, text, title: title || 'تنبيه إداري جديد', type: 'admin' }) });
      await this.refreshNotifications().catch(() => undefined);
      return true;
    } catch { return false; }
  };

  adminSendBulkNotifications = async (userIds: string[], text: string, title?: string): Promise<boolean> => {
    await Promise.all(userIds.map((id) => this.adminSendNotification(id, text, title)));
    return true;
  };

  adminDeleteRequest = async (requestId: number): Promise<boolean> => {
    try {
      await apiFetch('/api/interest-requests', { method: 'DELETE', body: JSON.stringify({ id: requestId }) });
      this.cacheRequests(this.requestCache.filter((r) => Number(r.id) !== Number(requestId)));
      return true;
    } catch { return false; }
  };

  adminGrantSeriousnessBadge = (id: string): Promise<boolean> => this.adminUpdateMember(id, { hasSeriousnessBadge: true });
  adminRevokeSeriousnessBadge = (id: string): Promise<boolean> => this.adminUpdateMember(id, { hasSeriousnessBadge: false });
  adminGetRequests = (): Promise<any[]> => this.getRequests();

  adminGetStats = async (): Promise<any> => {
    try { return await apiFetch('/api/stats'); }
    catch {
      const members = this.getLiveMembers(true);
      const requests = this.requestCache;
      const stageBreakdown = requests.reduce((acc: Record<string, number>, req: any) => {
        const stage = req.journey_stage === 'pending' ? 'sent' : (req.journey_stage || req.status || 'sent');
        acc[stage] = (acc[stage] || 0) + 1;
        return acc;
      }, {});
      const revenue = this.txCache.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
      return {
        totalMembers: members.length,
        activeMembers: members.filter((m) => !m.status || m.status === 'active').length,
        pendingMembers: members.filter((m) => m.status === 'pending').length,
        suspendedMembers: members.filter((m) => m.status === 'suspended').length,
        bannedMembers: members.filter((m) => m.status === 'banned').length,
        totalRequests: requests.length,
        pendingRequests: requests.filter((r) => ['pending', 'sent'].includes(r.journey_stage || r.status)).length,
        activeRequests: requests.filter((r) => !['declined', 'cancelled', 'completed'].includes(r.journey_stage || r.status)).length,
        activeJourneys: requests.filter((r) => !['declined', 'cancelled', 'completed'].includes(r.journey_stage || r.status)).length,
        completedRequests: requests.filter((r) => r.journey_stage === 'completed').length,
        declinedRequests: requests.filter((r) => r.journey_stage === 'declined').length,
        cancelledRequests: requests.filter((r) => r.journey_stage === 'cancelled').length,
        completed: requests.filter((r) => r.journey_stage === 'completed').length,
        declined: requests.filter((r) => r.journey_stage === 'declined').length,
        cancelled: requests.filter((r) => r.journey_stage === 'cancelled').length,
        maleCount: members.filter((m) => m.gender === 'male').length,
        femaleCount: members.filter((m) => m.gender === 'female').length,
        males: members.filter((m) => m.gender === 'male').length,
        females: members.filter((m) => m.gender === 'female').length,
        verified: members.filter((m) => m.verified).length,
        premium: members.filter((m) => m.premium || m.plan !== 'free').length,
        revenue,
        totalRevenue: revenue,
        totalTransactions: this.txCache.length,
        depositsPaid: requests.filter((r) => r.sender_paid || r.receiver_paid || r.senderPaid || r.receiverPaid).length,
        seriousnessBadges: members.filter((m) => m.hasSeriousnessBadge || m.has_seriousness_badge).length,
        stageBreakdown,
        recentEvents: this.txCache.slice(0, 8).map((tx) => ({
          id: `tx-${tx.id}`,
          note: tx.description || `معاملة ${tx.type || 'مالية'} بقيمة ${Number(tx.amount || 0).toLocaleString('ar-SA')} ر.س`,
          created_at: tx.created_at || new Date().toISOString(),
        })),
      };
    }
  };

  adminGetRequestPayments = async (requestId: number): Promise<any[]> => {
    try { return await apiFetch<any[]>(`/api/transactions?requestId=${encodeURIComponent(String(requestId))}`); }
    catch { return this.txCache.filter((tx) => Number(tx.request_id || tx.requestId) === Number(requestId)); }
  };

  adminApplyExemption = async (memberId: string, type: 'deposit' | 'badge', value: number | boolean, memberName?: string): Promise<boolean> => {
    if (type === 'badge') return this.adminUpdateMember(memberId, { hasSeriousnessBadge: !!value });
    await apiFetch('/api/transactions', { method: 'POST', body: JSON.stringify({ user_id: memberId, amount: 0, type: 'exemption', description: `إعفاء ${memberName || memberId} من رسوم الجدية`, status: 'completed' }) }).catch(() => undefined);
    return true;
  };

  // ===== الكوبونات والمعاملات =====
  /** آخر وقت تحديث لكل مورد — لمنع الاستعلامات المتكررة خلال فترة قصيرة */
  private lastRefreshAt: Record<string, number> = {};

  /** هل يسمح بتحديث المورد الآن؟ (فاصل أدنى 30 ثانية بين التحديثات) */
  private canRefresh(resource: string, minIntervalMs = 30000): boolean {
    const now = Date.now();
    if (now - (this.lastRefreshAt[resource] || 0) < minIntervalMs) return false;
    this.lastRefreshAt[resource] = now;
    return true;
  }

  private async refreshCoupons() {
    if (!this.canRefresh('coupons')) return this.couponCache;
    this.couponCache = await apiFetch<any[]>('/api/coupons');
    writeCache(COUPON_CACHE_KEY, this.couponCache);
    return this.couponCache;
  }

  getCoupons = (): any[] => {
    this.refreshCoupons().catch(() => undefined);
    return this.couponCache;
  };

  saveCoupon = (coupon: any): void => {
    const idx = this.couponCache.findIndex((c) => String(c.code).toLowerCase() === String(coupon.code).toLowerCase());
    if (idx >= 0) this.couponCache[idx] = coupon;
    else this.couponCache.unshift(coupon);
    writeCache(COUPON_CACHE_KEY, this.couponCache);
    apiFetch('/api/coupons', { method: 'POST', body: JSON.stringify(coupon) }).catch(() => undefined);
  };

  deleteCoupon = (code: string): void => {
    this.couponCache = this.couponCache.filter((c) => String(c.code).toLowerCase() !== String(code).toLowerCase());
    writeCache(COUPON_CACHE_KEY, this.couponCache);
    apiFetch('/api/coupons', { method: 'DELETE', body: JSON.stringify({ code }) }).catch(() => undefined);
  };

  toggleCouponActive = (code: string): void => {
    const coupon = this.couponCache.find((c) => String(c.code).toLowerCase() === String(code).toLowerCase());
    if (coupon) this.saveCoupon({ ...coupon, is_active: !(coupon.is_active ?? coupon.isActive), isActive: !(coupon.is_active ?? coupon.isActive) });
  };

  private async refreshTransactions() {
    if (!this.canRefresh('transactions')) return this.txCache;
    this.txCache = await apiFetch<any[]>('/api/transactions');
    writeCache(TX_CACHE_KEY, this.txCache);
    return this.txCache;
  }

  getTransactions = (): any[] => {
    this.refreshTransactions().catch(() => undefined);
    return this.txCache;
  };

  recordTransaction = (tx: any): void => {
    const row = { ...tx, id: tx.id || Date.now(), created_at: tx.created_at || new Date().toISOString() };
    this.txCache.unshift(row);
    writeCache(TX_CACHE_KEY, this.txCache);
    apiFetch('/api/transactions', { method: 'POST', body: JSON.stringify(row) }).catch(() => undefined);
  };

  validateCoupon = (code: string, amount?: number): any => {
    const coupon = this.couponCache.find((c) => String(c.code).toLowerCase() === String(code).toLowerCase());
    if (!coupon || coupon.is_active === false || coupon.isActive === false) return null;
    const discount = Number(coupon.discount || coupon.discount_percent || coupon.value || 0);
    return { ...coupon, amount, discount };
  };

  useCoupon = (code: string): boolean => {
    const coupon = this.couponCache.find((c) => String(c.code).toLowerCase() === String(code).toLowerCase());
    if (!coupon) return false;
    this.saveCoupon({ ...coupon, uses_count: Number(coupon.uses_count || coupon.usesCount || 0) + 1 });
    return true;
  };

  resetLocalDB = (): void => {
    [MEMBER_CACHE_KEY, REQUEST_CACHE_KEY, NOTIFICATION_CACHE_KEY, COUPON_CACHE_KEY, TX_CACHE_KEY, DOC_CACHE_KEY].forEach((key) => isBrowser() && localStorage.removeItem(key));
  };

  // ===== مستندات التوثيق =====
  private async refreshVerificationDocs() {
    if (!this.canRefresh('verification-docs')) return this.docCache;
    this.docCache = await apiFetch<any[]>('/api/verification-docs');
    writeCache(DOC_CACHE_KEY, this.docCache);
    return this.docCache;
  }

  submitVerificationDoc = (doc: any): any => {
    const row = { ...doc, id: doc.id || `doc_${Date.now()}`, status: doc.status || 'pending', created_at: doc.created_at || new Date().toISOString() };
    this.docCache.unshift(row);
    writeCache(DOC_CACHE_KEY, this.docCache);
    apiFetch('/api/verification-docs', { method: 'POST', body: JSON.stringify(row) }).catch(() => undefined);
    return row;
  };

  getAllVerificationDocs = (): any[] => {
    this.refreshVerificationDocs().catch(() => undefined);
    return this.docCache;
  };

  getMemberVerificationDoc = (memberId: string): any | null => this.docCache.find((d) => d.member_id === memberId || d.memberId === memberId) || null;

  getVerificationStatus = (memberId: string): any => this.getMemberVerificationDoc(memberId)?.status || 'none';

  approveVerificationDoc = (docId: string, reviewerName: string): boolean => {
    this.docCache = this.docCache.map((d) => d.id === docId ? { ...d, status: 'approved', reviewer_name: reviewerName } : d);
    writeCache(DOC_CACHE_KEY, this.docCache);
    apiFetch('/api/verification-docs', { method: 'PUT', body: JSON.stringify({ id: docId, status: 'approved', reviewer_name: reviewerName }) }).catch(() => undefined);
    return true;
  };

  rejectVerificationDoc = (docId: string, reviewerName: string, reason: string): boolean => {
    this.docCache = this.docCache.map((d) => d.id === docId ? { ...d, status: 'rejected', reviewer_name: reviewerName, rejection_reason: reason } : d);
    writeCache(DOC_CACHE_KEY, this.docCache);
    apiFetch('/api/verification-docs', { method: 'PUT', body: JSON.stringify({ id: docId, status: 'rejected', reviewer_name: reviewerName, rejection_reason: reason }) }).catch(() => undefined);
    return true;
  };

  deleteVerificationDoc = (docId: string): boolean => {
    this.docCache = this.docCache.filter((d) => d.id !== docId);
    writeCache(DOC_CACHE_KEY, this.docCache);
    apiFetch('/api/verification-docs', { method: 'DELETE', body: JSON.stringify({ id: docId }) }).catch(() => undefined);
    return true;
  };

  deleteReviewedDocs = (): number => {
    const reviewed = this.docCache.filter((d) => d.status !== 'pending').length;
    this.docCache.filter((d) => d.status === 'pending').forEach((d) => this.deleteVerificationDoc(d.id));
    return reviewed;
  };

  downloadDocImage = (_doc: any): void => undefined;
  downloadAllPendingDocs = (): number => this.docCache.filter((d) => d.status === 'pending').length;

  // ===== خيارات التسجيل والـ Geo =====
  private async refreshGeo() {
    if (!this.canRefresh('geo', 60000)) return;
    const countries = await apiFetch<any[]>('/api/geo?type=countries').catch(() => this.countriesCache);
    const citiesRows = await apiFetch<any[]>('/api/geo?type=cities').catch(() => []);
    const pending = await apiFetch<any[]>('/api/geo?type=pending').catch(() => this.pendingCitiesCache);
    const nationalities = await apiFetch<any[]>('/api/geo-nationalities').catch(() => []);
    const suggestions = await apiFetch<any[]>('/api/geo-suggestions').catch(() => this.geoSuggestionsCache);
    this.countriesCache = countries.length ? countries : this.countriesCache;
    if (Array.isArray(citiesRows) && citiesRows.length) {
      const grouped: Record<string, string[]> = {};
      citiesRows.forEach((row) => {
        const country = row.country || row.country_name;
        const name = row.name || row.city;
        if (!country || !name) return;
        grouped[country] = grouped[country] || [];
        if (!grouped[country].includes(name)) grouped[country].push(name);
      });
      this.citiesCache = grouped;
    }
    this.pendingCitiesCache = pending;
    if (Array.isArray(nationalities) && nationalities.length) this.nationalitiesCache = nationalities.map((n: any) => n.name || n).filter(Boolean);
    if (Array.isArray(suggestions)) this.geoSuggestionsCache = suggestions;
    writeCache(COUNTRIES_CACHE_KEY, this.countriesCache);
    writeCache(CITIES_CACHE_KEY, this.citiesCache);
    writeCache(PENDING_CITIES_CACHE_KEY, this.pendingCitiesCache);
    writeCache(NATIONALITIES_CACHE_KEY, this.nationalitiesCache);
    writeCache(GEO_SUGGESTIONS_CACHE_KEY, this.geoSuggestionsCache);
  }

  getCountries = (): any[] => { this.refreshGeo().catch(() => undefined); return this.countriesCache; };
  getCountryNames = (): string[] => this.getCountries().map((c: any) => c.name || c);
  getNationalities = (): string[] => {
    this.refreshGeo().catch(() => undefined);
    return Array.from(new Set(this.nationalitiesCache.length ? this.nationalitiesCache : this.getCountryNames()));
  };
  getCities = (country: string): string[] => this.citiesCache[country] || [];
  normalizeText = (s: string): string => (s || '').toString().trim().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').toLowerCase();
  isNationalityKnown = (name: string): boolean => {
    const target = this.normalizeText(name);
    return this.getNationalities().some((n) => this.normalizeText(n) === target);
  };
  isCountryKnown = (country: string): boolean => {
    const target = this.normalizeText(country);
    return this.countriesCache.some((c: any) => this.normalizeText(c.name || c) === target);
  };
  isCityKnown = (country: string, city: string): boolean => {
    const target = this.normalizeText(city);
    return (this.citiesCache[country] || []).some((c) => this.normalizeText(c) === target);
  };
  getPendingCities = (): any[] => this.pendingCitiesCache;
  getAllPendingCities = (): any[] => this.pendingCitiesCache;
  getPendingCitiesCount = (): number => this.pendingCitiesCache.filter((c) => c.status === 'pending').length + this.getPendingGeoSuggestionsCount();
  getPendingGeoSuggestions = (): any[] => {
    this.refreshGeo().catch(() => undefined);
    return this.geoSuggestionsCache;
  };
  getPendingGeoSuggestionsCount = (): number => this.geoSuggestionsCache.filter((g) => g.status === 'pending').length;

  addNationality = (name: string, country = '', gender = 'both'): any => {
    if (!this.nationalitiesCache.includes(name)) this.nationalitiesCache.unshift(name);
    writeCache(NATIONALITIES_CACHE_KEY, this.nationalitiesCache);
    apiFetch('/api/geo-nationalities', { method: 'POST', body: JSON.stringify({ name, country, gender }) }).catch(() => undefined);
    return { ok: true, name, country, gender };
  };

  removeNationality = (name: string): void => {
    this.nationalitiesCache = this.nationalitiesCache.filter((n) => n !== name);
    writeCache(NATIONALITIES_CACHE_KEY, this.nationalitiesCache);
    apiFetch('/api/geo-nationalities', { method: 'DELETE', body: JSON.stringify({ name }) }).catch(() => undefined);
  };

  renameNationality = (oldName: string, newName: string): any => {
    this.removeNationality(oldName);
    this.addNationality(newName);
    return { ok: true, oldName, newName };
  };

  addCountry = (name: string, code?: string, flag?: string): any => {
    const item = { name, code, flag };
    this.countriesCache.unshift(item);
    writeCache(COUNTRIES_CACHE_KEY, this.countriesCache);
    apiFetch('/api/geo', { method: 'POST', body: JSON.stringify({ type: 'country', ...item }) }).catch(() => undefined);
    return item;
  };

  removeCountry = (name: string): void => {
    this.countriesCache = this.countriesCache.filter((c) => (c.name || c) !== name);
    writeCache(COUNTRIES_CACHE_KEY, this.countriesCache);
    apiFetch('/api/geo', { method: 'DELETE', body: JSON.stringify({ type: 'country', name }) }).catch(() => undefined);
  };

  renameCountry = (oldName: string, newName: string): any => {
    const current = this.countriesCache.find((c: any) => (c.name || c) === oldName);
    this.removeCountry(oldName);
    const item = this.addCountry(newName, current?.code, current?.flag);
    if (this.citiesCache[oldName]) {
      this.citiesCache[newName] = [...(this.citiesCache[newName] || []), ...this.citiesCache[oldName]];
      delete this.citiesCache[oldName];
      writeCache(CITIES_CACHE_KEY, this.citiesCache);
    }
    return item;
  };

  addCityToCountry = (country: string, city: string): any => {
    this.citiesCache[country] = this.citiesCache[country] || [];
    if (!this.citiesCache[country].includes(city)) this.citiesCache[country].push(city);
    writeCache(CITIES_CACHE_KEY, this.citiesCache);
    apiFetch('/api/geo', { method: 'POST', body: JSON.stringify({ type: 'city', country, name: city }) }).catch(() => undefined);
    return { country, name: city };
  };

  addPendingGeo = (kind: 'country' | 'city' | 'nationality', name: string, country = '', suggestedBy = 'عضو', source = 'register', suggestedById?: string): any => {
    const item = {
      id: `geo_${kind}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      kind,
      name,
      country,
      suggested_by: suggestedBy,
      suggestedBy,
      suggested_by_id: suggestedById || '',
      source,
      status: 'pending',
      created_at: new Date().toISOString(),
    };
    this.geoSuggestionsCache.unshift(item);
    writeCache(GEO_SUGGESTIONS_CACHE_KEY, this.geoSuggestionsCache);
    apiFetch('/api/geo-suggestions', { method: 'POST', body: JSON.stringify(item) }).catch(() => undefined);
    return { ok: true, ...item };
  };

  approvePendingGeo = (id: string, editedName?: string): any => {
    const item = this.geoSuggestionsCache.find((g) => g.id === id);
    if (item) {
      item.status = 'approved';
      item.target_name = editedName || item.name;
      if (item.kind === 'country') this.addCountry(item.target_name);
      if (item.kind === 'city') this.addCityToCountry(item.country, item.target_name);
      if (item.kind === 'nationality') this.addNationality(item.target_name, item.country);
      writeCache(GEO_SUGGESTIONS_CACHE_KEY, this.geoSuggestionsCache);
    }
    apiFetch('/api/geo-suggestions', { method: 'PUT', body: JSON.stringify({ id, action: 'approve', editedName }) }).catch(() => undefined);
    return { ok: true, data: item };
  };

  mergePendingGeo = (id: string, targetName: string, targetCountry = ''): any => {
    const item = this.geoSuggestionsCache.find((g) => g.id === id);
    if (item) {
      item.status = 'merged';
      item.target_name = targetName;
      item.target_country = targetCountry;
      writeCache(GEO_SUGGESTIONS_CACHE_KEY, this.geoSuggestionsCache);
    }
    apiFetch('/api/geo-suggestions', { method: 'PUT', body: JSON.stringify({ id, action: 'merge', targetName, targetCountry }) }).catch(() => undefined);
    return { ok: true, data: item };
  };

  rejectPendingGeo = (id: string, reason = ''): any => {
    const item = this.geoSuggestionsCache.find((g) => g.id === id);
    if (item) {
      item.status = 'rejected';
      item.rejection_reason = reason;
      writeCache(GEO_SUGGESTIONS_CACHE_KEY, this.geoSuggestionsCache);
    }
    apiFetch('/api/geo-suggestions', { method: 'PUT', body: JSON.stringify({ id, action: 'reject', reason }) }).catch(() => undefined);
    return { ok: true, data: item };
  };

  deletePendingGeo = (id: string): void => {
    this.geoSuggestionsCache = this.geoSuggestionsCache.filter((g) => g.id !== id);
    writeCache(GEO_SUGGESTIONS_CACHE_KEY, this.geoSuggestionsCache);
    apiFetch('/api/geo-suggestions', { method: 'DELETE', body: JSON.stringify({ id }) }).catch(() => undefined);
  };

  removeCityFromCountry = (country: string, city: string): void => {
    this.citiesCache[country] = (this.citiesCache[country] || []).filter((c) => c !== city);
    writeCache(CITIES_CACHE_KEY, this.citiesCache);
    apiFetch('/api/geo', { method: 'DELETE', body: JSON.stringify({ type: 'city', country, name: city }) }).catch(() => undefined);
  };

  renameCity = (country: string, oldName: string, newName: string): any => {
    this.removeCityFromCountry(country, oldName);
    return this.addCityToCountry(country, newName);
  };

  adminMergeCities = (sourceCountry: string, sourceCity: string, targetCountry: string, targetCity: string): any => {
    this.removeCityFromCountry(sourceCountry, sourceCity);
    if (!this.isCityKnown(targetCountry, targetCity)) this.addCityToCountry(targetCountry, targetCity);
    return { sourceCountry, sourceCity, targetCountry, targetCity };
  };

  adminMergeCountries = (sourceCountry: string, targetCountry: string): any => {
    const sourceCities = this.citiesCache[sourceCountry] || [];
    sourceCities.forEach((city) => {
      if (!this.isCityKnown(targetCountry, city)) this.addCityToCountry(targetCountry, city);
    });
    this.removeCountry(sourceCountry);
    delete this.citiesCache[sourceCountry];
    writeCache(CITIES_CACHE_KEY, this.citiesCache);
    return { sourceCountry, targetCountry };
  };

  checkAndRegisterUnknownGeo = (members: any[], source = 'import'): any => {
    const addedCountries: string[] = [];
    const addedCities: string[] = [];
    members.forEach((member) => {
      const country = (member.country || '').trim();
      const city = (member.city || '').trim();
      if (country && !this.isCountryKnown(country)) {
        this.addPendingGeo('country', country, '', member.nickname || member.realName || 'استيراد', source);
        addedCountries.push(country);
      }
      if (country && city && !this.isCityKnown(country, city)) {
        this.addPendingGeo('city', city, country, member.nickname || member.realName || 'استيراد', source);
        addedCities.push(`${country}/${city}`);
      }
      const nationality = (member.nationality || '').trim();
      if (nationality && !this.isNationalityKnown(nationality)) {
        this.addPendingGeo('nationality', nationality, country, member.nickname || member.realName || 'استيراد', source);
      }
    });
    return { source, addedCountries, addedCities };
  };

  addPendingCity = (name: string, country: string, suggestedBy: string, source = 'register', suggestedById?: string): any => {
    const item = { id: `pc_${Date.now()}`, name, country, suggested_by: suggestedBy, suggested_by_id: suggestedById, source, status: 'pending', created_at: new Date().toISOString() };
    this.pendingCitiesCache.unshift(item);
    writeCache(PENDING_CITIES_CACHE_KEY, this.pendingCitiesCache);
    apiFetch('/api/geo', { method: 'POST', body: JSON.stringify({ type: 'pending', ...item }) }).catch(() => undefined);
    return item;
  };

  approvePendingCity = (id: string, reviewer: string, editedName?: string): any => {
    const item = this.pendingCitiesCache.find((c) => c.id === id);
    if (item) {
      item.status = 'approved'; item.reviewer = reviewer; if (editedName) item.name = editedName;
      this.addCityToCountry(item.country, item.name);
    }
    writeCache(PENDING_CITIES_CACHE_KEY, this.pendingCitiesCache);
    apiFetch('/api/geo', { method: 'PUT', body: JSON.stringify({ type: 'pending', id, status: 'approved', reviewer, editedName }) }).catch(() => undefined);
    return item;
  };

  rejectPendingCity = (id: string, reviewer: string, reason?: string): any => {
    const item = this.pendingCitiesCache.find((c) => c.id === id);
    if (item) { item.status = 'rejected'; item.reviewer = reviewer; item.rejection_reason = reason; }
    writeCache(PENDING_CITIES_CACHE_KEY, this.pendingCitiesCache);
    apiFetch('/api/geo', { method: 'PUT', body: JSON.stringify({ type: 'pending', id, status: 'rejected', reviewer, reason }) }).catch(() => undefined);
    return item;
  };

  deletePendingCity = (id: string): void => {
    this.pendingCitiesCache = this.pendingCitiesCache.filter((c) => c.id !== id);
    writeCache(PENDING_CITIES_CACHE_KEY, this.pendingCitiesCache);
    apiFetch('/api/geo', { method: 'DELETE', body: JSON.stringify({ type: 'pending', id }) }).catch(() => undefined);
  };
}
