import type { Member } from './members';
import type { ProfileData } from './AppContext';

// ====================================================================
//  محرك حساب التوافق — يعتمد على مواصفات الشريك في profileData
// ====================================================================

export interface CompatResult {
  score: number;           // النسبة 0-100
  isGenderMatch: boolean;  // هل الجنس متطابق (ذكر↔أنثى)
  isEstimated: boolean;    // هل الحساب تقديري (حقول شريك ناقصة)
  reasons: string[];       // أسباب التوافق الحقيقية
  details: { label: string; pct: number; weight: number }[]; // تفاصيل كل حقل
}

// مستويات التعليم مرتبة من الأقل للأعلى
const EDUCATION_RANK: Record<string, number> = {
  'أقل من الثانوية': 1,
  'الثانوية العامة': 2,
  'دبلوم': 3,
  'دبلوم عالي': 4,
  'بكالوريوس': 5,
  'ماجستير': 6,
  'دكتوراه': 7,
};

// خريطة الحالة الاجتماعية للقيم الموحدة
function normalizeMarital(status: string): string {
  const s = (status || '').toLowerCase();
  if (s === 'single' || s === 'أعزب/عزباء' || s === 'أعزب' || s === 'عزباء') return 'single';
  if (s === 'divorced' || s === 'مطلق/مطلقة' || s === 'مطلق' || s === 'مطلقة') return 'divorced';
  if (s === 'widower' || s === 'widow' || s === 'أرمل/أرملة' || s === 'أرمل' || s === 'أرملة') return 'widowed';
  if (s === 'married' || s === 'متزوج' || s === 'متزوجة') return 'married';
  return s;
}

// ====================================================================
//  الدالة الرئيسية لحساب التوافق
// ====================================================================
export function calculateCompatibility(
  currentUser: Member,
  target: Member,
  prefs: ProfileData
): CompatResult {
  // 1. التحقق من تطابق الجنس
  const isGenderMatch = currentUser.gender !== target.gender;

  if (!isGenderMatch) {
    return {
      score: 0,
      isGenderMatch: false,
      isEstimated: false,
      reasons: ['غير متطابق في الجنس'],
      details: [],
    };
  }

  // 2. التحقق من عدد حقول مواصفات الشريك المعبأة
  const partnerFields = [
    prefs.pCountry, prefs.pNationality, prefs.pMaritalStatus,
    prefs.pSect, prefs.pReligionLevel, prefs.pSkinColor,
    prefs.pEducation, prefs.pWorkType, prefs.pHousing,
  ];
  const filledPartnerFields = partnerFields.filter(v => v && v.trim().length > 0).length;
  const isEstimated = filledPartnerFields < 3;

  const reasons: string[] = [];
  const details: { label: string; pct: number; weight: number }[] = [];

  // ===== حساب كل حقل =====

  // العمر (15%)
  let agePct = 0;
  const ageMin = prefs.pAgeMin || 22;
  const ageMax = prefs.pAgeMax || 35;
  if (target.age >= ageMin && target.age <= ageMax) {
    agePct = 100;
    reasons.push('ضمن نطاق العمر المطلوب');
  } else {
    const dist = Math.min(Math.abs(target.age - ageMin), Math.abs(target.age - ageMax));
    agePct = dist <= 5 ? 50 : 0;
    if (agePct === 0) reasons.push('خارج نطاق العمر المطلوب');
  }
  details.push({ label: 'العمر', pct: agePct, weight: 15 });

  // الدولة (10%)
  let countryPct = 100;
  if (prefs.pCountry && prefs.pCountry !== 'لا يهم' && prefs.pCountry !== 'لا يهم') {
    if (target.country === prefs.pCountry) {
      countryPct = 100;
      reasons.push('نفس الدولة المطلوبة');
    } else {
      countryPct = 0;
      reasons.push('دولة مختلفة عن المطلوب');
    }
  }
  details.push({ label: 'الدولة', pct: countryPct, weight: 10 });

  // الجنسية (10%)
  let nationalityPct = 100;
  if (prefs.pNationality && prefs.pNationality !== 'لا يهم') {
    if (target.nationality === prefs.pNationality) {
      nationalityPct = 100;
      reasons.push('نفس الجنسية المطلوبة');
    } else {
      nationalityPct = 0;
      reasons.push('جنسية مختلفة عن المطلوب');
    }
  }
  details.push({ label: 'الجنسية', pct: nationalityPct, weight: 10 });

  // المذهب (15%)
  let sectPct = 100;
  const targetSect = target.sect || '';
  if (prefs.pSect && prefs.pSect !== 'لا يهم') {
    if (targetSect === prefs.pSect) {
      sectPct = 100;
      reasons.push('نفس المذهب المطلوب');
    } else {
      sectPct = 0;
      reasons.push('مذهب مختلف عن المطلوب');
    }
  }
  details.push({ label: 'المذهب', pct: sectPct, weight: 15 });

  // مستوى التدين (10%) — لا يوجد حقل مقابل في Member، نعامله كمحايد
  const religionPct = 100;
  details.push({ label: 'مستوى التدين', pct: religionPct, weight: 10 });

  // المؤهل (10%)
  let educationPct = 100;
  if (prefs.pEducation && prefs.pEducation !== 'لا يهم') {
    const prefRank = EDUCATION_RANK[prefs.pEducation] || 0;
    const targetRank = EDUCATION_RANK[target.education] || 0;
    if (targetRank >= prefRank) {
      educationPct = 100;
      reasons.push('مؤهل علمي مطابق أو أعلى');
    } else {
      educationPct = 50;
      reasons.push('مؤهل علمي أقل من المطلوب');
    }
  }
  details.push({ label: 'المؤهل', pct: educationPct, weight: 10 });

  // نوع العمل (5%)
  let workPct = 100;
  if (prefs.pWorkType && prefs.pWorkType !== 'لا يهم') {
    if (target.workType === prefs.pWorkType) {
      workPct = 100;
      reasons.push('نوع عمل مطابق');
    } else {
      workPct = 50;
    }
  }
  details.push({ label: 'نوع العمل', pct: workPct, weight: 5 });

  // لون البشرة (5%)
  let skinPct = 100;
  if (prefs.pSkinColor && prefs.pSkinColor !== 'لا يهم') {
    if (target.skinColor === prefs.pSkinColor) {
      skinPct = 100;
      reasons.push('لون بشرة مطابق');
    } else {
      skinPct = 50;
    }
  }
  details.push({ label: 'لون البشرة', pct: skinPct, weight: 5 });

  // الطول (10%)
  let heightPct = 100;
  if (!prefs.pHeightNoMatter && prefs.pHeight > 0) {
    const diff = Math.abs(target.height - prefs.pHeight);
    if (diff <= 5) {
      heightPct = 100;
      reasons.push('الطول ضمن النطاق المطلوب');
    } else if (diff <= 10) {
      heightPct = 50;
      reasons.push('الطول قريب من المطلوب');
    } else {
      heightPct = 0;
      reasons.push('الطول خارج النطاق المطلوب');
    }
  }
  details.push({ label: 'الطول', pct: heightPct, weight: 10 });

  // الحالة الاجتماعية (10%)
  let maritalPct = 100;
  if (prefs.pMaritalStatus && prefs.pMaritalStatus !== 'لا يهم') {
    const targetNorm = normalizeMarital(target.maritalStatus);
    const prefNorm = normalizeMarital(prefs.pMaritalStatus);
    if (targetNorm === prefNorm) {
      maritalPct = 100;
      reasons.push('الحالة الاجتماعية مطابقة');
    } else {
      maritalPct = 0;
      reasons.push('الحالة الاجتماعية مختلفة');
    }
  }
  details.push({ label: 'الحالة الاجتماعية', pct: maritalPct, weight: 10 });

  // ===== الحساب النهائي =====
  let totalWeight = 0;
  let weightedSum = 0;
  for (const d of details) {
    weightedSum += d.pct * d.weight;
    totalWeight += d.weight;
  }
  const score = totalWeight > 0 ? Math.round((weightedSum / totalWeight)) : 0;

  return {
    score,
    isGenderMatch: true,
    isEstimated,
    reasons: reasons.slice(0, 5),
    details,
  };
}

// ====================================================================
//  ألوان الشارة حسب النسبة
// ====================================================================
export function getCompatBadgeColor(score: number, isGenderMatch: boolean): {
  text: string;
  bg: string;
  stroke: string;
  ring: string;
} {
  if (!isGenderMatch) {
    return {
      text: 'text-navy-400',
      bg: 'bg-navy-100 bg-navy-900/5',
      stroke: '#9ca3af',
      ring: 'ring-navy-200',
    };
  }
  if (score >= 80) {
    return {
      text: 'text-emerald-600',
      bg: 'bg-emerald-50',
      stroke: '#059669',
      ring: 'ring-emerald-200',
    };
  }
  if (score >= 60) {
    return {
      text: 'text-gold-600',
      bg: 'bg-gold-300/15',
      stroke: '#c9a961',
      ring: 'ring-gold-300',
    };
  }
  return {
    text: 'text-rose-deep',
    bg: 'bg-rose-50',
    stroke: '#c97b7f',
    ring: 'ring-rose-200',
  };
}

// تسمية مستوى التوافق
export function getCompatLabel(score: number, isGenderMatch: boolean): string {
  if (!isGenderMatch) return 'غير متطابق';
  if (score >= 80) return 'توافق عالي';
  if (score >= 60) return 'توافق متوسط';
  return 'توافق منخفض';
}

// ====================================================================
//  مطابقة مواصفات الشريك بدون نسبة مئوية (نعم / جزئي / لا)
// ====================================================================
export type FitStatus = 'yes' | 'partial' | 'no' | 'na';
export interface PartnerFitItem {
  key: string;
  label: string;
  status: FitStatus;
  detail: string;
}

export function evaluatePartnerFit(target: Member, prefs: Partial<ProfileData> | any): PartnerFitItem[] {
  const items: PartnerFitItem[] = [];
  const push = (key: string, label: string, status: FitStatus, detail: string) => {
    items.push({ key, label, status, detail });
  };

  // العمر
  const ageMin = Number(prefs.pAgeMin || 0);
  const ageMax = Number(prefs.pAgeMax || 0);
  if (ageMin || ageMax) {
    const age = Number(target.age || 0);
    if (age && age >= (ageMin || 0) && age <= (ageMax || 120)) push('age', 'العمر', 'yes', `${age} ضمن ${ageMin || '—'}-${ageMax || '—'}`);
    else if (age) {
      const dist = Math.min(Math.abs(age - (ageMin || age)), Math.abs(age - (ageMax || age)));
      push('age', 'العمر', dist <= 3 ? 'partial' : 'no', `${age} خارج النطاق المطلوب`);
    } else push('age', 'العمر', 'na', 'غير متوفر');
  } else push('age', 'العمر', 'na', 'لا تفضيل محدد');

  // الدولة
  if (prefs.pCountry && prefs.pCountry !== 'لا يهم') {
    push('country', 'الدولة', target.country === prefs.pCountry ? 'yes' : 'no', target.country || '—');
  } else push('country', 'الدولة', 'na', 'لا يهم');

  // المدينة
  if (prefs.pCity && prefs.pCity !== 'لا يهم') {
    push('city', 'المدينة', target.city === prefs.pCity ? 'yes' : 'partial', target.city || '—');
  } else push('city', 'المدينة', 'na', 'لا يهم');

  // الجنسية
  if (prefs.pNationality && prefs.pNationality !== 'لا يهم' && prefs.pNationality !== 'نفس جنسيتي') {
    push('nationality', 'الجنسية', target.nationality === prefs.pNationality ? 'yes' : 'no', target.nationality || '—');
  } else push('nationality', 'الجنسية', 'na', 'لا يهم');

  // الحالة الاجتماعية
  if (prefs.pMaritalStatus && prefs.pMaritalStatus !== 'لا يهم') {
    const t = normalizeMarital(String(target.maritalStatus || ''));
    const p = normalizeMarital(String(prefs.pMaritalStatus || ''));
    const ok = t === p || String(target.maritalStatus) === String(prefs.pMaritalStatus) || String((target as any).maritalLabel || '').includes(String(prefs.pMaritalStatus));
    push('marital', 'الحالة الاجتماعية', ok ? 'yes' : 'no', String((target as any).maritalLabel || target.maritalStatus || '—'));
  } else push('marital', 'الحالة الاجتماعية', 'na', 'لا يهم');

  // الأبناء
  if (prefs.pAcceptChildren && prefs.pAcceptChildren !== 'لا يهم') {
    const has = !!(target as any).hasChildren;
    if (prefs.pAcceptChildren === 'yes' || prefs.pAcceptChildren === 'نعم') push('children', 'الأبناء', 'yes', has ? 'لديه أبناء' : 'بدون أبناء');
    else if (prefs.pAcceptChildren === 'no' || prefs.pAcceptChildren === 'لا') push('children', 'الأبناء', has ? 'no' : 'yes', has ? 'لديه أبناء' : 'بدون أبناء');
    else push('children', 'الأبناء', 'partial', 'مشروط');
  } else push('children', 'الأبناء', 'na', 'لا يهم');

  // التعليم
  if (prefs.pEducation && prefs.pEducation !== 'لا يهم') {
    const ok = (target.education || '') === prefs.pEducation || (target.education || '').includes(String(prefs.pEducation));
    push('education', 'التعليم', ok ? 'yes' : 'partial', target.education || '—');
  } else push('education', 'التعليم', 'na', 'لا يهم');

  // السكن
  if (prefs.pHousing && prefs.pHousing !== 'لا يهم') {
    const ok = ((target as any).housing || '') === prefs.pHousing;
    push('housing', 'السكن', ok ? 'yes' : 'partial', (target as any).housing || '—');
  } else push('housing', 'السكن', 'na', 'لا يهم');

  return items;
}

export function summarizePartnerFit(items: PartnerFitItem[]) {
  const relevant = items.filter((i) => i.status !== 'na');
  const yes = relevant.filter((i) => i.status === 'yes').length;
  const no = relevant.filter((i) => i.status === 'no').length;
  const partial = relevant.filter((i) => i.status === 'partial').length;
  return { yes, no, partial, total: relevant.length };
}
