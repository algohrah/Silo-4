const TOKEN_KEY = 'twafok_admin_token';
const ADMIN_KEY = 'twafok_admin_profile';

export type AdminProfile = {
  id: string;
  email: string;
  username?: string;
  role: string;
};

export function getAdminToken(): string {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY) || '';
}

export function getAdminProfile(): AdminProfile | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(ADMIN_KEY) || sessionStorage.getItem(ADMIN_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setAdminSession(token: string, admin: AdminProfile, remember = true) {
  const store = remember ? localStorage : sessionStorage;
  const other = remember ? sessionStorage : localStorage;
  store.setItem(TOKEN_KEY, token);
  store.setItem(ADMIN_KEY, JSON.stringify(admin));
  // backward compatible flag
  store.setItem('twafok_admin_authenticated', 'true');
  other.removeItem(TOKEN_KEY);
  other.removeItem(ADMIN_KEY);
  other.removeItem('twafok_admin_authenticated');
}

export function clearAdminSession() {
  [localStorage, sessionStorage].forEach((s) => {
    s.removeItem(TOKEN_KEY);
    s.removeItem(ADMIN_KEY);
    s.removeItem('twafok_admin_authenticated');
  });
}

export function adminAuthHeaders(extra: Record<string, string> = {}): Record<string, string> {
  const token = getAdminToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}`, 'X-Admin-Token': token } : {}),
    ...extra,
  };
}

export async function adminLogin(email: string, password: string) {
  const res = await fetch('/api/admin-auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'login', email, password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل تسجيل الدخول');
  setAdminSession(data.token, data.admin, true);
  return data;
}

export async function adminLogout() {
  try {
    await fetch('/api/admin-auth', {
      method: 'POST',
      headers: adminAuthHeaders(),
      body: JSON.stringify({ action: 'logout' }),
    });
  } catch {}
  clearAdminSession();
}

export async function verifyAdminSession(): Promise<AdminProfile | null> {
  const token = getAdminToken();
  if (!token) return null;
  try {
    const res = await fetch('/api/admin-auth', { headers: adminAuthHeaders() });
    if (!res.ok) {
      clearAdminSession();
      return null;
    }
    const data = await res.json();
    if (!data.authenticated) {
      clearAdminSession();
      return null;
    }
    return data.admin as AdminProfile;
  } catch {
    return getAdminProfile();
  }
}

export async function fetchAdminInbox() {
  const res = await fetch('/api/inbox', { headers: adminAuthHeaders() });
  if (!res.ok) throw new Error('تعذّر تحميل صندوق العمل');
  return res.json();
}

export async function writeAdminAudit(action: string, entityType = '', entityId = '', details: any = {}) {
  try {
    await fetch('/api/audit-logs', {
      method: 'POST',
      headers: adminAuthHeaders(),
      body: JSON.stringify({ action, entityType, entityId, details }),
    });
  } catch {}
}
