import { useCallback, useEffect, useMemo, useState } from 'react';
import { CreditCard, Search, ArrowDownLeft, Clock, CheckCircle2, XCircle, Download, Gift, ShieldCheck, MessageSquare, Gem, Tag, Loader2, RefreshCw } from 'lucide-react';
import FilterDropdown from '../../components/admin/FilterDropdown';
import { adminAuthHeaders } from '../../lib/adminAuth';

type Tx = {
  id: number | string;
  user_id?: string;
  amount?: number;
  type?: string;
  description?: string;
  status?: string;
  metadata?: any;
  created_at?: string;
};

const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
  completed: { label: 'ناجح', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle2 },
  pending: { label: 'معلق', color: 'bg-amber-100 text-amber-700', icon: Clock },
  failed: { label: 'مرفوض/فاشل', color: 'bg-rose-100 text-rose-700', icon: XCircle },
  refunded: { label: 'مسترد', color: 'bg-slate-100 text-slate-600', icon: ArrowDownLeft },
};

const typeConfig: Record<string, { label: string; icon: any; color: string }> = {
  subscription: { label: 'اشتراك', icon: CreditCard, color: 'text-purple-600' },
  deposit: { label: 'رسوم جدية', icon: ShieldCheck, color: 'text-amber-600' },
  inquiry: { label: 'باقة استفسار', icon: MessageSquare, color: 'text-sky-600' },
  final: { label: 'رسوم سعي', icon: Gem, color: 'text-emerald-600' },
  exemption: { label: 'إعفاء/وسام', icon: Gift, color: 'text-blue-600' },
  coupon: { label: 'كوبون', icon: Tag, color: 'text-rose-600' },
  payment: { label: 'دفعة', icon: CreditCard, color: 'text-slate-600' },
};

export default function AdminTransactions() {
  const [transactions, setTransactions] = useState<Tx[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | number | null>(null);
  const [toast, setToast] = useState('');
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/transactions?admin=true', { headers: adminAuthHeaders() });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل التحميل');
      setTransactions(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setToast(e.message || 'تعذّر تحميل المعاملات');
      setTransactions([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return transactions.filter((t) => {
      const meta = t.metadata || {};
      const hay = [t.description, t.user_id, t.type, meta.method, meta.senderName, String(t.id)].filter(Boolean).join(' ').toLowerCase();
      const matchSearch = !q || hay.includes(q);
      const matchStatus = filterStatus === 'all' || t.status === filterStatus;
      const matchType = filterType === 'all' || t.type === filterType;
      return matchSearch && matchStatus && matchType;
    });
  }, [transactions, search, filterStatus, filterType]);

  const stats = useMemo(() => ({
    total: transactions.filter((t) => t.status === 'completed').reduce((s, t) => s + Number(t.amount || 0), 0),
    count: transactions.length,
    pending: transactions.filter((t) => t.status === 'pending').length,
    deposits: transactions.filter((t) => t.type === 'deposit' && t.status === 'completed').length,
  }), [transactions]);

  const review = async (id: string | number, action: 'approve' | 'reject') => {
    const reason = action === 'reject' ? (window.prompt('سبب الرفض (اختياري):') || 'مرفوض من الإدارة') : undefined;
    setBusyId(id);
    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: adminAuthHeaders(),
        body: JSON.stringify({ action, id, reason }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل الإجراء');
      setToast(action === 'approve' ? 'تمت الموافقة وتفعيل الأثر المالي ✓' : 'تم رفض المعاملة');
      await load();
    } catch (e: any) {
      setToast(e.message || 'فشل الإجراء');
    } finally {
      setBusyId(null);
    }
  };

  const handleExport = () => {
    const headers = ['المعرف', 'العضو', 'الوصف', 'المبلغ', 'النوع', 'الحالة', 'التاريخ'];
    const rows = filtered.map((t) => [
      t.id,
      t.user_id || '',
      t.description || '',
      t.amount || 0,
      t.type || '',
      t.status || '',
      t.created_at ? new Date(t.created_at).toLocaleString('ar-SA') : '',
    ]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transactions-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-500" /> المعاملات المالية
          </h2>
          <p className="text-sm text-slate-500 font-tajawal">مراجعة المدفوعات المعلّقة وتفعيل الاشتراكات/الجدية بعد التحقق</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-slate-200 font-cairo font-semibold text-sm">
            <RefreshCw className="w-4 h-4" /> تحديث
          </button>
          <button onClick={handleExport} className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-semibold text-sm">
            <Download className="w-4 h-4" /> تصدير ({filtered.length})
          </button>
        </div>
      </div>

      {toast && (
        <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl px-3 py-2 text-sm font-tajawal">{toast}</div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'إيرادات مكتملة', value: `${stats.total.toLocaleString('ar-SA')} ر.س`, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'كل المعاملات', value: stats.count, color: 'text-slate-700', bg: 'bg-slate-50' },
          { label: 'معلّقة بانتظارك', value: stats.pending, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'رسوم جدية ناجحة', value: stats.deposits, color: 'text-blue-600', bg: 'bg-blue-50' },
        ].map((s) => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-3`}>
            <p className={`font-cairo font-extrabold text-xl ${s.color}`}>{s.value}</p>
            <p className="text-[11px] text-slate-500 font-cairo">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث بالوصف أو معرف العضو..." className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal" />
        </div>
        <div className="flex flex-wrap gap-2">
          <FilterDropdown label="الحالة:" value={filterStatus} onChange={setFilterStatus} options={[{ value: 'all', label: 'الكل' }, ...Object.entries(statusConfig).map(([k, v]) => ({ value: k, label: v.label }))]} />
          <FilterDropdown label="النوع:" value={filterType} onChange={setFilterType} options={[{ value: 'all', label: 'الكل' }, ...Object.entries(typeConfig).map(([k, v]) => ({ value: k, label: v.label }))]} />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16 text-slate-400"><Loader2 className="w-8 h-8 animate-spin" /></div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-500 font-tajawal">لا توجد معاملات مطابقة</div>
      ) : (
        <div className="space-y-2">
          {filtered.map((t) => {
            const cfg = statusConfig[t.status || 'pending'] || statusConfig.pending;
            const tcfg = typeConfig[t.type || 'payment'] || typeConfig.payment;
            const Icon = tcfg.icon;
            const meta = t.metadata || {};
            return (
              <div key={t.id} className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col lg:flex-row lg:items-center gap-3">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className={`w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center ${tcfg.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-cairo font-bold text-slate-900 text-sm">{t.description || tcfg.label}</h3>
                      <span className={`text-[10px] font-cairo font-bold px-2 py-0.5 rounded-md ${cfg.color}`}>{cfg.label}</span>
                      <span className="text-[10px] font-cairo px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">{tcfg.label}</span>
                    </div>
                    <p className="text-xs text-slate-500 font-tajawal mt-1">
                      العضو: {t.user_id || '—'} · {Number(t.amount || 0).toLocaleString('ar-SA')} ر.س
                      {meta.method ? ` · ${meta.method}` : ''}
                      {meta.senderName ? ` · ${meta.senderName}` : ''}
                    </p>
                    {t.created_at && <p className="text-[11px] text-slate-400 font-tajawal mt-0.5">{new Date(t.created_at).toLocaleString('ar-SA')}</p>}
                    {meta.cryptoTxid && <p className="text-[11px] text-slate-500 font-mono mt-1">TXID: {meta.cryptoTxid}</p>}
                  </div>
                </div>
                {t.status === 'pending' && (
                  <div className="flex gap-2">
                    <button disabled={busyId === t.id} onClick={() => review(t.id, 'approve')} className="px-3 py-2 rounded-xl bg-emerald-600 text-white text-xs font-cairo font-bold hover:bg-emerald-700 disabled:opacity-60">
                      {busyId === t.id ? '...' : 'موافقة وتفعيل'}
                    </button>
                    <button disabled={busyId === t.id} onClick={() => review(t.id, 'reject')} className="px-3 py-2 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-cairo font-bold disabled:opacity-60">
                      رفض
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
