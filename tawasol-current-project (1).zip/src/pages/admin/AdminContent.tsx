import { useEffect, useState } from 'react';
import { FileText, Plus, Edit3, Trash2, HelpCircle, Save, Loader2 } from 'lucide-react';
import { adminAuthHeaders } from '../../lib/adminAuth';

type BlogPost = {
  id: string;
  title: string;
  excerpt?: string;
  content?: string;
  category?: string;
  author?: string;
  read_time?: string;
  is_published?: boolean;
};

type Faq = {
  id: string;
  question: string;
  answer: string;
  category?: string;
  sort_order?: number;
  is_published?: boolean;
};

export default function AdminContent() {
  const [tab, setTab] = useState<'blog' | 'faq'>('blog');
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [faqs, setFaqs] = useState<Faq[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  const [blogForm, setBlogForm] = useState<BlogPost>({
    id: '', title: '', excerpt: '', content: '', category: 'نصائح', author: 'فريق تواصل', read_time: '5 دقائق', is_published: true,
  });
  const [faqForm, setFaqForm] = useState<Faq>({
    id: '', question: '', answer: '', category: 'عام', sort_order: 0, is_published: true,
  });

  const load = async () => {
    setLoading(true);
    try {
      const [b, f] = await Promise.all([
        fetch('/api/content?type=blog&all=1', { headers: adminAuthHeaders() }).then((r) => r.json()),
        fetch('/api/content?type=faq&all=1', { headers: adminAuthHeaders() }).then((r) => r.json()),
      ]);
      setPosts(Array.isArray(b) ? b : []);
      setFaqs(Array.isArray(f) ? f : []);
    } catch {
      setPosts([]);
      setFaqs([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const saveBlog = async () => {
    if (!blogForm.title.trim()) return setMsg('عنوان المقال مطلوب');
    setSaving(true);
    try {
      const res = await fetch('/api/content', {
        method: 'POST',
        headers: adminAuthHeaders(),
        body: JSON.stringify({ type: 'blog', ...blogForm, id: blogForm.id || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل الحفظ');
      setMsg('تم حفظ المقال');
      setBlogForm({ id: '', title: '', excerpt: '', content: '', category: 'نصائح', author: 'فريق تواصل', read_time: '5 دقائق', is_published: true });
      await load();
    } catch (e: any) {
      setMsg(e.message || 'فشل الحفظ');
    } finally {
      setSaving(false);
    }
  };

  const saveFaq = async () => {
    if (!faqForm.question.trim() || !faqForm.answer.trim()) return setMsg('السؤال والإجابة مطلوبان');
    setSaving(true);
    try {
      const res = await fetch('/api/content', {
        method: 'POST',
        headers: adminAuthHeaders(),
        body: JSON.stringify({ type: 'faq', ...faqForm, id: faqForm.id || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل الحفظ');
      setMsg('تم حفظ السؤال');
      setFaqForm({ id: '', question: '', answer: '', category: 'عام', sort_order: 0, is_published: true });
      await load();
    } catch (e: any) {
      setMsg(e.message || 'فشل الحفظ');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (type: 'blog' | 'faq', id: string) => {
    if (!confirm('حذف العنصر؟')) return;
    await fetch('/api/content', {
      method: 'DELETE',
      headers: adminAuthHeaders(),
      body: JSON.stringify({ type, id }),
    });
    await load();
  };

  const input = 'w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-tajawal focus:outline-none focus:border-amber-400';

  return (
    <div className="space-y-5" dir="rtl">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          <FileText className="w-5 h-5 text-amber-500" /> المحتوى (مدونة + أسئلة شائعة)
        </h2>
        <p className="text-sm text-slate-500 font-tajawal">يظهر مباشرة في صفحات /blog و /faq للزوّار</p>
      </div>

      <div className="flex gap-2">
        <button type="button" onClick={() => setTab('blog')} className={`px-4 py-2 rounded-xl text-sm font-cairo font-bold ${tab === 'blog' ? 'bg-amber-500 text-white' : 'bg-white border border-slate-200 text-slate-700'}`}>المدونة</button>
        <button type="button" onClick={() => setTab('faq')} className={`px-4 py-2 rounded-xl text-sm font-cairo font-bold ${tab === 'faq' ? 'bg-amber-500 text-white' : 'bg-white border border-slate-200 text-slate-700'}`}>الأسئلة الشائعة</button>
      </div>

      {msg && <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl px-3 py-2 text-sm font-tajawal">{msg}</div>}

      {loading ? (
        <div className="flex justify-center py-16 text-slate-400"><Loader2 className="w-8 h-8 animate-spin" /></div>
      ) : tab === 'blog' ? (
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
            <h3 className="font-cairo font-bold text-slate-900 flex items-center gap-2"><Plus className="w-4 h-4" /> {blogForm.id ? 'تعديل مقال' : 'مقال جديد'}</h3>
            <input className={input} placeholder="العنوان" value={blogForm.title} onChange={(e) => setBlogForm({ ...blogForm, title: e.target.value })} />
            <input className={input} placeholder="مقتطف قصير" value={blogForm.excerpt || ''} onChange={(e) => setBlogForm({ ...blogForm, excerpt: e.target.value })} />
            <textarea className={input + ' min-h-32'} placeholder="المحتوى" value={blogForm.content || ''} onChange={(e) => setBlogForm({ ...blogForm, content: e.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <input className={input} placeholder="التصنيف" value={blogForm.category || ''} onChange={(e) => setBlogForm({ ...blogForm, category: e.target.value })} />
              <input className={input} placeholder="وقت القراءة" value={blogForm.read_time || ''} onChange={(e) => setBlogForm({ ...blogForm, read_time: e.target.value })} />
            </div>
            <label className="flex items-center gap-2 text-sm font-cairo text-slate-700">
              <input type="checkbox" checked={!!blogForm.is_published} onChange={(e) => setBlogForm({ ...blogForm, is_published: e.target.checked })} /> منشور
            </label>
            <button type="button" disabled={saving} onClick={saveBlog} className="w-full py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm flex items-center justify-center gap-2">
              <Save className="w-4 h-4" /> {saving ? 'جاري الحفظ...' : 'حفظ المقال'}
            </button>
          </div>
          <div className="space-y-2">
            {posts.map((p) => (
              <div key={p.id} className="bg-white rounded-2xl border border-slate-200 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-cairo font-bold text-slate-900">{p.title}</h4>
                    <p className="text-xs text-slate-500 font-tajawal mt-1 line-clamp-2">{p.excerpt}</p>
                  </div>
                  <div className="flex gap-1">
                    <button type="button" onClick={() => setBlogForm({ ...p, read_time: p.read_time || '5 دقائق' })} className="p-2 rounded-lg bg-amber-50 text-amber-700"><Edit3 className="w-4 h-4" /></button>
                    <button type="button" onClick={() => remove('blog', p.id)} className="p-2 rounded-lg bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
            <h3 className="font-cairo font-bold text-slate-900 flex items-center gap-2"><HelpCircle className="w-4 h-4" /> {faqForm.id ? 'تعديل سؤال' : 'سؤال جديد'}</h3>
            <input className={input} placeholder="السؤال" value={faqForm.question} onChange={(e) => setFaqForm({ ...faqForm, question: e.target.value })} />
            <textarea className={input + ' min-h-28'} placeholder="الإجابة" value={faqForm.answer} onChange={(e) => setFaqForm({ ...faqForm, answer: e.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <input className={input} placeholder="التصنيف" value={faqForm.category || ''} onChange={(e) => setFaqForm({ ...faqForm, category: e.target.value })} />
              <input className={input} type="number" placeholder="الترتيب" value={faqForm.sort_order || 0} onChange={(e) => setFaqForm({ ...faqForm, sort_order: Number(e.target.value) })} />
            </div>
            <button type="button" disabled={saving} onClick={saveFaq} className="w-full py-2.5 rounded-xl bg-slate-900 text-white font-cairo font-bold text-sm flex items-center justify-center gap-2">
              <Save className="w-4 h-4" /> {saving ? 'جاري الحفظ...' : 'حفظ السؤال'}
            </button>
          </div>
          <div className="space-y-2">
            {faqs.map((f) => (
              <div key={f.id} className="bg-white rounded-2xl border border-slate-200 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-cairo font-bold text-slate-900">{f.question}</h4>
                    <p className="text-xs text-slate-500 font-tajawal mt-1 line-clamp-2">{f.answer}</p>
                  </div>
                  <div className="flex gap-1">
                    <button type="button" onClick={() => setFaqForm(f)} className="p-2 rounded-lg bg-amber-50 text-amber-700"><Edit3 className="w-4 h-4" /></button>
                    <button type="button" onClick={() => remove('faq', f.id)} className="p-2 rounded-lg bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
