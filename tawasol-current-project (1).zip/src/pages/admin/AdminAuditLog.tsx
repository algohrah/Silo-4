import { useEffect, useMemo, useState } from 'react';
import { ClipboardList, Search, ShieldCheck, Loader2 } from 'lucide-react';
import { adminAuthHeaders } from '../../lib/adminAuth';

type AuditRow = {
  id: number;
  actor_id?: string;
  actor_email?: string;
  actor_role?: string;
  action?: string;
  entity_type?: string;
  entity_id?: string;
  details?: any;
  created_at?: string;
};

const actionLabel: Record<string, string> = {
  admin_login: 'دخول لوحة الإدارة',
  admin_login_failed: 'محاولة دخول فاشلة',
  admin_update_member: 'تعديل عضو',
  admin_reset_password: 'إعادة تعيين كلمة مرور',
  member_login: 'دخول عضو',
  member_password_change: 'تغيير كلمة مرور عضو',
  impersonate_start: 'بدء انتحال هوية',
  impersonate_end: 'إنهاء انتحال هوية',
};

export default function AdminAuditLog() {
  const [logs, setLogs] = useState<AuditRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/audit-logs?limit=200', { headers: adminAuthHeaders() });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل التحميل');
        setLogs(Array.isArray(data) ? data : []);
      } catch (e: any) {
        setError(e.message || 'تعذّر تحميل السجل');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return logs;
    return logs.filter((l) =>
      [l.action, l.actor_email, l.entity_type, l.entity_id, l.actor_role]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q))
    );
  }, [logs, search]);

  return (
    <div className="space-y-5" dir="rtl">
      <div>
        <h2 className="font-cairo font-bold text-xl text-slate-900 flex items-center gap-2">
          <ClipboardList className="w-5 h-5 text-amber-500" /> سجل التدقيق
        </h2>
        <p className="text-sm text-slate-500 font-tajawal">سجل حقيقي للإجراءات الإدارية والحساسة على المنصة</p>
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالإجراء أو البريد أو المعرف..."
            className="w-full pr-12 pl-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none font-tajawal text-slate-900"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16 text-slate-400"><Loader2 className="w-8 h-8 animate-spin" /></div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl p-4 font-cairo text-sm">{error}</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center text-slate-500 font-tajawal">
          لا توجد سجلات بعد. ستظهر هنا عمليات الدخول وتعديل الأعضاء وإعادة التعيين.
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="divide-y divide-slate-100">
            {filtered.map((log) => (
              <div key={log.id} className="p-4 flex items-start gap-3 hover:bg-slate-50/80">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center flex-shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-cairo font-bold text-slate-900 text-sm">
                      {actionLabel[log.action || ''] || log.action || 'إجراء'}
                    </span>
                    {log.entity_type && (
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-cairo">
                        {log.entity_type}{log.entity_id ? ` #${log.entity_id}` : ''}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 font-tajawal mt-1">
                    بواسطة {log.actor_email || log.actor_id || 'نظام'} · {log.actor_role || '—'}
                  </p>
                  {log.created_at && (
                    <p className="text-[11px] text-slate-400 font-tajawal mt-1">
                      {new Date(log.created_at).toLocaleString('ar-SA')}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
