import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, HelpCircle, Loader2, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

type Faq = { id: string; question: string; answer: string; category?: string };

export default function FaqPage() {
  const [items, setItems] = useState<Faq[]>([]);
  const [loading, setLoading] = useState(true);
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/content?type=faq')
      .then((r) => r.json())
      .then((d) => setItems(Array.isArray(d) ? d : []))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-cream-50" dir="rtl">
      <section className="bg-navy-gradient text-white py-14 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-1.5 rounded-full text-sm mb-4">
            <HelpCircle className="w-4 h-4 text-amber-300" /> مركز المساعدة
          </div>
          <h1 className="font-cairo font-black text-3xl sm:text-4xl mb-3">الأسئلة الشائعة</h1>
          <p className="text-cream-100/80 font-tajawal leading-relaxed">
            إجابات واضحة عن التسجيل، الوساطة الشرعية، الخصوصية، ورسوم إثبات الجدية.
          </p>
        </div>
      </section>

      <div className="max-w-3xl mx-auto px-4 py-10">
        {loading ? (
          <div className="flex justify-center py-16 text-navy-500"><Loader2 className="w-8 h-8 animate-spin" /></div>
        ) : items.length === 0 ? (
          <div className="bg-white rounded-3xl border border-cream-200 p-8 text-center">
            <p className="font-cairo text-navy-700 mb-4">لا توجد أسئلة منشورة حالياً.</p>
            <Link to="/contact" className="text-amber-700 font-bold">تواصل معنا</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => {
              const open = openId === item.id;
              return (
                <div key={item.id} className="bg-white rounded-2xl border border-cream-200 shadow-sm overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setOpenId(open ? null : item.id)}
                    className="w-full flex items-center justify-between gap-3 p-4 text-right"
                  >
                    <span className="font-cairo font-bold text-navy-900">{item.question}</span>
                    <ChevronDown className={`w-5 h-5 text-navy-400 transition-transform ${open ? 'rotate-180' : ''}`} />
                  </button>
                  <AnimatePresence>
                    {open && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="px-4 pb-4 text-sm text-navy-600 font-tajawal leading-relaxed border-t border-cream-100 pt-3">
                          {item.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-10 bg-navy-900 text-white rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="font-cairo font-bold text-lg">لم تجد إجابتك؟</p>
            <p className="text-sm text-cream-200/80 font-tajawal">فريق الوساطة جاهز لمساعدتك.</p>
          </div>
          <Link to="/contact" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 text-navy-950 font-cairo font-bold">
            <MessageCircle className="w-4 h-4" /> تواصل معنا
          </Link>
        </div>
      </div>
    </div>
  );
}
