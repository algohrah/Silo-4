import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowRight, BookOpen, Loader2 } from 'lucide-react';

type Post = {
  id: string;
  title: string;
  excerpt?: string;
  content?: string;
  category?: string;
  author?: string;
  image?: string;
  read_time?: string;
  created_at?: string;
};

export default function BlogPage() {
  const { id } = useParams();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/content?type=blog')
      .then((r) => r.json())
      .then((d) => setPosts(Array.isArray(d) ? d : []))
      .catch(() => setPosts([]))
      .finally(() => setLoading(false));
  }, []);

  const selected = id ? posts.find((p) => p.id === id) : null;

  if (loading) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center text-navy-500">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (selected) {
    return (
      <div className="min-h-screen bg-cream-50" dir="rtl">
        <div className="max-w-3xl mx-auto px-4 py-10">
          <Link to="/blog" className="inline-flex items-center gap-2 text-sm text-navy-600 hover:text-amber-700 font-cairo mb-6">
            <ArrowRight className="w-4 h-4" /> العودة للمقالات
          </Link>
          <div className="bg-white rounded-3xl border border-cream-200 p-6 sm:p-8 shadow-sm">
            <span className="text-xs font-cairo text-amber-700 bg-amber-50 px-3 py-1 rounded-full">{selected.category || 'مقال'}</span>
            <h1 className="font-cairo font-black text-2xl sm:text-3xl text-navy-900 mt-3 mb-2">{selected.title}</h1>
            <p className="text-xs text-navy-400 font-tajawal mb-6">
              {selected.author || 'فريق تواصل'} · {selected.read_time || '5 دقائق'}
            </p>
            <div className="prose prose-sm max-w-none font-tajawal text-navy-700 leading-8 whitespace-pre-wrap">
              {selected.content || selected.excerpt}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream-50" dir="rtl">
      <section className="bg-navy-gradient text-white py-14 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-1.5 rounded-full text-sm mb-4">
            <BookOpen className="w-4 h-4 text-amber-300" /> مدونة تواصل
          </div>
          <h1 className="font-cairo font-black text-3xl sm:text-4xl mb-3">مقالات ونصائح للزواج الجاد</h1>
          <p className="text-cream-100/80 font-tajawal">محتوى توعوي حول الاختيار، الوساطة، والخصوصية.</p>
        </div>
      </section>
      <div className="max-w-5xl mx-auto px-4 py-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {posts.length === 0 ? (
          <div className="col-span-full bg-white rounded-3xl border border-cream-200 p-8 text-center font-cairo text-navy-600">
            لا توجد مقالات منشورة بعد.
          </div>
        ) : posts.map((post) => (
          <Link
            key={post.id}
            to={`/blog/${post.id}`}
            className="bg-white rounded-3xl border border-cream-200 p-5 shadow-sm hover:shadow-md hover:border-amber-300 transition-all"
          >
            <span className="text-[11px] font-cairo text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full">{post.category || 'نصائح'}</span>
            <h2 className="font-cairo font-extrabold text-navy-900 mt-3 mb-2 line-clamp-2">{post.title}</h2>
            <p className="text-sm text-navy-500 font-tajawal line-clamp-3">{post.excerpt}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
