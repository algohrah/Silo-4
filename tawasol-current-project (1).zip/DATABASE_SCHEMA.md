# هيكل قاعدة البيانات المحسّن — منصة تواصل / توافق

> **الغرض:** مرجع كامل لاستيراد المشروع وإعادة إنشاء قاعدة Supabase بنفس الخيارات دون أخطاء.
> **آخر تحديث:** 2026-08-08 (بعد دفعات الأمان / الوساطة / المحتوى / المدفوعات)

---

## 0) ملخص سريع

| البند | القيمة |
|------|--------|
| محرك DB | Supabase (Postgres) |
| وصول الخادم | Vercel API في `api/*` عبر `api/db-client.js` (Service Role) |
| الوصول العام من الواجهة | عبر `/api/*` فقط (لا تُكتب مفاتيح Service Role في الفرونت) |
| Storage | bucket عام: `verification-docs` |
| تشفير كلمات المرور | SHA-256 مع ملح ثابت `tawasul_v1:` (انظر `api/auth-helpers.js`) |
| جلسات الإدارة | جدول `admin_sessions` + توكن Bearer / `X-Admin-Token` |

### ملفات مرتبطة بالاستيراد
- `DATABASE_SCHEMA.md` — هذا الملف (بشري + AI)
- `database/schema.json` — تعريف أعمدة قابل للقراءة آلياً
- `database/seed.sql` — DDL + بذور أولية (SQL خام لـ Supabase SQL Editor)
- `PROJECT_EXPORT_NOTES.txt` — ملاحظات التشغيل

---

## 1) بيانات الدخول الافتراضية (بيئة تجريبية)

### لوحة الإدارة
- المسار: `/admin`
- البريد: `algohrah4u@gmail.com`
- كلمة المرور: `12345678`
- التخزين: `admin_users.password` مشفّرة، الجلسة في `admin_sessions`
- التوكن يُحفظ في المتصفح: `twafok_admin_token`

### أعضاء تجريبيون (بعد البذر)
- `fares@example.com` / `password123`
- `noura@example.com` / `password123`
- `demo@tawasul.sa` / `password123`

> **مهم:** لا تُعرض كلمات المرور في API. إعادة التعيين عبر `/api/member-auth` action=`admin_reset_password`.

---

## 2) قائمة الجداول (22 جدول)

### أساسية
1. `members`
2. `admin_users`
3. `admin_sessions`
4. `interest_requests`
5. `request_assignments`
6. `notifications`
7. `inquiry_messages`
8. `transactions`
9. `coupons`
10. `support_tickets`
11. `verification_docs`
12. `member_reports`
13. `exemption_requests`

### جغرافيا
14. `geo_countries`
15. `geo_cities`
16. `pending_cities`
17. `geo_nationalities`
18. `geo_suggestions`

### محتوى وإعدادات وتشغيل
19. `settings`
20. `faq_items`
21. `blog_posts`
22. `registration_drafts`
23. `audit_logs`

### Storage
- Bucket: `verification-docs` (public)

---

## 3) تعريف الأعمدة بالتفصيل

### 3.1 `members` (أعضاء المنصة)
| العمود | النوع | ملاحظات |
|--------|------|---------|
| id | text PK | مثل `m1` أو uuid نصي |
| nickname | text | الاسم المستعار (عام) |
| username | text | اختياري |
| gender | text | `male` \| `female` |
| age | integer | |
| country, city, district | text | |
| nationality | text | |
| sect | text | |
| marital_status | text | `single/divorced/widow/widower/married` |
| marital_label | text | تسمية عربية |
| has_children | boolean | |
| children_count | text | |
| height, weight | integer | |
| skin_color, health, smoking, ethnicity | text | |
| education, work_type, job_title, housing | text | |
| bio | text | |
| about_partner | text | ملاحظات الشريك (مختصر) |
| verified, premium, online | boolean | |
| last_active | text | |
| match_score | integer | **لا تُعرض في الواجهة** |
| has_seriousness_badge | boolean | |
| plan | text | `free` \| `gold` \| `elite` |
| pinned | boolean | |
| status | text | `active` \| `pending` \| `suspended` \| `banned` |
| status_reason, status_by | text | |
| notes | text | ملاحظة إدارية |
| flagged | boolean | |
| source_type | text | `registered` \| `imported` |
| import_batch_id, import_office_name, import_date, import_notes | text | |
| real_name, email, phone, whatsapp | text | **حساس — للإدارة** |
| password | text | **مشفّر hash — لا يُرجع في API** |
| birth_date | text | YYYY-MM-DD |
| is_profile_incomplete | boolean | |
| **details** | **jsonb** | **مواصفات الشريك + حقول إضافية** |
| created_at, updated_at | timestamptz | default now() |

#### محتوى `members.details` (jsonb) — حقول الواجهة
```json
{
  "sectOther": "",
  "nationalityMode": "same|other",
  "nationalityOther": "",
  "childrenLiveWith": "yes|no",
  "wifeCount": "1|2|3",
  "seekingWife": "yes|no",
  "acceptPolygamy": "yes|no|first_only",
  "acceptDivorced": "yes|no",
  "acceptWithChildren": "yes|no",
  "religionLevel": "",
  "pCountry": "",
  "pCity": "",
  "pNationality": "",
  "pNationalityOther": "",
  "pAgeMin": 22,
  "pAgeMax": 35,
  "pMaritalStatus": "",
  "pAcceptChildren": "yes|no|conditional",
  "pSect": "",
  "pSectOther": "",
  "pReligionLevel": "",
  "pEducation": "",
  "pWorkType": "",
  "pSkinColor": "",
  "pHeight": "",
  "pHeightNoMatter": false,
  "pHousing": "",
  "pNotes": ""
}
```

**API:** `api/members.js` يفك `details` إلى حقول مسطّحة في الاستجابة (`pCountry`, …).

---

### 3.2 `admin_users`
| العمود | النوع |
|--------|------|
| id | text PK |
| username | text |
| role | text (`super_admin`, `admin`, `moderator`, …) |
| email | text |
| password | text (hash) |
| created_at | timestamptz |

### 3.3 `admin_sessions`
| العمود | النوع |
|--------|------|
| id | text PK |
| admin_id | text |
| token | text |
| email | text |
| role | text |
| expires_at | timestamptz |
| created_at | timestamptz |

### 3.4 `interest_requests`
| العمود | النوع |
|--------|------|
| id | bigint PK |
| sender_id, receiver_id | text |
| journey_stage, status, mediation_stage | text |
| message | text |
| sender_paid, receiver_paid | boolean |
| sender_paid_at, receiver_paid_at | timestamptz |
| deadline_date | timestamptz |
| decline_reason, cancel_reason | text |
| defer_date, defer_by | text |
| meeting_date, meeting_notes | text |
| contact_info, contact_by | text |
| guardian_phone, guardian_name, guardian_relation | text |
| contact_time, contact_note | text |
| male_phone, male_name, male_relation | text |
| male_contact_time, male_contact_note | text |
| male_pledged, female_pledged | boolean |
| sender_viewing_result, receiver_viewing_result | text |
| sender_viewing_note, receiver_viewing_note | text |
| evaluation_result, evaluation_note | text |
| frozen | boolean |
| frozen_reason | text |
| frozen_at | timestamptz |
| created_at, updated_at | timestamptz |

**مراحل journey_stage:**  
`sent` → `accepted` → `seriousness` → `coordination` → `sharia_viewing` → `engagement` → `completed`  
طرفية: `declined`, `cancelled`

### 3.5 `request_assignments` (وسيطة + SLA)
| العمود | النوع |
|--------|------|
| id | text PK |
| request_id | bigint |
| mediator_id | text |
| mediator_name | text |
| sla_hours | integer |
| due_at | timestamptz |
| status | text (`active`, …) |
| notes | text |
| created_at, updated_at | timestamptz |

### 3.6 `notifications`
| العمود | النوع |
|--------|------|
| id | serial PK |
| user_id | text (`all` للبث) |
| request_id | bigint nullable |
| title, text, type | text |
| read | boolean |
| created_at | timestamptz |

### 3.7 `inquiry_messages`
| العمود | النوع |
|--------|------|
| id | serial PK |
| request_id | bigint |
| sender_id | text |
| text | text |
| charged_to | text nullable |
| status | text (`approved`, `rejected`, …) |
| moderated_by | text |
| created_at | timestamptz |

### 3.8 `transactions`
| العمود | النوع |
|--------|------|
| id | serial PK |
| user_id | text |
| request_id | bigint nullable |
| amount | numeric |
| type | text (`subscription`, `deposit`, `inquiry`, `final`, `payment`, …) |
| description | text |
| status | text (`pending`, `completed`, `failed`, `refunded`) |
| metadata | jsonb |
| created_at | timestamptz |

#### `transactions.metadata` أمثلة
```json
{
  "method": "bank|crypto|paypal",
  "planId": "gold|elite",
  "requestId": 1002,
  "side": "sender|receiver",
  "offline": true,
  "cryptoTxid": "",
  "senderName": "",
  "transferredBank": "",
  "receiptName": "",
  "couponCode": "",
  "reviewedBy": "",
  "approvedAt": "",
  "rejectReason": ""
}
```

**موافقة الإدارة:** `POST /api/transactions` body `{ action: "approve"|"reject", id }`

### 3.9 `coupons`
| العمود | النوع |
|--------|------|
| code | text PK |
| discount | numeric |
| is_active | boolean |
| uses_count | integer |
| expires_at | text |
| details | jsonb |
| created_at | timestamptz |

### 3.10 `support_tickets`
| العمود | النوع |
|--------|------|
| id | serial PK |
| user_id | text |
| subject, message, category, priority, status | text |
| details | jsonb |
| created_at, updated_at | timestamptz |

### 3.11 `verification_docs`
| العمود | النوع |
|--------|------|
| id | text PK |
| member_id | text |
| doc_type | text |
| file_url | text |
| status | text (`pending`, `approved`, `rejected`) |
| reviewer_name, rejection_reason | text |
| details | jsonb |
| created_at, updated_at | timestamptz |

ملفات تُرفع إلى Storage path: `{member_id}/{docId}.jpg|png|webp`

### 3.12 `member_reports`
| العمود | النوع |
|--------|------|
| id | text PK |
| reporter_id, reporter_name | text |
| reported_id, reported_name | text |
| reason, status, category, severity | text |
| admin_notes | text |
| action_log | jsonb |
| created_at | timestamptz |

### 3.13 `exemption_requests`
| العمود | النوع |
|--------|------|
| id | text PK |
| request_id, user_id, user_nickname | text |
| reason, status | text |
| created_at | timestamptz |

### 3.14 جغرافيا
**geo_countries:** `name` PK, `code`, `flag`  
**geo_cities:** `id` serial PK, `country`, `name`  
**pending_cities:** `id` PK, `name`, `country`, `suggested_by`, `suggested_by_id`, `source`, `status`, `rejection_reason`, `created_at`  
**geo_nationalities:** `name` PK, `country`, `gender` (`male|female|both`)  
**geo_suggestions:** `id` PK, `kind`, `name`, `country`, `suggested_by`, `suggested_by_id`, `source`, `status`, `target_name`, `target_country`, `rejection_reason`, `reviewer`, `reviewed_at`, `created_at`

### 3.15 `settings`
| العمود | النوع |
|--------|------|
| key | text PK |
| value | text |
| updated_at | timestamptz |

مفاتيح شائعة: `site_name`, `whatsapp_number`, `deposit_amount`, `gold_plan_price`, `elite_plan_price`, `features_json`, `terms`, `privacy`, `payment_gateway`

### 3.16 محتوى
**faq_items:** `id`, `question`, `answer`, `category`, `sort_order`, `is_published`, `created_at`  
**blog_posts:** `id`, `title`, `excerpt`, `content`, `category`, `author`, `image`, `read_time`, `is_published`, `created_at`

### 3.17 `registration_drafts`
| العمود | النوع |
|--------|------|
| id | text PK |
| email, phone | text |
| payload | jsonb (نموذج التسجيل كاملاً) |
| step | integer |
| updated_at, created_at | timestamptz |

### 3.18 `audit_logs`
| العمود | النوع |
|--------|------|
| id | serial PK |
| actor_id, actor_email, actor_role | text |
| action | text |
| entity_type, entity_id | text |
| details | jsonb |
| ip | text |
| created_at | timestamptz |

أمثلة `action`: `admin_login`, `admin_update_member`, `admin_reset_password`, `transaction_approved`, `assign_mediator`, `impersonate_start`

---

## 4) فهارس مقترحة (أداء)

```sql
CREATE INDEX IF NOT EXISTS idx_members_status ON members(status);
CREATE INDEX IF NOT EXISTS idx_members_gender ON members(gender);
CREATE INDEX IF NOT EXISTS idx_members_country_city ON members(country, city);
CREATE INDEX IF NOT EXISTS idx_members_plan ON members(plan);
CREATE INDEX IF NOT EXISTS idx_members_created ON members(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_requests_sender ON interest_requests(sender_id);
CREATE INDEX IF NOT EXISTS idx_requests_receiver ON interest_requests(receiver_id);
CREATE INDEX IF NOT EXISTS idx_requests_stage ON interest_requests(journey_stage);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tx_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_admin_sessions_token ON admin_sessions(token);
CREATE INDEX IF NOT EXISTS idx_assignments_request ON request_assignments(request_id);
CREATE INDEX IF NOT EXISTS idx_assignments_due ON request_assignments(due_at);
```

---

## 5) Storage

| Bucket | Public | الاستخدام |
|--------|--------|-----------|
| `verification-docs` | نعم | مستندات التوثيق |

---

## 6) خريطة API ↔ الجداول

| المسار | الجداول |
|--------|---------|
| `/api/members` | members |
| `/api/member-auth` | members, audit_logs |
| `/api/admin-auth` | admin_users, admin_sessions, audit_logs |
| `/api/admin-users` | admin_users |
| `/api/interest-requests` | interest_requests, notifications |
| `/api/assignments` | request_assignments, notifications, audit_logs |
| `/api/notifications` | notifications |
| `/api/inquiry-messages` | inquiry_messages |
| `/api/transactions` | transactions, members, interest_requests, audit_logs |
| `/api/coupons` | coupons |
| `/api/support-tickets` | support_tickets |
| `/api/verification-docs` | verification_docs + storage |
| `/api/member-reports` | member_reports |
| `/api/exemptions` | exemption_requests |
| `/api/geo` | geo_countries, geo_cities, pending_cities |
| `/api/geo-nationalities` | geo_nationalities |
| `/api/geo-suggestions` | geo_suggestions (+ members/geo_*) |
| `/api/settings` | settings |
| `/api/content` | faq_items, blog_posts |
| `/api/registration-drafts` | registration_drafts |
| `/api/audit-logs` | audit_logs |
| `/api/stats` | counts على members/requests/transactions |
| `/api/inbox` | تجميع مهام إدارية |

---

## 7) قواعد أمان مهمة عند الاستيراد

1. **لا** تضع `SUPABASE_SERVICE_ROLE_KEY` في كود الواجهة.
2. متغيرات البيئة المطلوبة (موجودة في `.env` / `vercel.json` لهذه البيئة):
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY`
   - `FULLSTACK_PROJECT_REF` / `FULLSTACK_RESTORE_API_URL` (اختياري للإيقاظ)
3. كلمات المرور تُشفّر بـ:  
   `sha256('tawasul_v1:' + password)` hex بطول 64.
4. مسارات الإدارة المحمية تحتاج هيدر:  
   `Authorization: Bearer <token>` أو `X-Admin-Token: <token>`
5. `api/db-client.js` و `api/db-wake.js` خاصان بالبيئة — **لا تستبدلهما** من أرشيف قديم إن وُجدت نسخة البيئة الحالية.

---

## 8) ترتيب إنشاء الجداول عند الاستيراد الجديد

1. `admin_users`, `admin_sessions`, `audit_logs`
2. `members`
3. `interest_requests`, `request_assignments`, `notifications`, `inquiry_messages`
4. `transactions`, `coupons`, `exemption_requests`
5. `support_tickets`, `verification_docs`, `member_reports`
6. `geo_*`, `pending_cities`
7. `settings`, `faq_items`, `blog_posts`, `registration_drafts`
8. إنشاء bucket `verification-docs`
9. تشغيل الفهارس من القسم 4
10. بذر البيانات من `database/seed.sql` أو أدوات Supabase

---

## 9) قيود واجهة معتمدة

- لا تعرض نسبة توافق رقمية مزعجة كشارة عامة (استخدم مطابقة نعم/جزئي/لا عند الحاجة).
- لا تعرض «متصل الآن» / آخر ظهور / عداد زيارات.
- البيانات الحساسة (اسم حقيقي، هاتف، بريد، كلمة مرور) للإدارة فقط.

---

## 10) التحقق بعد الاستيراد

```bash
# بعد ضبط .env
curl -s "$NEXT_PUBLIC_SUPABASE_URL/rest/v1/members?select=id&limit=1" \
  -H "apikey: $SUPABASE_SERVICE_ROLE_KEY" \
  -H "Authorization: Bearer $SUPABASE_SERVICE_ROLE_KEY"

# تسجيل أدمن
curl -s -X POST /api/admin-auth \
  -H 'Content-Type: application/json' \
  -d '{"action":"login","email":"algohrah4u@gmail.com","password":"12345678"}'
```

يجب أن ترجع التوكن وجداول `members` / `settings` / `faq_items` بدون أخطاء schema.

---

**مرجع آلي:** `database/schema.json`  
**SQL كامل:** `database/seed.sql`
