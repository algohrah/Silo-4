import { useState, useRef, useEffect, useMemo } from 'react';
import { ChevronDown, Search, Check, MapPin, X, Plus } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { dataService } from '../../lib/data/DataService';

const { normalizeText } = dataService.db;

interface MultiSearchableSelectProps {
  values: string[];
  onChange: (newValues: string[]) => void;
  options: string[];
  placeholder?: string;
  searchPlaceholder?: string;
  disabled?: boolean;
  error?: string;
  allowAddNew?: boolean;
  onAddNew?: (name: string) => { ok: boolean; error?: string };
  addNewLabel?: string;
  addNewPlaceholder?: string;
  groupLabel?: string;
}

export default function MultiSearchableSelect({
  values = [],
  onChange,
  options,
  placeholder = 'اختر واحدًا أو أكثر...',
  searchPlaceholder = 'ابحث...',
  disabled = false,
  error,
  allowAddNew = false,
  onAddNew,
  addNewLabel = 'اضغط هنا لكتابة خيار جديد',
  addNewPlaceholder = 'اكتب الاسم هنا...',
  groupLabel,
}: MultiSearchableSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [addError, setAddError] = useState('');
  const [addSuccess, setAddSuccess] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setShowAddForm(false);
        setQuery('');
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  const toggleOption = (opt: string) => {
    if (values.includes(opt)) {
      onChange(values.filter((v) => v !== opt));
    } else {
      onChange([...values, opt]);
    }
  };

  const removeValue = (opt: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(values.filter((v) => v !== opt));
  };

  const filtered = useMemo(() => {
    const allOptions = Array.from(new Set(options)).filter(Boolean);
    if (!query.trim()) return allOptions;
    const norm = normalizeText(query);
    return allOptions.filter((o) => normalizeText(o).includes(norm));
  }, [options, query]);

  const handleAddNew = () => {
    if (!onAddNew) return;
    const name = newItemName.trim();
    if (!name) {
      setAddError('الرجاء كتابة الاسم');
      return;
    }
    const result = onAddNew(name);
    if (result.ok) {
      if (!values.includes(name)) {
        onChange([...values, name]);
      }
      setAddSuccess(true);
      setNewItemName('');
      setAddError('');
      setTimeout(() => {
        setShowAddForm(false);
        setAddSuccess(false);
        setQuery('');
      }, 1200);
    } else {
      setAddError(result.error || 'تعذّر الإضافة');
    }
  };

  return (
    <div className="relative" ref={ref}>
      {/* Box containing selected chips + toggle button */}
      <div
        onClick={() => {
          if (!disabled) {
            setOpen((prev) => {
              if (!prev) setQuery('');
              return !prev;
            });
          }
        }}
        className={`w-full min-h-[48px] px-3 py-2 rounded-xl bg-cream-50 border-2 transition-colors text-right font-tajawal flex flex-wrap items-center justify-between gap-1.5 cursor-pointer
          ${error ? 'border-rose-400' : open ? 'border-gold-500' : 'border-cream-200'}
          ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-gold-300'}`}
      >
        <div className="flex flex-wrap items-center gap-1.5 flex-1 min-w-0">
          {values.length === 0 ? (
            <span className="text-navy-400 text-sm px-1">{placeholder}</span>
          ) : (
            values.map((val) => (
              <span
                key={val}
                className="inline-flex items-center gap-1 bg-gold-300/20 text-gold-900 border border-gold-300/40 text-xs font-cairo font-bold px-2.5 py-1 rounded-lg"
              >
                <span>{val}</span>
                <button
                  type="button"
                  onClick={(e) => removeValue(val, e)}
                  className="hover:bg-gold-300/40 rounded-full p-0.5 text-navy-600 transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))
          )}
        </div>
        <ChevronDown className={`w-4 h-4 text-navy-400 flex-shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 mt-1.5 w-full bg-white rounded-2xl shadow-2xl border border-cream-200 overflow-hidden"
          >
            {/* Search Input */}
            <div className="p-2.5 border-b border-cream-100">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={searchPlaceholder}
                  className="w-full pr-9 pl-8 py-2 rounded-xl bg-cream-50 border border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery('')}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* List */}
            <div className="max-h-56 overflow-y-auto">
              {groupLabel && filtered.length > 0 && (
                <div className="px-4 py-1.5 text-[11px] font-cairo font-bold text-navy-400 bg-cream-50/50 sticky top-0">
                  {groupLabel}
                </div>
              )}
              {filtered.length === 0 ? (
                <div className="px-4 py-6 text-center">
                  <Search className="w-6 h-6 text-cream-300 mx-auto mb-1.5" />
                  <p className="text-xs text-navy-400 font-tajawal">
                    {query ? 'لا توجد نتائج مطابقة' : 'لا توجد خيارات'}
                  </p>
                </div>
              ) : (
                filtered.map((opt, idx) => {
                  const isSelected = values.includes(opt);
                  return (
                    <button
                      key={`${opt}-${idx}`}
                      type="button"
                      onClick={() => toggleOption(opt)}
                      className={`w-full px-4 py-2.5 text-right text-sm font-tajawal transition-colors flex items-center justify-between gap-2
                        ${isSelected ? 'bg-gold-300/15 text-gold-900 font-bold' : 'text-navy-700 hover:bg-cream-50'}`}
                    >
                      <span className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-navy-300" />
                        {opt}
                      </span>
                      {isSelected && <Check className="w-4 h-4 text-gold-600 flex-shrink-0" />}
                    </button>
                  );
                })
              )}
            </div>

            {/* Add New Option */}
            {allowAddNew && (
              <div className="border-t border-cream-100">
                {!showAddForm ? (
                  <button
                    type="button"
                    onClick={() => setShowAddForm(true)}
                    className="w-full px-4 py-2.5 text-right text-sm font-cairo font-semibold text-gold-700 hover:bg-gold-300/10 transition-colors flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    {addNewLabel}
                  </button>
                ) : (
                  <div className="p-3 space-y-2 bg-cream-50/50">
                    {addSuccess ? (
                      <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span className="text-sm font-cairo font-semibold text-emerald-700">
                          تمت الإضافة بنجاح ✅
                        </span>
                      </div>
                    ) : (
                      <>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={newItemName}
                            onChange={(e) => { setNewItemName(e.target.value); setAddError(''); }}
                            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddNew(); } }}
                            placeholder={addNewPlaceholder}
                            autoFocus
                            className="flex-1 px-3 py-2 rounded-xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900"
                          />
                          <button
                            type="button"
                            onClick={handleAddNew}
                            className="px-4 py-2 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold text-sm transition-all"
                          >
                            إضافة
                          </button>
                        </div>
                        {addError && <p className="text-xs text-rose-deep font-tajawal">{addError}</p>}
                      </>
                    )}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
