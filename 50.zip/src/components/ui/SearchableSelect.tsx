import { useState, useRef, useEffect, useMemo } from 'react';
import { ChevronDown, Search, Plus, Check, MapPin, X } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { dataService } from '../../lib/data/DataService';
const { normalizeText } = dataService.db;



// ====================================================================
//  قائمة منسدلة قابلة للبحث — مع خيار «أضف مدينتك»
// ====================================================================

interface SearchableSelectProps {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  searchPlaceholder?: string;
  disabled?: boolean;
  error?: string;
  // خيار إضافة مدينة جديدة
  allowAddNew?: boolean;
  onAddNew?: (name: string) => { ok: boolean; error?: string };
  addNewLabel?: string;
  addNewPlaceholder?: string;
  // عنوان إضافي يظهر أعلى النتائج
  groupLabel?: string;
  // خيار «لا يهم» للقوائم الاختيارية
  includeNoPreference?: boolean;
  noPreferenceLabel?: string;
}

export default function SearchableSelect({
  value,
  onChange,
  options,
  placeholder = 'اختر',
  searchPlaceholder = 'ابحث...',
  disabled = false,
  error,
  allowAddNew = false,
  onAddNew,
  addNewLabel = 'لم تجد مدينتك؟ أضفها هنا',
  addNewPlaceholder = 'اكتب اسم المدينة...',
  groupLabel,
  includeNoPreference = false,
  noPreferenceLabel = 'لا يهم',
}: SearchableSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [addError, setAddError] = useState('');
  const [addSuccess, setAddSuccess] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setShowAddForm(false);
        setQuery('');
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  const filtered = useMemo(() => {
    const rawOptions = includeNoPreference ? [noPreferenceLabel, ...options] : options;
    const allOptions = Array.from(new Set(rawOptions));
    if (!query.trim()) return allOptions;
    const norm = normalizeText(query);
    return allOptions.filter((o) => normalizeText(o).includes(norm));
  }, [options, query, includeNoPreference, noPreferenceLabel]);

  const handleAddNew = () => {
    if (!onAddNew) return;
    const name = newItemName.trim();
    if (!name) {
      setAddError('الرجاء كتابة الاسم');
      return;
    }
    const result = onAddNew(name);
    if (result.ok) {
      // عيّن المدينة المُضافة كقيمة للحقل حتى يكمل المستخدم تسجيله
      onChange(name);
      setAddSuccess(true);
      setNewItemName('');
      setAddError('');
      // نُغلق بعد قليل لإظهار رسالة النجاح
      setTimeout(() => {
        setShowAddForm(false);
        setAddSuccess(false);
        setOpen(false);
        setQuery('');
      }, 1800);
    } else {
      setAddError(result.error || 'تعذّر الإضافة');
    }
  };

  const displayValue = value || placeholder;
  const hasValue = !!value;

  return (
    <div className="relative" ref={ref}>
      {/* زر الاختيار */}
      <button
        type="button"
        onClick={() => {
          if (!disabled) {
            setOpen((v) => {
              if (!v) setQuery('');
              return !v;
            });
          }
        }}
        disabled={disabled}
        className={`w-full px-4 py-3 pl-10 rounded-xl bg-cream-50 border-2 transition-colors text-right font-tajawal flex items-center justify-between gap-2
          ${error ? 'border-rose-400' : open ? 'border-gold-500' : 'border-cream-200'}
          ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-gold-300 cursor-pointer'}
          ${hasValue ? 'text-navy-900' : 'text-navy-400'}`}
      >
        <span className="flex items-center gap-2 truncate">
          {hasValue && <Check className="w-4 h-4 text-gold-600 flex-shrink-0" />}
          <span className="truncate">{displayValue}</span>
        </span>
        <ChevronDown className={`w-4 h-4 text-navy-400 flex-shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 mt-1.5 w-full bg-white rounded-2xl shadow-2xl border border-cream-200 overflow-hidden"
          >
            {/* حقل البحث */}
            <div className="p-2.5 border-b border-cream-100">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={searchPlaceholder}
                  className="w-full pr-9 pl-3 py-2.5 rounded-xl bg-cream-50 border border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery('')}
                    className="absolute left-2 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-700"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* قائمة النتائج */}
            <div className="max-h-56 overflow-y-auto">
              {groupLabel && filtered.length > 0 && (
                <div className="px-4 py-1.5 text-[11px] font-cairo font-bold text-navy-400 bg-cream-50/50 sticky top-0">
                  {groupLabel}
                </div>
              )}
              {filtered.length === 0 ? (
                <div className="px-4 py-6 text-center">
                  <Search className="w-6 h-6 text-cream-300 mx-auto mb-1.5" />
                  <p className="text-xs text-navy-400 font-tajawal">
                    {query ? 'لا توجد نتائج مطابقة' : 'لا توجد خيارات'}
                  </p>
                </div>
              ) : (
                filtered.map((opt, idx) => {
                  const isActive = opt === value;
                  const isNoPref = includeNoPreference && opt === noPreferenceLabel;
                  return (
                    <button
                      key={`${opt}-${idx}`}
                      type="button"
                      onClick={() => {
                        onChange(opt);
                        setOpen(false);
                        setQuery('');
                      }}
                      className={`w-full px-4 py-2.5 text-right text-sm font-tajawal transition-colors flex items-center justify-between gap-2
                        ${isActive ? 'bg-gold-300/15 text-gold-800 font-bold' : 'text-navy-700 hover:bg-cream-50'}`}
                    >
                      <span className="flex items-center gap-2">
                        {isNoPref ? (
                          <span className="text-xs text-navy-400">—</span>
                        ) : (
                          <MapPin className="w-3.5 h-3.5 text-navy-300" />
                        )}
                        {opt}
                      </span>
                      {isActive && <Check className="w-4 h-4 text-gold-600" />}
                    </button>
                  );
                })
              )}
            </div>

            {/* خيار إضافة مدينة جديدة */}
            {allowAddNew && (
              <div className="border-t border-cream-100">
                {!showAddForm ? (
                  <button
                    type="button"
                    onClick={() => setShowAddForm(true)}
                    className="w-full px-4 py-3 text-right text-sm font-cairo font-semibold text-gold-700 hover:bg-gold-300/10 transition-colors flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    {addNewLabel}
                  </button>
                ) : (
                  <div className="p-3 space-y-2 bg-cream-50/50">
                    {addSuccess ? (
                      <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span className="text-sm font-cairo font-semibold text-emerald-700">
                          تم إرسال طلب الإضافة — ستظهر بعد موافقة الإدارة ✅
                        </span>
                      </div>
                    ) : (
                      <>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={newItemName}
                            onChange={(e) => { setNewItemName(e.target.value); setAddError(''); }}
                            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddNew(); } }}
                            placeholder={addNewPlaceholder}
                            autoFocus
                            className="flex-1 px-3 py-2.5 rounded-xl bg-white border-2 border-cream-200 focus:border-gold-500 focus:outline-none font-tajawal text-sm text-navy-900"
                          />
                          <button
                            type="button"
                            onClick={handleAddNew}
                            className="px-4 py-2.5 rounded-xl bg-gold-gradient text-navy-900 font-cairo font-bold text-sm hover:shadow-soft transition-all flex items-center gap-1"
                          >
                            <Plus className="w-4 h-4" />
                            إضافة
                          </button>
                        </div>
                        {addError && (
                          <p className="text-xs text-rose-deep font-tajawal px-1">{addError}</p>
                        )}
                        <p className="text-[11px] text-navy-400 font-tajawal px-1">
                          ستُضاف مدينتك مؤقتاً لحسابك، وتراجعها الإدارة قبل إضافتها للقائمة الرسمية.
                        </p>
                      </>
                    )}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
