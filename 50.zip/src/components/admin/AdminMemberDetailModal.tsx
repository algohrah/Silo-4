import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Modal from '../ui/Modal';
import {
  Edit, Eye, Lock, BadgeCheck, Crown, UserCheck, UserX, Flag, Send,
  LogIn, Trash2, Copy, KeyRound, AlertCircle, Fingerprint, Mail, Phone,
  StickyNote, Ban, Award, Pin, Loader2, Save, RefreshCw
} from 'lucide-react';
import { useAdminMembers } from '../../lib/useAdminData';
import { useApp } from '../../lib/AppContext';
import { dataService } from '../../lib/data/DataService';
import supabase from '../../lib/supabase';
import * as C from '../../lib/constants';
import {
  getSelfMaritalOptions,
  getPartnerMaritalOptions,
  getPartnerTerms,
  shouldAskChildren,
  isMarriedMale
} from '../../lib/registrationOptions';

interface AdminMemberDetailModalProps {
  member: any | null;
  open: boolean;
  onClose: () => void;
  initialEditing?: boolean;
  onUpdated?: () => void;
}

// Helper for pending suggestions
const getPendingSuggestionsList = () => {
  try {
    if (typeof (dataService.db as any).getPendingSuggestions === 'function') {
      const res = (dataService.db as any).getPendingSuggestions();
      return Array.isArray(res) ? res : [];
    }
  } catch {}
  return [];
};

const safeGetCountries = (currentValue?: string): Array<{ name: string; isPending?: boolean }> => {
  try {
    const list = dataService.db.getCountries?.() || [];
    const dbCountries = (Array.isArray(list) ? list : []).map((c: any) => typeof c === 'string' ? c : c?.name || String(c)).filter(Boolean);
    const constCountries = C.COUNTRIES || [];

    const pendingList = getPendingSuggestionsList()
      .filter((s) => s.kind === 'country')
      .map((s) => s.name)
      .filter(Boolean);

    const map = new Map<string, { name: string; isPending?: boolean }>();

    [...dbCountries, ...constCountries].filter(Boolean).forEach((n) => {
      map.set(n, { name: n, isPending: false });
    });

    pendingList.forEach((n) => {
      if (!map.has(n)) map.set(n, { name: n, isPending: true });
    });

    if (currentValue && currentValue !== 'all' && currentValue !== 'لا يهم' && !map.has(currentValue)) {
      map.set(currentValue, { name: currentValue, isPending: false });
    }

    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  } catch {
    return (C.COUNTRIES || []).map((c) => ({ name: c, isPending: false }));
  }
};

const safeGetCities = (country: string, currentCity?: string): Array<{ name: string; isPending?: boolean }> => {
  try {
    let cities: string[] = [];
    if (!country || country === 'all' || country === 'لا يهم') {
      cities = Array.from(new Set(Object.values(C.CITIES_BY_COUNTRY || {}).flat()));
    } else {
      const dbCities = dataService.db.getCities?.(country) || [];
      const constCities = C.CITIES_BY_COUNTRY[country] || [];
      cities = Array.from(new Set([...(Array.isArray(dbCities) ? dbCities : []), ...(Array.isArray(constCities) ? constCities : [])]));
    }

    const normCountry = (country || '').trim().toLowerCase();
    const pendingList = getPendingSuggestionsList()
      .filter((s) => s.kind === 'city' && (!country || country === 'all' || country === 'لا يهم' || !s.country || s.country.trim().toLowerCase() === normCountry))
      .map((s) => s.name)
      .filter(Boolean);

    const map = new Map<string, { name: string; isPending?: boolean }>();

    cities.filter(Boolean).forEach((n) => {
      map.set(n, { name: n, isPending: false });
    });

    pendingList.forEach((n) => {
      if (!map.has(n)) map.set(n, { name: n, isPending: true });
    });

    if (currentCity && currentCity !== 'all' && currentCity !== 'لا يهم' && !map.has(currentCity)) {
      map.set(currentCity, { name: currentCity, isPending: false });
    }

    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  } catch {
    return currentCity ? [{ name: currentCity, isPending: false }] : [];
  }
};

const safeGetNationalities = (currentVal?: string): Array<{ name: string; isPending?: boolean }> => {
  try {
    const dbNats = (dataService.db.getNationalities?.() || []).map((x: any) => typeof x === 'string' ? x : x?.name || '').filter(Boolean);
    const constNats = C.NATIONALITIES || [];
    const dbCountries = dataService.db.getCountryNames?.() || [];

    const pendingList = getPendingSuggestionsList()
      .filter((s) => s.kind === 'nationality')
      .map((s) => s.name)
      .filter(Boolean);

    const map = new Map<string, { name: string; isPending?: boolean }>();

    [...dbNats, ...constNats, ...dbCountries].filter(Boolean).forEach((n) => map.set(n, { name: n, isPending: false }));

    pendingList.forEach((n) => {
      if (!map.has(n)) map.set(n, { name: n, isPending: true });
    });

    if (currentVal && currentVal !== 'all' && currentVal !== 'لا يهم' && !map.has(currentVal)) {
      map.set(currentVal, { name: currentVal, isPending: false });
    }

    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  } catch {
    return (C.NATIONALITIES || []).map((n) => ({ name: n, isPending: false }));
  }
};

const statusConfig: Record<string, { label: string; color: string; dot: string }> = {
  active: { label: 'نشط', color: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500' },
  pending: { label: 'قيد المراجعة', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
  suspended: { label: 'موقوف', color: 'bg-orange-100 text-orange-700', dot: 'bg-orange-500' },
  banned: { label: 'محظور نهائياً', color: 'bg-rose-100 text-rose-700', dot: 'bg-rose-600' },
  inactive: { label: 'غير نشط', color: 'bg-slate-100 text-slate-700', dot: 'bg-slate-400' },
  rejected: { label: 'مرفوض', color: 'bg-rose-100 text-rose-700', dot: 'bg-rose-500' },
  deleted: { label: 'مُحذوف', color: 'bg-rose-200 text-rose-900 border border-rose-300 font-bold', dot: 'bg-rose-700' },
};

const getStatusCfg = (st?: string) => {
  const s = st || 'active';
  return statusConfig[s] || { label: s, color: 'bg-slate-100 text-slate-700', dot: 'bg-slate-400' };
};

const getPlanCfg = (p?: string) => {
  if (p === 'gold') return { label: 'الذهبية', color: 'bg-amber-100 text-amber-800' };
  if (p === 'elite') return { label: 'المميز 👑', color: 'bg-purple-100 text-purple-800' };
  return { label: 'المجانية', color: 'bg-slate-100 text-slate-700' };
};

export default function AdminMemberDetailModal({
  member,
  open,
  onClose,
  initialEditing = false,
  onUpdated,
}: AdminMemberDetailModalProps) {
  const navigate = useNavigate();
  const { impersonateUser, showToast: globalShowToast } = useApp();
  const { updateMember, deleteMember, toggleVerified, setPremium, setNote, toggleFlag } = useAdminMembers();

  const [isEditing, setIsEditing] = useState(initialEditing);
  const [activeEditTab, setActiveEditTab] = useState<'basic' | 'partner' | 'account'>('basic');
  const [activeViewTab, setActiveViewTab] = useState<'basic' | 'partner'>('basic');

  const [editForm, setEditForm] = useState<any>({});
  const [showPassword, setShowPassword] = useState(false);
  const [revealSensitive, setRevealSensitive] = useState(false);
  const [noteDraft, setNoteDraft] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const generateNewPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$';
    let newPass = 'Tw-';
    for (let i = 0; i < 7; i++) {
      newPass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setEditForm((prev: any) => ({ ...prev, password: newPass }));
    showLocalToast('تم توليد كلمة مرور جديدة عشوائية ✓');
  };

  // Secondary dialogs
  const [deleteFor, setDeleteFor] = useState<any | null>(null);
  const [notifyFor, setNotifyFor] = useState<any | null>(null);
  const [notifyText, setNotifyText] = useState('');
  const [localToast, setLocalToast] = useState<string | null>(null);

  const showLocalToast = (msg: string) => {
    setLocalToast(msg);
    globalShowToast?.(msg);
    setTimeout(() => setLocalToast(null), 3000);
  };

  useEffect(() => {
    if (open && member) {
      setIsEditing(initialEditing);
      setEditForm({ ...member });
      setNoteDraft(member.adminNotes || member.admin_notes || '');
      setRevealSensitive(false);
      setActiveEditTab('basic');
      setActiveViewTab('basic');
    }
  }, [open, member, initialEditing]);

  if (!open || !member) return null;

  const impersonateAndGo = (m: any) => {
    impersonateUser({
      id: m.id,
      nickname: m.nickname,
      gender: m.gender,
      age: m.age,
      country: m.country,
      city: m.city,
      realName: m.realName,
      email: m.email,
      phone: m.phone,
      whatsapp: m.whatsapp,
      plan: m.plan,
      status: m.status,
      avatar: m.avatar,
      verified: m.verified,
      premium: m.premium,
    } as any);
    onClose();
    navigate('/my-profile');
  };

  const handleSaveEdit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);
    try {
      const ok = await updateMember(member.id, editForm);
      if (ok !== false) {
        showLocalToast('تم حفظ بيانات العضو بنجاح ✓');
        setIsEditing(false);
        onUpdated?.();
      } else {
        showLocalToast('حدث خطأ أثناء حفظ بيانات العضو');
      }
    } catch (err: any) {
      showLocalToast(err.message || 'حدث خطأ غير متوقع');
    } finally {
      setIsSaving(false);
    }
  };

  const hardDeleteMember = async (id: string) => {
    try {
      await dataService.db.adminDeleteMember?.(id);
      await deleteMember(id);
      showLocalToast('تم حذف العضو نهائياً من قاعدة البيانات');
      setDeleteFor(null);
      onClose();
      onUpdated?.();
    } catch (err) {
      console.error('Hard delete error:', err);
      showLocalToast('تعذّر إكمال الحذف على الخادم');
    }
  };

  return (
    <>
      {/* Toast Notification */}
      {localToast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-[99999] bg-slate-900 text-white font-cairo font-bold text-xs px-4 py-2.5 rounded-xl shadow-2xl border border-amber-500/40 animate-bounce">
          {localToast}
        </div>
      )}

      {/* Primary Modal: View / Edit Member */}
      <Modal
        open={open}
        onClose={onClose}
        title={isEditing ? `تعديل بيانات العضو: ${member.nickname || member.realName || member.id}` : `ملف العضو: ${member.nickname || member.realName || member.id}`}
      >
        <div dir="rtl" className="space-y-4">
          {isEditing ? (
            <form onSubmit={handleSaveEdit} className="space-y-4">
              {/* Incomplete profile warning banner */}
              {editForm.isProfileIncomplete && (
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0" />
                  <p className="text-xs font-cairo text-amber-900 font-bold">
                    هذا الملف معلّم كـ غير مكتمل وسيكون محجوباً عن العرض العام حتى يستكمل بياناته.
                  </p>
                </div>
              )}

              {/* Tabs */}
              <div className="flex border-b border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveEditTab('basic')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all font-cairo ${
                    activeEditTab === 'basic' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  البيانات الشخصية والأساسية
                </button>
                <button
                  type="button"
                  onClick={() => setActiveEditTab('partner')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all font-cairo ${
                    activeEditTab === 'partner' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  مواصفات الشريك المطلوبة
                </button>
                <button
                  type="button"
                  onClick={() => setActiveEditTab('account')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all font-cairo ${
                    activeEditTab === 'account' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  بيانات الحساب والاتصال
                </button>
              </div>

              {activeEditTab === 'basic' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto px-1 py-1 font-cairo">
                  {/* Nickname & Real Name */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الاسم المستعار (اللقب) <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.nickname || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, nickname: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.nickname ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="مثال: الواثق بالله"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الاسم الحقيقي الثلاثي <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      value={editForm.realName || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, realName: e.target.value, real_name: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.realName ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="الاسم الثلاثي للتثبت والتوثيق"
                    />
                  </div>

                  {/* Gender */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الجنس <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.gender || ''}
                      onChange={(e) => {
                        const newGender = e.target.value as 'male' | 'female';
                        setEditForm((prev: any) => ({
                          ...prev,
                          gender: newGender,
                          maritalStatus: newGender === 'female' ? (prev.maritalStatus === 'single' ? 'single' : 'single') : 'single',
                        }));
                      }}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.gender ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر الجنس --</option>
                      <option value="male">ذكر</option>
                      <option value="female">أنثى</option>
                    </select>
                  </div>

                  {/* Birth Date & Age */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">تاريخ الميلاد</label>
                      <input
                        type="date"
                        value={editForm.birthDate || editForm.birth_date || ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          let calcAge = editForm.age;
                          if (val) {
                            const bYear = new Date(val).getFullYear();
                            const cYear = new Date().getFullYear();
                            if (bYear > 1920 && bYear < cYear) {
                              calcAge = cYear - bYear;
                            }
                          }
                          setEditForm((prev: any) => ({ ...prev, birthDate: val, birth_date: val, age: calcAge }));
                        }}
                        className="w-full px-2 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">العمر (سنة) <span className="text-red-500">*</span></label>
                      <input
                        type="number"
                        value={editForm.age || ''}
                        onChange={(e) => setEditForm((prev: any) => ({ ...prev, age: Number(e.target.value) }))}
                        className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.age ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                        min="16"
                        max="90"
                      />
                    </div>
                  </div>

                  {/* Nationality & Country */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الجنسية</label>
                    <select
                      value={editForm.nationality || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, nationality: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                    >
                      <option value="">-- اختر الجنسية --</option>
                      {safeGetNationalities(editForm.nationality).map((nat, idx) => (
                        <option key={`edit-nat-${nat.name}-${idx}`} value={nat.name}>{nat.name}{nat.isPending ? ' (مقترح معلق)' : ''}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">بلد الإقامة <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.country || 'السعودية'}
                      onChange={(e) => {
                        const newCountry = e.target.value;
                        setEditForm((prev: any) => ({ ...prev, country: newCountry, city: '' }));
                      }}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.country ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر بلد الإقامة --</option>
                      {safeGetCountries(editForm.country).map((c, idx) => (
                        <option key={`edit-country-${c.name}-${idx}`} value={c.name}>{c.name}{c.isPending ? ' (مقترح معلق)' : ''}</option>
                      ))}
                    </select>
                  </div>

                  {/* City & District */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المدينة <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.city || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, city: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.city ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر المدينة --</option>
                      {(editForm.country || 'السعودية') ? safeGetCities(editForm.country || 'السعودية', editForm.city).map((ct, idx) => (
                        <option key={`edit-city-${ct.name}-${idx}`} value={ct.name}>{ct.name}{ct.isPending ? ' (مقترح معلق)' : ''}</option>
                      )) : null}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الحي / المنطقة</label>
                    <input
                      type="text"
                      value={editForm.district || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, district: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثال: الملقا"
                    />
                  </div>

                  {/* Tribe & Sect */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">القبيلة / النسب</label>
                    <input
                      type="text"
                      value={editForm.tribe || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, tribe: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثل: قبيلي، عتيبي، مطيري..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المذهب</label>
                    <select
                      value={editForm.sect || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, sect: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                    >
                      <option value="">-- اختر المذهب --</option>
                      {C.SECTS.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  {/* Marriage Type & Marital Status */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">نوع الزواج المطلوب</label>
                    <select
                      value={editForm.marriageType || 'announced'}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, marriageType: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-bold text-amber-900"
                    >
                      <option value="announced">معلن (زواج شرعي معلن)</option>
                      <option value="misyar">مسيار (زواج مسيار)</option>
                      <option value="both">الاثنين معاً (مسيار أو معلن)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الحالة الاجتماعية <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.maritalStatus || editForm.marital || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, maritalStatus: e.target.value, marital: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!(editForm.maritalStatus || editForm.marital) ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر الحالة الاجتماعية --</option>
                      {getSelfMaritalOptions(editForm.gender).map((opt) => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  </div>

                  {/* Married Male Fields */}
                  {isMarriedMale(editForm.gender, editForm.maritalStatus || editForm.marital) && (
                    <>
                      <div>
                        <label className="block text-xs font-bold text-amber-900 mb-1">عدد الزوجات الحاليين</label>
                        <select
                          value={editForm.wifeCount || editForm.currentWives || '1'}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, wifeCount: e.target.value, currentWives: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-amber-50/60 border border-amber-200 text-xs focus:outline-none focus:border-amber-400 font-bold"
                        >
                          <option value="1">زوجة واحدة (1)</option>
                          <option value="2">زوجتان (2)</option>
                          <option value="3">ثلاث زوجات (3)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-amber-900 mb-1">رغبة/سبب التعدد</label>
                        <input
                          type="text"
                          value={editForm.seekingWife || editForm.polygamyReason || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, seekingWife: e.target.value, polygamyReason: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-amber-50/60 border border-amber-200 text-xs focus:outline-none focus:border-amber-400"
                          placeholder="مثال: الرغبة في التعدد وإنجاب الأطفال"
                        />
                      </div>
                    </>
                  )}

                  {/* Female Polygamy & Marriage Options */}
                  {editForm.gender === 'female' && (
                    <>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">هل تقبل التعدد؟</label>
                        <select
                          value={editForm.acceptPolygamy || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, acceptPolygamy: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                        >
                          <option value="">— لم يتم الاختيار —</option>
                          <option value="yes">نعم، أقبل التعدد</option>
                          <option value="first_only">أقبل أن أكون الزوجة الأولى فقط</option>
                          <option value="no">لا أقبل التعدد</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">هل تقبل بالمطلّق؟</label>
                        <select
                          value={editForm.acceptDivorced || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, acceptDivorced: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                        >
                          <option value="">— لم يتم الاختيار —</option>
                          <option value="yes">نعم أقبل</option>
                          <option value="no">لا أقبل</option>
                          <option value="maybe">حسب التوافق والظروف</option>
                        </select>
                      </div>
                    </>
                  )}

                  {/* Children options */}
                  {(shouldAskChildren(editForm.maritalStatus || editForm.marital) || editForm.hasChildren) && (
                    <>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">عدد الأبناء</label>
                        <input
                          type="text"
                          value={editForm.childrenCount || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, childrenCount: e.target.value, hasChildren: e.target.value !== '0' && e.target.value !== 'لا يوجد' && e.target.value !== '' }))}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                          placeholder="مثال: لا يوجد، أو 2"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">مكان إقامة الأبناء</label>
                        <select
                          value={editForm.childrenLiveWith || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, childrenLiveWith: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                        >
                          <option value="">— اختر مكان الإقامة —</option>
                          <option value="مع الأم">يقيمون مع الأم</option>
                          <option value="مع الأب">يقيمون مع الأب</option>
                          <option value="مستقلين">مستقلين بالسكن</option>
                          <option value="مشترك">مشترك / بالتناوب</option>
                        </select>
                      </div>
                    </>
                  )}

                  {/* Height & Weight */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الطول (سم) <span className="text-red-500">*</span></label>
                    <input
                      type="number"
                      value={editForm.height || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, height: Number(e.target.value) }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.height ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="170"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الوزن (كجم) <span className="text-red-500">*</span></label>
                    <input
                      type="number"
                      value={editForm.weight || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, weight: Number(e.target.value) }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.weight ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                      placeholder="70"
                    />
                  </div>

                  {/* Skin Color & Religion */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">لون البشرة <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.skinColor || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, skinColor: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.skinColor ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر لون البشرة --</option>
                      {C.SKIN_COLORS.map((sc) => (
                        <option key={sc} value={sc}>{sc}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">العرق</label>
                    <input
                      type="text"
                      value={editForm.ethnicity || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, ethnicity: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثل: عربي، خليجي، قبلي..."
                    />
                  </div>

                  {/* Education & Work */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المستوى التعليمي <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.education || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, education: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.education ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر المستوى التعليمي --</option>
                      {C.EDUCATION_LEVELS.map((ed) => (
                        <option key={ed} value={ed}>{ed}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">نوع العمل / القطاع <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.workType || editForm.occupation || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, workType: e.target.value, occupation: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!(editForm.workType || editForm.occupation) ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر نوع العمل --</option>
                      {C.WORK_TYPES.map((wt) => (
                        <option key={wt} value={wt}>{wt}</option>
                      ))}
                    </select>
                  </div>

                  {/* Job Title & Housing */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المسمى الوظيفي / المهنة</label>
                    <input
                      type="text"
                      value={editForm.jobTitle || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, jobTitle: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                      placeholder="مثال: مهندس برمجيات، معلّمة..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">طبيعة السكن <span className="text-red-500">*</span></label>
                    <select
                      value={editForm.housing || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, housing: e.target.value }))}
                      className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.housing ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                    >
                      <option value="">-- اختر طبيعة السكن --</option>
                      {C.HOUSING_TYPES.map((ht) => (
                        <option key={ht} value={ht}>{ht}</option>
                      ))}
                    </select>
                  </div>

                  {/* Health & Smoking */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الحالة الصحية</label>
                    <select
                      value={editForm.healthStatus || editForm.health || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, healthStatus: e.target.value, health: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                    >
                      <option value="">-- اختر الحالة الصحية --</option>
                      {C.HEALTH_STATUS.map((h) => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">التدخين</label>
                    <select
                      value={editForm.smoking || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, smoking: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                    >
                      <option value="">-- اختر التدخين --</option>
                      {C.SMOKING_OPTIONS.map((sm) => (
                        <option key={sm} value={sm}>{sm}</option>
                      ))}
                    </select>
                  </div>

                  {/* Bio & About Partner */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">نبذة عن العضو (تحدث عن نفسك)</label>
                    <textarea
                      value={editForm.bio || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, bio: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 h-16 resize-none"
                      placeholder="اكتب بضعة أسطر عن شخصيتك واهتماماتك..."
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">شروط ومواصفات الشريك المطلوبة</label>
                    <textarea
                      value={editForm.aboutPartner || editForm.pNotes || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, aboutPartner: e.target.value, pNotes: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 h-16 resize-none"
                      placeholder="اكتب مواصفات شريك الحياة المطلوب..."
                    />
                  </div>

                  {/* Incompleteness Override Checkbox */}
                  <div className="sm:col-span-2 bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl flex items-center justify-between mt-2">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-xs text-amber-900">حالة غير مكتملة</p>
                        <p className="text-[10px] text-amber-700 leading-relaxed">عند تفعيل هذا الخيار، سيتم اعتبار الملف غير مكتمل وسيُحجب من العرض العام للأعضاء.</p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={!!editForm.isProfileIncomplete}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, isProfileIncomplete: e.target.checked }))}
                      className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                    />
                  </div>
                </div>
              ) : activeEditTab === 'partner' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[50vh] overflow-y-auto px-1 py-1 font-cairo">
                  {/* partner terms header */}
                  <div className="sm:col-span-2 bg-slate-100/70 p-2.5 rounded-xl border border-slate-200">
                    <p className="text-xs font-bold text-slate-800">
                      تحديد مواصفات {getPartnerTerms(editForm.gender).partnerFullLabel}
                    </p>
                  </div>

                  {/* بلد إقامة الشريك */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">{getPartnerTerms(editForm.gender).countryLabel}</label>
                    <select
                      value={editForm.pCountry || 'لا يهم'}
                      onChange={(e) => {
                        const val = e.target.value;
                        setEditForm((prev: any) => ({ ...prev, pCountry: val, pCity: val === 'لا يهم' ? 'لا يهم' : '' }));
                      }}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                    >
                      <option value="لا يهم">لا يهم (أي دولة)</option>
                      {safeGetCountries(editForm.pCountry)
                        .filter((c) => c.name && c.name !== 'لا يهم')
                        .map((c, idx: number) => (
                          <option key={`pcountry-${c.name}-${idx}`} value={c.name}>{c.name}{c.isPending ? ' (مقترح معلق)' : ''}</option>
                        ))}
                    </select>
                  </div>

                  {/* مدينة إقامة الشريك */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">{getPartnerTerms(editForm.gender).cityLabel}</label>
                    <select
                      value={editForm.pCity || 'لا يهم'}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, pCity: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                    >
                      <option value="لا يهم">لا يهم (أي مدينة)</option>
                      {editForm.pCountry && editForm.pCountry !== 'لا يهم' ? safeGetCities(editForm.pCountry, editForm.pCity)
                        .filter((ct) => ct.name && ct.name !== 'لا يهم')
                        .map((ct, idx: number) => (
                          <option key={`pcity-${ct.name}-${idx}`} value={ct.name}>{ct.name}{ct.isPending ? ' (مقترح معلق)' : ''}</option>
                        )) : null}
                    </select>
                  </div>

                  {/* جنسية الشريك */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">{getPartnerTerms(editForm.gender).nationalityLabel}</label>
                    <div className="flex flex-wrap gap-2 mb-2 font-cairo">
                      <button
                        type="button"
                        onClick={() => setEditForm((prev: any) => ({ ...prev, pNationality: 'نفس جنسيتي' }))}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                          editForm.pNationality === 'نفس جنسيتي'
                            ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        ✓ نفس جنسيتي
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditForm((prev: any) => ({ ...prev, pNationality: 'اقبل اجنبي' }))}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                          editForm.pNationality === 'اقبل اجنبي' || editForm.pNationality === 'أقبل أجنبي'
                            ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        اقبل اجنبي (أية جنسية)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (editForm.pNationality === 'نفس جنسيتي' || editForm.pNationality === 'اقبل اجنبي' || editForm.pNationality === 'أقبل أجنبي' || editForm.pNationality === 'لا يهم') {
                            setEditForm((prev: any) => ({ ...prev, pNationality: '' }));
                          }
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                          editForm.pNationality !== 'نفس جنسيتي' && editForm.pNationality !== 'اقبل اجنبي' && editForm.pNationality !== 'أقبل أجنبي'
                            ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        تحديد جنسيات معينة
                      </button>
                    </div>
                    {editForm.pNationality !== 'نفس جنسيتي' && editForm.pNationality !== 'اقبل اجنبي' && editForm.pNationality !== 'أقبل أجنبي' && (
                      <input
                        type="text"
                        value={editForm.pNationality || ''}
                        onChange={(e) => setEditForm((prev: any) => ({ ...prev, pNationality: e.target.value }))}
                        placeholder="أدخل الجنسيات المحددة (مثال: سعودية، كويتية...)"
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                      />
                    )}
                  </div>

                  {/* مذهب الشريك */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">مذهب الشريك</label>
                    <select
                      value={editForm.pSect || 'لا يهم'}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, pSect: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                    >
                      <option value="لا يهم">لا يهم</option>
                      {C.SECTS.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  {/* العمر المطلوب للشريك */}
                  <div className="sm:col-span-2 border-t border-slate-100 pt-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-700 font-cairo">العمر المطلوب للشريك</label>
                      <button
                        type="button"
                        onClick={() => setEditForm((prev: any) => ({ ...prev, pAgeMin: '', pAgeMax: '' }))}
                        className="text-[11px] text-amber-600 hover:text-amber-800 font-bold font-cairo underline"
                      >
                        غير محدد / أي عمر
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-cairo block mb-0.5">من عمر (الحد الأدنى):</span>
                        <input
                          type="number"
                          min={16}
                          max={90}
                          value={editForm.pAgeMin ?? ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setEditForm((prev: any) => ({ ...prev, pAgeMin: val === '' ? '' : Number(val) }));
                          }}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                          placeholder="فارغ (أي عمر)"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-cairo block mb-0.5">إلى عمر (الحد الأقصى):</span>
                        <input
                          type="number"
                          min={16}
                          max={90}
                          value={editForm.pAgeMax ?? ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setEditForm((prev: any) => ({ ...prev, pAgeMax: val === '' ? '' : Number(val) }));
                          }}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-cairo"
                          placeholder="فارغ (أي عمر)"
                        />
                      </div>
                    </div>
                  </div>

                  {/* الحالة الاجتماعية للشريك */}
                  <div className="sm:col-span-2 border-t border-slate-100 pt-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-700 font-cairo">{getPartnerTerms(editForm.gender).maritalLabel}</label>
                      <button
                        type="button"
                        onClick={() => setEditForm((prev: any) => ({ ...prev, pMaritalStatus: 'لا يهم', pMarital: 'لا يهم' }))}
                        className="text-[11px] text-amber-600 hover:text-amber-800 font-bold font-cairo underline"
                      >
                        لا يهم / الجميع
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2 font-cairo">
                      {getPartnerMaritalOptions(editForm.gender).map((opt) => {
                        const isSelected = (editForm.pMaritalStatus || editForm.pMarital || '').includes(opt);
                        return (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => {
                              let current = (editForm.pMaritalStatus || editForm.pMarital || '').split('، ').map((s: string) => s.trim()).filter(Boolean);
                              if (current.includes('لا يهم')) current = [];
                              if (current.includes(opt)) {
                                current = current.filter((x: string) => x !== opt);
                              } else {
                                current.push(opt);
                              }
                              const newVal = current.length === 0 ? 'لا يهم' : current.join('، ');
                              setEditForm((prev: any) => ({ ...prev, pMaritalStatus: newVal, pMarital: newVal }));
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1 ${
                              isSelected && (editForm.pMaritalStatus || editForm.pMarital) !== 'لا يهم'
                                ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {isSelected && (editForm.pMaritalStatus || editForm.pMarital) !== 'لا يهم' && <span>✓</span>}
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* قبول أطفال لدى الشريك */}
                  <div className="sm:col-span-2 border-t border-slate-100 pt-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1 font-cairo">{getPartnerTerms(editForm.gender).childrenLabel}</label>
                    <div className="flex flex-wrap gap-2 font-cairo">
                      {['نعم', 'لا', 'لا يهم', 'بشرط ألا يعيشوا معنا'].map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => setEditForm((prev: any) => ({ ...prev, pAcceptChildren: opt }))}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                            (editForm.pAcceptChildren || 'لا يهم') === opt
                              ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {opt === 'نعم' ? 'نعم (أقبل)' : opt === 'لا' ? 'لا (أفضل بدون أطفال)' : opt}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* ملاحظات وشروط إضافية */}
                  <div className="sm:col-span-2 border-t border-slate-100 pt-2 font-cairo">
                    <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات إضافية وشروط عن الشريك</label>
                    <textarea
                      value={editForm.pNotes || editForm.aboutPartner || ''}
                      onChange={(e) => setEditForm((prev: any) => ({ ...prev, pNotes: e.target.value, aboutPartner: e.target.value }))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 h-20 resize-none font-cairo"
                      placeholder={getPartnerTerms(editForm.gender).notesPlaceholder}
                    />
                  </div>
                </div>
              ) : (
                /* tab === 'account' */
                <div className="space-y-4 max-h-[50vh] overflow-y-auto px-1 py-1 font-cairo">
                  {/* Real Name & Contact */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">الاسم الحقيقي بالكامل <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={editForm.realName || editForm.real_name || ''}
                        onChange={(e) => setEditForm((prev: any) => ({ ...prev, realName: e.target.value, real_name: e.target.value }))}
                        className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${(!editForm.realName && !editForm.real_name) ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                        placeholder="الاسم الثلاثي أو الرباعي"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">رقم الواتساب / الهاتف <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={editForm.whatsapp || editForm.phone || ''}
                        onChange={(e) => setEditForm((prev: any) => ({ ...prev, whatsapp: e.target.value, phone: e.target.value }))}
                        className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${(!editForm.whatsapp && !editForm.phone) ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                        placeholder="0500000000"
                        dir="ltr"
                      />
                    </div>
                  </div>

                  {/* Email & Password */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">البريد الإلكتروني <span className="text-red-500">*</span></label>
                      <input
                        type="email"
                        value={editForm.email || ''}
                        onChange={(e) => setEditForm((prev: any) => ({ ...prev, email: e.target.value }))}
                        className={`w-full px-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.email ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                        placeholder="member@email.com"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-bold text-slate-700">كلمة المرور / الرمز السر <span className="text-red-500">*</span></label>
                        <button
                          type="button"
                          onClick={generateNewPassword}
                          className="text-[10px] font-bold text-amber-600 hover:text-amber-800 flex items-center gap-1"
                        >
                          <RefreshCw className="w-3 h-3" /> توليد عشوائي
                        </button>
                      </div>
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={editForm.password || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, password: e.target.value }))}
                          className={`w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border text-xs focus:outline-none focus:border-amber-400 ${!editForm.password ? 'border-red-300 bg-red-50/20' : 'border-slate-200'}`}
                          placeholder="Pass@1234"
                          dir="ltr"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword((v) => !v)}
                          className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Khataaba & Office Import Section */}
                  <div className="border border-purple-200 bg-purple-50/40 p-3 rounded-xl space-y-3">
                    <p className="text-xs font-extrabold text-purple-900 flex items-center gap-1.5">
                      <LogIn className="w-4 h-4 text-purple-600" /> بيانات الاستيراد والخطابة المنسوب إليها العضو
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-purple-900 mb-1">اسم الخطابة المنسوبة إليها</label>
                        <input
                          type="text"
                          value={editForm.khataabaName || 'مستورد مباشر (بدون خطابة)'}
                          disabled
                          className="w-full px-3 py-2 rounded-xl bg-purple-100/70 border border-purple-200 text-xs font-bold text-purple-900 cursor-not-allowed select-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-purple-900 mb-1">رقم هاتف الخطابة</label>
                        <input
                          type="text"
                          value={editForm.khataabaPhone || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, khataabaPhone: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-white border border-purple-200 text-xs focus:outline-none focus:border-purple-400 font-mono"
                          placeholder="0500000000"
                          dir="ltr"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-purple-900 mb-1">اسم مكتب / قروب الاستيراد</label>
                        <input
                          type="text"
                          value={editForm.importOfficeName || ''}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, importOfficeName: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-white border border-purple-200 text-xs focus:outline-none focus:border-purple-400"
                          placeholder="مثال: مكتب الرياض"
                        />
                      </div>
                    </div>
                    <p className="text-[10px] text-purple-700 leading-relaxed font-bold">
                      🔒 ملاحظة إدارية: اسم الخطابة مربوط برقم هاتفها المعرف في سجل الخطابات والمكاتب، وتعديل رقم الهاتف يحتفظ برابط المنسوبين تلقائياً لمنع فقدان أو حذف البيانات.
                    </p>
                  </div>

                  {/* Subscription Plan & Pinning */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-slate-100 pt-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">باقة الاشتراك</label>
                      <select
                        value={editForm.plan || 'free'}
                        onChange={(e) => setEditForm((prev: any) => ({ 
                          ...prev, 
                          plan: e.target.value, 
                          premium: e.target.value === 'gold' || e.target.value === 'elite' 
                        }))}
                        className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-bold"
                      >
                        <option value="free">المجانية (Free)</option>
                        <option value="gold">الذهبية (Gold)</option>
                        <option value="elite">المميز (Elite) ⭐</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-2 pt-5">
                      <input
                        type="checkbox"
                        id="editFormPinnedModal"
                        checked={!!editForm.pinned}
                        onChange={(e) => setEditForm((prev: any) => ({ ...prev, pinned: e.target.checked }))}
                        className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                      />
                      <label htmlFor="editFormPinnedModal" className="text-xs font-bold text-slate-700 cursor-pointer select-none flex items-center gap-1">
                        <Pin className="w-3.5 h-3.5 text-amber-500 fill-amber-500 rotate-45" /> تثبيت العضو في صدارة البحث والرئيسية
                      </label>
                    </div>
                  </div>

                  {/* Administrative Status */}
                  <div className="border-t border-slate-100 pt-3 space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">حالة الحساب الإدارية</label>
                        <select
                          value={editForm.status || 'active'}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, status: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400 font-bold"
                        >
                          <option value="active">نشط (مفعل بالمنصة) ✓</option>
                          <option value="pending">قيد المراجعة ⏳</option>
                          <option value="suspended">موقوف مؤقتاً ⚠️</option>
                          <option value="banned">محظور نهائياً ⛔</option>
                          <option value="inactive">غير نشط 💤</option>
                        </select>
                      </div>
                      {(editForm.status === 'suspended' || editForm.status === 'banned') && (
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">سبب الإيقاف / الحظر</label>
                          <input
                            type="text"
                            value={editForm.statusReason || ''}
                            onChange={(e) => setEditForm((prev: any) => ({ ...prev, statusReason: e.target.value }))}
                            className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-amber-400"
                            placeholder="سبب الإيقاف الظاهر للعضو..."
                          />
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div className="flex items-center gap-2 bg-sky-50/50 p-2.5 rounded-xl border border-sky-100">
                        <input
                          type="checkbox"
                          id="editFormVerifiedModal"
                          checked={!!editForm.verified}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, verified: e.target.checked }))}
                          className="w-4 h-4 rounded accent-sky-500 cursor-pointer"
                        />
                        <label htmlFor="editFormVerifiedModal" className="text-xs font-bold text-slate-800 cursor-pointer select-none flex items-center gap-1.5">
                          <BadgeCheck className="w-4 h-4 text-sky-500" /> توثيق الهوية بالمنصة
                        </label>
                      </div>
                      <div className="flex items-center gap-2 bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-100">
                        <input
                          type="checkbox"
                          id="editFormSeriousnessBadgeModal"
                          checked={!!editForm.hasSeriousnessBadge}
                          onChange={(e) => setEditForm((prev: any) => ({ ...prev, hasSeriousnessBadge: e.target.checked }))}
                          className="w-4 h-4 rounded accent-emerald-500 cursor-pointer"
                        />
                        <label htmlFor="editFormSeriousnessBadgeModal" className="text-xs font-bold text-slate-800 cursor-pointer select-none flex items-center gap-1.5">
                          <Award className="w-4 h-4 text-emerald-500" /> منح وسام الجدية
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Form Actions */}
              <div className="flex gap-2 pt-3 border-t border-slate-200 font-cairo">
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  <span>حفظ التغييرات</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </form>
          ) : (
            /* View Mode */
            <div className="space-y-4 font-cairo">
              {/* Header Info */}
              <div className="flex items-center gap-3">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-2xl ${
                    member.gender === 'male' ? 'bg-blue-500' : 'bg-rose-500'
                  }`}
                >
                  {(member.nickname || member.realName || '؟').charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 justify-between flex-wrap">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-extrabold text-lg text-slate-900 truncate">{member.nickname || member.realName || 'بدون اسم'}</h3>
                      {member.verified && <BadgeCheck className="w-5 h-5 text-blue-500 shrink-0" />}
                      {member.premium && <Crown className="w-5 h-5 text-amber-500 shrink-0" />}
                      {member.isProfileIncomplete && (
                        <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 rounded select-none shrink-0">غير مكتمل</span>
                      )}
                    </div>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 text-white font-bold text-xs hover:bg-amber-600 transition-all flex items-center gap-1"
                    >
                      <Edit className="w-3.5 h-3.5" /> تعديل البيانات
                    </button>
                  </div>
                  <p className="text-sm text-slate-500">
                    {member.age} سنة · {member.city}، {member.country}
                  </p>
                  <div className="flex gap-1.5 mt-1 flex-wrap">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${getStatusCfg(member.status).color}`}>
                      {getStatusCfg(member.status).label}
                    </span>
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${getPlanCfg(member.plan).color}`}>
                      {getPlanCfg(member.plan).label}
                    </span>
                    {member.flagged && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-100 text-rose-700 flex items-center gap-0.5">
                        <Flag className="w-3 h-3" /> معلّم
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Account restriction banner */}
              {member.status !== 'active' && member.status !== 'pending' && (
                <div className={`rounded-xl p-3 border ${
                  member.status === 'banned' ? 'bg-rose-50 border-rose-200' : 'bg-orange-50 border-orange-200'
                }`}>
                  <div className="flex items-center gap-1.5 mb-1">
                    {member.status === 'banned' ? <UserX className="w-4 h-4 text-rose-600" /> :
                     <Ban className="w-4 h-4 text-orange-600" />}
                    <span className="text-xs font-bold text-slate-800">
                      الحساب {getStatusCfg(member.status).label}
                    </span>
                  </div>
                  {member.statusReason && (
                    <p className="text-xs text-slate-600 leading-relaxed">السبب: {member.statusReason}</p>
                  )}
                  {member.statusChangedAt && (
                    <p className="text-[10px] text-slate-400 mt-1">
                      بواسطة {member.statusChangedBy || 'الإدارة'} · {new Date(member.statusChangedAt).toLocaleString('ar-SA')}
                    </p>
                  )}
                </div>
              )}

              {/* View Tabs */}
              <div className="flex border-b border-slate-200 mb-3">
                <button
                  type="button"
                  onClick={() => setActiveViewTab('basic')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all ${
                    activeViewTab === 'basic' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  البيانات والصفات الشخصية
                </button>
                <button
                  type="button"
                  onClick={() => setActiveViewTab('partner')}
                  className={`flex-1 text-center py-2.5 font-bold text-xs border-b-2 transition-all ${
                    activeViewTab === 'partner' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  مواصفات الشريك المطلوبة
                </button>
              </div>

              {activeViewTab === 'basic' ? (
                <div className="space-y-4 max-h-[50vh] overflow-y-auto px-1 py-1 font-cairo">
                  {(() => {
                    const basicItems = [
                      { label: 'نوع الزواج المطلوب', value: member.marriageType === 'misyar' ? 'مسيار' : member.marriageType === 'both' ? 'معلن أو مسيار' : member.marriageType === 'announced' ? 'معلن' : '' },
                      { label: 'القبيلة / النسب', value: member.tribe },
                      { label: 'العرق', value: member.ethnicity },
                      { label: 'الجنس', value: member.gender === 'male' ? 'ذكر' : member.gender === 'female' ? 'أنثى' : '' },
                      { label: 'الحالة الاجتماعية', value: member.maritalStatus === 'single' ? (member.gender === 'male' ? 'أعزب' : 'عزباء') : member.maritalStatus === 'divorced' ? (member.gender === 'male' ? 'مطلق' : 'مطلقة') : (member.maritalStatus === 'widow' || member.maritalStatus === 'widower') ? (member.gender === 'male' ? 'أرمل' : 'أرملة') : member.maritalStatus === 'married' ? 'متزوج' : member.maritalStatus },
                      { label: 'العمر', value: member.age ? `${member.age} سنة` : '' },
                      { label: 'الدولة', value: member.country },
                      { label: 'المدينة', value: member.city },
                      { label: 'المنطقة / الحي', value: member.district },
                      { label: 'الجنسية', value: member.nationality },
                      { label: 'المذهب', value: member.sect },
                      { label: 'عدد الأبناء', value: member.childrenCount },
                      { label: 'الطول', value: member.height ? `${member.height} سم` : '' },
                      { label: 'الوزن', value: member.weight ? `${member.weight} كجم` : '' },
                      { label: 'لون البشرة', value: member.skinColor },
                      { label: 'الحالة الصحية', value: member.health || member.healthStatus },
                      { label: 'التدخين', value: member.smoking },
                      { label: 'التعليم', value: member.education },
                      { label: 'طبيعة السكن', value: member.housing },
                      { label: 'جهة العمل', value: member.workType || member.occupation },
                      { label: 'المسمى الوظيفي', value: member.jobTitle },
                      ...(member.gender === 'female' ? [{ label: 'تقبل التعدد', value: member.acceptPolygamy === 'yes' ? 'نعم' : member.acceptPolygamy === 'no' ? 'لا' : member.acceptPolygamy === 'first_only' ? 'الزوجة الأولى فقط' : '' }] : []),
                    ].filter((item) => {
                      if (!item.value) return false;
                      const s = String(item.value).trim();
                      return s !== '' && s !== '—' && s !== '-' && s !== 'غير محدد' && s !== 'غير مذكور' && s !== 'لم يتم الاختيار' && s !== 'لا يوجد' && s !== 'لا يهم' && s !== '0';
                    });

                    const hasBio = member.bio && String(member.bio).trim() !== '' && String(member.bio).trim() !== '—';

                    if (basicItems.length === 0 && !hasBio) {
                      return (
                        <p className="text-xs text-slate-400 text-center py-8 font-cairo">
                          لا توجد بيانات شخصية محددة للعرض
                        </p>
                      );
                    }

                    return (
                      <>
                        {basicItems.length > 0 && (
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2">
                            {basicItems.map((item) => (
                              <div key={item.label} className="bg-slate-50 rounded-xl p-2.5 border border-slate-100">
                                <span className="text-[10px] text-slate-400 block mb-0.5">{item.label}</span>
                                <span className="font-bold text-xs text-slate-800">{item.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {hasBio && (
                          <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                            <span className="text-[10px] text-slate-400 block mb-1">نبذة تعريفية عن النفس</span>
                            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">{member.bio}</p>
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              ) : (
                <div className="space-y-4 max-h-[50vh] overflow-y-auto px-1 py-1 font-cairo">
                  {(() => {
                    const getPartnerNatDisplay = (nat?: string) => {
                      if (!nat || nat === 'لا يهم' || nat === 'غير محدد') return '';
                      if (nat === 'اقبل اجنبي' || nat === 'أقبل أجنبي') return 'اقبل اجنبي (أية جنسية)';
                      if (nat === 'نفس جنسيتي') return 'نفس جنسيتي';
                      return nat;
                    };

                    const getPartnerAgeDisplay = (min?: number | string, max?: number | string) => {
                      const minNum = min ? Number(min) : null;
                      const maxNum = max ? Number(max) : null;
                      if (minNum && maxNum) return `من ${minNum} إلى ${maxNum} سنة`;
                      if (minNum) return `من ${minNum} سنة فأكثر`;
                      if (maxNum) return `حتى ${maxNum} سنة`;
                      return '';
                    };

                    const partnerItems = [
                      { label: 'بلد إقامة الشريك', value: member.pCountry === 'لا يهم' ? '' : member.pCountry },
                      { label: 'مدينة إقامة الشريك', value: member.pCity === 'لا يهم' ? '' : member.pCity },
                      { label: 'جنسية الشريك', value: getPartnerNatDisplay(member.pNationality) },
                      { label: 'مذهب الشريك', value: member.pSect === 'لا يهم' ? '' : member.pSect },
                      { label: 'العمر المطلوب', value: getPartnerAgeDisplay(member.pAgeMin, member.pAgeMax) },
                      { label: 'الحالة الاجتماعية المقبولة', value: (member.pMaritalStatus || member.pMarital) === 'لا يهم' ? '' : (member.pMaritalStatus || member.pMarital) },
                      { label: 'قبول أطفال لدى الشريك', value: member.pAcceptChildren === 'لا يهم' ? '' : member.pAcceptChildren },
                      { label: 'لون البشرة المطلوب', value: member.pSkinColor === 'لا يهم' ? '' : member.pSkinColor },
                      { label: 'المؤهل الدراسي المطلوب', value: member.pEducation === 'لا يهم' ? '' : member.pEducation },
                      { label: 'جهة عمل الشريك', value: member.pWorkType === 'لا يهم' ? '' : member.pWorkType },
                      { label: 'الطول المفضل', value: member.pHeight ? `${member.pHeight} سم` : '' },
                      { label: 'نوع السكن المطلوب', value: member.pHousing === 'لا يهم' ? '' : member.pHousing },
                    ].filter((item) => {
                      if (!item.value) return false;
                      const s = String(item.value).trim();
                      return s !== '' && s !== '—' && s !== '-' && s !== 'غير محدد' && s !== 'غير مذكور' && s !== 'لم يتم الاختيار' && s !== 'لا يوجد' && s !== 'لا يهم' && s !== '0' && s !== 'null' && s !== 'undefined';
                    });

                    const pNotesVal = member.pNotes || member.aboutPartner;
                    const hasPNotes = pNotesVal && String(pNotesVal).trim() !== '' && String(pNotesVal).trim() !== '—';

                    if (partnerItems.length === 0 && !hasPNotes) {
                      return (
                        <p className="text-xs text-slate-400 text-center py-8 font-cairo">
                          لا توجد مواصفات محددة للشريك المطلوبة
                        </p>
                      );
                    }

                    return (
                      <>
                        {partnerItems.length > 0 && (
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2">
                            {partnerItems.map((item) => (
                              <div key={item.label} className="bg-slate-50 rounded-xl p-2.5 border border-slate-100">
                                <span className="text-[10px] text-slate-400 block mb-0.5">{item.label}</span>
                                <span className="font-bold text-xs text-slate-800">{item.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {hasPNotes && (
                          <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                            <span className="text-[10px] text-slate-400 block mb-1">ملاحظات إضافية عن الشريك المطلوب</span>
                            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">{pNotesVal}</p>
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              )}

              {/* Sensitive Data Section */}
              {(() => {
                const sensitiveItems = [
                  { icon: Fingerprint, label: 'الاسم الحقيقي', value: member.realName || member.real_name },
                  { icon: Mail, label: 'البريد', value: member.email },
                  { icon: Phone, label: 'رقم الواتساب', value: member.whatsapp || member.phone },
                  { icon: KeyRound, label: 'كلمة المرور', value: member.password },
                  { icon: LogIn, label: 'اسم الخطابة', value: member.khataabaName },
                  { icon: Phone, label: 'هاتف الخطابة', value: member.khataabaPhone },
                  { icon: Fingerprint, label: 'الهوية', value: member.nationalId },
                ].filter((f) => {
                  if (!f.value) return false;
                  const s = String(f.value).trim();
                  return s !== '' && s !== '—' && s !== 'غير محدد' && s !== 'مستورد مباشر';
                });

                if (sensitiveItems.length === 0) return null;

                return (
                  <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 font-cairo">
                    <div className="flex items-center justify-between mb-2">
                      <span className="flex items-center gap-1.5 text-xs font-bold text-rose-700">
                        <Lock className="w-4 h-4" /> بيانات حساسة — للإدارة فقط
                      </span>
                      <button
                        onClick={() => setRevealSensitive((v) => !v)}
                        className="text-[11px] font-bold text-rose-700 bg-white px-2.5 py-1 rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        {revealSensitive ? 'إخفاء' : 'كشف الكل'}
                      </button>
                    </div>
                    <div className="space-y-1.5">
                      {sensitiveItems.map((f) => {
                        const Icon = f.icon;
                        return (
                          <div key={f.label} className="flex items-center gap-2 text-sm bg-white/60 rounded-lg px-2 py-1.5">
                            <Icon className="w-4 h-4 text-slate-400 flex-shrink-0" />
                            <span className="text-slate-500 text-xs w-24 flex-shrink-0">{f.label}:</span>
                            <span className="text-slate-800 flex-1 truncate font-mono" dir="ltr">
                              {revealSensitive ? f.value : '•••••••••'}
                            </span>
                            {revealSensitive && (
                              <button
                                onClick={() => {
                                  navigator.clipboard?.writeText(f.value);
                                  showLocalToast('تم نسخ ' + f.label + ' ✓');
                                }}
                                className="text-slate-400 hover:text-slate-700 flex-shrink-0"
                                title="نسخ"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    {revealSensitive && member.email && (
                      <button
                        onClick={async () => {
                          const { error } = await supabase.auth.resetPasswordForEmail(member.email, {
                            redirectTo: `${window.location.origin}/reset-password`,
                          });
                          showLocalToast(error ? 'تعذّر إرسال رابط إعادة التعيين' : `تم إرسال رابط إعادة تعيين كلمة المرور إلى ${member.email} ✓`);
                        }}
                        className="w-full mt-2 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-white border border-rose-200 text-rose-600 font-bold text-xs hover:bg-rose-100 transition-colors"
                      >
                        <KeyRound className="w-3.5 h-3.5" /> إرسال رابط إعادة تعيين كلمة المرور للعضو
                      </button>
                    )}
                  </div>
                );
              })()}

              {/* Admin Note Section */}
              <div>
                <label className="flex items-center gap-1.5 text-xs font-bold text-slate-600 mb-1">
                  <StickyNote className="w-4 h-4" /> ملاحظة إدارية خاصة
                </label>
                <div className="flex gap-2">
                  <input
                    value={noteDraft}
                    onChange={(e) => setNoteDraft(e.target.value)}
                    placeholder="اكتب ملاحظة..."
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none text-sm"
                  />
                  <button
                    onClick={async () => {
                      await setNote(member.id, noteDraft);
                      showLocalToast('حُفظت الملاحظة ✓');
                      onUpdated?.();
                    }}
                    className="px-4 rounded-xl bg-slate-900 text-white font-bold text-sm"
                  >
                    حفظ
                  </button>
                </div>
              </div>

              {/* Quick Admin Actions (Grid) */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                <button
                  onClick={async () => {
                    await toggleVerified(member.id, !member.verified);
                    showLocalToast(member.verified ? 'أُلغي التوثيق' : 'تم التوثيق ✓');
                    onUpdated?.();
                  }}
                  className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-sm ${
                    member.verified ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  <BadgeCheck className="w-4 h-4" /> {member.verified ? 'موثق' : 'توثيق'}
                </button>
                <button
                  onClick={async () => {
                    await setPremium(member.id, !member.premium);
                    showLocalToast(member.premium ? 'أُلغي التميّز' : 'ترقية مميّز 👑');
                    onUpdated?.();
                  }}
                  className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-sm ${
                    member.premium ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  <Crown className="w-4 h-4" /> {member.premium ? 'مميّز' : 'ترقية'}
                </button>
                {member.status !== 'active' ? (
                  <button
                    onClick={async () => {
                      await updateMember(member.id, { status: 'active' });
                      showLocalToast('تم التفعيل ✓');
                      onUpdated?.();
                    }}
                    className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-100 text-emerald-700 font-bold text-sm"
                  >
                    <UserCheck className="w-4 h-4" /> تفعيل
                  </button>
                ) : (
                  <button
                    onClick={async () => {
                      await updateMember(member.id, { status: 'suspended' });
                      showLocalToast('تم الإيقاف');
                      onUpdated?.();
                    }}
                    className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-rose-100 text-rose-700 font-bold text-sm"
                  >
                    <UserX className="w-4 h-4" /> إيقاف
                  </button>
                )}
                <button
                  onClick={async () => {
                    await toggleFlag(member.id, !member.flagged);
                    showLocalToast(member.flagged ? 'أُزيل التعليم' : 'تم التعليم');
                    onUpdated?.();
                  }}
                  className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-sm ${
                    member.flagged ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  <Flag className="w-4 h-4" /> {member.flagged ? 'معلّم' : 'تعليم'}
                </button>
              </div>

              {/* Full-width Action Buttons */}
              <button
                onClick={() => { setNotifyFor(member); setNotifyText(''); }}
                className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-amber-500 text-white font-bold text-sm hover:brightness-105"
              >
                <Send className="w-4 h-4 -scale-x-100" /> إرسال إشعار للعضو
              </button>

              <button
                onClick={() => impersonateAndGo(member)}
                className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-l from-slate-900 to-slate-800 text-amber-300 font-bold text-sm hover:brightness-110 transition-all border border-amber-500/30"
              >
                <LogIn className="w-4 h-4" /> الدخول بحساب العضو
              </button>

              <button
                onClick={() => setDeleteFor(member)}
                className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-white border-2 border-rose-200 text-rose-600 font-bold text-sm hover:bg-rose-50 transition-colors"
              >
                <Trash2 className="w-4 h-4" /> حذف الحساب نهائياً
              </button>
            </div>
          )}
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal open={!!deleteFor} onClose={() => setDeleteFor(null)} title="حذف أو تعطيل الحساب">
        {deleteFor && (
          <div className="text-center font-cairo" dir="rtl">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-7 h-7 text-rose-500" />
            </div>
            <p className="font-bold text-slate-800 mb-1">التحكم بحساب العضو «{deleteFor.nickname || deleteFor.realName}»</p>
            <p className="text-xs text-slate-500 mb-4">اختر الإجراء المناسب لحالة العضو:</p>
            
            <div className="grid gap-3 mb-5 text-right">
              {/* Option 1: Temporary Suspension */}
              <button
                type="button"
                onClick={async () => {
                  await updateMember(deleteFor.id, { status: 'suspended', statusReason: 'تعطيل مؤقت من الإدارة' });
                  setDeleteFor(null);
                  showLocalToast('تم تعطيل حساب العضو مؤقتاً بنجاح');
                  onClose();
                  onUpdated?.();
                }}
                className="p-3.5 rounded-2xl border-2 border-amber-200 hover:border-amber-400 bg-amber-50/50 hover:bg-amber-50 transition-all text-right flex items-start gap-3"
              >
                <div className="w-6 h-6 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center flex-shrink-0 mt-0.5">⚠️</div>
                <div>
                  <h4 className="font-bold text-xs text-amber-900">تعطيل الحساب مؤقتاً (Suspend)</h4>
                  <p className="text-[11px] text-slate-600 mt-0.5">يخفي الملف من البحث والموقع ويمنع العضو من تسجيل الدخول، مع الاحتفاظ ببياناته وإمكانية تفعيله مجدداً لاحقاً.</p>
                </div>
              </button>

              {/* Option 2: Hard Delete */}
              <button
                type="button"
                onClick={() => hardDeleteMember(deleteFor.id)}
                className="p-3.5 rounded-2xl border-2 border-rose-200 hover:border-rose-400 bg-rose-50/30 hover:bg-rose-50 transition-all text-right flex items-start gap-3"
              >
                <div className="w-6 h-6 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center flex-shrink-0 mt-0.5">☠️</div>
                <div>
                  <h4 className="font-bold text-xs text-rose-900">حذف العضو نهائياً (Hard Delete)</h4>
                  <p className="text-[11px] text-slate-600 mt-0.5">يمسح العضو تماماً من قاعدة البيانات بما في ذلك كافة سجلاته ومعاملاته وإشعاراته، مما يتيح له إعادة التسجيل بنفس الهاتف أو البريد.</p>
                </div>
              </button>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setDeleteFor(null)}
                className="w-full py-2.5 rounded-xl bg-slate-100 text-slate-600 font-bold text-sm hover:bg-slate-200 transition-colors"
              >
                إلغاء التراجع
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Send Notification Modal */}
      <Modal open={!!notifyFor} onClose={() => setNotifyFor(null)} title="إرسال إشعار للعضو">
        {notifyFor && (
          <div dir="rtl" className="font-cairo">
            <p className="text-sm text-slate-500 mb-3">
              سيصل هذا الإشعار إلى <strong className="text-slate-800">{notifyFor.nickname || notifyFor.realName}</strong> داخل المنصة.
            </p>
            <textarea
              value={notifyText}
              onChange={(e) => setNotifyText(e.target.value)}
              rows={4}
              placeholder="نص الإشعار..."
              className="w-full px-3 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:border-amber-400 focus:outline-none text-sm"
            />
            <div className="flex flex-wrap gap-2 mt-2">
              {['نرحّب بك في توافق ✨', 'يرجى استكمال توثيق حسابك.', 'تمت مراجعة ملفك بنجاح ✓'].map((t) => (
                <button
                  key={t}
                  onClick={() => setNotifyText(t)}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs hover:bg-slate-200"
                >
                  {t}
                </button>
              ))}
            </div>
            <div className="flex gap-2 mt-4">
              <button
                onClick={() => setNotifyFor(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-600 font-bold text-sm"
              >
                إلغاء
              </button>
              <button
                onClick={() => {
                  if (!notifyText.trim()) return;
                  dataService.db.addNotification?.({
                    userId: notifyFor.id,
                    title: 'إشعار إداري',
                    message: notifyText.trim(),
                    type: 'admin',
                    read: false,
                    createdAt: new Date().toISOString(),
                  });
                  showLocalToast('تم إرسال الإشعار بنجاح ✓');
                  setNotifyFor(null);
                  setNotifyText('');
                }}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 text-white font-bold text-sm hover:bg-amber-600"
              >
                إرسال الآن
              </button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
}
