import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, MapPin, Briefcase, GraduationCap, Ruler, Heart, Bookmark,
  ShieldCheck, Calendar, Users, Copy, Share2, Crown, Check,
  AlertTriangle, Send, Ban, Weight, Palette, Stethoscope, Cigarette,
  Home, ExternalLink, FileText, User, Sparkles, Building2, Church,
  TreePine, Flame, Zap, Shield, Eye, Lock, Globe, Baby, Scale,
} from 'lucide-react';
import type { Member } from '../lib/members';
import { useApp } from '../lib/AppContext';
import { getAvatar, getGenderColors } from '../lib/types';
import { formatMaritalStatus, getPartnerSummary } from '../lib/memberUtils';
import { getCurrentUserId, useInterestRequests } from '../lib/useInterestRequests';
import { normalizeNationality } from '../lib/data/optionNormalizer';

interface MemberProfileModalProps {
  member: Member | null;
  open: boolean;
  onClose: () => void;
}

const MESSAGE_TEMPLATES = [
  'السلام عليكم ورحمة الله، لفت انتباهي توافق ملفنا وأتمنى التوفيق لنا.',
  'مرحبًا، أرى توافقًا في القيم والأهداف وأرغب بالتوافق الجاد للزواج بإذن الله.',
  'السلام عليكم، ملفك أعجبني وأبحث عن شريك بصفات مشابهة، أتمنى التواصل.',
  'تحية طيبة، لاحظت توافقًا في المواصفات وأرغب في التقدم عبر الإدارة.',
];

export default function MemberProfileModal({ member, open, onClose }: MemberProfileModalProps) {
  const navigate = useNavigate();
  const {
    user, likedMembers, toggleLike, showToast, checkLimit, incrementUsage,
    sendInterestRequest, submitReport,
    blockedMembers, toggleBlock,
  } = useApp();

  const [contactOpen, setContactOpen] = useState(false);
  const [contactMsg, setContactMsg] = useState('');
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [sending, setSending] = useState(false);

  const currentUserId = user?.isLoggedIn ? (user.memberId || getCurrentUserId()) : '';
  const { requests } = useInterestRequests(currentUserId);

  const latestRequest = useMemo(() => {
    if (!user?.isLoggedIn || !requests || requests.length === 0 || !member?.id || !currentUserId) return null;
    const sent = requests.filter(r => r.sender_id === currentUserId && r.receiver_id === member.id);
    if (sent.length === 0) return null;
    return [...sent].sort((a, b) => b.id - a.id)[0];
  }, [requests, currentUserId, member?.id, user?.isLoggedIn]);

  if (!open || !member) return null;

  const liked = user?.isLoggedIn ? likedMembers.has(member.id) : false;
  const isBlocked = user?.isLoggedIn ? blockedMembers.has(member.id) : false;
  const isSelf = Boolean(user?.isLoggedIn && currentUserId && member.id === currentUserId);

  const safeGender = (member.gender === 'male' || member.gender === 'female' ? member.gender : 'female') as any;
  const avatar = getAvatar(safeGender);
  const c = getGenderColors(safeGender);
  const isMale = member.gender === 'male';

  const maritalFormatted = formatMaritalStatus(member.maritalStatus, member.maritalLabel, member.gender);
  const marriageTypeFormatted = member.marriageTypeLabel || (
    member.marriageType === 'misyar' ? 'مسيار' :
    member.marriageType === 'both' ? 'معلن أو مسيار' :
    member.marriageType === 'announced' ? 'معلن' :
    (member as any).marriage_type === 'misyar' ? 'مسيار' :
    (member as any).marriage_type === 'both' ? 'معلن أو مسيار' :
    (member as any).marriage_type === 'announced' ? 'معلن' : ''
  );
  const partnerSummary = getPartnerSummary(member);

  const limitCheck = checkLimit('message');

  // نسخ جميع بيانات العضو بطريقة مرتبة وشاملة للحافظة
  const handleCopyMemberData = () => {
    const genderWord = isMale ? 'رجل' : 'امرأة';
    const profileUrl = member.username
      ? `${window.location.origin}/u/${member.username}`
      : `${window.location.origin}/member/${member.id}`;

    const lines = [
      `📌 **بيانات العضو في منصة توافق للزواج الشرعي** 📌`,
      `━━━━━━━━━━━━━━━━━━━━`,
      `👤 الاسم المستعار: ${member.nickname || 'غير محدد'}`,
      member.username ? `🆔 اليوزر: @${member.username}` : null,
      `⚤ الجنس: ${genderWord}`,
      `🎂 العمر: ${member.age ? `${member.age} سنة` : 'غير محدد'}`,
      `📍 الدولة والمدينة: ${[member.city, member.country].filter(Boolean).join('، ') || 'غير محدد'}`,
      member.district ? `🏙️ المنطقة/الحي: ${member.district}` : null,
      member.nationality ? `🌍 الجنسية: ${member.nationality}` : null,
      member.sect ? `🕌 المذهب: ${member.sect}` : null,
      (member as any).tribe ? `🏛️ القبيلة/النسب: ${(member as any).tribe}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      `💍 الحالة الاجتماعية: ${member.maritalLabel || member.maritalStatus || 'غير محدد'}`,
      marriageTypeFormatted ? `📜 نوع الزواج المطلوب: ${marriageTypeFormatted}` : null,
      member.hasChildren ? `👶 الأطفال: نعم (${member.childrenCount || 'يوجد'})` : `👶 الأطفال: لا يوجد`,
      member.housing ? `🏠 السكن: ${member.housing}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      `💼 العمل والوظيفة: ${member.jobTitle || member.workType || 'غير محدد'}`,
      member.education ? `🎓 المؤهل التعليمي: ${member.education}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      member.height ? `📏 الطول: ${member.height} سم` : null,
      member.weight ? `⚖️ الوزن: ${member.weight} كجم` : null,
      member.skinColor ? `🎨 لون البشرة: ${member.skinColor}` : null,
      member.health ? `🏥 الحالة الصحية: ${member.health}` : null,
      member.smoking ? `🚬 التدخين: ${member.smoking}` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      member.bio ? `📝 نبذة عني:\n"${member.bio}"` : null,
      member.aboutPartner ? `🎯 مواصفات الشريك المطلوب:\n"${member.aboutPartner}"` : null,
      `━━━━━━━━━━━━━━━━━━━━`,
      `✨ الشارات: ${[
        member.verified ? '✓ موثق' : '',
        member.hasSeriousnessBadge ? '🏅 جاد' : '',
        member.plan === 'gold' ? '👑 ذهبي' : member.plan === 'elite' ? '⭐ مميز' : '',
      ].filter(Boolean).join(' | ') || 'عضو عادي'}`,
      `🔗 رابط الملف الشخصي: ${profileUrl}`,
    ].filter(Boolean).join('\n');

    navigator.clipboard.writeText(lines)
      .then(() => {
        showToast('تم نسخ كافة بيانات العضو إلى الحافظة بنجاح! 📋', 'success');
      })
      .catch(() => {
        showToast('تعذّر النسخ إلى الحافظة', 'error');
      });
  };

  const handleCopyLink = () => {
    const profileUrl = member.username
      ? `${window.location.origin}/u/${member.username}`
      : `${window.location.origin}/member/${member.id}`;
    navigator.clipboard.writeText(profileUrl)
      .then(() => showToast('تم نسخ رابط الملف الشخصي ✓', 'success'))
      .catch(() => showToast('تعذّر النسخ', 'error'));
  };

  const handleShareWhatsApp = () => {
    const profileUrl = member.username
      ? `${window.location.origin}/u/${member.username}`
      : `${window.location.origin}/member/${member.id}`;
    const text = `مرحبًا، وجدت هذا الملف في منصة توافق للزواج: ${profileUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleViewFullPage = () => {
    onClose();
    navigate(`/member/${member.id}`);
  };

  const handleSendInterest = async () => {
    if (!limitCheck.allowed) {
      showToast('لقد وصلت للحد الأقصى لإرسال طلبات الاهتمام اليوم', 'error');
      return;
    }
    setSending(true);
    try {
      const msg = contactMsg || 'طلب توافق جديد للزواج عبر المنصة';
      const res = await sendInterestRequest(member.id, msg);
      if (res?.ok) {
        incrementUsage('message');
        setContactOpen(false);
        setContactMsg('');
        showToast('تم إرسال طلب التوافق بنجاح! سيتم إشعار الطرف الآخر. 💌', 'success');
      } else {
        showToast(res?.error || 'حدث خطأ أثناء إرسال الطلب', 'error');
      }
    } catch {
      showToast('تعذر إرسال الطلب، يرجى المحاولة لاحقاً', 'error');
    } finally {
      setSending(false);
    }
  };

  const handleReportSubmit = () => {
    if (!reportReason.trim()) {
      showToast('يرجى كتابة سبب البلاغ', 'error');
      return;
    }
    submitReport(member.id, reportReason);
    setReportOpen(false);
    setReportReason('');
    showToast('تم إرسال بلاغك للإدارة بنجاح، وستتم مراجعته بفحص دقيق.', 'success');
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-hidden dir-rtl" dir="rtl">
        {/* الخلفية المظلمة الضبابية */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-navy-950/70 backdrop-blur-md"
          onClick={onClose}
        />

        {/* جسم النافذة المنبثقة */}
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.96 }}
          transition={{ type: 'spring', damping: 26, stiffness: 300 }}
          className={`relative w-full max-w-2xl rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[92vh] flex flex-col overflow-hidden border transition-colors ${
            isMale
              ? 'bg-[#edf5ff] dark:bg-[#0b1728] border-sky-300 dark:border-sky-800/80'
              : 'bg-[#faf0f4] dark:bg-[#230913] border-rose-300 dark:border-rose-900/80'
          }`}
        >
          {/* Header Bar: زر الإغلاق وزر عرض الصفحة وزر النسخ */}
          <div className={`sticky top-0 z-20 flex items-center justify-between px-4 sm:px-6 py-3.5 border-b ${
            isMale
              ? 'bg-[#e0f2fe] dark:bg-[#071322] border-sky-200 dark:border-sky-800/80'
              : 'bg-[#f4dbe3] dark:bg-[#1a050d] border-rose-200 dark:border-rose-900/80'
          }`}>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${isMale ? 'bg-sky-500' : 'bg-rose-700'}`} />
              <h3 className="font-cairo font-bold text-sm sm:text-base text-navy-900 dark:text-cream-50 truncate">
                ملف العضو: {member.nickname}
              </h3>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2">
              {/* زر نسخ البيانات */}
              <button
                onClick={handleCopyMemberData}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 font-cairo font-bold text-xs transition-colors border border-amber-200/60"
                title="نسخ جميع بيانات العضو للحافظة"
              >
                <Copy className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">نسخ البيانات</span>
              </button>

              {/* زر عرض الصفحة كاملة */}
              <button
                onClick={handleViewFullPage}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gold-500 hover:bg-gold-600 text-white font-cairo font-bold text-xs transition-colors shadow-xs"
                title="الانتقال لصفحة العضو الكاملة"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">عرض الصفحة كاملة</span>
              </button>

              {/* زر إغلاق النافذة */}
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-cream-100 hover:bg-cream-200 dark:bg-navy-800 dark:hover:bg-navy-700 flex items-center justify-center text-navy-600 dark:text-cream-200 transition-colors"
                title="إغلاق القائمة"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* محتوى البطاقة القابل للتمرير */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">

            {/* 1. HERO HEADER SUMMARY */}
            <div className={`relative rounded-2xl p-4 border shadow-sm transition-colors ${
              isMale
                ? 'bg-gradient-to-br from-sky-50 via-blue-50/40 to-white dark:from-sky-950/40 dark:to-navy-800/90 border-sky-200/80 dark:border-sky-800/40'
                : 'bg-gradient-to-br from-[#4a1224]/10 via-rose-50/50 to-white dark:from-[#3a0d1c]/40 dark:to-navy-800/90 border-rose-200/80 dark:border-rose-900/50'
            }`}>
              <div className="flex items-start gap-4">
                {/* الصورة */}
                <div className="relative flex-shrink-0">
                  <div className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white dark:bg-navy-950 p-1 ring-2 ${c.ring} ring-opacity-30 shadow-md flex items-center justify-center overflow-hidden`}>
                    <img src={avatar} alt="" className="w-full h-full object-contain p-1.5" />
                  </div>
                  {member.verified && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 ring-2 ring-white flex items-center justify-center shadow-xs" title="حساب موثّق">
                      <ShieldCheck className="w-3 h-3 text-white" />
                    </span>
                  )}
                </div>

                {/* الاسم + الشارات */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h2 className="font-cairo font-black text-lg sm:text-xl text-navy-900 dark:text-cream-50 leading-tight">
                      {member.nickname}
                    </h2>
                    {member.username && (
                      <span className="text-xs font-mono text-navy-400 dark:text-slate-400" dir="ltr">@{member.username}</span>
                    )}
                  </div>

                  {/* الشارات المرتّبة */}
                  <div className="flex items-center gap-1.5 flex-wrap mb-2">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg ${c.badgeBg} text-white font-cairo font-bold text-[10px]`}>
                      {isMale ? 'رجل' : 'امرأة'}
                    </span>
                    {member.verified && (
                      <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold">
                        <ShieldCheck className="w-3 h-3 text-emerald-600" /> موثّق
                      </span>
                    )}
                    {member.hasSeriousnessBadge && (
                      <span className="inline-flex items-center gap-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold shadow-xs">
                        🏅 جاد
                      </span>
                    )}
                    {member.plan === 'gold' && (
                      <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold">
                        <Crown className="w-3 h-3 text-amber-500 fill-amber-500" /> ذهبي
                      </span>
                    )}
                    {(member.plan === 'elite' || (member.premium && member.plan !== 'gold')) && (
                      <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-200 px-2 py-0.5 rounded-lg text-[10px] font-cairo font-bold">
                        ⭐ مميز
                      </span>
                    )}
                  </div>

                  {/* معلومات أساسية سريعة */}
                  <div className="flex items-center gap-3 flex-wrap text-xs text-navy-700 dark:text-cream-200/80 font-tajawal">
                    <span className="inline-flex items-center gap-1"><Calendar className="w-3.5 h-3.5 text-gold-600" />{member.age ? `${member.age} سنة` : '—'}</span>
                    <span className="inline-flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-gold-600" />{[member.city, member.country].filter(Boolean).join('، ')}</span>
                    <span className="inline-flex items-center gap-1"><Users className="w-3.5 h-3.5 text-gold-600" />{maritalFormatted}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. شريط الخصوصية والوساطة الشرعية (رسالة طمأنة) */}
            <div className="bg-emerald-50/70 dark:bg-emerald-950/30 rounded-2xl p-3 border border-emerald-200/70 dark:border-emerald-800/50 flex items-start gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs font-tajawal text-emerald-900 dark:text-emerald-200 leading-relaxed">
                <strong className="font-cairo font-bold block mb-0.5">وساطة شرعية وسرية تامة:</strong>
                يتم التواصل والتوافق بخصوصية عالية تحت إشراف الإدارة، ولا تظهر بيانات الاتصال المباشرة إلا بإذن شرعي رسمي.
              </div>
            </div>

            {/* 3. مواصفات الشريك المطلوب (أبحث عن) — كاملة مع جميع الوسوم */}
            <div className="bg-white dark:bg-navy-800/60 rounded-2xl p-4 border border-rose-200/80 dark:border-rose-900/50 shadow-xs space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-cairo font-bold text-xs sm:text-sm">
                  <Heart className="w-4.5 h-4.5 text-rose-500 fill-rose-100" />
                  <span>مواصفات الشريك المطلوب (أبحث عن):</span>
                </div>
                <span className="text-[10px] font-cairo font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300 px-2 py-0.5 rounded-full border border-rose-200/60">
                  المواصفات المطلوبة
                </span>
              </div>

              {/* الوسوم الشاملة لمواصفات الشريك (تتضمن العمر، المدن، الجنسية، الدولة، والحالة) */}
              {partnerSummary.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {partnerSummary.tags.map((tag, tIdx) => (
                    <span key={tIdx} className="bg-rose-50 dark:bg-rose-950/50 text-rose-900 dark:text-rose-200 px-2.5 py-1 rounded-lg text-xs font-cairo font-bold border border-rose-200/80 dark:border-rose-800/60 shadow-2xs">
                      {tag.label}: {tag.value}
                    </span>
                  ))}
                </div>
              )}

              {/* النص التفصيلي والملاحظات */}
              {partnerSummary.text ? (
                <p className="text-xs sm:text-sm font-tajawal text-navy-800 dark:text-cream-100 leading-relaxed bg-rose-50/40 dark:bg-navy-950/40 p-3 rounded-xl border border-rose-100 dark:border-navy-800">
                  {partnerSummary.text}
                </p>
              ) : partnerSummary.tags.length === 0 ? (
                <p className="text-xs font-tajawal text-navy-400 dark:text-slate-400 italic">
                  لم يقم العضو بتحديد مواصفات الشريك بعد.
                </p>
              ) : null}
            </div>

            {/* 4. نبذة عني (عن نفسي) */}
            <div className="bg-white dark:bg-navy-800/60 rounded-2xl p-4 border border-cream-200 dark:border-navy-700/60 shadow-xs space-y-1.5">
              <div className="flex items-center gap-2 text-gold-600 font-cairo font-bold text-xs sm:text-sm">
                <FileText className="w-4.5 h-4.5 text-gold-500" />
                <span>نبذة عن العضو (عن نفسي):</span>
              </div>
              <p className="text-xs sm:text-sm font-tajawal text-navy-800 dark:text-cream-100 leading-relaxed bg-cream-50/60 dark:bg-navy-950/40 p-3 rounded-xl border border-cream-100 dark:border-navy-800">
                {member.bio || 'لم يقم العضو بإضافة نبذة عن نفسه بعد.'}
              </p>
            </div>

            {/* 5. المعلومات الأساسية والشخصية */}
            <div className="space-y-2">
              <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                <User className="w-4 h-4 text-amber-500" />
                <span>المعلومات الأساسية والشخصية:</span>
              </h4>
              <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                <DetailGridItem icon={User} label="الجنس" value={member.gender === 'female' ? 'أنثى' : 'ذكر'} />
                {member.age ? <DetailGridItem icon={Calendar} label="العمر" value={`${member.age} سنة`} /> : null}
                {member.country && !['—', ''].includes(member.country) ? <DetailGridItem icon={MapPin} label="الدولة" value={normalizeNationality(member.country)} /> : null}
                {member.city && !['—', ''].includes(member.city) ? <DetailGridItem icon={MapPin} label="المدينة" value={member.city} /> : null}
                {member.district && !['—', 'غير ينطبق', ''].includes(member.district) ? <DetailGridItem icon={MapPin} label="الحي / المنطقة" value={member.district} /> : null}
                {member.nationality && !['—', ''].includes(member.nationality) ? <DetailGridItem icon={Globe} label="الجنسية" value={normalizeNationality(member.nationality)} /> : null}
                {member.sect && !['—', 'غير ينطبق', ''].includes(member.sect) ? <DetailGridItem icon={Church} label="المذهب" value={member.sect} /> : null}
                {member.tribe && !['—', 'غير ينطبق', ''].includes(member.tribe) ? (
                  <DetailGridItem icon={TreePine} label="القبيلة / النسب" value={member.tribe} />
                ) : null}
                {member.ethnicity && !['—', 'غير ينطبق', ''].includes(member.ethnicity) ? (
                  <DetailGridItem icon={Globe} label="العرق / الأصل" value={member.ethnicity} />
                ) : null}
              </div>
            </div>

            {/* 6. الحالة الاجتماعية والسكن والأبناء والتعدد */}
            <div className="space-y-2">
              <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-500" />
                <span>الحالة الاجتماعية والسكن والأبناء والتعدد:</span>
              </h4>
              <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                <DetailGridItem icon={Users} label="الحالة الاجتماعية" value={maritalFormatted} />
                {marriageTypeFormatted && !['غير ينطبق', '—', ''].includes(marriageTypeFormatted) && (
                  <DetailGridItem icon={Heart} label="نوع الزواج" value={marriageTypeFormatted} />
                )}
                {member.gender === 'male' && member.wifeCount && !['غير ينطبق', 'لا يوجد', 'لا يوجد (أعزب)', '—', '0', ''].includes(member.wifeCount) && ['married', 'متزوج'].includes(member.maritalStatus) && (
                  <DetailGridItem icon={Users} label="عدد الزوجات الحالي" value={member.wifeCount} />
                )}
                {member.gender === 'male' && member.seekingWife && !['غير ينطبق', '—', '', 'غير متعدد', 'زواج أول (غير متعدد)'].includes(member.seekingWife) && (
                  <DetailGridItem icon={Heart} label="التعدد / رغبة الزواج" value={member.seekingWife} />
                )}
                {member.gender === 'female' && member.acceptPolygamy && !['غير ينطبق', '—', ''].includes(member.acceptPolygamy) && (
                  <DetailGridItem icon={Heart} label="موقف التعدد" value={member.acceptPolygamy} />
                )}
                {(() => {
                  const isSingle = ['single', 'أعزب', 'عزباء'].includes(member.maritalStatus) || ['أعزب', 'عزباء'].includes(maritalFormatted);
                  if (member.hasChildren) {
                    return <DetailGridItem icon={Users} label="وجود أبناء" value="نعم" />;
                  }
                  if (!isSingle) {
                    return <DetailGridItem icon={Users} label="وجود أبناء" value="لا يوجد" />;
                  }
                  return null;
                })()}
                {member.hasChildren && member.childrenCount && !['لا يوجد', 'غير ينطبق', '—', '0', ''].includes(member.childrenCount) && (
                  <DetailGridItem icon={Baby} label="عدد الأبناء" value={member.childrenCount} />
                )}
                {member.hasChildren && member.childrenLiveWith && !['لا يوجد', 'غير ينطبق', '—', ''].includes(member.childrenLiveWith) && (
                  <DetailGridItem icon={Home} label="إقامة الأبناء" value={member.childrenLiveWith} />
                )}
                {member.acceptDivorced && !['غير ينطبق', '—', ''].includes(member.acceptDivorced) && (
                  <DetailGridItem icon={Heart} label="قبول المطلق/ة" value={member.acceptDivorced} />
                )}
                {member.acceptWithChildren && !['غير ينطبق', '—', ''].includes(member.acceptWithChildren) && (
                  <DetailGridItem icon={Baby} label="قبول بأبناء" value={member.acceptWithChildren} />
                )}
                {member.housing && !['—', 'غير ينطبق', ''].includes(member.housing) && (
                  <DetailGridItem icon={Home} label="نوع السكن" value={member.housing} />
                )}
              </div>
            </div>

            {/* 7. التعليم والعمل */}
            {(member.education || member.workType || member.jobTitle) && (
              <div className="space-y-2">
                <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-blue-500" />
                  <span>التعليم والعمل:</span>
                </h4>
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                  {member.education && !['—', ''].includes(member.education) ? <DetailGridItem icon={GraduationCap} label="المؤهل العلمي" value={member.education} /> : null}
                  {member.workType && !['—', ''].includes(member.workType) ? <DetailGridItem icon={Building2} label="جهة العمل" value={member.workType} /> : null}
                  {member.jobTitle && !['—', ''].includes(member.jobTitle) ? <DetailGridItem icon={Briefcase} label="المسمى الوظيفي" value={member.jobTitle} /> : null}
                </div>
              </div>
            )}

            {/* 8. المواصفات الجسدية والصحية */}
            {(member.height || member.weight || member.skinColor || member.health || member.smoking) && (
              <div className="space-y-2">
                <h4 className="font-cairo font-bold text-xs sm:text-sm text-navy-900 dark:text-cream-100 flex items-center gap-1.5">
                  <Ruler className="w-4 h-4 text-purple-500" />
                  <span>المواصفات الجسدية والصحية:</span>
                </h4>
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                  {member.height ? <DetailGridItem icon={Ruler} label="الطول" value={`${member.height} سم`} /> : null}
                  {member.weight ? <DetailGridItem icon={Weight} label="الوزن" value={`${member.weight} كجم`} /> : null}
                  {member.skinColor && !['—', ''].includes(member.skinColor) ? <DetailGridItem icon={Palette} label="لون البشرة" value={member.skinColor} /> : null}
                  {member.health && !['—', ''].includes(member.health) ? <DetailGridItem icon={Stethoscope} label="الحالة الصحية" value={member.health} /> : null}
                  {member.smoking && !['—', ''].includes(member.smoking) ? <DetailGridItem icon={Cigarette} label="التدخين" value={member.smoking} /> : null}
                </div>
              </div>
            )}

            {/* 9. شريط الأزرار والتفاعل الشامل (جميع الأزرار والخيارات) */}
            <div className="bg-cream-50 dark:bg-navy-950/60 rounded-2xl p-3.5 border border-cream-200 dark:border-navy-800 space-y-2.5">
              <span className="text-[11px] font-cairo font-bold text-navy-500 dark:text-slate-400 block px-1">
                ⚡ خيارات الإجراءات والتواصل:
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {/* 1. إرسال طلب اهتمام / التواصل */}
                <button
                  onClick={() => {
                    if (!user?.isLoggedIn) {
                      showToast('يرجى تسجيل الدخول أو إنشاء حساب أولاً لإرسال طلب اهتمام', 'info');
                      onClose();
                      navigate('/login');
                      return;
                    }
                    setContactOpen(!contactOpen);
                  }}
                  disabled={isSelf}
                  className={`col-span-2 sm:col-span-1 py-2.5 px-3 rounded-xl font-cairo font-bold text-xs shadow-soft transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    latestRequest
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                      : 'bg-gold-500 hover:bg-gold-600 text-white'
                  }`}
                >
                  <Send className="w-4 h-4 -scale-x-100" />
                  <span>{latestRequest ? 'تم إرسال طلب تواصل' : 'إرسال طلب اهتمام'}</span>
                </button>

                {/* 2. حفظ في المفضلة */}
                <button
                  onClick={() => {
                    if (!user?.isLoggedIn) {
                      showToast('يرجى تسجيل الدخول لإضافة الأعضاء إلى المفضلة', 'info');
                      onClose();
                      navigate('/login');
                      return;
                    }
                    toggleLike(member.id);
                  }}
                  className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs transition-all flex items-center justify-center gap-1.5 border cursor-pointer ${
                    liked
                      ? 'bg-amber-500 text-white border-amber-500 shadow-soft'
                      : 'bg-white dark:bg-navy-900 text-navy-700 dark:text-cream-100 border-cream-200 dark:border-navy-700 hover:bg-cream-100'
                  }`}
                >
                  <Bookmark className={`w-4 h-4 ${liked ? 'fill-white' : ''}`} />
                  <span>{liked ? 'محفوظ للمفضلة' : 'حفظ بالمفضلة'}</span>
                </button>

                {/* 3. نسخ جميع بيانات العضو */}
                <button
                  onClick={handleCopyMemberData}
                  className="py-2.5 px-3 rounded-xl bg-white dark:bg-navy-900 hover:bg-amber-50 text-amber-800 dark:text-amber-300 font-cairo font-bold text-xs border border-cream-200 dark:border-navy-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Copy className="w-4 h-4 text-amber-600" />
                  <span>نسخ البيانات</span>
                </button>

                {/* 4. مشاركة واتساب */}
                <button
                  onClick={handleShareWhatsApp}
                  className="py-2.5 px-3 rounded-xl bg-white dark:bg-navy-900 hover:bg-emerald-50 text-emerald-800 dark:text-emerald-300 font-cairo font-bold text-xs border border-cream-200 dark:border-navy-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Share2 className="w-4 h-4 text-emerald-600" />
                  <span>مشاركة واتساب</span>
                </button>

                {/* 5. عرض الصفحة كاملة */}
                <button
                  onClick={handleViewFullPage}
                  className="py-2.5 px-3 rounded-xl bg-white dark:bg-navy-900 hover:bg-cream-100 text-navy-800 dark:text-cream-100 font-cairo font-bold text-xs border border-cream-200 dark:border-navy-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4 text-gold-600" />
                  <span>الصفحة كاملة</span>
                </button>

                {/* 6. حظر / إلغاء حظر (للقرّاء المسجلين فقط) */}
                {user?.isLoggedIn && !isSelf && (
                  <button
                    onClick={() => {
                      toggleBlock(member.id);
                      showToast(isBlocked ? 'تم إلغاء حظر العضو' : 'تم حظر العضو بنجاح', isBlocked ? 'info' : 'warning');
                    }}
                    className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs transition-colors flex items-center justify-center gap-1.5 border cursor-pointer ${
                      isBlocked
                        ? 'bg-slate-700 text-white border-slate-700'
                        : 'bg-white dark:bg-navy-900 text-slate-600 dark:text-slate-300 border-cream-200 dark:border-navy-700 hover:bg-slate-100'
                    }`}
                  >
                    <Ban className="w-4 h-4" />
                    <span>{isBlocked ? 'إلغاء الحظر' : 'حظر العضو'}</span>
                  </button>
                )}

                {/* 7. إبلاغ عن العضو (للقرّاء المسجلين فقط) */}
                {user?.isLoggedIn && !isSelf && (
                  <button
                    onClick={() => setReportOpen(!reportOpen)}
                    className="py-2.5 px-3 rounded-xl bg-white dark:bg-navy-900 hover:bg-rose-50 text-rose-700 dark:text-rose-400 font-cairo font-bold text-xs border border-cream-200 dark:border-navy-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <AlertTriangle className="w-4 h-4 text-rose-500" />
                    <span>إبلاغ للإدارة</span>
                  </button>
                )}
              </div>

              {/* حقل رسالة طلب الاهتمام إن كُشف */}
              {contactOpen && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-white dark:bg-navy-900 rounded-2xl p-4 border border-amber-200 dark:border-amber-900/60 space-y-3 mt-2 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-cairo font-bold text-xs text-navy-900 dark:text-cream-50">
                      إرسال رسالة اهتمام مخصصة:
                    </span>
                    <button onClick={() => setContactOpen(false)} className="text-slate-400 hover:text-slate-600">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* القوالب الجاهزة */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-cairo">اختر قالب جاهز:</span>
                    <div className="grid grid-cols-1 gap-1.5 max-h-32 overflow-y-auto pr-1">
                      {MESSAGE_TEMPLATES.map((tpl, i) => (
                        <button
                          key={i}
                          onClick={() => setContactMsg(tpl)}
                          className="text-right text-xs font-tajawal bg-cream-50 dark:bg-navy-800/60 hover:bg-cream-100 p-2 rounded-xl text-navy-800 dark:text-cream-100 border border-cream-200 dark:border-navy-700 transition-colors truncate"
                        >
                          {tpl}
                        </button>
                      ))}
                    </div>
                  </div>

                  <textarea
                    value={contactMsg}
                    onChange={(e) => setContactMsg(e.target.value)}
                    rows={2}
                    placeholder="اكتب رسالتك..."
                    className="w-full px-3 py-2 rounded-xl bg-cream-50 dark:bg-navy-950 border border-cream-300 dark:border-navy-700 font-tajawal text-xs focus:outline-none focus:border-amber-500 dark:text-cream-50"
                  />

                  <button
                    onClick={handleSendInterest}
                    disabled={sending}
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-cairo font-bold text-xs shadow-soft transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5 -scale-x-100" />
                    <span>{sending ? 'جاري الإرسال...' : 'تأكيد إرسال طلب الاهتمام 💌'}</span>
                  </button>
                </motion.div>
              )}

              {/* نموذج الإبلاغ إن كُشف */}
              {reportOpen && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-white dark:bg-navy-900 rounded-2xl p-4 border border-rose-200 dark:border-rose-900/60 space-y-3 mt-2 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-cairo font-bold text-xs text-rose-700 dark:text-rose-400">
                      إرسال بلاغ ضد العضو:
                    </span>
                    <button onClick={() => setReportOpen(false)} className="text-slate-400 hover:text-slate-600">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <textarea
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    rows={2}
                    placeholder="وضح سبب البلاغ للإدارة..."
                    className="w-full px-3 py-2 rounded-xl bg-rose-50/50 dark:bg-navy-950 border border-rose-200 dark:border-navy-700 font-tajawal text-xs focus:outline-none focus:border-rose-500 dark:text-cream-50"
                  />

                  <button
                    onClick={handleReportSubmit}
                    className="w-full py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-cairo font-bold text-xs transition-all cursor-pointer"
                  >
                    تأكيد إرسال البلاغ ⚠️
                  </button>
                </motion.div>
              )}
            </div>

          </div>

          {/* Footer Bar: زر الإغلاق وزر الانتقال لصفحة العضو الكاملة */}
          <div className={`p-3.5 border-t flex items-center justify-between gap-3 ${
            isMale
              ? 'bg-[#e0f2fe] dark:bg-[#071322] border-sky-200 dark:border-sky-800/80'
              : 'bg-[#f4dbe3] dark:bg-[#1a050d] border-rose-200 dark:border-rose-900/80'
          }`}>
            <button
              onClick={handleCopyMemberData}
              className="px-4 py-2.5 rounded-xl bg-white dark:bg-navy-900 hover:bg-amber-50 text-amber-900 dark:text-amber-300 font-cairo font-bold text-xs border border-cream-300 dark:border-navy-700 transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Copy className="w-4 h-4 text-amber-600" />
              <span>نسخ كافة البيانات 📋</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-cream-200 hover:bg-cream-300 dark:bg-navy-800 dark:hover:bg-navy-700 text-navy-800 dark:text-cream-100 font-cairo font-bold text-xs transition-colors cursor-pointer"
              >
                إغلاق النافذة
              </button>
              <button
                onClick={handleViewFullPage}
                className="px-5 py-2.5 rounded-xl bg-gold-500 hover:bg-gold-600 text-white font-cairo font-bold text-xs transition-colors shadow-soft flex items-center gap-1.5 cursor-pointer"
              >
                <ExternalLink className="w-4 h-4" />
                <span>عرض الصفحة كاملة</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

// عنصر الخلية الصغيرة في قائمة التفاصيل
function DetailGridItem({ icon: Icon, label, value }: { icon: any; label: string; value: string | number }) {
  return (
    <div className="bg-cream-50/80 dark:bg-navy-950/60 rounded-xl p-2 sm:p-2.5 border border-cream-200/70 dark:border-navy-800 flex items-start gap-1.5 sm:gap-2 min-w-0">
      <Icon className="w-3.5 h-3.5 text-gold-600 dark:text-gold-400 mt-0.5 flex-shrink-0" />
      <div className="min-w-0 flex-1">
        <span className="block text-[9px] sm:text-[10px] text-navy-400 dark:text-slate-400 font-tajawal leading-none mb-1 truncate">{label}</span>
        <span className="block text-[11px] sm:text-xs font-cairo font-bold text-navy-900 dark:text-cream-50 truncate" title={String(value)}>{value}</span>
      </div>
    </div>
  );
}
