import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShieldCheck, Lock, BadgeCheck, Heart, Search, Send,
  Sparkles, ArrowLeft, Star, Quote, Users, TrendingUp, Clock,
  HeartHandshake, CalendarClock, PartyPopper, ChevronLeft, ChevronRight,
  UserPlus, ShieldAlert, Eye, FileCheck,
} from 'lucide-react';
import { ButtonLink } from '../components/ui/Button';
import MemberCard from '../components/MemberCard';
import SectionHeading from '../components/layout/SectionHeading';
import SectionDivider from '../components/ui/SectionDivider';
import CountUp from '../components/ui/CountUp';
import { TESTIMONIALS, STATS } from '../lib/data';
import { useApp } from '../lib/AppContext';
import { MemberGridSkeleton } from '../components/ui/MemberCardSkeleton';
import { getMemberTimestamp } from '../lib/memberUtils';

const features = [
  { icon: BadgeCheck, title: 'تحقق كامل من الحسابات', desc: 'كل عضو يخضع لتحقق من الهوية والبيانات لضمان مصداقية المنصة.' },
  { icon: Lock, title: 'خصوصية وحماية البيانات', desc: 'بياناتك الحساسة مشفّرة ومحمية، وتتحكم أنت بمن يراها.' },
  { icon: Search, title: 'بحث متقدم ودقيق', desc: 'فلاتر دقيقة حسب العمر، المدينة، الاهتمامات، والمزيد.' },
  { icon: ShieldCheck, title: 'وساطة مهنية للتواصل', desc: 'تتولى الإدارة التواصل بين الطرفين بسرية تامة واحترام كامل.' },
];

const steps = [
  { icon: Users, title: 'أنشئ حسابك', desc: 'سجّل مجانًا وأكمل ملفك الشخصي بخطوات بسيطة.' },
  { icon: Search, title: 'ابحث واكتشف', desc: 'استخدم البحث المتقدم للعثور على من يشاركك القيم.' },
  { icon: Heart, title: 'أرسل طلب اهتمام', desc: 'عبّر عن اهتمامك وستتولى الإدارة التواصل نيابة عنك.' },
  { icon: Sparkles, title: 'ابدأ رحلتك', desc: 'تواصل جاد عبر الإدارة نحو خطوة الزواج.' },
];

const journeyStages = [
  { icon: Send, title: 'مُرسَل', desc: 'تُرسل طلب اهتمامك بسرية عبر الإدارة.', accent: 'text-amber-600 bg-amber-50' },
  { icon: HeartHandshake, title: 'مقبول', desc: 'يقبل الطرف الآخر ويبدأ التوافق الجاد للزواج.', accent: 'text-emerald-600 bg-emerald-50' },
  { icon: ShieldCheck, title: 'تأكيد الجدية', desc: 'رسوم الجدية لمرة واحدة لتأكيد جدية الطرفين وتبادل التواصل.', accent: 'text-amber-700 bg-amber-50' },
  { icon: CalendarClock, title: 'التنسيق', desc: 'الإدارة والوسيطة تنسّق موعد التوافق.', accent: 'text-blue-600 bg-blue-50' },
  { icon: Users, title: 'التوافق', desc: 'تبادل القنوات والنظرة الشرعية بإشراف.', accent: 'text-indigo-600 bg-indigo-50' },
  { icon: PartyPopper, title: 'مكتمل', desc: 'توافق مبارك نحو إتمام الزواج.', accent: 'text-emerald-700 bg-emerald-50' },
];

const securityPoints = [
  { icon: ShieldCheck, text: 'تحقق ثلاثي الخطوات من كل حساب جديد', color: 'text-emerald-400', bg: 'bg-emerald-500/15' },
  { icon: Lock, text: 'تشفير SSL 256-bit لجميع البيانات الحساسة', color: 'text-gold-300', bg: 'bg-gold-500/15' },
  { icon: BadgeCheck, text: 'مراقبة على مدار الساعة للحسابات المزيفة', color: 'text-blue-300', bg: 'bg-blue-500/15' },
];

export default function Home() {
  const { members, membersLoading, interestRequests, currentUser, user } = useApp();
  const isLoggedIn = !!(currentUser || user?.isLoggedIn);

  // ===== تبويب قسم "كيف تعمل المنصة / رحلة الطلب" =====
  const [processTab, setProcessTab] = useState<'overview' | 'journey'>('overview');

  // ===== تبويب قسم الأعضاء =====
  const [membersTab, setMembersTab] = useState<'featured' | 'new'>('new');

  // ===== Carousel قصص النجاح =====
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  const activeMembersOnly = useMemo(() => {
    return members.filter((m) => {
      if (m.status && m.status !== 'active') return false;
      return !!(m.nickname || m.realName || m.id);
    });
  }, [members]);

  const dynamicStats = useMemo(() => {
    const activeCount = activeMembersOnly.length;
    const verifiedCount = activeMembersOnly.filter((m) => m.verified).length;
    const requestsCount = interestRequests.length;
    return [
      { label: 'عضو نشط بالمنصة', value: `+${activeCount > 0 ? activeCount : 150}` },
      { label: 'حساب موثّق بالهوية', value: `+${verifiedCount > 0 ? verifiedCount : 45}` },
      { label: 'طلب اهتمام وتبادل', value: `+${requestsCount > 0 ? requestsCount : 12}` },
      { label: 'دعم ووساطة شرعية', value: '24/7' },
    ];
  }, [activeMembersOnly, interestRequests]);

  const canShowOnHome = (member: any) => {
    // لا نخفي الأعضاء المستوردين بسبب نقص حقول مثل الطول/الوزن؛
    // يكفي توفر اسم أو رمز عضو نشط كي يظهر في الصفحة الرئيسية، حتى لو كان الجنس أو العمر غير مكتملين.
    return !!(member.nickname || member.realName || member.id);
  };

  const featuredMembers = useMemo(() => {
    return [...activeMembersOnly]
      .filter((m) => canShowOnHome(m) && (m.premium || m.pinned || m.sourceType === 'imported' || m.hasSeriousnessBadge || m.verified))
      .sort((a, b) => {
        const pinA = a.pinned ? 1 : 0;
        const pinB = b.pinned ? 1 : 0;
        if (pinA !== pinB) return pinB - pinA;

        const getPlanScore = (member: any) => {
          const plan = member.plan || (member.premium ? 'elite' : 'free');
          if (plan === 'elite') return 100;
          if (plan === 'gold') return 50;
          return 10;
        };
        const scoreA = getPlanScore(a) + (a.hasSeriousnessBadge ? 5 : 0);
        const scoreB = getPlanScore(b) + (b.hasSeriousnessBadge ? 5 : 0);
        if (scoreA !== scoreB) return scoreB - scoreA;

        const timeA = getMemberTimestamp(a);
        const timeB = getMemberTimestamp(b);
        if (timeA !== timeB) return timeB - timeA;

        return b.id.localeCompare(a.id);
      })
      .slice(0, 12);
  }, [activeMembersOnly]);

  const newMembers = useMemo(() => {
    return [...activeMembersOnly]
      .filter(canShowOnHome)
      .sort((a, b) => {
        const pinA = a.pinned ? 1 : 0;
        const pinB = b.pinned ? 1 : 0;
        if (pinA !== pinB) return pinB - pinA;

        const timeA = getMemberTimestamp(a);
        const timeB = getMemberTimestamp(b);
        if (timeA !== timeB) return timeB - timeA;

        const getPlanScore = (member: any) => {
          const plan = member.plan || (member.premium ? 'elite' : 'free');
          if (plan === 'elite') return 100;
          if (plan === 'gold') return 50;
          return 10;
        };
        const scoreA = getPlanScore(a);
        const scoreB = getPlanScore(b);
        if (scoreA !== scoreB) return scoreB - scoreA;

        return b.id.localeCompare(a.id);
      })
      .slice(0, 12);
  }, [activeMembersOnly]);

  const activeMembers = membersTab === 'featured' ? featuredMembers : newMembers;

  const nextTestimonial = () => setTestimonialIdx((prev) => (prev + 1) % TESTIMONIALS.length);
  const prevTestimonial = () => setTestimonialIdx((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  const activeTestimonial = TESTIMONIALS[testimonialIdx];

  return (
    <div>
      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden bg-navy-gradient pb-4 pt-2">
        <div className="absolute inset-0 pattern-islamic opacity-40" />
        <div className="absolute -top-24 -left-24 w-80 h-80 bg-gold-500/15 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '4s' }} />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-rose-deep/5 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-6 lg:pt-14 lg:pb-10">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* النص */}
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center lg:text-right flex flex-col items-center lg:items-start"
            >
              <span className="badge-shimmer inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-gold-500/15 border border-gold-500/30 text-gold-300 text-xs font-cairo font-semibold mb-3">
                <Sparkles className="w-3.5 h-3.5" />
                منصة الزواج العربية الأولى
              </span>

              <h1 className="font-cairo font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white leading-[1.2] text-shadow-gold">
                ابدأ رحلة العمر مع
                <span className="block text-gradient-gold mt-1.5">شريك الحياة المناسب</span>
              </h1>

              <p className="mt-3.5 text-base text-cream-200/85 font-tajawal leading-relaxed max-w-xl lg:max-w-lg">
                توافق يربطك بأشخاص موثوقين يشاركونك القيم والطموح، في بيئة آمنة تحترم خصوصيتك وتساعدك على بناء علاقة جادة نحو الزواج.
              </p>

              <div className="mt-5 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start w-full sm:w-auto">
                {isLoggedIn ? (
                  <>
                    <ButtonLink to="/search" size="lg" className="shadow-gold w-full sm:w-auto">
                      <Search className="w-4 h-4" />
                      تصفّح الأعضاء
                    </ButtonLink>
                    <ButtonLink to="/profile" variant="outline" size="lg" className="bg-white/5 hover:bg-white hover:text-navy-950 border border-white/40 text-white font-cairo font-bold transition-all duration-300 shadow-md w-full sm:w-auto">
                      <Heart className="w-4 h-4" />
                      ملفي الشخصي
                    </ButtonLink>
                  </>
                ) : (
                  <>
                    <ButtonLink to="/register" size="lg" className="shadow-gold w-full sm:w-auto">
                      <Heart className="w-4 h-4" />
                      ابدأ مجانًا الآن
                    </ButtonLink>
                    <ButtonLink to="/search" variant="outline" size="lg" className="bg-white/5 hover:bg-white hover:text-navy-950 border border-white/40 text-white font-cairo font-bold transition-all duration-300 shadow-md w-full sm:w-auto">
                      <Search className="w-4 h-4" />
                      تصفّح الأعضاء
                    </ButtonLink>
                  </>
                )}
              </div>

              {/* مؤشرات الثقة */}
              <div className="mt-5 flex flex-wrap items-center justify-center lg:justify-start gap-x-5 gap-y-2 text-xs text-cream-200/70 font-tajawal">
                <span className="flex items-center gap-1.5"><BadgeCheck className="w-3.5 h-3.5 text-emerald-400" /> حسابات موثّقة</span>
                <span className="flex items-center gap-1.5"><Lock className="w-3.5 h-3.5 text-gold-300" /> خصوصية تامة</span>
                <span className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5 text-blue-300" /> وساطة مهنية</span>
              </div>
            </motion.div>

            {/* العنصر البصري الجانبي */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="hidden lg:flex justify-center items-center relative"
            >
              <div className="relative w-full max-w-sm aspect-square">
                {/* دوائر زخرفية متحرّكة */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-0 rounded-full border-2 border-dashed border-gold-500/10"
                />
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
                  className="absolute inset-6 rounded-full border border-gold-500/10"
                />

                {/* البطاقة المركزية */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-56 h-56 rounded-[2rem] bg-gradient-to-br from-navy-800/90 to-navy-950/90 backdrop-blur-sm border border-gold-500/20 shadow-luxe glow-gold flex flex-col items-center justify-center p-6 text-center">
                    <div className="w-14 h-14 rounded-full bg-gold-gradient flex items-center justify-center mb-3 shadow-gold">
                      <Heart className="w-7 h-7 text-navy-900 fill-navy-900" />
                    </div>
                    <p className="font-cairo font-bold text-white text-base">توافق مبارك</p>
                    <p className="text-cream-200/60 text-xs font-tajawal mt-1">ابدأ قصتك اليوم</p>

                    {/* قلوب متساقطة */}
                    {[...Array(4)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute text-gold-300/20"
                        initial={{ y: -10, opacity: 0 }}
                        animate={{ y: 150, opacity: [0, 1, 0] }}
                        transition={{ duration: 3, repeat: Infinity, delay: i * 0.8, ease: 'easeOut' }}
                        style={{ left: `${20 + i * 20}%`, top: '0%' }}
                      >
                        <Heart className="w-3.5 h-3.5 fill-current" />
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* بطاقات عائمة حول الدائرة */}
                <motion.div
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                  className="absolute top-6 right-6 glass-navy rounded-xl p-2.5 border border-gold-500/20 flex items-center gap-2 shadow-md"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="text-white text-[10px] font-cairo font-bold">موثوق 100%</span>
                </motion.div>

                <motion.div
                  animate={{ y: [0, 6, 0] }}
                  transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
                  className="absolute bottom-10 left-2 glass-navy rounded-xl p-2.5 border border-gold-500/20 flex items-center gap-2 shadow-md"
                >
                  <Users className="w-4 h-4 text-gold-300" />
                  <span className="text-white text-[10px] font-cairo font-bold">+150 ألف عضو</span>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* شريط الإحصائيات — مع عدّاد متحرّك */}
        <div className="relative border-t border-gold-500/10 bg-navy-950/20 backdrop-blur-sm">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4 grid grid-cols-2 lg:grid-cols-4 gap-4">
            {dynamicStats.map((s, i) => {
              const isNumeric = /^[\d,]+$/.test(s.value.replace(/[+%\sألف]/g, '').trim());
              const numeric = isNumeric ? parseInt(s.value.replace(/[^0-9]/g, '')) : 0;
              const prefix = s.value.includes('+') ? '+' : '';
              const suffix = s.value.replace(/[0-9+\s]/g, '').trim() || '';
              return (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.08 }}
                  className="text-center"
                >
                  <div className="font-cairo font-extrabold text-xl sm:text-2xl text-gradient-gold">
                    {numeric > 0 ? <CountUp end={numeric} prefix={prefix} suffix={` ${suffix}`} /> : s.value}
                  </div>
                  <div className="text-[11px] sm:text-xs text-cream-200/70 font-tajawal mt-0.5">{s.label}</div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <SectionDivider />

      {/* ===== FEATURES ===== */}
      <section className="py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="لماذا توافق؟"
            title={<>منصة تُبنى على <span className="text-amber-600 font-extrabold">الثقة والأمان</span></>}
            subtitle="نحن نلتزم بأعلى معايير الأمان والخصوصية لنمنحك تجربة مريحة وموثوقة في رحلتك نحو شريك الحياة."
          />

          <div className="mt-14 relative">
            {/* الخط الرابط للأفقية (شاشات كبيرة) */}
            <div className="hidden lg:block absolute top-10 right-[12.5%] left-[12.5%] h-0.5 bg-gradient-to-l from-gold-500/10 via-gold-500/30 to-gold-500/10" />

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((f, i) => (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  className="relative flex flex-col items-center text-center group"
                >
                  {/* الدائرة الملونة المتصلة */}
                  <div className="relative z-10 w-20 h-20 rounded-full bg-white dark:bg-navy-950 border-2 border-gold-500/40 dark:border-gold-500/20 flex items-center justify-center shadow-soft mb-5 transition-transform duration-300 group-hover:scale-105">
                    <div className="w-12 h-12 rounded-xl bg-gold-500/10 flex items-center justify-center group-hover:bg-gold-gradient transition-colors duration-300">
                      <f.icon className="w-6 h-6 text-gold-600 group-hover:text-navy-900 transition-colors duration-300" />
                    </div>
                    <span className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-navy-900 text-gold-300 font-cairo font-bold text-xs flex items-center justify-center">
                      {i + 1}
                    </span>
                  </div>

                  <h3 className="font-cairo font-bold text-navy-900 dark:text-cream-50 text-base mb-2">{f.title}</h3>
                  <p className="text-xs sm:text-sm text-navy-600 dark:text-slate-300 font-tajawal leading-relaxed max-w-[200px]">{f.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ===== PROCESS: كيف تعمل المنصة ===== */}
      <section className="py-16 lg:py-20 bg-cream-100 dark:bg-navy-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="كيف تعمل المنصة؟"
            title={<>مسار واضح <span className="text-amber-600 font-extrabold">من الطلب حتى الزواج</span></>}
            subtitle="رحلة منظّمة وآمنة بإشراف الإدارة والوسيطة الشرعية، تنتقل فيها خطوة بخطوة بكل وضوح وسرية تامة."
          />

          <div className="mt-14 relative">
            {/* الخط الرابط للأفقية (شاشات كبيرة) */}
            <div className="hidden lg:block absolute top-10 right-[8.33%] left-[8.33%] h-0.5 bg-gradient-to-l from-gold-500/10 via-gold-500/30 to-gold-500/10" />

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {journeyStages.map((stage, i) => (
                <motion.div
                  key={stage.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="relative flex flex-col items-center text-center group"
                >
                  {/* النقطة على الخط */}
                  <div className="relative z-10 w-20 h-20 rounded-full bg-white dark:bg-navy-950 border-2 border-gold-500/40 dark:border-gold-500/20 flex items-center justify-center shadow-soft mb-4 transition-transform duration-300 group-hover:scale-105">
                    <div className={`w-12 h-12 rounded-xl ${stage.accent} flex items-center justify-center group-hover:bg-gold-gradient transition-all duration-300`}>
                      <stage.icon className="w-6 h-6 group-hover:text-navy-900 transition-colors duration-300" />
                    </div>
                    <span className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-navy-900 text-gold-300 font-cairo font-bold text-xs flex items-center justify-center">
                      {i + 1}
                    </span>
                  </div>
                  <h3 className="font-cairo font-bold text-navy-900 dark:text-cream-50 text-sm mb-1">{stage.title}</h3>
                  <p className="text-xs text-navy-500 dark:text-slate-400 font-tajawal leading-relaxed max-w-[140px]">{stage.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mt-12 text-center">
            <ButtonLink to="/search" variant="outline">
              ابدأ رحلتك الآن <ArrowLeft className="w-4 h-4" />
            </ButtonLink>
          </div>
        </div>
      </section>

      {/* ===== MEMBERS (مدمج: مميزون + جدد + أعلى توافق) ===== */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="أعضاء موثوقون"
            title={<>تعرّف على <span className="text-amber-600 font-extrabold">أعضاء يبحثون عن شريك</span></>}
            subtitle="تصفّح ملفات لأعضاء موثقين يبحثون عن علاقة جادة."
          />

          {/* تبويب الأعضاء */}
          <div className="mt-8 flex justify-center">
            <div className="inline-flex bg-cream-100 dark:bg-navy-900 rounded-2xl p-1.5 border border-cream-200/60 dark:border-navy-800">
              {[
                { key: 'featured', label: 'مميزون' },
                { key: 'new', label: 'جدد' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setMembersTab(tab.key as typeof membersTab)}
                  className={`px-5 sm:px-7 py-2.5 rounded-xl font-cairo font-bold text-sm transition-all duration-300 ${
                    membersTab === tab.key ? 'bg-white dark:bg-navy-950 text-gold-700 dark:text-gold-400 shadow-soft' : 'text-navy-500 hover:text-navy-700 dark:text-cream-200/70 dark:hover:text-cream-50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* شبكة الأعضاء */}
          <AnimatePresence mode="wait">
            <motion.div
              key={membersTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="mt-10 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5"
            >
              {membersLoading && activeMembers.length === 0 ? (
                <MemberGridSkeleton count={7} />
              ) : (
                activeMembers.slice(0, 7).map((m) => (
                  <MemberCard key={m.id} member={m} />
                ))
              )}

              {/* بطاقة "انضم إليهم" أو "استكشف المزيد" */}
              <Link
                to={isLoggedIn ? "/search" : "/register"}
                className="group rounded-2xl border-2 border-dashed border-gold-400/50 hover:border-gold-500 bg-gold-300/5 hover:bg-gold-300/10 transition-all duration-500 flex flex-col items-center justify-center p-6 min-h-[280px] text-center"
              >
                <div className="w-16 h-16 rounded-full bg-gold-gradient flex items-center justify-center mb-4 shadow-gold group-hover:scale-110 transition-transform duration-500">
                  {isLoggedIn ? <Search className="w-8 h-8 text-navy-900" /> : <UserPlus className="w-8 h-8 text-navy-900" />}
                </div>
                <h3 className="font-cairo font-bold text-navy-900 dark:text-cream-50 text-base mb-1">
                  {isLoggedIn ? 'تصفّح كافة الأعضاء' : 'انضم إليهم الآن'}
                </h3>
                <p className="text-xs text-navy-500 dark:text-slate-400 font-tajawal">
                  {isLoggedIn ? 'ابحث وفلتر حسب مواصفات الشريك' : 'ابدأ رحلتك نحو شريك الحياة'}
                </p>
              </Link>
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* ===== SECURITY HIGHLIGHT ===== */}
      <section className="py-16 lg:py-24 bg-navy-gradient relative overflow-hidden">
        <div className="absolute inset-0 pattern-islamic opacity-30" />
        <div className="absolute top-0 right-0 w-72 h-72 bg-gold-500/10 rounded-full blur-3xl" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading
                center={false}
                light
                eyebrow="الأمان أولاً"
                title={<>خصوصيتك <span className="text-gradient-gold">أمانة لدينا</span></>}
                subtitle="نستخدم أحدث تقنيات التشفير والتحقق لحماية بياناتك ومنحك تجربة آمنة تمامًا."
              />
              <div className="mt-8 grid sm:grid-cols-3 gap-4">
                {securityPoints.map((item, i) => (
                  <motion.div
                    key={item.text}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.15 }}
                    className="glass-navy rounded-2xl p-4 border border-gold-500/20 flex flex-col items-center text-center gap-3"
                  >
                    <div className={`w-12 h-12 rounded-xl ${item.bg} flex items-center justify-center flex-shrink-0`}>
                      <item.icon className={`w-6 h-6 ${item.color}`} />
                    </div>
                    <p className="text-cream-200/90 font-tajawal text-sm leading-relaxed">{item.text}</p>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* عنصر بصري: بطاقة شهادة موثوقية */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative flex justify-center"
            >
              <div className="relative w-full max-w-sm">
                {/* هالة خلفية */}
                <div className="absolute inset-0 bg-gold-500/10 rounded-[2.5rem] blur-2xl" />

                <div className="relative glass-navy rounded-[2.5rem] p-8 border border-gold-500/30 shadow-luxe text-center">
                  {/* أيقونة الدرع الكبيرة */}
                  <div className="relative inline-flex mb-6">
                    <motion.div
                      animate={{ scale: [1, 1.05, 1] }}
                      transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                      className="w-24 h-24 rounded-full bg-gold-gradient flex items-center justify-center shadow-gold"
                    >
                      <ShieldCheck className="w-12 h-12 text-navy-900" />
                    </motion.div>
                    {/* دوائر متحرّكة */}
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                      className="absolute inset-0 -m-3 rounded-full border border-dashed border-gold-500/30"
                    />
                  </div>

                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 mb-4">
                    <BadgeCheck className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-300 font-cairo font-bold text-sm">معتمد وموثوق</span>
                  </div>

                  <h3 className="font-cairo font-bold text-white text-xl mb-2">حماية بمعايير عالمية</h3>
                  <p className="text-cream-200/70 font-tajawal text-sm leading-relaxed mb-6">
                    ملتزمون بنظام حماية البيانات السعودي وأعلى معايير الأمان الرقمي لحماية معلوماتك الشخصية.
                  </p>

                  {/* شارات التحقق */}
                  <div className="flex items-center justify-center gap-4 flex-wrap">
                    {[
                      { icon: FileCheck, label: 'SSL مشفّر' },
                      { icon: Eye, label: 'مراقبة 24/7' },
                      { icon: Lock, label: 'بيانات محمية' },
                    ].map((badge) => (
                      <div key={badge.label} className="flex items-center gap-1.5 text-cream-200/60">
                        <badge.icon className="w-4 h-4 text-gold-300" />
                        <span className="text-xs font-tajawal">{badge.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ===== TESTIMONIALS (Carousel) ===== */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="قصص نجاح"
            title={<>قصص حب بدأت <span className="text-amber-600 font-extrabold">من توافق</span></>}
            subtitle="آلاف القصص السعيدة بدأت هنا. كن أنت القصة القادمة."
          />

          <div className="mt-14 max-w-3xl mx-auto">
            <div className="relative bg-white dark:bg-navy-900 rounded-3xl p-8 sm:p-12 shadow-luxe border border-cream-200/60 dark:border-navy-800 overflow-hidden">
              {/* علامة اقتباس كبيرة مزخرفة */}
              <Quote className="w-24 h-24 text-gold-300/20 absolute -top-4 -left-4" />

              <AnimatePresence mode="wait">
                <motion.div
                  key={testimonialIdx}
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.4 }}
                  className="relative z-10"
                >
                  <div className="flex gap-1 mb-4">
                    {[...Array(5)].map((_, idx) => (
                      <Star key={idx} className="w-5 h-5 fill-gold-500 text-gold-500" />
                    ))}
                  </div>

                  <p className="text-navy-700 dark:text-cream-100 font-tajawal text-lg leading-relaxed mb-8">
                    {activeTestimonial.story}
                  </p>

                  <div className="flex items-center gap-4 pt-6 border-t border-cream-200 dark:border-navy-800">
                    <div className="w-14 h-14 rounded-full bg-gold-gradient flex items-center justify-center text-navy-900 font-cairo font-bold text-xl">
                      {activeTestimonial.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-cairo font-bold text-navy-900 dark:text-cream-50 text-lg">{activeTestimonial.name}</div>
                      <div className="text-sm text-navy-500 dark:text-slate-400 font-tajawal">{activeTestimonial.city} · {activeTestimonial.duration}</div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* أزرار التنقّل */}
              <div className="flex items-center justify-between mt-8">
                <button
                  onClick={prevTestimonial}
                  className="w-11 h-11 rounded-full bg-cream-100 dark:bg-navy-800 hover:bg-gold-300/20 dark:hover:bg-gold-300/10 flex items-center justify-center transition-all duration-300 group"
                  aria-label="السابق"
                >
                  <ChevronRight className="w-5 h-5 text-navy-600 dark:text-cream-200 group-hover:text-gold-700 dark:group-hover:text-gold-400" />
                </button>

                {/* نقاط مؤشّرة */}
                <div className="flex items-center gap-2">
                  {TESTIMONIALS.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setTestimonialIdx(idx)}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        idx === testimonialIdx ? 'w-8 bg-gold-gradient' : 'w-2 bg-cream-300 dark:bg-navy-700 hover:bg-gold-300 dark:hover:bg-gold-600'
                      }`}
                      aria-label={`قصة ${idx + 1}`}
                    />
                  ))}
                </div>

                <button
                  onClick={nextTestimonial}
                  className="w-11 h-11 rounded-full bg-cream-100 dark:bg-navy-800 hover:bg-gold-300/20 dark:hover:bg-gold-300/10 flex items-center justify-center transition-all duration-300 group"
                  aria-label="التالي"
                >
                  <ChevronLeft className="w-5 h-5 text-navy-600 dark:text-cream-200 group-hover:text-gold-700 dark:group-hover:text-gold-400" />
                </button>
              </div>
            </div>

            {/* عدّاد القصص */}
            <div className="text-center mt-4 text-sm text-navy-400 dark:text-slate-400 font-tajawal">
              قصة {testimonialIdx + 1} من {TESTIMONIALS.length}
            </div>
          </div>
        </div>
      </section>

      {/* ===== CTA (خلفية ذهبية مميّزة) ===== */}
      <section className="py-16 lg:py-24">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative wave-bg rounded-[2.5rem] overflow-hidden p-10 lg:p-16 text-center shadow-luxe">
            {/* زخارف خلفية */}
            <div className="absolute inset-0 pattern-islamic opacity-20" />
            <div className="absolute -top-20 -right-20 w-72 h-72 bg-white/15 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-navy-900/10 rounded-full blur-3xl" />

            {/* قلوب متساقطة */}
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-navy-900/10"
                initial={{ y: -30, opacity: 0 }}
                animate={{ y: 400, opacity: [0, 0.5, 0] }}
                transition={{ duration: 4, repeat: Infinity, delay: i * 0.7, ease: 'easeOut' }}
                style={{ left: `${10 + i * 15}%`, top: '0%' }}
              >
                <Heart className="w-5 h-5 fill-current" />
              </motion.div>
            ))}

            <div className="relative">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-navy-900 mb-6 shadow-luxe"
              >
                <Heart className="w-8 h-8 text-gold-300 fill-gold-300" />
              </motion.div>

              <h2 className="font-cairo font-extrabold text-3xl sm:text-4xl lg:text-5xl text-navy-900 leading-tight">
                {isLoggedIn ? 'ابحث عن شريك حياتك المناسب...' : 'قلبك ينتظر شريكه...'}
              </h2>
              <p className="mt-4 text-lg text-navy-800/80 font-tajawal max-w-xl mx-auto">
                {isLoggedIn ? 'تصفّح ملفات الأعضاء المتوافقين وأرسل طلب اهتمام جاد بسهولة.' : 'انضم اليوم وابدأ رحلتك نحو شريك الحياة في بيئة آمنة وموثوقة.'}
              </p>

              <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
                {isLoggedIn ? (
                  <>
                    <ButtonLink to="/search" variant="navy" size="lg" className="shadow-luxe">
                      <Search className="w-5 h-5" /> ابحث عن شريك حياتك
                    </ButtonLink>
                    <ButtonLink to="/profile" variant="outline" size="lg" className="!border-navy-900/30 !text-navy-900 hover:!bg-navy-900/10">
                      <Heart className="w-5 h-5" /> ملفي الشخصي
                    </ButtonLink>
                  </>
                ) : (
                  <>
                    <ButtonLink to="/register" variant="navy" size="lg" className="shadow-luxe">
                      <Heart className="w-5 h-5" /> أنشئ حسابك مجانًا
                    </ButtonLink>
                    <ButtonLink to="/plans" variant="outline" size="lg" className="!border-navy-900/30 !text-navy-900 hover:!bg-navy-900/10">
                      <TrendingUp className="w-5 h-5" /> اكتشف الباقات
                    </ButtonLink>
                  </>
                )}
              </div>

              {/* عنصر ثقة إضافي */}
              <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-navy-800/70 font-tajawal">
                <span className="flex items-center gap-1.5"><BadgeCheck className="w-4 h-4" /> بدون بطاقة ائتمان</span>
                <span className="flex items-center gap-1.5"><Users className="w-4 h-4" /> +150 ألف عضو يثقون بنا</span>
                <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4" /> بيئة آمنة وموثوقة</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
