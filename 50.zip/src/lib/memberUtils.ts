/**
 * Utility functions for member record calculations and sorting.
 */

export function getMemberTimestamp(member: any): number {
  if (!member) return 0;

  // 1. Candidate date/time fields
  const candidates = [
    member.createdAt,
    member.created_at,
    member.importDate,
    member.importedAt,
    member.registeredAt,
    member.registered_at,
    member.date,
    member.lastActive,
    member.last_active,
  ];

  for (const cand of candidates) {
    if (cand) {
      if (typeof cand === 'number' && cand > 0) {
        return cand < 10000000000 ? cand * 1000 : cand;
      }
      if (typeof cand === 'string') {
        const parsed = new Date(cand).getTime();
        if (!isNaN(parsed) && parsed > 0) return parsed;
      }
      if (cand instanceof Date) {
        const parsed = cand.getTime();
        if (!isNaN(parsed) && parsed > 0) return parsed;
      }
    }
  }

  // 2. Check joinedAt string if present
  if (member.joinedAt && typeof member.joinedAt === 'string') {
    const parsed = new Date(member.joinedAt).getTime();
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }

  // 3. Fallback to ID timestamp if ID contains epoch digits like m_1740...
  if (member.id) {
    const strId = String(member.id);
    const match = strId.match(/(\d{10,13})/);
    if (match) {
      const num = parseInt(match[1], 10);
      if (!isNaN(num) && num > 1000000000) {
        return num < 10000000000 ? num * 1000 : num;
      }
    }
    const numOnly = parseInt(strId.replace(/\D/g, ''), 10);
    if (!isNaN(numOnly) && numOnly > 0) {
      return numOnly;
    }
  }

  return 0;
}

/**
 * Ensures marital status is ALWAYS returned as a proper Arabic label based on gender.
 */
export function formatMaritalStatus(status?: string, label?: string, gender?: string): string {
  const val = (label || status || '').toString().trim();
  if (!val) return 'غير محدد';

  const lower = val.toLowerCase();
  const isMale = gender === 'male' || gender === 'ذكر';

  const map: Record<string, string> = {
    single: isMale ? 'أعزب' : 'عزباء',
    divorced: isMale ? 'مطلق' : 'مطلقة',
    widow: isMale ? 'أرمل' : 'أرملة',
    widower: isMale ? 'أرمل' : 'أرملة',
    widowed: isMale ? 'أرمل' : 'أرملة',
    married: isMale ? 'متزوج' : 'متزوجة',
    'أعزب': 'أعزب',
    'عزباء': 'عزباء',
    'مطلق': 'مطلق',
    'مطلقة': 'مطلقة',
    'أرمل': 'أرمل',
    'أرملة': 'أرملة',
    'متزوج': 'متزوج',
    'متزوجة': 'متزوجة',
  };

  if (map[lower]) return map[lower];

  if (lower.includes('single')) return isMale ? 'أعزب' : 'عزباء';
  if (lower.includes('divorce')) return isMale ? 'مطلق' : 'مطلقة';
  if (lower.includes('widow')) return isMale ? 'أرمل' : 'أرملة';
  if (lower.includes('marri')) return isMale ? 'متزوج' : 'متزوجة';

  return val;
}

export interface PartnerTag {
  label: string;
  value: string;
}

export interface PartnerSummary {
  tags: PartnerTag[];
  text: string;
}

/**
 * Extracts and formats concise partner preference tags (Age, Cities, Nationality, Country, Marital)
 */
export function getPartnerSummary(member: any): PartnerSummary {
  if (!member) return { tags: [], text: '' };

  const tags: PartnerTag[] = [];

  // 1. العمر المطلوبة
  const pAgeMin = member.pAgeMin || member.partnerAgeMin;
  const pAgeMax = member.pAgeMax || member.partnerAgeMax;
  if (pAgeMin || pAgeMax) {
    if (pAgeMin && pAgeMax) {
      tags.push({ label: 'العمر', value: `${pAgeMin} - ${pAgeMax} سنة` });
    } else if (pAgeMin) {
      tags.push({ label: 'العمر', value: `من ${pAgeMin} سنة` });
    } else if (pAgeMax) {
      tags.push({ label: 'العمر', value: `حتى ${pAgeMax} سنة` });
    }
  }

  // 2. المدن المطلوبة
  const pCity = member.pCity || member.partnerCity || member.partnerCities;
  if (pCity && pCity !== 'لا يهم' && pCity !== 'غير محدد') {
    tags.push({ label: 'المدن', value: String(pCity) });
  }

  // 3. الجنسية المطلوبة
  const pNat = member.pNationalityOther || member.pNationality || member.partnerNationality;
  if (pNat && pNat !== 'لا يهم' && pNat !== 'غير محدد') {
    const displayNat = pNat === 'نفس جنسيتي' ? (member.nationality || 'نفس الجنسية') : String(pNat);
    tags.push({ label: 'الجنسية', value: displayNat });
  }

  // 4. الدولة المطلوبة
  const pCountry = member.pCountry || member.partnerCountry;
  if (pCountry && pCountry !== 'لا يهم' && pCountry !== 'غير محدد' && pCountry !== pCity) {
    tags.push({ label: 'الدولة', value: String(pCountry) });
  }

  // 5. الحالة الاجتماعية المطلوبة
  const pMarital = member.pMarital || member.partnerMarital || member.partnerMaritalStatus;
  if (pMarital && pMarital !== 'لا يهم' && pMarital !== 'غير محدد') {
    tags.push({ label: 'الحالة', value: String(pMarital) });
  }

  const text = (member.aboutPartner || member.pNotes || member.p_notes || '').toString().trim();

  return { tags, text };
}
