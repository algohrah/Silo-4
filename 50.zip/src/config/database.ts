export type DatabaseProvider = 'api' | 'local' | 'supabase';

export const DATABASE_CONFIG = {
  // الوضع الافتراضي الآن هو قاعدة البيانات المحلية (LocalStorage) لتشغيل المنصة بالكامل محلياً وبشكل مترابط وديناميكي.
  PROVIDER: ((import.meta.env.VITE_DATABASE_PROVIDER as DatabaseProvider) || 'local') as DatabaseProvider,
};
